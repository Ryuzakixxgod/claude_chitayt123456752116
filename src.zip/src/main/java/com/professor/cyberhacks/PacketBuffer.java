package com.professor.cyberhacks;

import net.minecraft.network.packet.Packet;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.Random;

public final class PacketBuffer {
    
    private PacketBuffer() {}
    
    private static final Queue<DelayedPacket> QUEUE = new ConcurrentLinkedQueue<>();
    private static final Random RAND = new Random();
    private static final int MIN_DELAY = 50;
    private static final int MAX_DELAY = 120;
    private static final int MAX_QUEUE_SIZE = 64;
    
    private record DelayedPacket(Packet packet, long sendTime) {}
    
    public static void tick() {
        if (QUEUE.isEmpty()) return;
        var nh = MC.networkHandler();
        if (nh == null) return;
        
        long now = System.currentTimeMillis();
        while (true) {
            DelayedPacket head = QUEUE.peek();
            if (head == null || head.sendTime() > now) break;
            QUEUE.poll();
            nh.sendPacket(head.packet());
            DebugLogger.log("BUFFER", "SEND_DELAYED", 
                head.packet().getClass().getSimpleName() + " after " + (now - head.sendTime()) + "ms delay");
        }
    }
    
    public static void add(Packet packet) {
        if (QUEUE.size() >= MAX_QUEUE_SIZE) {
            QUEUE.poll();
        }
        
        int delay = MIN_DELAY + RAND.nextInt(MAX_DELAY - MIN_DELAY + 1);
        long sendTime = System.currentTimeMillis() + delay;
        QUEUE.offer(new DelayedPacket(packet, sendTime));
        
        DebugLogger.log("BUFFER", "QUEUED", 
            packet.getClass().getSimpleName() + " delay=" + delay + "ms");
    }
    
    public static boolean shouldSend(Packet packet) {
        return true;
    }
    
    public static int queueSize() {
        return QUEUE.size();
    }
    
    public static void clear() {
        QUEUE.clear();
    }
}
