package com.professor.cyberhacks;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public final class DebugLogger {
    private static final String LOG_FILE = "cyberhacks_debug.log";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private DebugLogger() {}
    public static void log(String module, String event, String details) {
        String line = String.format("[%s] [%s] %s | %s", LocalDateTime.now().format(FMT), module, event, details);
        System.out.println("[CYBERHACKS] " + line);
        try (BufferedWriter w = new BufferedWriter(new FileWriter(LOG_FILE, true))) { w.write(line); w.newLine(); } catch (IOException ignored) {}
    }
    public static void logRotation(float yawDelta, float pitchDelta, double gcd) {
        log("ROTATION", "DELTA", String.format("yaw=%.4f pitch=%.4f gcd=%.6f smooth=%.3f", yawDelta, pitchDelta, gcd, RotationManager.getSmoothing()));
    }
    public static void logPacket(net.minecraft.network.packet.Packet<?> p, int delay) {
        log("PACKET", p.getClass().getSimpleName(), "delay=" + delay + "ms");
    }
}
