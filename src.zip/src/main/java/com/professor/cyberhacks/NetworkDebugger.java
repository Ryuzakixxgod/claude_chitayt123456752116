package com.professor.cyberhacks;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.LongAdder;

public final class NetworkDebugger {
    
    private static final String LOG_FILE = "network_debug.log";
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    private static final long PACKET_FLUSH_INTERVAL_MS = 1_000L;
    private static final boolean CONSOLE_ENABLED = Boolean.getBoolean("ryuzaki.netdebug.console");
    private static final Map<String, LongAdder> PACKET_COUNTS = new ConcurrentHashMap<>();

    private static volatile boolean enabled = Boolean.getBoolean("ryuzaki.netdebug");
    private static volatile long nextPacketFlush = System.currentTimeMillis() + PACKET_FLUSH_INTERVAL_MS;
    private static BufferedWriter writer;
    
    private NetworkDebugger() {}

    public static boolean isEnabled() {
        return enabled;
    }

    public static void setEnabled(boolean enabled) {
        NetworkDebugger.enabled = enabled;
        if (!enabled) flushPacketSummary(true);
    }
    
    public static void log(String module, String event, String details) {
        if (!enabled) return;
        
        String line = String.format("[%s] [%s] %s | %s", 
            LocalDateTime.now().format(FMT), module, event, details);

        writeLine(line);
    }
    
    public static void log(String module, String message) {
        log(module, "INFO", message);
    }
    
    public static void logConnectionStatus() {
        var p = MC.player();
        var nh = MC.networkHandler();
        if (p == null || nh == null) {
            log("CONN", "NOT_IN_GAME");
            return;
        }
        
        int ping = MC.getPing();
        float tps = MC.getTps();
        float cooldown = MC.attackCooldown();
        boolean canAttack = MC.canAttack();
        
        log("CONN", "STATUS", String.format(
            "ping=%dms tps=%.1f cooldown=%.2f canAttack=%s",
            ping, tps, cooldown, canAttack));
    }
    
    public static void logPacketDirection(boolean outbound, String packetClass, int size) {
        if (!enabled) return;

        String dir = outbound ? "OUT" : "IN";
        String key = dir + " " + packetClass;
        PACKET_COUNTS.computeIfAbsent(key, ignored -> new LongAdder()).increment();
        flushPacketSummary(false);
    }

    private static void flushPacketSummary(boolean force) {
        if (!enabled && !force) return;

        long now = System.currentTimeMillis();
        if (!force && now < nextPacketFlush) return;

        synchronized (NetworkDebugger.class) {
            now = System.currentTimeMillis();
            if (!force && now < nextPacketFlush) return;
            nextPacketFlush = now + PACKET_FLUSH_INTERVAL_MS;

            StringBuilder summary = new StringBuilder(128);
            for (Map.Entry<String, LongAdder> entry : PACKET_COUNTS.entrySet()) {
                long count = entry.getValue().sumThenReset();
                if (count <= 0) continue;
                if (summary.length() > 0) summary.append(", ");
                summary.append(entry.getKey()).append('=').append(count);
            }

            if (summary.length() > 0) {
                writeLine(String.format("[%s] [PACKET] SUMMARY | %s",
                    LocalDateTime.now().format(FMT), summary));
            }
        }
    }

    private static synchronized void writeLine(String line) {
        if (CONSOLE_ENABLED) System.out.println("[NETDEBUG] " + line);

        try {
            if (writer == null) writer = new BufferedWriter(new FileWriter(LOG_FILE, true));
            writer.write(line);
            writer.newLine();
            writer.flush();
        } catch (IOException ignored) {}
    }
}
