package com.professor.cyberhacks;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.combat.*;

public class CyberHacksModule implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        MC.set(MinecraftClient.getInstance());

        // Регистрация модулей
        ModuleManager.getModule(KillAuraModule.class);
        ModuleManager.getModule(TriggerBotModule.class);
        ModuleManager.getModule(AimAssistModule.class);
        ModuleManager.getModule(AutoTotemModule.class);

        System.out.println("[CyberHacks] Модули зарегистрированы");

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (!MC.inGame()) return;

            RotationManager.updateDynamicParameters();
            PacketQueue.tick();
            PacketBuffer.tick();
            NetworkDebugger.logConnectionStatus();
        });

        RotationManager.setProfile(RotationManager.AnticheatProfile.GENERIC_SAFE);

        System.out.println("[CyberHacks] Инициализация завершена. Клавиши: H=KillAura, J=TriggerBot, K=AimAssist, L=AutoTotem");
    }
}