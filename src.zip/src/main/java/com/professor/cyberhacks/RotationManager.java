package com.professor.cyberhacks;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
public final class RotationManager {
    private RotationManager() {}

    // Серверная ротация — отправляется на сервер
    private static float serverYaw = 0f;
    private static float serverPitch = 0f;

    // Клиентская (визуальная) ротация
    private static float currentYaw = 0f;
    private static float currentPitch = 0f;
    private static float prevYaw = 0f;
    private static float prevPitch = 0f;

    // Параметры
    private static double gcd = 0.0;
    private static long lastGcdTick = 0;
    private static float smooth = 0.90f;
    private static float noiseYaw = 0.18f;
    private static float noisePitch = 0.15f;
    private static float maxAccel = 35.0f;
    private static float bezierMin = 0.80f;
    private static float bezierMax = 0.95f;

    // Состояние: ROTATING — идём к цели, IDLE — возвращаемся или стоим
    private static boolean isRotating = false;
    private static long rotationStartTime = 0L;

    public enum AnticheatProfile { FUNTIME_POLAR, HOLYWORLD_AI, REALLYWORLD_INTAVE, DONUTSMP_CUSTOM, WELLMINE_GRIM_VULCAN, GENERIC_GRIM, GENERIC_VULCAN, GENERIC_INTAVE, GENERIC_POLAR, GENERIC_SLOTHAC, GENERIC_SAFE }

    public static void setProfile(AnticheatProfile profile) {
        switch (profile) {
            case FUNTIME_POLAR, GENERIC_POLAR -> { smooth = 0.81f; noiseYaw = 0.34f; noisePitch = 0.27f; maxAccel = 44.0f; bezierMin = 0.72f; bezierMax = 0.89f; }
            case HOLYWORLD_AI ->                { smooth = 0.74f; noiseYaw = 0.41f; noisePitch = 0.33f; maxAccel = 49.0f; bezierMin = 0.65f; bezierMax = 0.92f; }
            case REALLYWORLD_INTAVE, GENERIC_INTAVE -> { smooth = 0.85f; noiseYaw = 0.26f; noisePitch = 0.19f; maxAccel = 46.0f; bezierMin = 0.75f; bezierMax = 0.88f; }
            case DONUTSMP_CUSTOM ->              { smooth = 0.79f; noiseYaw = 0.31f; noisePitch = 0.24f; maxAccel = 50.0f; bezierMin = 0.68f; bezierMax = 0.91f; }
            case WELLMINE_GRIM_VULCAN, GENERIC_GRIM -> { smooth = 0.68f; noiseYaw = 0.22f; noisePitch = 0.18f; maxAccel = 41.0f; bezierMin = 0.70f; bezierMax = 0.84f; }
            case GENERIC_VULCAN ->              { smooth = 0.77f; noiseYaw = 0.28f; noisePitch = 0.21f; maxAccel = 45.0f; bezierMin = 0.71f; bezierMax = 0.87f; }
            case GENERIC_SLOTHAC ->             { smooth = 0.82f; noiseYaw = 0.30f; noisePitch = 0.25f; maxAccel = 47.0f; bezierMin = 0.69f; bezierMax = 0.90f; }
            case GENERIC_SAFE ->                { smooth = 0.90f; noiseYaw = 0.18f; noisePitch = 0.15f; maxAccel = 35.0f; bezierMin = 0.80f; bezierMax = 0.95f; }
        }
        gcd = 0.0;
        DebugLogger.log("ROTATION", "PROFILE", "Switched to " + profile.name());
    }

    public static void updateDynamicParameters() {
        if (!MC.inGame()) return;
        var player = MC.player();
        if (player == null) return;

        // Сохраняем предыдущую ротацию для интерполяции
        prevYaw = currentYaw;
        prevPitch = currentPitch;

        // Синхронизируем если не вращаемся
        if (!isRotating) {
            currentYaw = player.getYaw();
            currentPitch = player.getPitch();
            serverYaw = currentYaw;
            serverPitch = currentPitch;
        }

        int ping = MC.getPing(); float tps = MC.getTps();
        smooth = MathHelper.clamp(smooth + ping * 0.0012f + (20.0f - tps) * 0.18f, smooth - 0.12f, smooth + 0.14f);
        long tick = MC.tickCounter();
        if (tick - lastGcdTick > 700) { gcd = calculateGCD(MC.sensitivity()); lastGcdTick = tick; }
    }

    /**
     * Плавное вращение к точке — как в RockReady.
     * Поворачивает и визуально, и серверную ротацию.
     */
    public static void rotateTo(Vec3d targetPos, boolean silent) {
        var player = MC.player();
        if (player == null) return;

        Vec3d eyes = player.getEyePos();
        Vec3d delta = targetPos.subtract(eyes);
        double dist = delta.length();
        if (dist < 1e-6) return;

        float targetYaw   = (float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0f;
        float targetPitch = (float) -Math.toDegrees(Math.asin(MathHelper.clamp(delta.y / dist, -1.0, 1.0)));
        targetPitch = MathHelper.clamp(targetPitch, -90.0f, 90.0f);

        // Округляем до GCD
        if (gcd == 0.0) gcd = calculateGCD(MC.sensitivity());
        targetYaw   = (float) (Math.round(targetYaw   / gcd) * gcd);
        targetPitch = (float) (Math.round(targetPitch / gcd) * gcd);

        // Интерполяция
        float deltaYaw   = MathHelper.wrapDegrees(targetYaw   - currentYaw);
        float deltaPitch = MathHelper.wrapDegrees(targetPitch - currentPitch);

        float t = cubicBezier(bezierMin + player.getWorld().random.nextFloat() * (bezierMax - bezierMin));
        currentYaw   += deltaYaw   * t + (float) (player.getWorld().random.nextGaussian() * noiseYaw);
        currentPitch += deltaPitch * t + (float) (player.getWorld().random.nextGaussian() * noisePitch);

        // Ограничение ускорения
        float wrappedYaw = MathHelper.wrapDegrees(currentYaw - player.getYaw());
        if (Math.abs(wrappedYaw) > maxAccel) {
            currentYaw = player.getYaw() + Math.signum(deltaYaw) * maxAccel;
        }

        currentPitch = MathHelper.clamp(currentPitch, -90.0f, 90.0f);

        // Серверная ротация — плавно приближаем
        serverYaw   = currentYaw;
        serverPitch = currentPitch;

        // Визуальная ротация — применяем к игроку
        player.setYaw(currentYaw);
        player.setPitch(currentPitch);

        isRotating = true;
    }

    /**
     * Сброс вращения — возврат к реальной ротации игрока.
     */
    public static void resetRotation() {
        isRotating = false;
        var player = MC.player();
        if (player != null) {
            currentYaw = player.getYaw();
            currentPitch = player.getPitch();
            serverYaw = currentYaw;
            serverPitch = currentPitch;
        }
    }

    /**
     * Проверка: вращаемся ли мы сейчас.
     */
    public static boolean isRotating() {
        return isRotating;
    }

    /**
     * Серверная ротация — для отправки на сервер через Mixin.
     */
    public static float getServerYaw() { return serverYaw; }
    public static float getServerPitch() { return serverPitch; }

    /**
     * Визуальная ротация для рендера (с интерполяцией).
     */
    public static float getVisualYaw(float partialTicks) {
        return prevYaw + (currentYaw - prevYaw) * partialTicks;
    }
    public static float getVisualPitch(float partialTicks) {
        float pitch = prevPitch + (currentPitch - prevPitch) * partialTicks;
        return MathHelper.clamp(pitch, -85.0f, 85.0f);
    }

    public static float getSmoothing() { return smooth; }

    private static float cubicBezier(float t) { float u = 1.0f - t; return t * t * (3.0f - 2.0f * t); }

    private static double calculateGCD(double sens) {
        double f = sens * 0.6 * 8.0E-4 * (180.0 / Math.PI) * 2.0;
        return f - Math.floor(f / 1.0E-4) * 1.0E-4;
    }
}
