package com.professor.cyberhacks;
import it.unimi.dsi.fastutil.objects.Object2LongLinkedOpenHashMap;
import net.minecraft.network.packet.Packet;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
public final class PacketQueue {
    private static final int MAX_QUEUE_SIZE = 64;
    private static final Queue<QueuedPacket> QUEUE = new ConcurrentLinkedQueue<>();
    private static final Object2LongLinkedOpenHashMap<Packet<?>> SEEN = new Object2LongLinkedOpenHashMap<>();
    private record QueuedPacket(Packet<?> packet, long sendTime) {}
    private PacketQueue() {}
    public static void add(Packet<?> packet, int minDelay, int maxDelay) {
        if (QUEUE.size() >= MAX_QUEUE_SIZE) QUEUE.poll();
        long now = System.currentTimeMillis();
        if (now - SEEN.getOrDefault(packet, 0L) < 50) return;
        SEEN.put(packet, now);
        long delay = EntropyManager.randInt(minDelay, maxDelay) + adaptiveJitter();
        QUEUE.offer(new QueuedPacket(packet, now + delay));
        DebugLogger.logPacket(packet, (int) delay);
    }
    public static void tick() {
        if (QUEUE.isEmpty()) return;
        var nh = MC.networkHandler(); if (nh == null) return;
        long now = System.currentTimeMillis();
        QueuedPacket head = QUEUE.peek();
        if (head != null && head.sendTime() <= now) nh.sendPacket(QUEUE.poll().packet());
    }
    public static int size() { return QUEUE.size(); }
    public static void clear() { QUEUE.clear(); }
    private static int adaptiveJitter() {
        int ping = MC.getPing(); float tps = MC.getTps();
        return (int) (ping * 0.42 + (20.0f - tps) * 15 + EntropyManager.randInt(0, 28));
    }
}
