package com.professor.cyberhacks;
import net.minecraft.util.math.Vec3d;
import java.util.Random;
public final class EntropyManager {
    private EntropyManager() {}
    private static final Random RAND = new Random();
    public static boolean shouldMissClick() {
        double u = RAND.nextDouble();
        return Math.pow(-Math.log(1 - u), 1.2) * 0.11 > 0.89;
    }
    public static long getNextAttackDelay(double baseCPS) {
        return (long) (1000.0 / baseCPS * (0.92 + RAND.nextDouble() * 0.26));
    }
    public static int randInt(int min, int max) { return min + RAND.nextInt(max - min + 1); }
    public static float randFloat(float min, float max) { return min + RAND.nextFloat() * (max - min); }
    public static double gaussian(double stdDev) { return RAND.nextGaussian() * stdDev; }

    /**
     * Добавляет entropy-шум к точке прицеливания.
     * Шум меньше по вертикали (игрок логичнее целится в тело).
     */
    public static Vec3d perturbAimPoint(Vec3d base, Object target) {
        double offX = gaussian(0.045);
        double offY = gaussian(0.025);
        double offZ = gaussian(0.045);
        return base.add(offX, offY, offZ);
    }
}
