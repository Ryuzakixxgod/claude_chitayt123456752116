package com.professor.cyberhacks;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import java.util.Comparator;

public final class TargetUtils {
    private TargetUtils() {}

    public enum Priority { DISTANCE, ANGLE, HEALTH }

    public static LivingEntity findBestTarget(double reach, double fov, Priority priority) {
        var player = MC.player();
        var world = MC.world();
        if (player == null || world == null) return null;

        Vec3d eyePos = player.getEyePos();
        Vec3d look = player.getRotationVec(1.0f);

        LivingEntity best = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity le) || le == player || !le.isAlive()) continue;
            double dist = le.distanceTo(player);
            if (dist > reach) continue;

            if (fov > 0 && fov < 180) {
                Vec3d to = le.getEyePos().subtract(eyePos).normalize();
                double dot = MathHelper.clamp(look.dotProduct(to), -1, 1);
                if (Math.toDegrees(Math.acos(dot)) > fov) continue;
            }

            double score = switch (priority) {
                case ANGLE -> {
                    Vec3d to = le.getEyePos().subtract(eyePos).normalize();
                    yield Math.toDegrees(Math.acos(MathHelper.clamp(look.dotProduct(to), -1, 1)));
                }
                case HEALTH -> le.getHealth();
                default -> dist;
            };

            if (score < bestScore) {
                bestScore = score;
                best = le;
            }
        }
        return best;
    }

    public static LivingEntity raycastTarget(double maxDist) {
        var player = MC.player();
        var world = MC.world();
        if (player == null || world == null) return null;

        Vec3d dir = player.getRotationVec(1.0f);
        Vec3d start = player.getEyePos();
        HitResult hit = world.raycast(new RaycastContext(
                start,
                start.add(dir.multiply(maxDist)),
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                player
        ));

        if (hit instanceof EntityHitResult ehr && ehr.getEntity() instanceof LivingEntity le
                && le != player && le.isAlive()) {
            return le;
        }
        return null;
    }

    public static double angleTo(Entity viewer, LivingEntity target) {
        Vec3d look = viewer.getRotationVec(1.0f);
        Vec3d to = target.getEyePos().subtract(viewer.getEyePos()).normalize();
        return Math.toDegrees(Math.acos(MathHelper.clamp(look.dotProduct(to), -1.0, 1.0)));
    }
}