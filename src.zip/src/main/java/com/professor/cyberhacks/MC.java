package com.professor.cyberhacks;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.network.packet.Packet;

public final class MC {

    private MC() {}

    // Метод, который вызывается из CyberHacksModule и RyuzakiClient
    public static void set(MinecraftClient client) {
        // Ничего не сохраняем — всегда берём свежий экземпляр
    }

    private static MinecraftClient getClient() {
        return MinecraftClient.getInstance();
    }

    public static MinecraftClient mc() {
        return getClient();
    }

    public static ClientPlayerEntity player() {
        return getClient().player;
    }

    public static ClientWorld world() {
        return getClient().world;
    }

    public static ClientPlayNetworkHandler networkHandler() {
        return getClient().getNetworkHandler();
    }

    public static int getPing() {
        ClientPlayerEntity p = player();
        ClientPlayNetworkHandler nh = networkHandler();
        if (p == null || nh == null) return 0;
        var entry = nh.getPlayerListEntry(p.getUuid());
        return entry != null ? entry.getLatency() : 0;
    }

    public static float getTps() {
        ClientWorld w = world();
        return w != null ? w.getTickManager().getTickRate() : 20.0f;
    }

    // Убрали tickCounter полностью — заменяем на простой счётчик
    private static long simpleTick = 0;
    public static long tickCounter() {
        return simpleTick++;
    }

    public static double sensitivity() {
        return getClient().options != null ? getClient().options.getMouseSensitivity().getValue() : 0.0;
    }

    public static boolean inGame() {
        return player() != null && world() != null;
    }

    public static void sendPacket(Packet<?> packet) {
        var nh = networkHandler();
        if (nh != null) nh.sendPacket(packet);
    }

    public static boolean canAttack() {
        var p = player();
        return p != null && p.getAttackCooldownProgress(0.0f) >= 1.0f;
    }

    public static float attackCooldown() {
        var p = player();
        return p != null ? p.getAttackCooldownProgress(0.0f) : 1.0f;
    }

    public static float attackSpeed() {
        var p = player();
        if (p == null) return 4.0f;
        var attr = p.getAttributeInstance(EntityAttributes.ATTACK_SPEED);
        return attr != null ? (float) attr.getValue() : 4.0f;
    }
}