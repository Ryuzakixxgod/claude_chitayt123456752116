package rich.screens.loading;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import rich.util.render.Render2D;
import rich.util.render.font.Font;
import rich.util.render.font.Fonts;

public class Loading {

    private static Loading instance;

    private static final float FIXED_GUI_SCALE = 2.0f;

    private static final String[] LOADING_TEXTS = {
            "Запуск паста клиент",
            "Панчан ответь",
            "Панчан где связь",
            "Панчан молодец"
    };

    private static final long TEXT_DISPLAY_DURATION   = 2200L;
    private static final long LAST_TEXT_DISPLAY_DURATION = 2500L;
    private static final long TEXT_TRANSITION_DURATION = 400L;
    private static final float ZOOM_LEVEL = 1.08f;

    private float animatedProgress = 0f;
    private float targetProgress   = 0f;
    private float pulseTime        = 0f;
    private long  lastRenderTime   = 0L;
    private long  startTime        = 0L;
    private boolean initialized    = false;

    private int   currentTextIndex  = 0;
    private float currentTextOffsetY = 0f;
    private float currentTextAlpha   = 1f;
    private float newTextOffsetY     = -12f;
    private float newTextAlpha       = 0f;
    private long  lastTextChangeTime = 0L;
    private boolean isTransitioning  = false;
    private long  transitionStartTime = 0L;

    private float backgroundAlpha = 0f;
    private float contentAlpha    = 0f;
    private boolean isFadingOut   = false;
    private boolean readyToClose  = false;

    private boolean resourcesLoaded = false;
    private boolean allTextsShown   = false;
    private long    lastTextShownTime = 0L;

    private final Particle[] particles = new Particle[40];
    private float progressGlow = 0f;

    public Loading() {
        instance = this;
        this.startTime = Util.getMeasuringTimeMs();
        this.lastTextChangeTime = this.startTime;
        initParticles();
    }

    public static Loading getInstance() {
        if (instance == null) instance = new Loading();
        return instance;
    }

    private void initParticles() {
        for (int i = 0; i < particles.length; i++) particles[i] = new Particle();
    }

    private static class Particle {
        float x, y, speed, size, alpha, drift;
        Particle() { reset(true); }
        void reset(boolean randomY) {
            x     = (float)(Math.random() * 2000);
            y     = randomY ? (float)(Math.random() * 1200) : 1200 + (float)(Math.random() * 100);
            speed = 8f + (float)(Math.random() * 25f);
            size  = 1f + (float)(Math.random() * 2.5f);
            alpha = 0.08f + (float)(Math.random() * 0.2f);
            drift = -15f + (float)(Math.random() * 30f);
        }
        void update(float dt) {
            y -= speed * dt;
            x += drift * dt;
            if (y < -20) reset(false);
        }
    }

    private int getFixedScaledWidth() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null) return 960;
        return (int) Math.ceil((double) mc.getWindow().getFramebufferWidth() / FIXED_GUI_SCALE);
    }

    private int getFixedScaledHeight() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.getWindow() == null) return 540;
        return (int) Math.ceil((double) mc.getWindow().getFramebufferHeight() / FIXED_GUI_SCALE);
    }

    // ── Вызывается из MixinSplashOverlay ─────────────────────────────
    public void render(DrawContext context, int width, int height, float opacity) {
        long currentTime = Util.getMeasuringTimeMs();

        if (!initialized) {
            lastRenderTime = currentTime;
            initialized = true;
        }

        float deltaTime = MathHelper.clamp((currentTime - lastRenderTime) / 1000f, 0.001f, 0.1f);
        lastRenderTime = currentTime;

        updateAnimations(deltaTime, currentTime);

        int fixedWidth  = getFixedScaledWidth();
        int fixedHeight = getFixedScaledHeight();

        Render2D.beginOverlay(context);

        // Фон
        Render2D.backgroundImage(backgroundAlpha * opacity, ZOOM_LEVEL);
        float overlayAlpha = backgroundAlpha * opacity * 0.3f;
        Render2D.rect(0, 0, fixedWidth, fixedHeight,
                withAlpha(0xFF000000, (int)(overlayAlpha * 255)), 0);

        float finalContentAlpha = contentAlpha * opacity;

        if (finalContentAlpha > 0.001f) {
            renderParticles(fixedWidth, fixedHeight, finalContentAlpha, deltaTime);
            renderLogo(context, fixedWidth, fixedHeight, finalContentAlpha);
            renderSubtitle(context, fixedWidth, fixedHeight, finalContentAlpha);
            renderProgressBar(context, fixedWidth, fixedHeight, finalContentAlpha);
            renderLoadingText(context, fixedWidth, fixedHeight, finalContentAlpha);
            renderBottomInfo(context, fixedWidth, fixedHeight, finalContentAlpha);
        }

        Render2D.endOverlay();
    }

    // ── Анимации ──────────────────────────────────────────────────────
    private void updateAnimations(float deltaTime, long currentTime) {
        pulseTime += deltaTime;
        animatedProgress = MathHelper.lerp(deltaTime * 5f, animatedProgress, targetProgress);
        progressGlow += deltaTime * 3f;

        backgroundAlpha = MathHelper.lerp(deltaTime * 4f, backgroundAlpha, 1f);
        if (backgroundAlpha > 0.99f) backgroundAlpha = 1f;

        if (!isFadingOut) {
            contentAlpha = MathHelper.lerp(deltaTime * 2.5f, contentAlpha, 1f);
            if (contentAlpha > 0.99f) contentAlpha = 1f;
        } else {
            contentAlpha -= deltaTime * 1.8f;
            if (contentAlpha < 0f) { contentAlpha = 0f; readyToClose = true; }
        }

        if (!isFadingOut) updateTextAnimation(currentTime, deltaTime);

        if (allTextsShown && resourcesLoaded && !isFadingOut) {
            if (currentTime - lastTextShownTime >= LAST_TEXT_DISPLAY_DURATION)
                isFadingOut = true;
        }
    }

    private void updateTextAnimation(long currentTime, float deltaTime) {
        if (allTextsShown) return;

        if (!isTransitioning) {
            if (currentTextIndex >= LOADING_TEXTS.length - 1) {
                if (!allTextsShown) { allTextsShown = true; lastTextShownTime = currentTime; }
                return;
            }
            if (currentTime - lastTextChangeTime >= TEXT_DISPLAY_DURATION) {
                isTransitioning = true;
                transitionStartTime = currentTime;
            }
        }

        if (isTransitioning) {
            float rawProgress = MathHelper.clamp(
                    (float)(currentTime - transitionStartTime) / TEXT_TRANSITION_DURATION, 0f, 1f);
            float eased = easeOutCubic(rawProgress);

            currentTextOffsetY = 14f * eased;
            currentTextAlpha   = MathHelper.clamp(1f - eased * 1.5f, 0f, 1f);
            newTextOffsetY     = -12f * (1f - eased);
            newTextAlpha       = MathHelper.clamp(eased * 1.3f, 0f, 1f);

            if (rawProgress >= 1f) {
                isTransitioning = false;
                currentTextIndex++;
                currentTextOffsetY = 0f; currentTextAlpha = 1f;
                newTextOffsetY = -12f;   newTextAlpha = 0f;
                lastTextChangeTime = currentTime;
                if (currentTextIndex >= LOADING_TEXTS.length - 1) {
                    allTextsShown = true;
                    lastTextShownTime = currentTime;
                }
            }
        }
    }

    // ── Рендер ────────────────────────────────────────────────────────
    private void renderParticles(int width, int height, float opacity, float dt) {
        for (Particle p : particles) {
            p.update(dt);
            int alpha = (int)(p.alpha * opacity * 255);
            if (alpha <= 0) continue;
            Render2D.rect(p.x, p.y, p.size, p.size, withAlpha(0xFFFFFFFF, alpha), p.size / 2f);
        }
    }

    private void renderLogo(DrawContext ctx, int width, int height, float opacity) {
        float centerX = width / 2f;
        float centerY = height / 2f - 40;
        int textAlpha = (int)(opacity * 255);
        float breathe = (float) Math.sin(pulseTime * 1.2f) * 1.5f;
        float fontSize = 44f;

        // Защита от NPE — проверяем Fonts.ICONS
        Font icons = null;
        try { icons = Fonts.ICONS; } catch (Exception ignored) {}

        if (icons != null) {
            String icon = "A";
            float iconW = icons.getWidth(icon, fontSize);
            float iconH = icons.getHeight(fontSize);
            float iconX = centerX - iconW / 2f;
            float iconY = centerY - iconH / 2f + breathe;

            float glowPulse = 0.4f + 0.2f * (float) Math.sin(pulseTime * 1.5f);
            icons.draw(icon, iconX, iconY + 3, fontSize, withAlpha(0xFFFF7276, (int)(textAlpha * glowPulse)));
            icons.draw(icon, iconX + 2, iconY + 2, fontSize, withAlpha(0xFF000000, textAlpha / 3));
            icons.draw(icon, iconX, iconY, fontSize, withAlpha(0xFFFFFFFF, textAlpha));
        } else {
            // Fallback — ванильный рендерер
            float glowPulse = 0.4f + 0.2f * (float) Math.sin(pulseTime * 1.5f);
            drawTextCentered(ctx, "R", centerX, centerY + breathe + 3, withAlpha(0xFFFF7276, (int)(textAlpha * glowPulse)));
            drawTextCentered(ctx, "R", centerX + 2, centerY + breathe + 2, withAlpha(0xFF000000, textAlpha / 3));
            drawTextCentered(ctx, "R", centerX, centerY + breathe, withAlpha(0xFFFFFFFF, textAlpha));
        }
    }

    private void renderSubtitle(DrawContext ctx, int width, int height, float opacity) {
        float centerX = width / 2f;
        float subtitleY = height / 2f - 8;
        int alpha = (int)(opacity * 180);
        String subtitle = "R Y U Z A K I";
        float lineW = 30, gap = 8;
        float lineY = subtitleY + 4f;
        int lineColor = withAlpha(0xFFFF7276, (int)(opacity * 40));
        Render2D.rect(centerX - 55 - gap - lineW, lineY, lineW, 0.5f, lineColor, 0);
        Render2D.rect(centerX + 55 + gap, lineY, lineW, 0.5f, lineColor, 0);

        Font bold = Fonts.BOLD;
        if (bold != null) {
            float w = bold.getWidth(subtitle, 9f);
            bold.draw(subtitle, centerX - w / 2f, subtitleY, 9f, withAlpha(0xFFFFFFFF, alpha));
        } else {
            drawTextCentered(ctx, subtitle, centerX, subtitleY, withAlpha(0xFFFFFFFF, alpha));
        }
    }

    private void renderProgressBar(DrawContext ctx, int width, int height, float opacity) {
        float centerX = width / 2f;
        float barY = height / 2f + 12;
        float barW = 180, barH = 3;
        float barX = centerX - barW / 2f;

        Render2D.rect(barX, barY, barW, barH, withAlpha(0xFFFFFFFF, (int)(opacity * 60)), 1.5f);

        if (animatedProgress > 0) {
            float filledW = barW * MathHelper.clamp(animatedProgress, 0f, 1f);
            int a1 = (int)(opacity * 200), a2 = (int)(opacity * 140);
            Render2D.gradientRect(barX, barY, filledW, barH,
                    new int[]{ withAlpha(0xFFFF7276, a1), withAlpha(0xFFFF9A76, a2),
                            withAlpha(0xFFFF7276, a1), withAlpha(0xFFFF9A76, a2) }, 1.5f);

            float glowPos = (float)((progressGlow * 0.3f) % 1.0);
            float glowX = barX + filledW * glowPos;
            float glowW = Math.min(20, barX + filledW - glowX);
            if (glowW > 0)
                Render2D.rect(glowX, barY, glowW, barH, withAlpha(0xFFFFFFFF, (int)(opacity * 80)), 1.5f);
        }

        String pct = (int)(animatedProgress * 100) + "%";
        Font bold = Fonts.BOLD;
        if (bold != null) {
            bold.draw(pct, barX + barW + 8, barY - 1, 6f, withAlpha(0xFFFFFFFF, (int)(opacity * 120)));
        } else {
            drawText(ctx, pct, barX + barW + 8, barY - 1, withAlpha(0xFFFFFFFF, (int)(opacity * 120)));
        }
    }

    private void renderLoadingText(DrawContext ctx, int width, int height, float opacity) {
        float baseY = height / 2f + 30;
        float centerX = width / 2f;
        Font font = Fonts.REGULARNEW;

        if (currentTextAlpha > 0.01f && currentTextIndex < LOADING_TEXTS.length) {
            String text = LOADING_TEXTS[currentTextIndex];
            int alpha = (int)(opacity * currentTextAlpha * 220);
            if (font != null) {
                float w = font.getWidth(text, 10f);
                font.draw(text, centerX - w / 2f, baseY + currentTextOffsetY, 10f, withAlpha(0xFFFFFFFF, alpha));
            } else {
                drawTextCentered(ctx, text, centerX, baseY + currentTextOffsetY, withAlpha(0xFFFFFFFF, alpha));
            }
        }

        if (isTransitioning && newTextAlpha > 0.01f) {
            int nextIndex = currentTextIndex + 1;
            if (nextIndex < LOADING_TEXTS.length) {
                String text = LOADING_TEXTS[nextIndex];
                int alpha = (int)(opacity * newTextAlpha * 220);
                if (font != null) {
                    float w = font.getWidth(text, 10f);
                    font.draw(text, centerX - w / 2f, baseY + newTextOffsetY, 10f, withAlpha(0xFFFFFFFF, alpha));
                } else {
                    drawTextCentered(ctx, text, centerX, baseY + newTextOffsetY, withAlpha(0xFFFFFFFF, alpha));
                }
            }
        }
    }

    private void renderBottomInfo(DrawContext ctx, int width, int height, float opacity) {
        float y = height - 20;
        int alpha = (int)(opacity * 50);
        Font bold = Fonts.BOLD;

        String version = "Ryuzaki · 1.21.4";
        String copyright = "Ryuzaki";

        if (bold != null) {
            bold.draw(version, 15, y, 6f, withAlpha(0xFFFFFFFF, alpha));
            float cpW = bold.getWidth(copyright, 6f);
            bold.draw(copyright, width - cpW - 15, y, 6f, withAlpha(0xFFFFFFFF, alpha));
        } else {
            drawText(ctx, version, 15, y, withAlpha(0xFFFFFFFF, alpha));
            int cpW = MinecraftClient.getInstance().textRenderer.getWidth(copyright);
            drawText(ctx, copyright, width - cpW - 15, y, withAlpha(0xFFFFFFFF, alpha));
        }

        if (!allTextsShown) {
            int dotCount = ((int)(pulseTime * 2f)) % 4;
            String dots = ".".repeat(dotCount);
            if (!dots.isEmpty()) {
                if (bold != null) {
                    float dotsW = bold.getWidth("...", 6f);
                    bold.draw(dots, width / 2f - dotsW / 2f, y, 6f, withAlpha(0xFFFF7276, (int)(opacity * 80)));
                } else {
                    drawTextCentered(ctx, dots, width / 2f, y, withAlpha(0xFFFF7276, (int)(opacity * 80)));
                }
            }
        }
    }

    // ── Утилиты ───────────────────────────────────────────────────────
    private void drawText(DrawContext ctx, String text, float x, float y, int color) {
        ctx.drawText(MinecraftClient.getInstance().textRenderer,
                Text.literal(text), (int)x, (int)y, color, false);
    }

    private void drawTextCentered(DrawContext ctx, String text, float cx, float y, int color) {
        int w = MinecraftClient.getInstance().textRenderer.getWidth(text);
        drawText(ctx, text, cx - w / 2f, y, color);
    }

    private float easeOutCubic(float x) {
        return 1f - (float) Math.pow(1f - x, 3);
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | (MathHelper.clamp(alpha, 0, 255) << 24);
    }

    // ── Публичное API ─────────────────────────────────────────────────
    public void markComplete() { resourcesLoaded = true; }
    public boolean isReadyToClose() { return readyToClose; }
    public boolean isComplete() { return allTextsShown && resourcesLoaded; }
    public boolean isFadingOut() { return isFadingOut; }
    public boolean isContentFadedOut() { return isFadingOut && contentAlpha <= 0.01f; }
    public float getContentAlpha() { return contentAlpha; }
    public void setProgress(float progress) { targetProgress = MathHelper.clamp(progress, 0f, 1f); }
    public float getProgress() { return targetProgress; }
    public long getStartTime() { return startTime; }

    public void reset() {
        animatedProgress = 0f; targetProgress = 0f; pulseTime = 0f;
        lastRenderTime = 0L; startTime = Util.getMeasuringTimeMs(); initialized = false;
        currentTextIndex = 0; currentTextOffsetY = 0f; currentTextAlpha = 1f;
        newTextOffsetY = -12f; newTextAlpha = 0f; lastTextChangeTime = startTime;
        isTransitioning = false; transitionStartTime = 0L;
        backgroundAlpha = 0f; contentAlpha = 0f; isFadingOut = false; readyToClose = false;
        resourcesLoaded = false; allTextsShown = false; lastTextShownTime = 0L;
        initParticles();
    }
}