package rich.screens.loading.particle;

import java.util.Random;

public class Particle {
    private float x, y, z;
    private float vx, vy, vz;
    private float size;
    private float life;
    private float maxLife;
    private float alpha;
    private float hue;
    private Random random = new Random();

    public Particle(float x, float y, float z, float maxLife) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.maxLife = maxLife;
        this.life = maxLife;
        this.size = 0.5f + random.nextFloat() * 1.5f;
        this.alpha = 0.3f + random.nextFloat() * 0.5f;
        this.hue = random.nextFloat();
        float speed = 0.3f + random.nextFloat() * 0.5f;
        this.vx = (random.nextFloat() - 0.5f) * speed;
        this.vy = (random.nextFloat() - 0.5f) * speed;
        this.vz = (random.nextFloat() - 0.5f) * speed;
    }

    public void update(float delta) {
        x += vx * delta;
        y += vy * delta;
        z += vz * delta;
        life -= delta;
        float lifeRatio = life / maxLife;
        alpha = lifeRatio * 0.7f;
    }

    public boolean isDead() { return life <= 0; }
    public float getX() { return x; }
    public float getY() { return y; }
    public float getZ() { return z; }
    public float getSize() { return size; }
    public float getAlpha() { return alpha; }
    public float getHue() { return hue; }
}