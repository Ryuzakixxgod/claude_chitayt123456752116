package rich.screens.loading.particle;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ParticleSystem {
    private final List<Particle> particles = new ArrayList<>();
    private final Random random = new Random();
    private float spawnTimer = 0;
    private float spawnInterval = 0.05f;

    public void update(float delta) {
        spawnTimer += delta;
        if (spawnTimer >= spawnInterval && particles.size() < 150) {
            spawnTimer = 0;
            float x = (random.nextFloat() - 0.5f) * 400;
            float y = (random.nextFloat() - 0.5f) * 200;
            float z = (random.nextFloat() - 0.5f) * 50;
            float life = 2.0f + random.nextFloat() * 3.0f;
            particles.add(new Particle(x, y, z, life));
        }
        for (int i = particles.size() - 1; i >= 0; i--) {
            particles.get(i).update(delta);
            if (particles.get(i).isDead()) particles.remove(i);
        }
    }

    public void render(float centerX, float centerY, int screenWidth, int screenHeight) {
        for (Particle p : particles) {
            float px = centerX + p.getX();
            float py = centerY + p.getY();
            float size = p.getSize() * 2.0f;
            float a = p.getAlpha();
            int color = 0x4A9EFF;
            rich.util.render.Render2D.rect(px - size / 2, py - size / 2, size, size, color, a);
        }
    }
}