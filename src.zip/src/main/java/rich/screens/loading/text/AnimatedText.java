package rich.screens.loading.text;

import java.util.Random;

public class AnimatedText {
    private static final String[] LOADING_MESSAGES = {
        "Initializing modules...", "Loading resources...", "Building UI...", "Preparing shaders...",
        "Loading fonts...", "Initializing HUD...", "Loading config...", "Connecting to server...",
        "Caching textures...", "Loading sounds..."
    };
    private final String[] displayLines = new String[3];
    private final Random random = new Random();
    private float lineTimer = 0;
    private float lineDuration = 0.8f;
    private int currentLine = 0;
    private float slideOffset = 0;
    private long lastUpdateTime = System.currentTimeMillis();

    public AnimatedText() {
        for (int i = 0; i < displayLines.length; i++) {
            displayLines[i] = LOADING_MESSAGES[i];
        }
    }

    public void update(float delta) {
        lineTimer += delta;
        if (lineTimer >= lineDuration) {
            lineTimer = 0;
            currentLine = (currentLine + 1) % LOADING_MESSAGES.length;
            for (int i = displayLines.length - 1; i > 0; i--) {
                displayLines[i] = displayLines[i - 1];
            }
            displayLines[0] = LOADING_MESSAGES[currentLine];
            slideOffset = 30;
        }
        slideOffset = Math.max(0, slideOffset - delta * 60);
    }

    public String[] getLines() {
        return displayLines;
    }
}