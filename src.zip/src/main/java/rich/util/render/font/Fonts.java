package rich.util.render.font;

public final class Fonts {

    public static Font BOLD;
    public static Font MEDIUM;
    public static Font REGULARNEW;
    public static Font ICONS;

    private static boolean initialized = false;

    public static void init() {
        if (initialized) return;
        initialized = true;
        try {
            BOLD = loadFont("sf-pro-bold");
            MEDIUM = loadFont("sf-pro-medium");
            REGULARNEW = MEDIUM;
            ICONS = BOLD;
        } catch (Exception e) {
            System.err.println("[Rich] Font load failed: " + e.getMessage());
            BOLD = null; MEDIUM = null; REGULARNEW = null; ICONS = null;
        }
    }

    private static Font loadFont(String name) {
        return null;
    }

    public static float getWidth(String text, float size, boolean bold) {
        Font f = bold ? BOLD : MEDIUM;
        if (f == null) return net.minecraft.client.MinecraftClient.getInstance().textRenderer.getWidth(text);
        return f.getWidth(text, size);
    }

    public static float getHeight(float size, boolean bold) {
        Font f = bold ? BOLD : MEDIUM;
        if (f == null) return 8f;
        return f.getHeight(size);
    }
}
