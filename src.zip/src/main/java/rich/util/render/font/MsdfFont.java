package rich.util.render.font;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public final class MsdfFont {

    private final String name;
    private final Identifier atlas;
    private final float fontSize;
    private final Map<Integer, Glyph> glyphs = new HashMap<>();
    private final Map<String, Float> kernings = new HashMap<>();

    private MsdfFont(String name, Identifier atlas, float fontSize, Map<Integer, Glyph> glyphs, Map<String, Float> kernings) {
        this.name = name;
        this.atlas = atlas;
        this.fontSize = fontSize;
        this.glyphs.putAll(glyphs);
        this.kernings.putAll(kernings);
    }

    public static Builder builder() { return new Builder(); }

    public static class Builder {
        private Identifier atlas;
        private Identifier data;
        private float fontSize = 64f;

        public Builder atlas(Identifier id) { this.atlas = id; return this; }
        public Builder data(Identifier id) { this.data = id; return this; }
        public Builder fontSize(float size) { this.fontSize = size; return this; }

        public MsdfFont build() {
            return createFallback();
        }

        private MsdfFont parseJson(String json, float fontSize) {
            Map<Integer, Glyph> glyphs = new HashMap<>();
            Map<String, Float> kernings = new HashMap<>();
            glyphs.put((int)'A', new Glyph(0, 0, 0.8f, 0.8f, 0, 0, 1, 1, 0.8f));
            glyphs.put((int)'R', new Glyph(0, 0, 0.8f, 0.8f, 0, 0, 1, 1, 0.8f));
            glyphs.put((int)' ', new Glyph(0, 0, 0.3f, 0.3f, 0, 0, 0.3f, 0.3f, 0.3f));
            glyphs.put((int)'.', new Glyph(0.1f, 0.3f, 0.3f, 0.5f, 0.1f, 0.3f, 0.3f, 0.5f, 0.2f));
            return new MsdfFont("msdf", atlas, fontSize, glyphs, kernings);
        }

        private MsdfFont createFallback() {
            Map<Integer, Glyph> glyphs = new HashMap<>();
            glyphs.put((int)'A', new Glyph(0, 0, 0.8f, 0.8f, 0, 0, 1, 1, 0.8f));
            glyphs.put((int)'R', new Glyph(0, 0, 0.8f, 0.8f, 0, 0, 1, 1, 0.8f));
            return new MsdfFont("fallback", null, fontSize, glyphs, new HashMap<>());
        }
    }

    public record Glyph(float lx, float ly, float rx, float ry, float u0, float v0, float u1, float v1, float advance) {}

    public void draw(String text, float x, float y, float size, int color) {
        if (text == null || text.isEmpty()) return;
        int a = (color >> 24) & 0xFF;
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        float fontScale = size / fontSize;
        float px = x;
        float py = y;

        for (int i = 0; i < text.length(); i++) {
            int ch = text.charAt(i);
            if (ch == ' ') { px += size * 0.3f; continue; }
            Glyph gld = glyphs.get(ch);
            if (gld == null) { px += size * 0.6f; continue; }
            float w = (gld.rx() - gld.lx()) * fontScale;
            float h = (gld.ry() - gld.ly()) * fontScale;
            float gx = px + gld.lx() * fontScale;
            float gy = py + gld.ly() * fontScale;
            drawGlyph(gx, gy, w, h, gld.u0(), gld.v0(), gld.u1(), gld.v1(), r, g, b, a);
            px += gld.advance() * fontScale;
        }
    }

    private void drawGlyph(float x, float y, float w, float h, float u0, float v0, float u1, float v1, int r, int g, int b, int a) {
        if (atlas == null) return;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, atlas);
        MatrixStack ms = new MatrixStack();
        ms.translate(x, y, 0);
        Matrix4f m = ms.peek().getPositionMatrix();
        MinecraftClient mc = MinecraftClient.getInstance();
        VertexConsumer vc = mc.getBufferBuilders().getEntityVertexConsumers().getBuffer(RenderLayer.getGuiTextured(atlas));
        float rf = r / 255f, gf = g / 255f, bf = b / 255f, af = a / 255f;
        vc.vertex(m, 0, h, 0).color(rf, gf, bf, af).texture(u0, v1);
        vc.vertex(m, w, h, 0).color(rf, gf, bf, af).texture(u1, v1);
        vc.vertex(m, w, 0, 0).color(rf, gf, bf, af).texture(u1, v0);
        vc.vertex(m, 0, 0, 0).color(rf, gf, bf, af).texture(u0, v0);
    }

    public float getWidth(String text, float size) {
        if (text == null || text.isEmpty()) return 0;
        float fontScale = size / fontSize;
        float width = 0;
        for (int i = 0; i < text.length(); i++) {
            int ch = text.charAt(i);
            if (ch == ' ') { width += size * 0.3f; continue; }
            Glyph gld = glyphs.get(ch);
            if (gld == null) { width += size * 0.6f; continue; }
            width += gld.advance() * fontScale;
        }
        return width;
    }

    public float getHeight(float size) { return size; }
}
