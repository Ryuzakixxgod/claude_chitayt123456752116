package rich.util.render.font;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public class Font {

    private final MsdfFont msdfFont;

    public Font(MsdfFont msdfFont) {
        this.msdfFont = msdfFont;
    }

    public void draw(String text, float x, float y, float size, int color) {
        if (msdfFont != null) {
            msdfFont.draw(text, x, y, size, color);
        } else {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.textRenderer != null) {
                DrawContext ctx = new DrawContext(mc, mc.getBufferBuilders().getEntityVertexConsumers());
                ctx.drawText(mc.textRenderer, Text.literal(text), (int)x, (int)y, color, false);
            }
        }
    }

    public float getWidth(String text, float size) {
        if (msdfFont != null) {
            return msdfFont.getWidth(text, size);
        } else {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.textRenderer != null) {
                return mc.textRenderer.getWidth(text);
            }
            return 0;
        }
    }

    public float getHeight(float size) {
        return size;
    }
}
