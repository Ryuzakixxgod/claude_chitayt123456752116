package rich.util.render;

import net.minecraft.client.gui.DrawContext;

public final class Render2D {

    private static DrawContext ctx;
    private static boolean active = false;

    public static void beginOverlay(DrawContext context) {
        ctx = context;
        active = true;
    }

    public static void endOverlay() {
        ctx = null;
        active = false;
    }

    public static void backgroundImage(float alpha, float zoom) {}

    public static void rect(float x, float y, float w, float h, int color, float alpha) {
        if (!active || ctx == null) return;
        int a = (int)(Math.min(alpha, 1f) * 255) << 24;
        ctx.fill((int)x, (int)y, (int)(x + w), (int)(y + h), a | (color & 0xFFFFFF));
    }

    public static void gradientRect(float x, float y, float w, float h, int[] colors, float radius) {
        if (!active || ctx == null || colors.length < 3) return;
        int top = colors[0];
        int mid = colors[1];
        int bot = colors[2];
        int mh = (int)(y + h / 2);
        ctx.fillGradient((int)x, (int)y, (int)(x + w), mh, top, mid, 0);
        ctx.fillGradient((int)x, mh, (int)(x + w), (int)(y + h), mid, bot, 0);
    }
}
