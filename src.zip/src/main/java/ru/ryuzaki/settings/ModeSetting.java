package ru.ryuzaki.settings;

public class ModeSetting extends Setting {

    private final String[] modes;
    private int currentIndex = 0;

    public ModeSetting(String name, String defaultMode, String... modes) {
        super(name);
        this.modes = modes;
        setCurrent(defaultMode);
    }

    public String getCurrent() {
        if (currentIndex < 0 || currentIndex >= modes.length) currentIndex = 0;
        return modes[currentIndex];
    }

    public int getCurrentIndex() { return currentIndex; }

    public void setCurrent(String name) {
        for (int i = 0; i < modes.length; i++) {
            if (modes[i].equalsIgnoreCase(name)) { currentIndex = i; return; }
        }
    }

    public void set(String name) { setCurrent(name); }

    public void next() { currentIndex = (currentIndex + 1) % modes.length; }
    public void prev() { currentIndex = (currentIndex - 1 + modes.length) % modes.length; }

    public int size() { return modes.length; }

    public String[] getModes() { return modes; }

    /** Alias — getSelected() = getCurrent() для совместимости */
    public String getSelected() { return getCurrent(); }

    public boolean is(String name) { return getCurrent().equalsIgnoreCase(name); }
}
