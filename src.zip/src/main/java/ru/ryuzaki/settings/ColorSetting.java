package ru.ryuzaki.settings;

import ru.ryuzaki.util.color.ColorRGBA;
import java.awt.Color;

public class ColorSetting extends Setting {
    private ColorRGBA color;
    public ColorSetting(String name, ColorRGBA def) { super(name); this.color = def; }
    public ColorSetting(String name, Color def) { super(name); this.color = new ColorRGBA(def); }
    /** Конструктор (name, r, g, b, a) для удобства */
    public ColorSetting(String name, int r, int g, int b, int a) { super(name); this.color = new ColorRGBA(r, g, b, a); }
    public ColorRGBA getColor() { return color; }
    public void setColor(ColorRGBA c) { this.color = c; }
    public void setColor(int r, int g, int b, int a) { this.color = new ColorRGBA(r,g,b,a); }
    /** Делегаты для прямого доступа к цветовым каналам */
    public int getRGB()   { return color != null ? color.getRGB()   : 0xFFFFFFFF; }
    public int getRed()   { return color != null ? color.getRed()   : 255; }
    public int getGreen() { return color != null ? color.getGreen() : 255; }
    public int getBlue()  { return color != null ? color.getBlue()  : 255; }
    public int getAlpha() { return color != null ? color.getAlpha() : 255; }
}
