package ru.ryuzaki.settings;

public class NumberSetting extends Setting {
    private double value;
    private final double min, max, step;
    public NumberSetting(String name, double def, double min, double max, double step) {
        super(name); this.value = def; this.min = min; this.max = max; this.step = step;
    }
    public Double getValue() { return value; }
    public void setValue(double v) { this.value = Math.max(min, Math.min(max, v)); }
    public double getMin() { return min; }
    public double getMax() { return max; }
    public double getStep() { return step; }
}
