package ru.ryuzaki.settings;

public class BooleanSetting extends Setting {
    private boolean value;
    public BooleanSetting(String name, boolean def) { super(name); this.value = def; }
    public boolean isEnabled() { return value; }
    public boolean getValue() { return value; }
    public void setValue(boolean v) { this.value = v; }
    public void toggle() { this.value = !this.value; }
}
