package ru.ryuzaki.settings;

/**
 * BindSetting — хранит бинд модуля
 * Поддерживает: клавиши клавиатуры, кнопки мыши, колёсико мыши
 *
 * Константы колёсика:
 *   BIND_MOUSE_WHEEL_UP   = -100  (прокрутка вверх)
 *   BIND_MOUSE_WHEEL_DOWN = -101  (прокрутка вниз)
 *   BIND_NONE             = 0     (не задан)
 *   > 0                           = GLFW клавиша
 *   -1..-9                        = кнопка мыши (GLFW_MOUSE_BUTTON_1 = -1, etc.)
 */
public class BindSetting extends Setting {

    // ── Специальные константы ─────────────────────────────────────────────
    public static final int BIND_NONE             = 0;
    public static final int BIND_MOUSE_WHEEL_UP   = -100;
    public static final int BIND_MOUSE_WHEEL_DOWN = -101;

    private int key;
    private boolean listening = false;

    public BindSetting(String name, int defaultKey) {
        super(name);
        this.key = defaultKey;
    }

    public BindSetting(String name) {
        this(name, BIND_NONE);
    }

    // ── Геттеры/сеттеры ───────────────────────────────────────────────────
    public int getKey()          { return key; }
    public void setKey(int key)  { this.key = key; }

    public boolean isListening() { return listening; }
    public void startListening() { listening = true; }
    public void stopListening()  { listening = false; }

    public boolean isBound()     { return key != BIND_NONE; }
    public void clearBind()      { key = BIND_NONE; }

    // ── Красивое имя бинда ────────────────────────────────────────────────
    public String getDisplayName() {
        if (key == BIND_NONE)             return "NONE";
        if (key == BIND_MOUSE_WHEEL_UP)   return "WHEEL ↑";
        if (key == BIND_MOUSE_WHEEL_DOWN) return "WHEEL ↓";
        if (key < 0) {
            int btn = -(key + 1); // -1 → 0, -2 → 1 ...
            return switch (btn) {
                case 0 -> "LMB";
                case 1 -> "RMB";
                case 2 -> "MMB";
                case 3 -> "MB4";
                case 4 -> "MB5";
                default -> "MB" + btn;
            };
        }
        // Клавиатура — GLFW keycode → имя
        return glfwKeyName(key);
    }

    private static String glfwKeyName(int key) {
        return switch (key) {
            case 32  -> "SPACE";
            case 256 -> "ESC";
            case 257 -> "ENTER";
            case 258 -> "TAB";
            case 259 -> "BACKSPACE";
            case 262 -> "RIGHT";
            case 263 -> "LEFT";
            case 264 -> "DOWN";
            case 265 -> "UP";
            case 290 -> "F1";  case 291 -> "F2";  case 292 -> "F3";
            case 293 -> "F4";  case 294 -> "F5";  case 295 -> "F6";
            case 296 -> "F7";  case 297 -> "F8";  case 298 -> "F9";
            case 299 -> "F10"; case 300 -> "F11"; case 301 -> "F12";
            case 340 -> "LSHIFT"; case 344 -> "RSHIFT";
            case 341 -> "LCTRL";  case 345 -> "RCTRL";
            case 342 -> "LALT";   case 346 -> "RALT";
            default  -> {
                // Для обычных символов (A-Z, 0-9)
                if (key >= 65 && key <= 90)  yield String.valueOf((char)key);
                if (key >= 48 && key <= 57)  yield String.valueOf((char)key);
                yield "KEY_" + key;
            }
        };
    }

    // ── Сериализация ──────────────────────────────────────────────────────
    public String serialize()               { return String.valueOf(key); }
    public void   deserialize(String value) {
        try { key = Integer.parseInt(value); } catch (Exception ignored) {}
    }

    @Override
    public String getName() { return name; }
}
