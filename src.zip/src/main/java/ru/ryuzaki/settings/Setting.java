package ru.ryuzaki.settings;

public abstract class Setting {
    public String name;
    protected boolean visible = true;
    public Setting(String name) { this.name = name; }
    public String getName() { return name; }
    public boolean isVisible() { return visible; }
    public void setVisible(boolean v) { this.visible = v; }
}
