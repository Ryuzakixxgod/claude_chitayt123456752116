package ru.ryuzaki.waypoints;

public class Waypoint {
    public String name;
    public double x, y, z;
    public int color;
    public String dimension;

    public Waypoint(String name, double x, double y, double z, int color, String dimension) {
        this.name=name; this.x=x; this.y=y; this.z=z; this.color=color; this.dimension=dimension;
    }
    public Waypoint(String name, double x, double y, double z, int color) {
        this(name, x, y, z, color, "overworld");
    }
}
