package ru.ryuzaki.waypoints;
import java.util.ArrayList;
import java.util.List;
public class WaypointManager {
    private static WaypointManager instance;
    private final List<Waypoint> waypoints = new ArrayList<>();
    private WaypointManager() {}
    public static WaypointManager getInstance() { if(instance==null) instance=new WaypointManager(); return instance; }
    public void addWaypoint(Waypoint w) { waypoints.add(w); }
    public void removeWaypoint(Waypoint w) { waypoints.remove(w); }
    public List<Waypoint> getWaypoints() { return waypoints; }
}