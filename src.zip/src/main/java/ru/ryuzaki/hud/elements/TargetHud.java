package ru.ryuzaki.hud.elements;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.util.FriendManager;
import ru.ryuzaki.util.TargetManager;

/**
 * TargetHud — компактный пилл с инфо о цели.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - Все `new Color(r, g, b, dynamicAlpha)` заменены на int ARGB паковку
 *    (побитовый сдвиг вместо объекта). При 240 FPS когда цель в зоне ~30 Color/кадр → 0
 *  - DrawHelper.drawRect/Outline принимают Color — заменены на fillRound/borderRound
 *    из HudElement, которые принимают int ARGB напрямую
 *  - ctx.drawText() вместо DrawHelper.drawText() для маленьких элементов
 *    (dist, abs) — batch вместо отдельного shader call
 *  - Skin texture кэшируется — не ищется через getPlayerListEntry каждый кадр
 */
public class TargetHud extends HudElement {

    private static final float W  = 200f;
    private static final float H  = 44f;
    private static final float R  = 22f;
    private static final float P  = 7f;
    private static final float AV = 30f;

    // Статические цвета (без alpha) — пакуем alpha динамически как int
    private static final int RGB_BG         = 0x00080612; // alpha добавляем динамически
    private static final int RGB_BORDER     = 0x00FFFFFF;
    private static final int RGB_AVATAR_BG  = 0x00281C40;
    private static final int RGB_HP_FILL_SH = 0x00FFFFFF;
    private static final int RGB_ABS        = 0x00FBBF24;

    // HP цвета
    private static final int RGB_GREEN  = 0x004CDC59;
    private static final int RGB_YELLOW = 0x00FAC81E;
    private static final int RGB_RED    = 0x00EF4444;
    private static final int RGB_FRIEND = 0x0022C55E;

    private float animHp    = -1f;
    private float animAlpha = 0f;
    private float animAbs   = 0f;
    private boolean placed  = false;

    // Skin кэш — не ищем каждый кадр
    private Identifier cachedSkin     = null;
    private java.util.UUID cachedUuid = null;
    private int skinCheckTimer = 0;

    public TargetHud(int x, int y) { super("TargetHud", new Dragging(x, y, (int)W, (int)H)); }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        LivingEntity target = TargetManager.getInstance().getTarget();
        float targetA = (target != null && target.isAlive()) ? 1f : 0f;
        animAlpha += (targetA - animAlpha) * Math.min(1f, delta * 9f);
        if (animAlpha < 0.02f) { animHp = -1f; return; }

        float hp    = target != null ? target.getHealth()          : 0f;
        float maxHp = target != null ? target.getMaxHealth()       : 20f;
        float abs   = target != null ? target.getAbsorptionAmount(): 0f;
        float hpF   = maxHp > 0 ? hp / maxHp : 0f;
        float absF  = maxHp > 0 ? Math.min(1f - hpF, abs / maxHp) : 0f;

        if (animHp < 0) animHp = hpF;
        animHp  += (hpF  - animHp)  * Math.min(1f, delta * 7f);
        animAbs += (absF - animAbs) * Math.min(1f, delta * 5f);

        dragging.setWidth((int)W); dragging.setHeight((int)H);
        if (!placed || dragging.getX() < 0) {
            dragging.setX((int)(sw / 2f - W / 2f));
            dragging.setY(sh - (int)H - 54);
            placed = true;
        }

        float x = dragging.getX(), y = dragging.getY();
        // Пакуем alpha в int — ноль new Color()
        int a = clampA((int)(animAlpha * 255));

        boolean friend = target != null
            && (target instanceof net.minecraft.entity.player.PlayerEntity)
            && FriendManager.isFriend(target.getName().getString());

        // HP rgb
        int hpRgb = friend ? RGB_FRIEND : (hpF > .5f ? RGB_GREEN : (hpF > .25f ? RGB_YELLOW : RGB_RED));

        MatrixStack ms = ctx.getMatrices();

        // ── Фон ──────────────────────────────────────────────────────
        fillRound(ctx, (int)x, (int)y, (int)(x+W), (int)(y+H), pack(RGB_BG, clampA((int)(240*animAlpha))), (int)R);
        borderRound(ctx, (int)x, (int)y, (int)(x+W), (int)(y+H), pack(RGB_BORDER, clampA((int)(16*animAlpha))), 1);

        // ── Кольцо аватара — цвет HP ──────────────────────────────────
        float ax = x + P, ay = y + (H - AV) / 2f;
        borderRound(ctx, (int)(ax-1), (int)(ay-1), (int)(ax+AV+1), (int)(ay+AV+1),
            pack(hpRgb, clampA((int)(160*animAlpha))), 2);

        // ── Фон аватара ───────────────────────────────────────────────
        fillRound(ctx, (int)ax, (int)ay, (int)(ax+AV), (int)(ay+AV),
            pack(RGB_AVATAR_BG, clampA((int)(200*animAlpha))), (int)(AV/2f));

        // ── Скин ──────────────────────────────────────────────────────
        if (target != null) {
            updateSkinCache(mc, target);
            if (cachedSkin != null) {
                try {
                    RenderSystem.setShaderColor(1f, 1f, 1f, animAlpha);
                    ctx.drawTexture(RenderLayer::getGuiTextured, cachedSkin,
                        (int)ax, (int)ay, (int)AV, (int)AV, 8, 8, 8, 8, 64, 64);
                    ctx.drawTexture(RenderLayer::getGuiTextured, cachedSkin,
                        (int)ax, (int)ay, (int)AV, (int)AV, 40, 8, 8, 8, 64, 64);
                    RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
                } catch (Exception ignored) {}
            }
        }

        // ── Имя + HP текст ────────────────────────────────────────────
        float tx = ax + AV + P;
        String name = target != null ? target.getName().getString() : "";
        if (friend) {
            // Friend tag — ctx.drawText vanilla batch
            ctx.drawText(mc.textRenderer, Text.literal("♥"), (int)tx, (int)(y + 8f),
                pack(RGB_FRIEND, a), false);
            tx += mc.textRenderer.getWidth("♥") + 3;
        }

        // Имя — MSDF только для главного текста (виден отчётливо)
        if (Fonts.BOLD != null) {
            try {
                DrawHelper.drawText(ms.peek().getPositionMatrix(), Fonts.BOLD.getFont(10.5f),
                    name, tx, y + 8f, new java.awt.Color(237, 232, 255, a));
            } catch (Exception e) {
                ctx.drawText(mc.textRenderer, Text.literal(name), (int)tx, (int)(y+1f), pack(0x00EDE8FF, a), false);
            }
        } else {
            ctx.drawText(mc.textRenderer, Text.literal(name), (int)tx, (int)(y+1f), pack(0x00EDE8FF, a), false);
        }

        // HP значение — vanilla (маленький текст справа)
        String hpStr = String.format("%.1f HP", hp);
        int hpTw = mc.textRenderer.getWidth(hpStr);
        ctx.drawText(mc.textRenderer, Text.literal(hpStr),
            (int)(x + W - P) - hpTw, (int)(y + 8f), pack(hpRgb, a), false);

        // ── HP бар ────────────────────────────────────────────────────
        float bx = ax + AV + P;
        float bw  = x + W - P - bx;
        float by  = y + 23f;
        float bh  = 4f;

        // Фон бара
        ctx.fill((int)bx, (int)by, (int)(bx+bw), (int)(by+bh),
            pack(RGB_HP_FILL_SH, clampA((int)(18*animAlpha))));

        // Заполнение
        float fw = bw * Math.max(0f, Math.min(1f, animHp));
        if (fw > 1f) {
            ctx.fill((int)bx, (int)by, (int)(bx+fw), (int)(by+bh),
                pack(hpRgb, clampA((int)(215*animAlpha))));
            // Блик
            if (fw > 2f)
                ctx.fill((int)(bx+1f), (int)by, (int)(bx+fw-1f), (int)(by+bh*0.5f),
                    pack(RGB_HP_FILL_SH, clampA((int)(35*animAlpha))));
        }

        // Absorption
        if (animAbs > 0.005f) {
            float aw = bw * Math.max(0f, Math.min(1f - animHp, animAbs));
            if (aw > 1f)
                ctx.fill((int)(bx+fw), (int)by, (int)(bx+fw+aw), (int)(by+bh),
                    pack(RGB_ABS, clampA((int)(170*animAlpha))));
        }

        // ── Dist + Abs текст — vanilla batch ──────────────────────────
        float infoY = y + 32f;
        if (abs > 0f) {
            String absStr = String.format("+%.1f", abs);
            ctx.drawText(mc.textRenderer, Text.literal(absStr),
                (int)bx, (int)infoY, pack(RGB_ABS, clampA((int)(150*animAlpha))), false);
        }
    }

    /** Обновляем кэш скина раз в 40 кадров */
    private void updateSkinCache(MinecraftClient mc, LivingEntity target) {
        if (++skinCheckTimer < 40 && cachedUuid != null && cachedUuid.equals(target.getUuid())) return;
        skinCheckTimer = 0;
        cachedUuid = target.getUuid();
        try {
            PlayerListEntry entry = mc.getNetworkHandler() != null
                ? mc.getNetworkHandler().getPlayerListEntry(target.getUuid()) : null;
            cachedSkin = entry != null
                ? entry.getSkinTextures().texture()
                : Identifier.of("minecraft", "textures/entity/player/wide/steve.png");
        } catch (Exception ignored) {
            cachedSkin = null;
        }
    }

    /** Упаковка RGB (без alpha) + alpha → ARGB int */
    private static int pack(int rgb, int alpha) {
        return ((alpha & 0xFF) << 24) | (rgb & 0x00FFFFFF);
    }

    private static int clampA(int a) { return Math.max(0, Math.min(255, a)); }
}
