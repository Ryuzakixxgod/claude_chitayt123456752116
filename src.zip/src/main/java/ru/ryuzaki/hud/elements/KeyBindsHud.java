package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

/**
 * KeyBindsHud — красивый список активных модулей с биндами.
 * Стилистика Ryuzaki: оранжевые акценты, скруглённые панели, тени.
 *
 * ОПТИМИЗАЦИИ:
 *  - Сортировка кэшируется — пересчёт ТОЛЬКО при изменении списка
 *  - Ноль new Color() — цвета как int ARGB
 *  - ctx.drawText() vanilla batched renderer
 *  - Тень через 1-pixel offset ctx.drawText()
 */
public class KeyBindsHud extends HudElement {

    public KeyBindsHud()             { super("KeyBinds", new Dragging(0, 6, 120, 12)); }
    public KeyBindsHud(int x, int y)  { super("KeyBinds", new Dragging(x, y, 120, 12)); }

    private static final Set<Category> SHOW_CATS = Set.of(
        Category.VISUAL, Category.ANIMATION, Category.PARTICLES,
        Category.COMBAT, Category.PLAYER, Category.WORLD
    );

    private final List<ModuleBind> cachedList = new ArrayList<>(32);
    private final List<Float> animAlphas = new ArrayList<>(32);
    private final java.util.Map<Module, Integer> keyWidthCache = new java.util.HashMap<>(32);
    private int lastHash = 0;
    private int checkTimer = 0;
    private boolean positioned = false;

    // Цвета
    private static final int ORANGE = 0xFFFF9900;
    private static final int ORANGE_DIM = 0xFFCC7700;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF888888;
    private static final int SHADOW = 0xAA000000;

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (++checkTimer >= 8) {
            checkTimer = 0;
            checkRebuild(mc);
        }

        if (cachedList.isEmpty()) return;

        float rowH = 14f;
        int padding = 6;
        int cornerRadius = 4;

        // Вычисляем размер панели
        int panelWidth = 0;
        int panelHeight = cachedList.size() > 0
            ? (int)(cachedList.size() * rowH + padding * 2)
            : 0;

        for (ModuleBind mb : cachedList) {
            int textWidth = mc.textRenderer.getWidth(mb.module.name);
            int keyWidth = mc.textRenderer.getWidth(mb.keyString);
            int totalW = textWidth + keyWidth + 16; // +padding+gap
            panelWidth = Math.max(panelWidth, totalW);
        }

        if (panelWidth == 0) return;
        panelWidth = Math.max(panelWidth, 80);

        // Позиционирование по умолчанию
        int bx, by;
        if (!positioned || dragging.getX() < 0) {
            bx = sw - panelWidth - 8;
            by = sh / 2 - panelHeight / 2;
            dragging.setX(bx);
            dragging.setY(by);
            dragging.setWidth(panelWidth);
            dragging.setHeight(panelHeight);
            positioned = true;
        }
        bx = (int) dragging.getX();
        by = (int) dragging.getY();

        // Фон панели
        HudRenderer.fillRounded(ctx, bx, by, panelWidth, panelHeight, cornerRadius, HudRenderer.BG);

        // Верхняя граница (оранжевая линия)
        HudRenderer.outlineRounded(ctx, bx, by, panelWidth, panelHeight, cornerRadius, ORANGE_DIM);

        int[] rgb = RyuzakiRenderCache.rgb1;

        for (int i = 0; i < cachedList.size(); i++) {
            ModuleBind mb = cachedList.get(i);

            float a = Math.min(1f, animAlphas.get(i) + delta * 4f);
            animAlphas.set(i, a);

            int alpha = (int)(255 * a);
            int rowY = by + padding + (int)(i * rowH);

            // Кэшируем ширину ключа
            Integer cachedW = keyWidthCache.get(mb.module);
            if (cachedW == null) {
                cachedW = mc.textRenderer.getWidth(mb.keyString);
                keyWidthCache.put(mb.module, cachedW);
            }
            final int keyWidth = cachedW;

            int textColor = ((alpha & 0xFF) << 24) | ((rgb[0] & 0xFF) << 16) | ((rgb[1] & 0xFF) << 8) | (rgb[2] & 0xFF);
            int keyBgColor = withAlpha(ORANGE, (int)(40 * a));
            int keyTextColor = withAlpha(WHITE, alpha);
            int keyTextShadow = withAlpha(0xFF1A1A1A, (int)(150 * a));

            // Текст модуля с тенью
            ctx.drawText(mc.textRenderer, Text.literal(mb.module.name),
                bx + 8, rowY + 1, SHADOW, false);
            ctx.drawText(mc.textRenderer, Text.literal(mb.module.name),
                bx + 7, rowY, textColor, false);

            // Бинд клавиши в оранжевом боксе
            int keyX = bx + panelWidth - keyWidth - 16;
            int keyY = rowY - 1;
            int keyH = 12;

            // Фон для бинда
            HudRenderer.fillRounded(ctx, keyX, keyY, keyWidth + 6, keyH, 3, keyBgColor);

            // Текст бинда
            ctx.drawText(mc.textRenderer, Text.literal(mb.keyString),
                keyX + 3, rowY + 1, keyTextShadow, false);
            ctx.drawText(mc.textRenderer, Text.literal(mb.keyString),
                keyX + 2, rowY, keyTextColor, false);
        }

        dragging.setWidth(panelWidth);
        dragging.setHeight(panelHeight);
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((Math.max(0, Math.min(255, alpha)) & 0xFF) << 24);
    }

    private void checkRebuild(MinecraftClient mc) {
        int hash = 0;
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled() && SHOW_CATS.contains(m.category)) {
                hash = hash * 31 + System.identityHashCode(m);
            }
        }
        if (hash == lastHash) return;
        lastHash = hash;
        rebuild(mc);
    }

    private void rebuild(MinecraftClient mc) {
        List<ModuleBind> fresh = new ArrayList<>(16);
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled() && SHOW_CATS.contains(m.category)) {
                String keyStr = getKeyString(m.getBind());
                fresh.add(new ModuleBind(m, keyStr));
            }
        }

        // Сортируем по длине имени
        fresh.sort(Comparator.comparingInt(mb -> -mc.textRenderer.getWidth(mb.module.name)));

        // Сохраняем альфы для анимации
        List<Float> newAlphas = new ArrayList<>(fresh.size());
        for (ModuleBind mb : fresh) {
            int idx = -1;
            for (int i = 0; i < cachedList.size(); i++) {
                if (cachedList.get(i).module == mb.module) {
                    idx = i;
                    break;
                }
            }
            newAlphas.add(idx >= 0 ? animAlphas.get(idx) : 0f);
        }

        cachedList.clear(); cachedList.addAll(fresh);
        animAlphas.clear(); animAlphas.addAll(newAlphas);

        // Очищаем кэш ширин — пересчитаем при следующем рендере
        keyWidthCache.clear();
    }

    private String getKeyString(ru.ryuzaki.settings.BindSetting bind) {
        if (bind == null) return "NONE";
        return bind.getDisplayName();
    }

    private record ModuleBind(Module module, String keyString) {}
}
