package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.util.MediaUtil;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.awt.Color;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * WatermarkHud — два стиля: PHONE (пилюля) и CLASSIC (строка).
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - Радужная полоска через ctx.fillGradient() — 1 draw call вместо ширины экрана
 *  - Все Color объекты — статические поля или создаются ВНЕ render path
 *  - Строки кэшируются (FPS, Ping, BPS), не форматируются каждый кадр
 *  - pingColor — enum-like статика, не new Color() каждый кадр
 */
public class WatermarkHud extends HudElement {

    private static WatermarkHud instance;

    // ── Динамический акцентный цвет (устанавливается из ThemeModule) ─────
    private static int accentR = 255;
    private static int accentG = 48;
    private static int accentB = 48;

    // ── Статические цвета — ноль аллокаций в render ──────────────────
    private static final Color C_TIME     = new Color(160, 160, 160, 190);
    private static final Color C_TEXT     = new Color(242, 242, 242, 238);
    private static final Color C_PILL_BG  = new Color(6,   6,   6,   214);
    private static final Color C_PILL_TOP = new Color(255, 255, 255,  18);
    private static final Color C_WAVE     = new Color(255, 48, 48, 168);
    private static final Color C_GREEN    = new Color(70,  255,   0, 255);
    private static final Color C_RED      = new Color(255,  66,  66, 255);
    private static final Color C_GRAY     = new Color(160, 160, 160, 180);
    private static final Color C_DIM      = new Color(94, 94, 94, 190);

    // Ping индикаторы — без new Color() в render
    private static final int COL_PING_GOOD = rgba(0,   200, 80, 200);
    private static final int COL_PING_MID  = rgba(230, 180, 0,  180);
    private static final int COL_PING_BAD  = rgba(230, 50,  50, 180);

    // ── Настройки ────────────────────────────────────────────────────
    public String style = "Phone";

    // ── Нотификация о переключении модуля ────────────────────────────
    private static volatile String  notifLabel = null;
    private static volatile boolean notifOn    = false;
    private static volatile long    notifReset = 0;

    // ── Кэши строк — обновляются раз в N тиков ───────────────────────
    private String cachedFpsStr  = "";
    private String cachedPingStr = "";
    private String cachedBpsStr  = "";
    private int    lastFps  = -1;
    private int    lastPing = -1;
    private int    strTimer = 0;

    // ── Музыкальные волны ────────────────────────────────────────────
    private final float[] waveH   = {5f, 8f, 6f, 10f};
    private final float[] waveTgt = {5f, 8f, 6f, 10f};
    private long lastWave = 0;

    // ── Анимация ширины пилюли ────────────────────────────────────────
    private float animW = 120f;

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm");

    public WatermarkHud()             { super("Watermark", new Dragging(8, 8, 240, 36)); instance = this; MediaUtil.init(); }
    public WatermarkHud(int x, int y) { super("Watermark", new Dragging(x, y, 240, 36)); instance = this; MediaUtil.init(); }

    public static WatermarkHud getInstance() { return instance; }

    /** Установить акцентный цвет из ThemeModule */
    public static void setAccentColor(int r, int g, int b) {
        accentR = r;
        accentG = g;
        accentB = b;
    }

    /** Получить текущий акцентный цвет как Color */
    public static Color getAccentColor() {
        return new Color(accentR, accentG, accentB);
    }

    public static void notifyToggle(String name, boolean enabled) {
        notifLabel = name + (enabled ? " вкл!" : " выкл!");
        notifOn    = enabled;
        notifReset = System.currentTimeMillis() + 2200;
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        if ("Classic".equals(style)) renderClassic(ctx, sw, sh);
        else                          renderPhone(ctx, sw, sh);
    }

    // ════════════════════════════════════════════════════════════════
    //  PHONE
    // ════════════════════════════════════════════════════════════════
    private void renderPhone(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        MatrixStack ms = ctx.getMatrices();
        long now = System.currentTimeMillis();

        if (notifLabel != null && now >= notifReset) notifLabel = null;

        String timeStr  = LocalTime.now().format(TIME_FMT);
        boolean music   = MediaUtil.isPlaying();
        MediaUtil.TrackInfo track = music ? MediaUtil.getCurrent() : null;
        boolean hasNotif = notifLabel != null;

        // Волны музыки — раз в 150ms
        if (music && now - lastWave > 150) {
            lastWave = now;
            for (int i = 0; i < 4; i++) waveTgt[i] = 3f + (float)(Math.random() * 11f);
        }
        for (int i = 0; i < 4; i++) waveH[i] += (waveTgt[i] - waveH[i]) * 0.18f;

        // Определяем что показываем в пилюле
        String label;
        int dotColor;
        boolean showDot;
        if (hasNotif) {
            label   = notifLabel;
            dotColor = notifOn ? rgba(70, 255, 0, 230) : rgba(255, 66, 66, 230);
            showDot = true;
        } else if (music && track != null) {
            label   = track.display();
            dotColor = 0;
            showDot = false;
        } else {
            label   = "Ryuzaki";
            dotColor = rgba(accentR, accentG, accentB, 230);
            showDot = true;
        }

        float timeW  = tw(timeStr, 9f);
        float labelW = tw(label, 9f);
        float waveW  = (music && !hasNotif) ? 4 * 3f + 3 * 2f + 8f : 0f;
        float artW   = (music && !hasNotif) ? 22f + 5f : 0f;
        float dotW   = showDot ? 9f + 6f : 0f;

        float targetW = 9f * 2 + dotW + labelW + waveW + artW + 4f;
        // Плавная интерполяция ширины — без new object
        animW += (Math.max(70f, targetW) - animW) * 0.18f;

        float pillW  = animW;
        float pillH  = 20f;
        float totalW = timeW + 8f + pillW;
        float baseX  = sw / 2f - totalW / 2f;
        float baseY  = 8f;
        float pillX  = baseX + timeW + 8f;
        float cy     = baseY + pillH / 2f;

        // Время — статический цвет
        drawT(ctx, ms, timeStr, baseX, baseY + (pillH - 9f) / 2f, C_TIME, 9f, true);

        HudRenderer.compactMaterial(ctx, (int)pillX, (int)baseY, (int)pillW, (int)pillH, 10, 0.12f);
        DrawHelper.drawRect(ms, pillX + 1.0f, baseY + 1.0f, pillW - 2.0f, 1.0f, 0.5f, C_PILL_TOP);

        float cx2 = pillX + 10f;

        if (music && track != null && !hasNotif) {
            Identifier art    = MediaUtil.getArtId();
            float      artSz  = 16f;
            float      artY   = baseY + (pillH - artSz) / 2f;
            if (art != null) {
                ctx.drawTexture(RenderLayer::getGuiTextured, art,
                    (int)cx2, (int)artY, (int)artSz, (int)artSz,
                    0, 0, (int)artSz, (int)artSz, (int)artSz, (int)artSz);
            } else {
                int[] rgb = RyuzakiRenderCache.rgb1;
                DrawHelper.drawRect(ms, cx2, artY, artSz, artSz, artSz / 2f,
                    new Color(rgb[0], rgb[1], rgb[2], 180));
                drawT(ctx, ms, "M", cx2 + 4, artY + 2, C_WAVE, 8.5f, false);
            }
            cx2 += artSz + 5f;
            drawT(ctx, ms, label, cx2, cy - 4.5f, C_TEXT, 9f, false);
            cx2 += labelW + 6f;
            // Волны — минимум draw calls: 4 заливки
            for (int i = 0; i < 4; i++) {
                float bh = Math.max(2f, waveH[i]);
                DrawHelper.drawRect(ms, cx2 + i * (3f + 2f), cy + 5f - bh, 3f, bh, 1.5f, C_WAVE);
            }
        } else if (showDot) {
            float dotSz = 7f;
            float dotY  = cy - dotSz / 2f;
            fillRound(ctx, (int)(cx2 - 2), (int)(dotY - 2), (int)(cx2 + dotSz + 2), (int)(dotY + dotSz + 2),
                    (dotColor & 0x00FFFFFF) | 0x26000000, 6);
            fillRound(ctx, (int)cx2, (int)dotY, (int)(cx2 + dotSz), (int)(dotY + dotSz), dotColor, 4);
            cx2 += dotSz + 6f;
            drawT(ctx, ms, label, cx2, cy - 4.5f, C_TEXT, 9f, false);
        } else {
            drawT(ctx, ms, label, cx2, cy - 4.5f, C_TEXT, 9f, false);
        }

        // Ping индикатор — без new Color
        int ping = getPing(mc);
        int pingCol = ping < 80 ? COL_PING_GOOD : ping < 200 ? COL_PING_MID : COL_PING_BAD;
        ctx.fill((int)(pillX + pillW + 5), (int)(cy - 1), (int)(pillX + pillW + 11), (int)(cy + 1), pingCol);
    }

    // ════════════════════════════════════════════════════════════════
    //  CLASSIC
    // ════════════════════════════════════════════════════════════════
    private void renderClassic(DrawContext ctx, int sw, int sh) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        MatrixStack ms = ctx.getMatrices();

        // Кэш строк — обновляем раз в 10 кадров
        if (++strTimer >= 10) {
            strTimer = 0;
            int fps  = mc.getCurrentFps();
            int ping = getPing(mc);
            double dx  = mc.player.getX() - mc.player.prevX;
            double dz  = mc.player.getZ() - mc.player.prevZ;
            double bps = Math.round(Math.sqrt(dx * dx + dz * dz) * 200.0) / 10.0;
            if (fps  != lastFps)  { cachedFpsStr  = String.valueOf(fps);  lastFps  = fps; }
            if (ping != lastPing) { cachedPingStr = ping + "ms";          lastPing = ping; }
            cachedBpsStr = String.format("%.1f", bps);
        }

        String[] r1 = {"R ", "Ryuzaki", "  /  ", "FPS ", cachedFpsStr, "  /  ", "PING ", cachedPingStr};
        int[]    c1 = {
            rgba(accentR, accentG, accentB, 255), HudRenderer.WHITE,
            HudRenderer.MUTED, HudRenderer.GRAY, rgba(accentR, accentG, accentB, 255),
            HudRenderer.MUTED, HudRenderer.GRAY, rgba(accentR, accentG, accentB, 255)
        };

        int px  = (int)dragging.getX(), py = (int)dragging.getY();
        float w1 = 0; for (String s : r1) w1 += tw(s, 10f);

        int px2 = (int)dragging.getX();
        int py2 = (int)dragging.getY();
        float panelW = w1 + 18f;

        HudRenderer.compactMaterial(ctx, px2, py2, (int)panelW, 30, 7, 0.10f);

        // Строка 1
        float cx = px2 + 9f;
        for (int i = 0; i < r1.length; i++) {
            drawT(ctx, ms, r1[i], cx, py2 + 10f, color(c1[i]), 9.5f, true);
            cx += tw(r1[i], 10f);
        }
        // Строка 2 — BPS
        cx = px2 + 9f;
        int px3 = (int)mc.player.getX(), py3 = (int)mc.player.getY(), pz3 = (int)mc.player.getZ();
        String coordStr = px3 + ", " + py3 + ", " + pz3;
        drawT(ctx, ms, coordStr, cx, py2 + 22f, C_DIM, 9.5f, false);
        cx += tw(coordStr, 9.5f);
        drawT(ctx, ms, "  /  BPS ", cx, py2 + 22f, C_GRAY, 9.0f, false);
        cx += tw("  /  BPS ", 9.0f);
        drawT(ctx, ms, cachedBpsStr, cx, py2 + 22f, C_TEXT, 9.0f, false);
    }

    // ── Утилиты ──────────────────────────────────────────────────────

    private static int getPing(MinecraftClient mc) {
        try {
            if (mc.getNetworkHandler() == null || mc.player == null) return 0;
            var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return entry != null ? entry.getLatency() : 0;
        } catch (Exception ignored) { return 0; }
    }

    private float tw(String s, float size) {
        if (Fonts.BOLD != null) return Fonts.BOLD.getWidth(s, size);
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    private void drawT(DrawContext ctx, MatrixStack ms, String t, float x, float y, Color col, float size, boolean bold) {
        var f = bold ? Fonts.BOLD : Fonts.MEDIUM;
        if (f != null) {
            try { DrawHelper.drawText(ms.peek().getPositionMatrix(), f.getFont(size), t, x, y, col); return; }
            catch (Exception ignored) {}
        }
        int argb = (col.getAlpha() << 24) | (col.getRed() << 16) | (col.getGreen() << 8) | col.getBlue();
        ctx.drawText(MinecraftClient.getInstance().textRenderer, t, (int)x, (int)(y - 7), argb, false);
    }

    protected static int rgba(int r, int g, int b, int a) {
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    private static Color color(int argb) {
        return new Color(argb, true);
    }
}
