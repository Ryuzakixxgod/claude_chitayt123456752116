package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;

import java.util.ArrayList;
import java.util.List;

/**
 * BindingHud — отображает привязки клавиш для активных модулей.
 * Поддерживает изменение размера через RMB-попап.
 */
public class BindingHud extends HudElement {

    private static final int PAD = 6;
    private static final int ROW_H = 14;
    private static final int TITLE_H = 16;
    private static final int RADIUS = 4;
    private static final int LABEL_W = 80;

    private final List<String> cachedLines = new ArrayList<>();
    private final List<String> cachedKeys = new ArrayList<>();

    public BindingHud() {
        super("Bindings", new Dragging(-1, -1, 180, 100));
    }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        buildCache();

        int lines = cachedLines.size();
        int totalW = LABEL_W + 60;
        int totalH = TITLE_H + lines * ROW_H + PAD * 2;

        // Применяем size
        if (size != 60) {
            float factor = size / 60f;
            int bx = (int) dragging.getX();
            int by = (int) dragging.getY();
            ctx.getMatrices().push();
            ctx.getMatrices().translate(bx, by, 0);
            ctx.getMatrices().scale(factor, factor, 1f);
            drawAt(ctx, mc, 0, 0, totalW, totalH, lines);
            ctx.getMatrices().pop();
            dragging.setWidth((int)(totalW * factor));
            dragging.setHeight((int)(totalH * factor));
            return;
        }

        // Позиционирование по умолчанию
        if (dragging.getX() < 0) {
            dragging.setX(sw - totalW - 8);
            dragging.setY(sh / 2 - totalH / 2);
        }

        dragging.setWidth(totalW);
        dragging.setHeight(totalH);

        drawAt(ctx, mc, (int) dragging.getX(), (int) dragging.getY(), totalW, totalH, lines);
    }

    private void drawAt(DrawContext ctx, MinecraftClient mc, int x, int y, int totalW, int totalH, int lines) {
        if (showBackground) {
            HudRenderer.fillRounded(ctx, x, y, totalW, totalH, RADIUS, HudRenderer.BG);
            ctx.fill(x, y, x + 2, y + totalH, HudRenderer.ORANGE);
        }

        // Заголовок
        ctx.drawText(mc.textRenderer, Text.literal("§b§lBINDINGS"), x + PAD, y + PAD, 0xFFFFFFFF, false);

        // Строки
        for (int i = 0; i < lines; i++) {
            int ly = y + TITLE_H + PAD + i * ROW_H;

            // Фон строки
            ctx.fill(x + PAD, ly, x + totalW - PAD, ly + ROW_H - 2, 0x33FFFFFF);

            // Модуль
            ctx.drawText(mc.textRenderer, Text.literal(cachedLines.get(i)),
                    x + PAD + 2, ly + 2, 0xFFAAAAAA, false);

            // Клавиша
            String key = cachedKeys.get(i);
            int kx = x + LABEL_W + PAD;
            int kw = totalW - PAD * 2 - LABEL_W;
            boolean enabled = i < cachedLines.size(); // проверяем активность

            // Фон клавиши
            ctx.fill(kx, ly, kx + kw, ly + ROW_H - 2, enabled ? 0xFF335533 : 0xFF333333);

            // Текст клавиши
            int tw = mc.textRenderer.getWidth(key);
            int tx = kx + (kw - tw) / 2;
            ctx.drawText(mc.textRenderer, Text.literal(key),
                    tx, ly + 2, enabled ? 0xFF88FF88 : 0xFF666666, false);
        }
    }

    private void buildCache() {
        cachedLines.clear();
        cachedKeys.clear();

        for (Module m : ModuleManager.modules) {
            if (!m.isEnabled()) continue;

            int keyCode = m.getBind().getKey();
            if (keyCode <= 0) continue;

            String name = m.name;
            String keyName = getKeyName(keyCode);

            cachedLines.add(name);
            cachedKeys.add(keyName);
        }
    }

    private String getKeyName(int keyCode) {
        if (keyCode == 256) return "None";
        if (keyCode == 341) return "L Ctrl";
        if (keyCode == 344) return "R Shift";
        if (keyCode == 345) return "R Ctrl";
        if (keyCode == 340) return "Shift";
        if (keyCode == 16)  return "1.8";
        if (keyCode == 42)  return "Shift";
        if (keyCode >= 48 && keyCode <= 57) return String.valueOf((char)(keyCode));
        if (keyCode >= 65 && keyCode <= 90) return String.valueOf((char)keyCode);
        if (keyCode >= 112 && keyCode <= 123) return "F" + (keyCode - 111);
        if (keyCode == 70) return "F";
        if (keyCode == 66) return "B";
        if (keyCode == 86) return "V";
        if (keyCode == 78) return "N";
        if (keyCode == 77) return "M";
        if (keyCode == 72) return "H";
        if (keyCode == 71) return "G";
        if (keyCode == 84) return "T";
        if (keyCode == 89) return "Y";
        if (keyCode == 85) return "U";
        if (keyCode == 73) return "I";
        if (keyCode == 79) return "O";
        if (keyCode == 80) return "P";
        return "K" + keyCode;
    }

    @Override
    public void renderEditor(DrawContext ctx, MinecraftClient mc, int mx, int my) {
        render(ctx, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), 0);
    }

    @Override public int getCalculatedWidth()  {
        int lines = cachedLines.isEmpty() ? 5 : cachedLines.size();
        return (int)((LABEL_W + 60) * (size / 60f));
    }
    @Override public int getCalculatedHeight() {
        int lines = cachedLines.isEmpty() ? 5 : cachedLines.size();
        return (int)((TITLE_H + lines * ROW_H + PAD * 2) * (size / 60f));
    }
}
