package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.DiffuseLighting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;

public class ArmorHud extends HudElement {

    private static final EquipmentSlot[] SLOTS = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };
    private static final int PAD       = 8;
    private static final int RADIUS    = 5;
    private static final int TITLE_H   = 20;
    private static final int SLOT_SZ   = 20;
    private static final int SLOT_GAP  = 3;
    private static final int TOTAL_W   = PAD * 2 + 4 * SLOT_SZ + 3 * SLOT_GAP;
    private static final int TOTAL_H   = TITLE_H + SLOT_SZ + PAD;

    private final ItemStack[] cachedStacks = new ItemStack[4];
    private final float[]     cachedDurPct = new float[4];
    private int  cacheTimer  = 0;
    private boolean positioned = false;

    public ArmorHud()             { super("Armor", new Dragging(-1, -1, 100, 50)); }
    public ArmorHud(int x, int y) { super("Armor", new Dragging(x, y, 100, 50)); }

    @Override public int getCalculatedWidth()  { return TOTAL_W; }
    @Override public int getCalculatedHeight() { return TOTAL_H; }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (++cacheTimer >= 10) {
            cacheTimer = 0;
            for (int i = 0; i < 4; i++) {
                ItemStack s = mc.player.getEquippedStack(SLOTS[i]);
                cachedStacks[i] = s;
                cachedDurPct[i] = (s != null && s.isDamageable() && s.getMaxDamage() > 0)
                        ? 1f - (float) s.getDamage() / s.getMaxDamage() : -1f;
            }
        }

        if (!positioned || dragging.getX() < 0) {
            dragging.setX(sw - TOTAL_W - 6);
            dragging.setY(sh - TOTAL_H - 6 - 76);
            positioned = true;
        }

        if (size != 60) {
            float factor = size / 60f;
            int baseX = (int) dragging.getX();
            int baseY = (int) dragging.getY();
            ctx.getMatrices().push();
            ctx.getMatrices().translate(baseX, baseY, 0);
            ctx.getMatrices().scale(factor, factor, 1f);
            drawAt(ctx, mc, 0, 0);
            ctx.getMatrices().pop();
            dragging.setWidth((int)(TOTAL_W * factor));
            dragging.setHeight((int)(TOTAL_H * factor));
            return;
        }

        dragging.setWidth(TOTAL_W);
        dragging.setHeight(TOTAL_H);
        drawAt(ctx, mc, (int)dragging.getX(), (int)dragging.getY());
    }

    private void drawAt(DrawContext ctx, MinecraftClient mc, int x, int y) {
        if (showBackground) HudRenderer.fillRounded(ctx, x, y, TOTAL_W, TOTAL_H, RADIUS, HudRenderer.BG);
        if (showBackground) ctx.fill(x, y, x + 2, y + TOTAL_H, HudRenderer.ORANGE);

        ctx.drawText(mc.textRenderer, "Armor", x + PAD + 2, y + (TITLE_H - 8) / 2, HudRenderer.ORANGE, false);
        ctx.fill(x + PAD, y + TITLE_H - 1, x + TOTAL_W - PAD, y + TITLE_H, 0x33FFFFFF);

        for (int i = 0; i < 4; i++) {
            ItemStack stack = cachedStacks[i];
            if (stack == null) continue;

            int sx = x + PAD + i * (SLOT_SZ + SLOT_GAP);
            int sy = y + TITLE_H + 1;

            ctx.fill(sx, sy, sx + SLOT_SZ, sy + SLOT_SZ, 0x55333333);

            if (!stack.isEmpty()) {
                DiffuseLighting.disableGuiDepthLighting();
                MatrixStack matrices = ctx.getMatrices();
                matrices.push();
                matrices.translate(sx + 2, sy + 2, 0);
                matrices.scale(SLOT_SZ - 4, SLOT_SZ - 4, 1.0f);
                ctx.drawItem(stack, 0, 0);
                ctx.drawStackOverlay(mc.textRenderer, stack, 0, 0);
                matrices.pop();

                float pct = cachedDurPct[i];
                if (pct >= 0f) {
                    int barW = Math.max(1, (int) ((SLOT_SZ - 4) * pct));
                    int col;
                    if (pct > 0.5f) {
                        float t = (pct - 0.5f) * 2f;
                        int r = (int) ((1f - t) * 255);
                        col = 0xFF000000 | (r << 16) | (0xCC << 8);
                    } else {
                        float t = pct * 2f;
                        int g = (int) (t * 0xCC);
                        col = 0xFF000000 | (0xFF << 16) | (g << 8);
                    }
                    ctx.fill(sx + 2, sy + SLOT_SZ - 3, sx + SLOT_SZ - 2, sy + SLOT_SZ - 1, 0xFF000000);
                    ctx.fill(sx + 2, sy + SLOT_SZ - 3, sx + 2 + barW,    sy + SLOT_SZ - 1, col);
                }
            }
        }
    }
}
