package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;
import ru.ryuzaki.util.FriendManager;

import java.util.Set;
import java.util.HashSet;

public class FriendsHud extends HudElement {

    private boolean positioned = false;
    private Set<String> lastFriends = new HashSet<>();
    private int animationTimer = 0;
    private int fadeOutTimer = 0;
    private boolean wasVisible = false;
    
    private static final int COLOR_ACCENT = 0xFFFF9900;
    private static final int COLOR_TEXT = 0xFFCCCCCC;
    private static final int COLOR_TEXT_DIM = 0xFF666666;
    private static final int COLOR_BG = HudRenderer.BG;
    private static final int COLOR_BORDER = HudRenderer.ORANGE_DIM;

    public FriendsHud() { super("Friends", new Dragging(-1, -1, 120, 60)); }
    public FriendsHud(int x, int y) { super("Friends", new Dragging(x, y, 120, 60)); }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        Set<String> friends = FriendManager.getFriends();
        int count = friends.size();
        
        if (count > 0) {
            if (!wasVisible) animationTimer = Math.min(animationTimer + 2, 20);
            wasVisible = true;
            fadeOutTimer = 20;
        } else {
            if (wasVisible) fadeOutTimer = Math.max(fadeOutTimer - 1, 0);
            if (fadeOutTimer == 0) wasVisible = false;
            animationTimer = Math.max(animationTimer - 1, 0);
        }
        
        if (animationTimer == 0 && count == 0) return;

        float alpha = Math.min(1f, animationTimer / 20f);
        if (fadeOutTimer < 20 && count == 0) alpha = fadeOutTimer / 20f;

        int padding = 6;
        int rowHeight = 14;
        int headerHeight = 18;
        int cornerRadius = 4;
        
        int panelWidth = 120;
        int panelHeight = padding * 2 + headerHeight + Math.max(count, 1) * rowHeight + 4;

        int bx, by;
        if (!positioned || dragging.getX() < 0) {
            bx = sw - panelWidth - 8;
            by = sh / 2 - panelHeight / 2;
            dragging.setX(bx);
            dragging.setY(by);
            dragging.setWidth(panelWidth);
            dragging.setHeight(panelHeight);
            positioned = true;
        }
        bx = (int) dragging.getX();
        by = (int) dragging.getY();

        int bgColor = withAlpha(COLOR_BG, (int)(200 * alpha));
        int borderColor = withAlpha(COLOR_BORDER, (int)(80 * alpha));
        int textColor = withAlpha(COLOR_TEXT, (int)(255 * alpha));
        int textDimColor = withAlpha(COLOR_TEXT_DIM, (int)(200 * alpha));
        int accentColor = withAlpha(COLOR_ACCENT, (int)(255 * alpha));

        HudRenderer.fillRounded(ctx, bx, by, panelWidth, panelHeight, cornerRadius, bgColor);
        HudRenderer.outlineRounded(ctx, bx, by, panelWidth, panelHeight, cornerRadius, borderColor);

        int titleY = by + padding;
        ctx.drawText(mc.textRenderer, Text.literal("Friends"), bx + padding, titleY, accentColor, false);
        ctx.drawText(mc.textRenderer, Text.literal("(" + count + ")"), bx + padding + mc.textRenderer.getWidth("Friends") + 4, titleY, textDimColor, false);
        ctx.fill(bx + padding, by + padding + headerHeight - 4, bx + panelWidth - padding, by + padding + headerHeight - 3, borderColor);

        int rowY = by + padding + headerHeight + 2;
        int idx = 0;
        for (String friend : friends) {
            if (idx >= 8) break;
            
            float rowAlpha = Math.max(0.5f, alpha - idx * 0.05f);
            int rowTextColor = withAlpha(COLOR_TEXT, (int)(255 * rowAlpha));
            
            ctx.drawText(mc.textRenderer, Text.literal(">"), bx + padding, rowY, accentColor, false);
            ctx.drawText(mc.textRenderer, Text.literal(friend), bx + padding + 12, rowY, rowTextColor, false);
            
            rowY += rowHeight;
            idx++;
        }

        if (count == 0) {
            ctx.drawText(mc.textRenderer, Text.literal("No friends"), bx + padding, rowY + 4, textDimColor, false);
        }

        dragging.setWidth(panelWidth);
        dragging.setHeight(panelHeight);
    }

    private int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((Math.max(0, Math.min(255, alpha)) & 0xFF) << 24);
    }

    @Override public int getCalculatedWidth() { return 120; }
    @Override public int getCalculatedHeight() { return 60; }
}
