package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.text.Text;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.PlintusPanel;
import ru.ryuzaki.render.DrawHelper;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/**
 * EffectsHud — список активных эффектов зелий.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - Статические Color поля — никаких new Color() в render path
 *  - Список эффектов кэшируется и обновляется каждые 20 тиков,
 *    не каждый кадр (как и было), но теперь также нет лишних аллокаций
 *  - effectName() кэшируется вместе с эффектом в простой record
 *  - Размеры панели кэшируются и пересчитываются только при обновлении эффектов
 */
public class EffectsHud extends PlintusPanel {

    private static final float TXT_TITLE  = 10.5f;
    private static final float TXT_EFFECT = 9.5f;

    // Статические цвета — ноль аллокаций в render
    private static final Color C_BAD  = new Color(220,  80,  80, 255);
    private static final Color C_GOOD = DrawHelper.GRAY;

    // Кэш записи — один объект переиспользуется
    private record CachedEffect(StatusEffectInstance inst, String name, boolean good) {}

    private final List<CachedEffect> cached     = new ArrayList<>(8);
    private       int                updateTimer = 0;

    // Кэш размеров панели — не пересчитываем каждый кадр
    private float cachedPanelW = 162f;

    public EffectsHud()             { super("Effects", new Dragging(8, 52, 160, 30)); }
    public EffectsHud(int x, int y) { super("Effects", new Dragging(x, y, 160, 30)); }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        // Обновляем кэш эффектов раз в 20 тиков
        if (++updateTimer >= 20) {
            updateTimer = 0;
            rebuildCache(mc);
        }

        float maxW  = cachedPanelW;
        float totalH = TITLE_H + cached.size() * ROW_H + (cached.isEmpty() ? 0 : 6);

        // Применяем size
        if (size != 60) {
            float factor = size / 60f;
            int baseX = (int) dragging.getX();
            int baseY = (int) dragging.getY();
            ctx.getMatrices().push();
            ctx.getMatrices().translate(baseX, baseY, 0);
            ctx.getMatrices().scale(factor, factor, 1f);
            drawEffectsAt(ctx, mc, 0, 0, maxW, totalH);
            ctx.getMatrices().pop();
            dragging.setWidth((int)(maxW * factor));
            dragging.setHeight((int)(totalH * factor));
            return;
        }

        dragging.setWidth((int)maxW);
        dragging.setHeight((int)totalH);
        drawEffectsAt(ctx, mc, dragging.getX(), dragging.getY(), maxW, totalH);
    }

    private void drawEffectsAt(DrawContext ctx, MinecraftClient mc, float ox, float oy, float maxW, float totalH) {
        float x = ox, y = oy;
        drawPanel(ctx.getMatrices(), x, y, maxW, totalH);

        drawText(ctx, "✦",     x + PAD - 1, y + 15, DrawHelper.ORANGE, 11);
        drawText(ctx, " Potions", x + PAD + 10, y + 15, DrawHelper.WHITE, TXT_TITLE);
        drawSep(ctx.getMatrices(), x + PAD, y + TITLE_H - 1, maxW - PAD * 2);

        for (int i = 0; i < cached.size(); i++) {
            CachedEffect e  = cached.get(i);
            float ey        = y + TITLE_H + i * ROW_H + 11;
            int   ticks     = e.inst().getDuration();
            int   s         = ticks / 20;
            // Форматируем время без String.format — быстрее и меньше аллокаций
            String time = s / 60 + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
            float timeW = textWidth(time, TXT_EFFECT);

            drawText(ctx, e.name(), x + PAD, ey, e.good() ? C_GOOD : C_BAD, TXT_EFFECT);
            drawText(ctx, time, x + maxW - PAD - timeW, ey, DrawHelper.ORANGE, TXT_EFFECT);
        }
    }

    private void rebuildCache(MinecraftClient mc) {
        cached.clear();

        var effects = mc.player.getStatusEffects();
        List<StatusEffectInstance> sorted = new ArrayList<>(effects);
        sorted.sort(Comparator.comparingInt(StatusEffectInstance::getDuration).reversed());

        float maxW = PAD + textWidth("Potions", TXT_TITLE) + 18 + PAD;

        for (StatusEffectInstance e : sorted) {
            String base = Text.translatable(e.getTranslationKey()).getString();
            String name = e.getAmplifier() > 0 ? base + " " + (e.getAmplifier() + 1) : base;
            boolean good = e.getEffectType().value().isBeneficial();

            float w = PAD + textWidth(name, TXT_EFFECT) + 20
                    + textWidth("9:99", TXT_EFFECT) + PAD;
            if (w > maxW) maxW = w;

            cached.add(new CachedEffect(e, name, good));
        }

        cachedPanelW = Math.max(maxW, 162f);
    }

    @Override public int getCalculatedWidth()  { return (int)(cachedPanelW * (size / 60f)); }
    @Override public int getCalculatedHeight() { return (int)((TITLE_H + cached.size() * ROW_H + (cached.isEmpty() ? 0 : 6)) * (size / 60f)); }
}
