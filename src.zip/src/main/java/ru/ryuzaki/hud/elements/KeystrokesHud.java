package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * KeystrokesHud — WASD + мышь + CPS.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - Убраны все вызовы MSDF DrawHelper.drawText() и PlintusPanel.drawText()
 *    Каждый MSDF вызов = shader switch + GPU draw.
 *    10 клавиш × 1-2 текста = 10-20 MSDF draws/кадр → 0.
 *  - Используем ctx.drawText() (vanilla batched renderer) — всё одним батчем
 *  - Фоны клавиш через DrawHelper.drawRect (шейдер скруглений) — без изменений,
 *    визуально идентично
 *  - Цвета как int ARGB — ноль new Color()
 *  - CPS счёт через простой цикл по массиву long[], никаких коллекций
 */
public class KeystrokesHud extends HudElement {

    private static final int   KS  = 22;
    private static final int   GAP = 2;
    private static final float R   = 4f;

    // Цвета как int — ноль аллокаций
    private static final int C_TEXT_PRESSED  = 0xFFFFFFFF;
    private static final int C_TEXT_NORMAL   = 0xFF888888;
    private static final int C_TEXT_CPS      = 0xFFFFC864; // pressed sub
    private static final int C_TEXT_CPS_OFF  = 0xFF505050;

    private boolean positioned = false;
    private final long[] lmbT = new long[20], rmbT = new long[20];
    private int lmbI, rmbI;
    private boolean wasL, wasR;

    public KeystrokesHud()             { super("Keystrokes", new Dragging(-1, -1, 68, 112)); }
    public KeystrokesHud(int x, int y) { super("Keystrokes", new Dragging(x, y, 68, 112)); }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        long handle = mc.getWindow().getHandle();
        boolean lmb = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT)  == GLFW.GLFW_PRESS;
        boolean rmb = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean w   = mc.options.forwardKey.isPressed();
        boolean a   = mc.options.leftKey.isPressed();
        boolean s   = mc.options.backKey.isPressed();
        boolean d   = mc.options.rightKey.isPressed();
        boolean spc = mc.options.jumpKey.isPressed();
        boolean snk = mc.options.sneakKey.isPressed();
        boolean spr = mc.options.sprintKey.isPressed();

        long now = System.currentTimeMillis();
        if (lmb && !wasL) lmbT[lmbI++ % 20] = now;
        if (rmb && !wasR) rmbT[rmbI++ % 20] = now;
        wasL = lmb; wasR = rmb;

        // CPS — простой цикл, ноль аллокаций
        int lCps = 0, rCps = 0;
        for (long t : lmbT) if (now - t < 1000) lCps++;
        for (long t : rmbT) if (now - t < 1000) rCps++;

        int totalW = KS * 3 + GAP * 2;
        int totalH = KS * 5 + GAP * 4;

        // Применяем size (если не 60)
        if (size != 60) {
            float factor = size / 60f;
            dragging.setWidth(totalW * factor);
            dragging.setHeight(totalH * factor);
            int bx = (int) dragging.getX();
            int by = (int) dragging.getY();
            ctx.getMatrices().push();
            ctx.getMatrices().translate(bx, by, 0);
            ctx.getMatrices().scale(factor, factor, 1f);
            bx = 0; by = 0;
            renderKeystrokes(ctx, mc, bx, by, KS, GAP, R);
            ctx.getMatrices().pop();
            return;
        }

        dragging.setWidth(totalW); dragging.setHeight(totalH);
        if (!positioned || dragging.getX() < 0) {
            dragging.setX(sw - totalW - 8);
            dragging.setY(sh / 2 - totalH / 2);
            positioned = true;
        }
        int bx = (int) dragging.getX();
        int by = (int) dragging.getY();

        renderKeystrokes(ctx, mc, bx, by, KS, GAP, R);
    }

    private void renderKeystrokes(DrawContext ctx, MinecraftClient mc,
                                  int bx, int by, int KS, int GAP, float R) {
        long handle = mc.getWindow().getHandle();
        boolean lmb = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT)  == GLFW.GLFW_PRESS;
        boolean rmb = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean w   = mc.options.forwardKey.isPressed();
        boolean a   = mc.options.leftKey.isPressed();
        boolean s   = mc.options.backKey.isPressed();
        boolean d   = mc.options.rightKey.isPressed();
        boolean spc = mc.options.jumpKey.isPressed();
        boolean snk = mc.options.sneakKey.isPressed();
        boolean spr = mc.options.sprintKey.isPressed();

        long now = System.currentTimeMillis();
        if (lmb && !wasL) lmbT[lmbI++ % 20] = now;
        if (rmb && !wasR) rmbT[rmbI++ % 20] = now;
        wasL = lmb; wasR = rmb;

        int lCps = 0, rCps = 0;
        for (long t : lmbT) if (now - t < 1000) lCps++;
        for (long t : rmbT) if (now - t < 1000) rCps++;

        int totalW = KS * 3 + GAP * 2;
        var ms = ctx.getMatrices();

        // Row 0: W
        key(ctx, mc, ms, bx + KS + GAP, by, KS, KS, "W", w);
        // Row 1: A S D
        key(ctx, mc, ms, bx,             by + KS + GAP, KS, KS, "A", a);
        key(ctx, mc, ms, bx + KS + GAP,  by + KS + GAP, KS, KS, "S", s);
        key(ctx, mc, ms, bx+(KS+GAP)*2,  by + KS + GAP, KS, KS, "D", d);
        // Row 2: Space
        key(ctx, mc, ms, bx, by + (KS+GAP)*2, totalW, KS, "Space", spc);
        // Row 3: Sneak / Sprint
        key(ctx, mc, ms, bx,            by + (KS+GAP)*3, KS,       KS, "C",      snk);
        key(ctx, mc, ms, bx + KS + GAP, by + (KS+GAP)*3, KS*2+GAP, KS, "LSHIFT", spr);
        // Row 4: LMB / RMB
        keyDouble(ctx, mc, ms, bx,                  by + (KS+GAP)*4, KS+KS/2, KS, "LMB", lCps + " CPS", lmb);
        keyDouble(ctx, mc, ms, bx + KS+KS/2 + GAP,  by + (KS+GAP)*4, KS+KS/2, KS, "RMB", rCps + " CPS", rmb);
    }

    private void key(DrawContext ctx, MinecraftClient mc, net.minecraft.client.util.math.MatrixStack ms,
                     int x, int y, int w, int h, String label, boolean pressed) {
        DrawHelper.drawRect(ms, x, y, w, h, R, pressed ? DrawHelper.KEY_PRESS : DrawHelper.BG);
        if (pressed) {
            DrawHelper.drawRect(ms, x + R, y, w - R*2, 1.5f, 0, DrawHelper.ORANGE);
        }
        int tw  = mc.textRenderer.getWidth(label);
        int tx  = x + (w - tw) / 2;
        int ty  = y + (h - 8)  / 2;
        int col = pressed ? C_TEXT_PRESSED : C_TEXT_NORMAL;
        ctx.drawText(mc.textRenderer, net.minecraft.text.Text.literal(label), tx, ty, col, false);
    }

    private void keyDouble(DrawContext ctx, MinecraftClient mc, net.minecraft.client.util.math.MatrixStack ms,
                           int x, int y, int w, int h, String top, String bot, boolean pressed) {
        DrawHelper.drawRect(ms, x, y, w, h, R, pressed ? DrawHelper.KEY_PRESS : DrawHelper.BG);
        if (pressed) DrawHelper.drawRect(ms, x + R, y, w - R*2, 1.5f, 0, DrawHelper.ORANGE);

        int topCol = pressed ? C_TEXT_PRESSED : C_TEXT_NORMAL;
        int botCol = pressed ? C_TEXT_CPS     : C_TEXT_CPS_OFF;

        int tw1 = mc.textRenderer.getWidth(top);
        int tw2 = mc.textRenderer.getWidth(bot);
        ctx.drawText(mc.textRenderer, net.minecraft.text.Text.literal(top), x + (w - tw1) / 2, y + 5,  topCol, false);
        ctx.drawText(mc.textRenderer, net.minecraft.text.Text.literal(bot), x + (w - tw2) / 2, y + 14, botCol, false);
    }

    @Override public int getCalculatedWidth()  { return (int)((KS * 3 + GAP * 2) * (size / 60f)); }
    @Override public int getCalculatedHeight() { return (int)((KS * 5 + GAP * 4) * (size / 60f)); }
}
