package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudRenderer;

/**
 * SessionStatsHud — инвентарь игрока (3×9 слотов) на экране.
 *
 * Особенности:
 *  - Инвентарь кэшируется раз в 6 кадров (снижает нагрузку при 240+ FPS).
 *  - Количество предметов рисуется вручную через drawText — избегаем
 *    нестабильного API drawItemInSlot, который меняет сигнатуру каждую версию.
 *  - Полоски прочности кэшируются как float[].
 */
public class SessionStatsHud extends HudElement {

    private static final int ROWS = 3, COLS = 9;
    private static final int SLOTS = ROWS * COLS;
    private static final int SLOT_SIZE = 16, SLOT_GAP = 2;
    private static final int PAD = 7, RADIUS = 5, TITLE_H = 20;
    private static final int GRID_W  = COLS * SLOT_SIZE + (COLS - 1) * SLOT_GAP;
    private static final int TOTAL_W = PAD * 2 + GRID_W;
    private static final int TOTAL_H = TITLE_H + ROWS * SLOT_SIZE + (ROWS - 1) * SLOT_GAP + PAD;

    private boolean positioned = false;

    // ── Счётчики сессии (используются MixinLivingEntity) ────────────────
    private int kills  = 0;
    private int deaths = 0;

    public void addKill()  { kills++;  }
    public void addDeath() { deaths++; }

    // ── Кэш инвентаря ────────────────────────────────────────────────
    private final ItemStack[] cachedStacks = new ItemStack[SLOTS];
    private final String[]    cachedCount  = new String[SLOTS];   // null = не рисовать
    private final float[]     cachedDurPct = new float[SLOTS];    // -1f = нет полоски
    private int cacheTimer = 0;

    public SessionStatsHud()             { super("Inventory", new Dragging(-1, -1, 170, 80)); }
    public SessionStatsHud(int x, int y) { super("Inventory", new Dragging(x, y, 170, 80)); }

    @Override public int getCalculatedWidth()  { return TOTAL_W; }
    @Override public int getCalculatedHeight() { return TOTAL_H; }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        // ── Обновляем кэш раз в 6 кадров ────────────────────────────
        if (++cacheTimer >= 6) {
            cacheTimer = 0;
            for (int i = 0; i < SLOTS; i++) {
                // Слоты 9–35 = инвентарь (не хотбар)
                ItemStack s = mc.player.getInventory().getStack(9 + i);
                cachedStacks[i] = s;
                if (!s.isEmpty()) {
                    cachedCount[i]  = s.getCount() > 1 ? String.valueOf(s.getCount()) : null;
                    cachedDurPct[i] = (s.isDamageable() && s.getMaxDamage() > 0)
                            ? 1f - (float) s.getDamage() / s.getMaxDamage() : -1f;
                } else {
                    cachedCount[i]  = null;
                    cachedDurPct[i] = -1f;
                }
            }
        }

        // ── Геометрия ────────────────────────────────────────────────
        if (!positioned || dragging.getX() < 0) {
            dragging.setX(sw - TOTAL_W - 6);
            dragging.setY(sh - TOTAL_H - 6);
            positioned = true;
        }
        dragging.setWidth(TOTAL_W);
        dragging.setHeight(TOTAL_H);

        int x = (int) dragging.getX(), y = (int) dragging.getY();

        // Применяем size
        if (size != 60) {
            float factor = size / 60f;
            ctx.getMatrices().push();
            ctx.getMatrices().translate(x, y, 0);
            ctx.getMatrices().scale(factor, factor, 1f);
            drawAt(ctx, mc, 0, 0);
            ctx.getMatrices().pop();
            dragging.setWidth((int)(TOTAL_W * factor));
            dragging.setHeight((int)(TOTAL_H * factor));
            return;
        }

        drawAt(ctx, mc, x, y);
    }

    private void drawAt(DrawContext ctx, MinecraftClient mc, int x, int y) {
        // ── Фон + акцентная полоса ────────────────────────────────────
        if (showBackground) HudRenderer.fillRounded(ctx, x, y, TOTAL_W, TOTAL_H, RADIUS, HudRenderer.BG);
        if (showBackground) ctx.fill(x, y, x + 2, y + TOTAL_H, HudRenderer.ORANGE);

        ctx.drawText(mc.textRenderer, "Inventory", x + PAD, y + (TITLE_H - 8) / 2, HudRenderer.ORANGE, false);
        ctx.fill(x + PAD, y + TITLE_H - 1, x + TOTAL_W - PAD, y + TITLE_H, 0x33FFFFFF);

        // ── Сетка слотов ─────────────────────────────────────────────
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                int idx = row * COLS + col;
                int sx  = x + PAD + col * (SLOT_SIZE + SLOT_GAP);
                int sy  = y + TITLE_H + row * (SLOT_SIZE + SLOT_GAP);

                ctx.fill(sx, sy, sx + SLOT_SIZE, sy + SLOT_SIZE, 0x55333333);

                ItemStack stack = cachedStacks[idx];
                if (stack == null || stack.isEmpty()) continue;

                ctx.drawItem(stack, sx, sy);

                // Количество — рисуем поверх предмета
                String count = cachedCount[idx];
                if (count != null) {
                    int tw = mc.textRenderer.getWidth(count);
                    int tx = sx + SLOT_SIZE - tw - 1;
                    int ty = sy + SLOT_SIZE - mc.textRenderer.fontHeight - 1;
                    ctx.drawText(mc.textRenderer, count, tx,     ty,     0xFF000000, false);
                    ctx.drawText(mc.textRenderer, count, tx + 1, ty + 1, 0xFFFFFFFF, false);
                }

                // Полоска прочности
                float pct = cachedDurPct[idx];
                if (pct >= 0f && pct < 1f) {
                    int barLen = Math.max(1, Math.round(13f * pct));
                    int g2 = (int) (255 * pct), r2 = 255 - g2;
                    ctx.fill(sx + 1, sy + 14, sx + 15, sy + 16, 0xFF000000);
                    ctx.fill(sx + 1, sy + 14, sx + 1 + barLen, sy + 15, (0xFF << 24) | (r2 << 16) | (g2 << 8));
                }
            }
        }
    }
}