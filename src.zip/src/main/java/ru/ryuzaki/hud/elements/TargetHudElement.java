package ru.ryuzaki.hud.elements;

import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;

// Merged into TargetHud
public class TargetHudElement extends HudElement {
    public TargetHudElement() { super("TargetElement", new Dragging(0, 0, 1, 1)); }
    public TargetHudElement(int x, int y) { super("TargetElement", new Dragging(x, y, 1, 1)); }
    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {}
}
