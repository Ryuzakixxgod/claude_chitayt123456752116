package ru.ryuzaki.hud.elements;

import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;

// Координаты встроены в WatermarkHud
public class CoordinatesHud extends HudElement {
    public CoordinatesHud() { super("Coordinates", new Dragging(0, 0, 1, 1)); }
    public CoordinatesHud(int x, int y) { super("Coordinates", new Dragging(x, y, 1, 1)); }
    @Override public void render(DrawContext ctx, int sw, int sh, float delta) {}
}
