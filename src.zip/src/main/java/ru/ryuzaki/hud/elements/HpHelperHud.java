package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;

public class HpHelperHud extends HudElement {
    public HpHelperHud() { super("HpHelper", new Dragging(8, 70, 80, 14)); }
    public HpHelperHud(int x, int y) { super("HpHelper", new Dragging(x, y, 80, 14)); }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        float hp = Math.max(0.0F, mc.player.getHealth());
        float maxHp = Math.max(1.0F, mc.player.getMaxHealth());
        float ratio = Math.max(0.0F, Math.min(1.0F, hp / maxHp));

        int x = getX();
        int y = getY();
        int w = Math.max(80, getWidth());
        int h = Math.max(14, getHeight());
        dragging.setWidth(w);
        dragging.setHeight(h);

        drawBackground(ctx, x, y, w, h);
        int fillW = Math.max(1, Math.round((w - 4) * ratio));
        int color = ratio > 0.55F ? rgba(76, 220, 89, 210) : ratio > 0.25F ? rgba(250, 200, 30, 210) : rgba(239, 68, 68, 210);
        ctx.fill(x + 2, y + h - 4, x + 2 + fillW, y + h - 2, color);

        String text = Math.round(hp) + " / " + Math.round(maxHp) + " HP";
        ctx.drawText(mc.textRenderer, text, x + 4, y + 3, 0xFFEDE8FF, false);
    }
}
