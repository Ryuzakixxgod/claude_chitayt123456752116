package ru.ryuzaki.hud.elements;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.hud.Dragging;
import ru.ryuzaki.hud.HudElement;

public class SpeedHud extends HudElement {
    public SpeedHud() { super("Speed", new Dragging(8, 54, 80, 14)); }
    public SpeedHud(int x, int y) { super("Speed", new Dragging(x, y, 80, 14)); }

    @Override
    public void render(DrawContext ctx, int sw, int sh, float delta) {
        // Merged into CoordinatesHud as BPS
    }
}
