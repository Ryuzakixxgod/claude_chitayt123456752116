package ru.ryuzaki.hud;

import net.minecraft.client.gui.DrawContext;

/**
 * Утилиты рендера HUD — компактный obsidian/crimson visual language.
 */
public class HudRenderer {

    public static final int BG         = 0xB80A0A0A;
    public static final int BG_DARK    = 0xE4050505;
    public static final int SURFACE    = 0xC8101010;
    public static final int SURFACE_2  = 0xA8141414;
    public static final int ACCENT     = 0xFFFF3030;
    public static final int ACCENT_DIM = 0xFFC91F1F;
    public static final int WHITE      = 0xFFF2F2F2;
    public static final int GRAY       = 0xFFA0A0A0;
    public static final int MUTED      = 0xFF5E5E5E;
    public static final int BORDER     = 0x22FFFFFF;
    public static final int BORDER_HOT = 0x70FF4040;
    public static final int SHADOW     = 0x8C000000;
    public static final int CELL_BG    = 0x38181818;
    public static final int KEY_PRESS  = 0x88FF3030;

    public static final int ORANGE     = ACCENT;
    public static final int ORANGE_DIM = ACCENT_DIM;

    public static void material(DrawContext ctx, int x, int y, int w, int h, int r) {
        shadow(ctx, x, y, w, h, r, 0.72f);
        fillRounded(ctx, x, y, w, h, r, BG);
        ctx.fill(x + r, y + 1, x + Math.max(r, w - r), y + 2, 0x18FFFFFF);
        outlineRounded(ctx, x, y, w, h, r, BORDER);
    }

    public static void compactMaterial(DrawContext ctx, int x, int y, int w, int h, int r, float hot) {
        float h2 = Math.max(0.0f, Math.min(1.0f, hot));
        shadow(ctx, x, y, w, h, r, 0.48f + h2 * 0.22f);
        fillRounded(ctx, x, y, w, h, r, mix(SURFACE, BG_DARK, 0.35f));
        if (h2 > 0.01f) {
            fillRounded(ctx, x, y, w, h, r, withAlpha(ACCENT_DIM, (int) (18 * h2)));
            edge(ctx, x, y, w, h, r, h2);
        }
        outlineRounded(ctx, x, y, w, h, r, withAlpha(WHITE, (int) (18 + h2 * 24)));
    }

    public static void shadow(DrawContext ctx, int x, int y, int w, int h, int r, float strength) {
        int a1 = (int) (42 * strength);
        int a2 = (int) (22 * strength);
        fillRounded(ctx, x - 2, y + 3, w + 4, h + 8, r + 4, rgba(0, 0, 0, a2));
        fillRounded(ctx, x - 1, y + 1, w + 2, h + 3, r + 2, rgba(0, 0, 0, a1));
    }

    public static void edge(DrawContext ctx, int x, int y, int w, int h, int r, float strength) {
        int alpha = (int) (80 * Math.max(0.0f, Math.min(1.0f, strength)));
        ctx.fill(x + r, y, x + Math.max(r, w - r), y + 1, withAlpha(ACCENT, alpha));
        ctx.fill(x + 1, y + r, x + 2, y + h - r, withAlpha(ACCENT, alpha / 2));
    }

    public static int withAlpha(int color, int alpha) {
        return (color & 0x00FFFFFF) | ((Math.max(0, Math.min(255, alpha)) & 0xFF) << 24);
    }

    public static int mix(int a, int b, float t) {
        float c = Math.max(0.0f, Math.min(1.0f, t));
        int aa = (a >>> 24) & 255, ar = (a >>> 16) & 255, ag = (a >>> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >>> 16) & 255, bg = (b >>> 8) & 255, bb = b & 255;
        return rgba(
                Math.round(ar + (br - ar) * c),
                Math.round(ag + (bg - ag) * c),
                Math.round(ab + (bb - ab) * c),
                Math.round(aa + (ba - aa) * c)
        );
    }

    /**
     * Скруглённый прямоугольник через 9-patch заливку пикселями.
     * r = радиус скругления (обычно 4-6px).
     */
    public static void fillRounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        if (r <= 0) { ctx.fill(x, y, x + w, y + h, color); return; }
        r = Math.min(r, Math.min(w, h) / 2);

        // Центральный прямоугольник
        ctx.fill(x + r, y,     x + w - r, y + h,     color);
        // Левая и правая полосы
        ctx.fill(x,     y + r, x + r,     y + h - r, color);
        ctx.fill(x+w-r, y + r, x + w,     y + h - r, color);
        // Углы (окружность)
        fillCorner(ctx, x + r,     y + r,     r, color, 0); // top-left
        fillCorner(ctx, x + w - r, y + r,     r, color, 1); // top-right
        fillCorner(ctx, x + r,     y + h - r, r, color, 2); // bottom-left
        fillCorner(ctx, x + w - r, y + h - r, r, color, 3); // bottom-right
    }

    /** Рамка скруглённого прямоугольника */
    public static void outlineRounded(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
        r = Math.min(r, Math.min(w, h) / 2);
        // Горизонтальные линии
        ctx.fill(x + r, y,       x + w - r, y + 1,     color);
        ctx.fill(x + r, y + h-1, x + w - r, y + h,     color);
        // Вертикальные линии
        ctx.fill(x,       y + r, x + 1,     y + h - r, color);
        ctx.fill(x + w-1, y + r, x + w,     y + h - r, color);
    }

    /**
     * Chord-based corner fill — O(r) вместо O(r²).
     * Для каждой горизонтальной строки y вычисляем половину ширины дуги
     * через √ и рисуем одну горизонтальную линию ctx.fill().
     *
     * Было: r×r вызовов Math.sqrt + r×r ctx.fill() (на пиксель)
     * Стало: r вызовов Math.sqrt + r ctx.fill() (на строку)
     *
     * При r=8: 64 sqrt + 64 fill → 8 sqrt + 8 fill (в 8 раз быстрее)
     */
    private static void fillCorner(DrawContext ctx, int cx, int cy, int r, int color, int quadrant) {
        if (r <= 0) return;

        int xDir = (quadrant == 1 || quadrant == 3) ? 1 : -1;
        int yDir = (quadrant == 2 || quadrant == 3) ? 1 : -1;

        for (int dy = 0; dy < r; dy++) {
            // Хорда на строке dy: √(r² - (r-dy)²) = √(2·r·dy - dy²)
            // dy=0: ширина=0, dy=r: ширина=r
            // Вместо вычисления для каждого пикселя — для каждой СТРОКИ
            double chordHalf = Math.sqrt(Math.max(0.0, 2.0 * r * dy - (double) dy * dy));
            int halfWidth = (int) Math.ceil(chordHalf);

            int y = cy + dy * yDir;
            int x1, x2;
            if (xDir == 1) {
                x1 = cx;
                x2 = cx + halfWidth;
            } else {
                x1 = cx - halfWidth;
                x2 = cx;
            }

            if (x1 < x2) {
                ctx.fill(x1, y, x2, y + 1, color);
            }
        }
    }

    /** Полоса прогресса */
    public static void fillBar(DrawContext ctx, int x, int y, int w, int h, float pct, int bgColor, int fgColor, int r) {
        fillRounded(ctx, x, y, w, h, r, bgColor);
        int fw = (int)(w * Math.max(0, Math.min(1, pct)));
        if (fw > 0) {
            if (fw >= w) fillRounded(ctx, x, y, fw, h, r, fgColor);
            else {
                ctx.fill(x, y, x + fw, y + h, fgColor);
            }
        }
    }

    /** Цвет HP в зависимости от процента */
    public static int hpColor(float pct) {
        if (pct > 0.5f) return 0xFF55CC55;
        if (pct > 0.25f) return 0xFFCCAA00;
        return 0xFFCC4444;
    }

    protected static int rgba(int r, int g, int b, int a) {
        return ((a & 255) << 24) | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255);
    }
}
