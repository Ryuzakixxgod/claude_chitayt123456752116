package ru.ryuzaki.hud;

/**
 * Dragging — вспомогательный класс для перетаскивания HUD элементов.
 */
public class Dragging {
    private float x, y, width = 100, height = 20;
    private boolean dragging;
    private float offX, offY;

    public Dragging(float x, float y) { this.x=x; this.y=y; }
    public Dragging(int x, int y, int width, int height) { this.x=x; this.y=y; this.width=width; this.height=height; }

    public void onMouseClick(int mx, int my, int btn) {
        if (btn==0 && isHovered(mx,my)) { dragging=true; offX=mx-x; offY=my-y; }
    }
    public void onMouseRelease(int btn) { if (btn==0) dragging=false; }
    public void onMouseDrag(int mx, int my) { if (dragging) { x=mx-offX; y=my-offY; } }
    public boolean isHovered(int mx, int my) { return mx>=x&&mx<=x+width&&my>=y&&my<=y+height; }
    public boolean isDragging() { return dragging; }

    public float getX()      { return x; }
    public float getY()      { return y; }
    public int   getWidth()  { return (int)width; }
    public int   getHeight() { return (int)height; }
    public void  setWidth(float w)  { this.width=w; }
    public void  setHeight(float h) { this.height=h; }
    public void  setX(float x) { this.x=x; }
    public void  setY(float y) { this.y=y; }
}
