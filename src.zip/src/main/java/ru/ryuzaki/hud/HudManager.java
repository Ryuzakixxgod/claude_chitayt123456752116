package ru.ryuzaki.hud;

import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.hud.elements.*;
import ru.ryuzaki.hud.elements.BindingHud;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class HudManager {

    private static final class Holder {
        static final HudManager INSTANCE = new HudManager();
    }
    public static HudManager getInstance() { return Holder.INSTANCE; }

    private final List<HudElement> elements = new ArrayList<>();
    private WatermarkHud watermark;

    private HudManager() {}

    public void init() {
        watermark = new WatermarkHud(6, 6);
        elements.add(watermark);

        EffectsHud effects = new EffectsHud(6, 52);
        effects.enabled = true;
        elements.add(effects);

        KeystrokesHud keys = new KeystrokesHud(0, 0);
        keys.enabled = true;
        elements.add(keys);

        ArmorHud armor = new ArmorHud(0, 0);
        armor.enabled = true;
        elements.add(armor);

        SessionStatsHud inv = new SessionStatsHud(0, 0);
        inv.enabled = true;
        elements.add(inv);

        TargetHud target = new TargetHud(0, 0);
        target.enabled = true;
        elements.add(target);

        CoordinatesHud coord = new CoordinatesHud(); coord.enabled = false; elements.add(coord);
        SpeedHud spd = new SpeedHud(); spd.enabled = false; elements.add(spd);
        TargetHudElement tge = new TargetHudElement(); tge.enabled = false; elements.add(tge);
        HpHelperHud hp = new HpHelperHud(); hp.enabled = false; elements.add(hp);

        BindingHud bindings = new BindingHud(); bindings.enabled = true; elements.add(bindings);

        FriendsHud friends = new FriendsHud(); friends.enabled = false; elements.add(friends);
    }

    public WatermarkHud getWatermark() { return watermark; }

    public void render(DrawContext ctx, int sw, int sh, float delta) {
        for (HudElement e : elements) {
            if (e.enabled) e.render(ctx, sw, sh, delta);
        }
    }

    public void onMouseClick  (int mx, int my, int btn) { elements.forEach(e -> e.onMouseClick(mx, my, btn)); }
    public void onMouseRelease(int btn)                  { elements.forEach(e -> e.onMouseRelease(btn)); }
    public void onMouseDrag   (int mx, int my)           { elements.forEach(e -> e.onMouseDrag(mx, my)); }

    public List<HudElement> getElements() { return Collections.unmodifiableList(elements); }
}