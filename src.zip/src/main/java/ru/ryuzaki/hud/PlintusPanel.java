package ru.ryuzaki.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Font;
import ru.ryuzaki.render.msdf.Fonts;

import java.awt.Color;

/**
 * Base class for all HUD panels.
 * Provides: rounded background, separator, text drawing with MSDF font fallback.
 */
public abstract class PlintusPanel extends HudElement {

    protected static final float RADIUS    = 6f;
    protected static final float PAD       = 8f;
    protected static final float TITLE_H   = 22f;
    protected static final float ROW_H     = 16f;

    public PlintusPanel(String name, Dragging dragging) {
        super(name, dragging);
    }

    // ── Drawing helpers ───────────────────────────────────────────────

    protected void drawPanel(MatrixStack ms, float x, float y, float w, float h) {
        DrawHelper.drawRect(ms, x - 1.0f, y + 2.0f, w + 2.0f, h + 4.0f, RADIUS + 3.0f, new Color(0, 0, 0, 46));
        DrawHelper.drawRect(ms, x, y, w, h, RADIUS, new Color(8, 8, 8, 205));
        DrawHelper.drawRect(ms, x + 1.0f, y + 1.0f, w - 2.0f, 1.0f, 0.5f, new Color(255, 255, 255, 18));
    }

    protected void drawSep(MatrixStack ms, float x, float y, float w) {
        DrawHelper.drawRect(ms, x, y, w, 1, 0, new Color(255, 255, 255, 18));
    }

    protected void drawText(DrawContext ctx, String text, float x, float y, Color color, float size) {
        drawText(ctx, text, x, y, color, size, true);
    }

    protected void drawText(DrawContext ctx, String text, float x, float y, Color color, float size, boolean bold) {
        if (text == null || text.isEmpty()) return;
        Font font = bold ? Fonts.BOLD : Fonts.MEDIUM;
        if (font != null) {
            try {
                DrawHelper.drawText(
                    ctx.getMatrices().peek().getPositionMatrix(),
                    font.getFont(size), text, x, y, color
                );
                return;
            } catch (Exception ignored) {}
        }
        // MC fallback
        int argb = colorToArgb(color);
        ctx.drawText(MinecraftClient.getInstance().textRenderer, text, (int)x, (int)(y - 8), argb, false);
    }

    protected float textWidth(String text, float size) {
        return textWidth(text, size, true);
    }

    protected float textWidth(String text, float size, boolean bold) {
        if (text == null) return 0;
        Font font = bold ? Fonts.BOLD : Fonts.MEDIUM;
        if (font != null) return font.getWidth(text, size);
        return MinecraftClient.getInstance().textRenderer.getWidth(text);
    }

    protected float textHeight(float size) {
        if (Fonts.BOLD != null) return Fonts.BOLD.getLineHeight(size);
        return 8f;
    }

    protected static int colorToArgb(Color c) {
        return (c.getAlpha() << 24) | (c.getRed() << 16) | (c.getGreen() << 8) | c.getBlue();
    }
}
