package ru.ryuzaki.hud;

// src/main/java/ru/ryuzaki/hud/HudElement.java

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.settings.Setting;
import java.util.ArrayList;
import java.util.List;

public abstract class HudElement {
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    public String name;
    public boolean enabled = true;
    public float scale = 1.0f;  // масштаб элемента (0.5 - 2.0), legacy
    public int   size  = 60;    // размер в процентах: 0=30%, 60=100%, 100=150%
    public Dragging dragging;
    public static boolean showBackground = true;

    public HudElement(String name, float x, float y) {
        this.name     = name;
        this.dragging = new Dragging(x, y);
    }

    /** Второй конструктор — принимает готовый Dragging (для WatermarkHud, EffectsHud) */
    public HudElement(String name, Dragging drag) {
        this.name     = name;
        this.dragging = drag;
    }

    /**
     * Рендер элемента.
     * sw, sh — размеры экрана (scaled width/height).
     * delta  — tickDelta.
     */
    public abstract void render(DrawContext ctx, int sw, int sh, float delta);

    private final List<Setting> settings = new ArrayList<>();
    protected void addSettings(Setting... s) { for (Setting x : s) settings.add(x); }
    public List<Setting> getSettings() { return settings; }

    public int getX()      { return (int) dragging.getX(); }
    public int getY()      { return (int) dragging.getY(); }
    public int getWidth()  { return (int) dragging.getWidth(); }
    public int getHeight() { return (int) dragging.getHeight(); }

    /** Рисует рамку выделения в HUD Editor */
    public void renderEditor(DrawContext ctx, MinecraftClient mc, int mx, int my) {
        MinecraftClient mc2 = MinecraftClient.getInstance();
        render(ctx, mc2.getWindow().getScaledWidth(), mc2.getWindow().getScaledHeight(), 0);
        float rx = dragging.getX(), ry = dragging.getY();
        float rw = dragging.getWidth(), rh = dragging.getHeight();
        ctx.fill((int)rx-1, (int)ry-1, (int)(rx+rw)+1, (int)ry,           HudRenderer.BORDER_HOT);
        ctx.fill((int)rx-1, (int)(ry+rh), (int)(rx+rw)+1, (int)(ry+rh)+1, HudRenderer.BORDER_HOT);
        ctx.fill((int)rx-1, (int)ry, (int)rx, (int)(ry+rh),               HudRenderer.BORDER_HOT);
        ctx.fill((int)(rx+rw), (int)ry, (int)(rx+rw)+1, (int)(ry+rh),     HudRenderer.BORDER_HOT);
        ctx.drawText(mc.textRenderer,
                net.minecraft.text.Text.literal(name), (int)rx+2, (int)ry+2, 0xFFFFFFFF, false);
    }

    protected void drawBackground(DrawContext ctx, float x, float y, float w, float h) {
        if (!showBackground) return;
        ru.ryuzaki.util.RenderUtils.drawRoundedRect(ctx, x, y, w, h, 3,
                new java.awt.Color(0, 0, 0, 180).getRGB());
    }


    // ──────────────────────────────────────────────────────────────────
    //  ОБЩИЕ УТИЛИТЫ — используются всеми HUD-элементами
    // ──────────────────────────────────────────────────────────────────
    protected static void fillRound(DrawContext ctx, int x, int y, int x2, int y2, int col, int r) {
        if (x2 <= x || y2 <= y) return;
        r = Math.min(r, Math.min((x2 - x) / 2, (y2 - y) / 2));
        if (r <= 0) { ctx.fill(x, y, x2, y2, col); return; }
        ctx.fill(x + r, y,       x2 - r, y2,     col);
        ctx.fill(x,     y + r,   x + r,  y2 - r, col);
        ctx.fill(x2 - r, y + r,  x2,     y2 - r, col);
        for (int i = 0; i < r; i++) {
            int w = r - (int) Math.sqrt(Math.max(0.0, (double)r*r - (double)(r-1-i)*(r-1-i)));
            ctx.fill(x  + w,     y  + i,     x  + r,  y  + i + 1, col);
            ctx.fill(x2 - r,     y  + i,     x2 - w,  y  + i + 1, col);
            ctx.fill(x  + w,     y2 - i - 1, x  + r,  y2 - i,     col);
            ctx.fill(x2 - r,     y2 - i - 1, x2 - w,  y2 - i,     col);
        }
    }

    protected static void borderRound(DrawContext ctx, int x, int y, int x2, int y2, int col, int r) {
        if (x2 <= x || y2 <= y) return;
        r = Math.min(r, Math.min((x2 - x) / 2, (y2 - y) / 2));
        ctx.fill(x + r,  y,      x2 - r, y + 1,  col);
        ctx.fill(x + r,  y2 - 1, x2 - r, y2,     col);
        ctx.fill(x,      y + r,  x + 1,  y2 - r, col);
        ctx.fill(x2 - 1, y + r,  x2,     y2 - r, col);
        for (int i = 0; i < r; i++) {
            int w = r - (int) Math.sqrt(Math.max(0.0, (double)r*r - (double)(r-1-i)*(r-1-i)));
            ctx.fill(x  + w,     y  + i,     x  + w + 1, y  + i + 1, col);
            ctx.fill(x2 - w - 1, y  + i,     x2 - w,     y  + i + 1, col);
            ctx.fill(x  + w,     y2 - i - 1, x  + w + 1, y2 - i,     col);
            ctx.fill(x2 - w - 1, y2 - i - 1, x2 - w,     y2 - i,     col);
        }
    }

    protected static int rgba(int r, int g, int b, int a) {
        a = Math.max(0, Math.min(255, a));
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    protected static int[] hsv(float h, float s, float v) {
        h = h % 1f; if (h < 0) h += 1f;
        int i = (int)(h * 6);
        float f = h*6-i, p = v*(1-s), q = v*(1-f*s), t = v*(1-(1-f)*s);
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r=v; g=t; b=p; } case 1 -> { r=q; g=v; b=p; }
            case 2 -> { r=p; g=v; b=t; } case 3 -> { r=p; g=q; b=v; }
            case 4 -> { r=t; g=p; b=v; } default ->{ r=v; g=p; b=q; }
        }
        return new int[]{ (int)(r*255), (int)(g*255), (int)(b*255) };
    }

    protected static float lerp(float a, float b, float t) { return a + (b - a) * t; }

    /**
     * Радужный горизонтальный градиент — ОДИН ctx.fillGradient вместо W пиксельных fill().
     * До: ~150 draw calls. После: 1 draw call.
     * ctx.fillGradient использует нативный Minecraft gradient shader.
     */
    protected static void fillGradientH(DrawContext ctx, int x, int y, int w, int h,
                                        float hue, float sat, float val, int alpha) {
        // Берём только начальный и конечный цвет — экономим 148 draw calls на элемент
        int[] cStart = hsv(hue                % 1f, sat, val);
        int[] cEnd   = hsv((hue + 0.20f)      % 1f, sat, val);
        int   colA   = rgba(cStart[0], cStart[1], cStart[2], alpha);
        int   colB   = rgba(cEnd[0],   cEnd[1],   cEnd[2],   alpha);
        ctx.fillGradient(x, y, x + w, y + h, colA, colB);
    }

    protected static void drawAccentBar(DrawContext ctx, int x, int y, int h, int[] c, int baseAlpha) {
        for (int i = 0; i < 3; i++)
            ctx.fill(x, y + 2 + i, x + 1, y + h - 2 - i,
                    rgba(c[0], c[1], c[2], (int)(baseAlpha * (1f - i * 0.28f))));
    }

    public void onMouseClick(int mx, int my, int btn) { dragging.onMouseClick(mx, my, btn); }
    public void onMouseRelease(int btn)               { dragging.onMouseRelease(btn); }
    public void onMouseDrag(int mx, int my)           { dragging.onMouseDrag(mx, my); }
    public boolean isDragging()                       { return dragging.isDragging(); }

    /**
     * Рендерит элемент с применением size (новый способ).
     * size=60 → scale=1.0, size<60 → масштаб уменьшается, size>60 → увеличивается.
     * Центр масштабирования — верхний левый угол элемента (как в GUI).
     */
    public void renderWithSize(DrawContext ctx, int sw, int sh, float delta) {
        float factor = size / 60f;
        float w = dragging.getWidth()  * factor;
        float h = dragging.getHeight() * factor;

        int baseX = (int) dragging.getX();
        int baseY = (int) dragging.getY();
        int newX  = baseX;
        int newY  = baseY;

        ctx.getMatrices().push();
        ctx.getMatrices().translate(newX, newY, 0);
        ctx.getMatrices().scale(factor, factor, 1f);

        dragging.setX(0);
        dragging.setY(0);
        dragging.setWidth(w / factor);
        dragging.setHeight(h / factor);
        render(ctx, sw, sh, delta);
        dragging.setX(baseX);
        dragging.setY(baseY);
        dragging.setWidth(w / factor);
        dragging.setHeight(h / factor);

        ctx.getMatrices().pop();
    }

    /**
     * Рассчитывает размеры элемента БЕЗ рендера.
     * Используется для hover-теста в HUD Editor до фактического рендера.
     * По умолчанию возвращает текущие размеры dragging.
     * Переопределить в наследниках для динамических размеров.
     */
    public int getCalculatedWidth()  { return (int) dragging.getWidth(); }
    public int getCalculatedHeight() { return (int) dragging.getHeight(); }

    /** Проверка попадания курсора в элемент с учётом size. */
    public boolean isHoveredBy(int mx, int my) {
        float factor = size / 60f;
        float w = dragging.getWidth()  * factor;
        float h = dragging.getHeight() * factor;
        return mx >= dragging.getX() && mx <= dragging.getX() + w
                && my >= dragging.getY() && my <= dragging.getY() + h;
    }
}
