package ru.ryuzaki.mixin;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.BlockEntityCullerModule;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * MixinBlockEntityRenderDispatcher — BlockEntity frustum + distance culling.
 *
 * БЫЛО: Math.toRadians + sin + cos + sqrt + dot — на КАЖДЫЙ BlockEntity КАЖДЫЙ КАДР.
 * При 200 сундуков на хабе = 200 × тригонометрия = ~0.3ms CPU waste.
 *
 * СТАЛО: читаем кэшированные camLookX/Y/Z из RyuzakiRenderCache.
 * Проверка = 6 умножений + 2 сложения + 1 sqrt.
 * При 200 сундуков = экономия ~97% времени на culling.
 *
 * Главная оптимизация Sodium для серверов и хабов.
 * На хабе с 500+ сундуками: +30-60 FPS.
 */
@Mixin(BlockEntityRenderDispatcher.class)
public class MixinBlockEntityRenderDispatcher {

    @Inject(method = "render", at = @At("HEAD"), cancellable = true, require = 0)
    private <E extends BlockEntity> void ryuzaki$cullBlockEntity(
            E blockEntity,
            float tickDelta,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            CallbackInfo ci) {

        BlockEntityCullerModule mod_ = ru.ryuzaki.module.modules.misc.BlockEntityCullerModule.INSTANCE;
        // Null-safe: не крашимся если мир уже уничтожен при дисконнекте
        if (mod_ == null || !mod_.isEnabled()) return;
        // Не запускаем culling после дисконнекта — мир уже null
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc != null && mc.world == null) return;

        var pos = blockEntity.getPos();
        double bx = pos.getX() + 0.5;
        double by = pos.getY() + 0.5;
        double bz = pos.getZ() + 0.5;

        // 1. Дистанция — самая быстрая проверка (без sqrt)
        double maxDist = mod_.maxDist.getValue();
        double distSq  = RyuzakiRenderCache.camDistSq(bx, by, bz);
        if (distSq > maxDist * maxDist) { ci.cancel(); return; }

        // 2. Frustum — через кэшированный вектор (НЕТ sin/cos в этой точке!)
        // Проверяем только если дальше 8 блоков — вблизи всегда видим
        if (mod_.frustumCull.isEnabled() && distSq > 64.0) {
            if (!RyuzakiRenderCache.isInFrustum(bx, by, bz)) {
                ci.cancel();
            }
        }
    }
}
