package ru.ryuzaki.mixin;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;

/**
 * MixinLivingEntityRenderer — stripped to avoid per-entity render overhead.
 * SmartLOD removed: cancelling renders caused flicker + mixin cost per entity.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class MixinLivingEntityRenderer<
        T extends net.minecraft.entity.LivingEntity,
        S extends LivingEntityRenderState,
        M extends net.minecraft.client.render.entity.model.EntityModel<? super S>> {
    // intentionally empty
}
