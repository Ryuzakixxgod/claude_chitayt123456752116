package ru.ryuzaki.mixin;
// src/main/java/ru/ryuzaki/mixin/MixinPlayerEntityRenderer.java

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.visual.CustomSkinModule;

@Mixin(PlayerEntityRenderer.class)
public abstract class MixinPlayerEntityRenderer {

    // В 1.21.4 updateRenderState заполняет PlayerEntityRenderState
    // Именно здесь устанавливается текстура скина — перехватываем после
    @Inject(method = "updateRenderState", at = @At("RETURN"))
    private void ryuzaki$customSkin(AbstractClientPlayerEntity player,
                                    PlayerEntityRenderState state,
                                    float tickDelta,
                                    CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || !player.equals(mc.player)) return;

        CustomSkinModule mod = ru.ryuzaki.module.modules.visual.CustomSkinModule.INSTANCE;
        if (mod == null) return;

        Identifier custom = mod.getActiveTexture();
        if (custom == null) return;

        // Заменяем текстуру скина в RenderState
        // skinTextures — поле PlayerEntityRenderState
        try {
            var field = state.getClass().getDeclaredField("skinTextures");
            field.setAccessible(true);
            var current = field.get(state);
            if (current instanceof net.minecraft.client.util.SkinTextures st) {
                // Создаём новый SkinTextures с нашей текстурой
                var newSkin = new net.minecraft.client.util.SkinTextures(
                        custom,
                        st.textureUrl(),
                        st.capeTexture(),
                        st.elytraTexture(),
                        st.model(),
                        st.secure()
                );
                field.set(state, newSkin);
            }
        } catch (Exception ignored) {
            // Если reflection не сработал — скин не меняется, краша нет
        }
    }
}// PlayerOutline is applied via getRenderLayer returning outline layer
// Already handled by PlayerOutlineModule.getColor() which is read from MixinPlayerEntityRenderer
