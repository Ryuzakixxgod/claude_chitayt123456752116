package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.ChunkCullingModule;
import ru.ryuzaki.render.ChunkVisibilityGraph;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * MixinWorldRendererOcclusion — оптимизации цикла setupTerrain.
 *
 * setupTerrain() = 1-3ms CPU каждый кадр:
 *   - итерирует все видимые секции
 *   - проверяет нужно ли перестраивать
 *   - обновляет граф видимости
 *
 * Оптимизации:
 * 1. Throttle: при стоячей камере и FPS > 80 пропускаем каждый 2й кадр
 * 2. Обновляем ChunkVisibilityGraph перед setupTerrain — он нужен свежим
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRendererOcclusion {

    private float  lastYaw = 0, lastPitch = 0;
    private double lastX = 0, lastY = 0, lastZ = 0;
    private int    skipCount = 0;

    @Inject(method = "setupTerrain", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$terrainSetup(Camera camera, Frustum frustum,
                                      boolean hasForcedFrustum, boolean spectator,
                                      CallbackInfo ci) {
        ChunkCullingModule mod = ru.ryuzaki.module.modules.misc.ChunkCullingModule.INSTANCE;

        // Обновляем VisibilityGraph в начале setupTerrain — всегда
        if (mod != null && mod.isEnabled() && mod.visibilityGraph.isEnabled()) {
            ChunkVisibilityGraph.get().update();
        }

        if (mod == null || !mod.isEnabled() || !mod.priorityRebuild.isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getCurrentFps() < 80) return;

        // Определяем двигалась ли камера
        float yaw   = RyuzakiRenderCache.camYaw;
        float pitch = RyuzakiRenderCache.camPitch;
        double cx   = RyuzakiRenderCache.camPosX;
        double cy   = RyuzakiRenderCache.camPosY;
        double cz   = RyuzakiRenderCache.camPosZ;

        boolean moved = Math.abs(yaw-lastYaw)>0.5f || Math.abs(pitch-lastPitch)>0.5f
            || Math.abs(cx-lastX)>0.5 || Math.abs(cy-lastY)>0.25 || Math.abs(cz-lastZ)>0.5;

        lastYaw=yaw; lastPitch=pitch; lastX=cx; lastY=cy; lastZ=cz;

        if (moved) { skipCount=0; return; }

        // Камера стоит — пропускаем каждый 2й кадр
        if (++skipCount % 2 != 0) ci.cancel();
    }
}
