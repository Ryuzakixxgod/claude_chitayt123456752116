package ru.ryuzaki.mixin;

import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Скрывает ванильный дисплей эффектов зелий.
 * В 1.21.4 renderStatusEffectOverlay принимает RenderTickCounter вместо float.
 */
@Mixin(InGameHud.class)
public class MixinInGameHudEffects {

    @Inject(
        method = "renderStatusEffectOverlay",
        at = @At("HEAD"),
        cancellable = true,
        require = 0
    )
    private void cancelVanillaEffects(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        ci.cancel();
    }
}
