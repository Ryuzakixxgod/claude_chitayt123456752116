package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.animation.CapePhysicsModule;
import ru.ryuzaki.module.modules.visual.CapeModule;

/**
 * MixinCapeFeatureRenderer — модифицирует vanilla cape рендер.
 * Vanilla cape УЖЕ корректно прикреплён к спине игрока.
 * Мы только добавляем физику через matrix transforms.
 */
@Mixin(CapeFeatureRenderer.class)
public class MixinCapeFeatureRenderer {

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void onRenderCape(MatrixStack matrices,
                              VertexConsumerProvider vertexConsumers,
                              int light,
                              PlayerEntityRenderState state,
                              float limbAngle,
                              float limbDistance,
                              CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        // CapeModule — custom physics/style on vanilla cape
        CapeModule cape = CapeModule.INSTANCE;
        if (cape != null && cape.isEnabled()) {
            float intensity = cape.intensity.getValue().floatValue();
            float velX = (float)(mc.player.getX() - mc.player.prevX);
            float velZ = (float)(mc.player.getZ() - mc.player.prevZ);
            float velocity = (float)Math.sqrt(velX*velX + velZ*velZ);
            float velY = (float)(mc.player.getY() - mc.player.prevY);
            long time = System.currentTimeMillis();

            String phys = cape.physics.getCurrent();
            switch (phys) {
                case "Smooth" -> {
                    // Smooth velocity-based tilt
                    float targetAngle = 6f + velocity * 90f - velY * 40f;
                    targetAngle = Math.min(targetAngle, 55f) * intensity;
                    cape.capeVel += (targetAngle - cape.capeAngle) * 0.12f;
                    cape.capeVel *= 0.78f;
                    cape.capeAngle += cape.capeVel;
                    matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(cape.capeAngle)));
                    // Side sway
                    float sway = (float)Math.sin(time * 0.0015f) * 0.012f * intensity;
                    matrices.multiply(new Quaternionf().rotateZ(sway));
                }
                case "Realistic" -> {
                    float angle = velocity * 35f * intensity - velY * 50f * intensity;
                    angle = Math.min(Math.max(angle, 0f), 65f);
                    cape.capeAngle += (angle - cape.capeAngle) * 0.15f;
                    matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(cape.capeAngle)));
                    float yawDelta = (float)(mc.player.getYaw() - mc.player.prevYaw);
                    matrices.multiply(new Quaternionf().rotateY((float)Math.toRadians(yawDelta * 0.5f * intensity)));
                }
                case "Wavy" -> {
                    float wave = (float)Math.sin(time * 0.0025f);
                    float waveZ = (float)Math.sin(time * 0.003f + 0.5f);
                    matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(
                        6f + wave * 12f * intensity + velocity * 80f * intensity)));
                    matrices.multiply(new Quaternionf().rotateZ((float)Math.toRadians(waveZ * 6f * intensity)));
                }
                // "None" = no modification
            }
            return;
        }

        // CapePhysicsModule — legacy physics (if CapeModule disabled)
        CapePhysicsModule mod = CapePhysicsModule.INSTANCE;
        if (mod == null || !mod.isEnabled()) return;

        float velX = (float)(mc.player.getX() - mc.player.prevX);
        float velZ = (float)(mc.player.getZ() - mc.player.prevZ);
        float velocity = (float)Math.sqrt(velX*velX + velZ*velZ);
        long  time = System.currentTimeMillis();
        float wave = (float)Math.sin(time * 0.001) * mod.getIntensity();
        float intensity = mod.getIntensity();

        switch (mod.getMode()) {
            case "Smooth" -> {
                matrices.translate(0, wave * 0.05, wave * 0.1);
                if (velocity > 0.01f)
                    matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(velocity * 20f * intensity)));
            }
            case "Realistic" -> {
                float capeAngle = velocity * 30f * intensity + wave * 5f;
                matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(capeAngle)));
                float yawDelta = (float)(mc.player.getYaw() - mc.player.prevYaw);
                matrices.multiply(new Quaternionf().rotateZ((float)Math.toRadians(yawDelta * intensity)));
            }
            case "Wavy" -> {
                float wavePhase = (float)Math.sin(time * 0.002);
                matrices.translate(wavePhase * 0.1f * intensity,
                    (float)(Math.sin(wavePhase * Math.PI) * 0.1 * intensity), 0);
                matrices.multiply(new Quaternionf().rotateZ((float)Math.toRadians(wave * 10f)));
                matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(wavePhase * 15f * intensity)));
            }
        }
    }
}
