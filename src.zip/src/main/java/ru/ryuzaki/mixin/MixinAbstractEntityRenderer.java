package ru.ryuzaki.mixin;

import net.minecraft.client.render.entity.EntityRenderer;
import org.spongepowered.asm.mixin.Mixin;

/**
 * Disabled - duplicate of MixinEntityRenderDispatcher.
 * Having two @Inject on shouldRender doubles overhead per entity.
 */
@Mixin(EntityRenderer.class)
public class MixinAbstractEntityRenderer {
    // intentionally empty
}
