package ru.ryuzaki.mixin;

import net.minecraft.client.Keyboard;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.BindManager;

@Mixin(Keyboard.class)
public class Mixinkeyboard {

    @Inject(method = "onKey", at = @At("HEAD"))
    private void ryuzaki$onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
        BindManager.onKeyPress(key, action);
    }
}