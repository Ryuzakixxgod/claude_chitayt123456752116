package ru.ryuzaki.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.animation.SwingModule;

// В 1.21.4 getHandSwingDuration находится в LivingEntity, а не в PlayerEntity
@Mixin(LivingEntity.class)
public class MixinPlayerEntity {

    @Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
    private void ryuzaki$swingSpeed(CallbackInfoReturnable<Integer> cir) {
        SwingModule swing = ru.ryuzaki.module.modules.animation.SwingModule.INSTANCE;
        if (swing != null && swing.isEnabled()) {
            cir.setReturnValue(Math.max(1, swing.getSwingDuration()));
        }
    }
}