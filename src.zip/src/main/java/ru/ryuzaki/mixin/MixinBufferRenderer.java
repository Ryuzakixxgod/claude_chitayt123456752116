package ru.ryuzaki.mixin;

import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.misc.DrawCallBatcherModule;

@Mixin(BufferRenderer.class)
public class MixinBufferRenderer {
    @Inject(method = "drawWithGlobalProgram", at = @At("HEAD"), require = 0)
    private static void ryuzaki$count(BuiltBuffer buffer, CallbackInfo ci) {
        // Static check - avoids getModule() call on every draw
        if (DrawCallBatcherModule.isActive()) DrawCallBatcherModule.onDrawCall();
    }
}
