package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.animation.SmoothCameraModule;
import ru.ryuzaki.module.modules.combat.KillAuraModule;

/**
 * Mixin для камеры. Использует getPitch/getYaw/setRotation без @Shadow
 * чтобы избежать проблем с приватными полями в разных версиях MC.
 */
@Mixin(Camera.class)
public abstract class MixinCamera {

    @Inject(method = "update", at = @At("RETURN"))
    private void ryuzaki$applyEffects(BlockView area, Entity focusedEntity,
                                     boolean thirdPerson, boolean inverseView,
                                     float tickDelta, CallbackInfo ci) {
        // Только SmoothCamera управляет камерой когда нет KillAura
        if (!KillAuraModule.isRotating()) {
            var sc = SmoothCameraModule.INSTANCE;
            if (sc != null && sc.isEnabled()) {
                // Используем accessor методы вместо @Shadow полей
                Camera self = (Camera) (Object) this;
                float currentYaw = self.getYaw();
                float currentPitch = self.getPitch();

                float newYaw = sc.getSmoothYaw(currentYaw);
                float newPitch = sc.getSmoothPitch(currentPitch);

                if (newYaw != currentYaw || newPitch != currentPitch) {
                    // Используем reflection для setRotation
                    try {
                        var method = Camera.class.getDeclaredMethod("setRotation", float.class, float.class);
                        method.setAccessible(true);
                        method.invoke(self, newYaw, newPitch);
                    } catch (Exception ignored) {
                        // Если не получилось — ничего страшного, камера останется с текущим углом
                    }
                }
            }
        }
        // Когда KillAura активна — камера показывает player.yaw как есть
    }
}
