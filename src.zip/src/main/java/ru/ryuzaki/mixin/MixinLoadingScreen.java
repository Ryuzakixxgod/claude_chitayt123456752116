package ru.ryuzaki.mixin;

import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;

/**
 * MixinLoadingScreen — intentionally empty mixin target.
 * Показ IntroScreen при входе в мир теперь обрабатывается
 * через ClientPlayConnectionEvents.JOIN в RyuzakiClient (Fabric API),
 * что надёжнее и не зависит от изменений сигнатур пакетных методов.
 * Перезагрузка ресурс паков — MixinMinecraftClientReload.
 */
@Mixin(ClientPlayNetworkHandler.class)
public class MixinLoadingScreen {
    // intentionally empty — see RyuzakiClient#onInitializeClient
}
