package ru.ryuzaki.mixin;

import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;

/**
 * MixinWindow — AspectRatio теперь через MixinGameRenderer.getBasicProjectionMatrix.
 * Framebuffer-подход убран (ломал F11 и resize окна).
 */
@Mixin(Window.class)
public class MixinWindow {
    // intentionally empty — aspect ratio handled via projection matrix in MixinGameRenderer
}
