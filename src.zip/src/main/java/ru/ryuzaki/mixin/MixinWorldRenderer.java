package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.world.NoWeatherModule;
import ru.ryuzaki.module.modules.misc.RenderTweaksModule;

@Mixin(WorldRenderer.class)
public class MixinWorldRenderer {

    @Inject(
        method = "renderWeather(Lnet/minecraft/client/render/FrameGraphBuilder;Lnet/minecraft/util/math/Vec3d;FLnet/minecraft/client/render/Fog;)V",
        at = @At("HEAD"), cancellable = true, require = 0
    )
    private void ryuzaki$noWeather(FrameGraphBuilder fb, Vec3d pos,
                                    float td, Fog fog, CallbackInfo ci) {
        NoWeatherModule nw = ru.ryuzaki.module.modules.world.NoWeatherModule.INSTANCE;
        if (nw != null && nw.isEnabled()) ci.cancel();
    }

    @Inject(
        method = "renderClouds",
        at = @At("HEAD"), cancellable = true, require = 0
    )
    private void ryuzaki$noClouds(FrameGraphBuilder frameGraphBuilder,
                                   org.joml.Matrix4f frustumMatrix,
                                   org.joml.Matrix4f positionMatrix,
                                   net.minecraft.client.option.CloudRenderMode cloudRenderMode,
                                   net.minecraft.util.math.Vec3d cameraPos,
                                   float tickDelta, int ticks, float f,
                                   CallbackInfo ci) {
        RenderTweaksModule mod = ru.ryuzaki.module.modules.misc.RenderTweaksModule.INSTANCE;
        ru.ryuzaki.module.modules.misc.RyuzakiFpsOptimizer fpsOpt =
            ru.ryuzaki.module.modules.misc.RyuzakiFpsOptimizer.INSTANCE;
        boolean cloudsOff = (mod != null && mod.isEnabled() && mod.noClouds.isEnabled())
                         || (fpsOpt != null && fpsOpt.isNoClouds());
        if (!cloudsOff) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        ci.cancel();
    }
}
