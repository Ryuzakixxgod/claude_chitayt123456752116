package ru.ryuzaki.mixin;

import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.modules.world.BetterWaterModule;
import ru.ryuzaki.module.modules.world.CustomSkyModule;
import ru.ryuzaki.module.modules.world.FogControlModule;
import ru.ryuzaki.module.modules.misc.StaticFogModule;

/**
 * MixinBackgroundRenderer — перехват тумана.
 *
 * ИСПРАВЛЕНИЯ vs оригинал:
 *  1. Убраны двойные пути пакетов (ru.ryuzaki.module.ru.ryuzaki.module...)
 *     — они не компилировались вообще
 *  2. Кэш последнего Fog — если входные данные не изменились,
 *     возвращаем тот же объект. Fog создавался КАЖДЫЙ КАДР → GC pressure.
 */
@Mixin(BackgroundRenderer.class)
public class MixinBackgroundRenderer {

    // Кэш последнего результата — избегаем new Fog() каждый кадр
    private static Fog   lastFog        = null;
    private static float lastStart      = Float.NaN;
    private static float lastEnd        = Float.NaN;
    private static float lastR          = Float.NaN;
    private static float lastG          = Float.NaN;
    private static float lastB          = Float.NaN;

    @Inject(method = "applyFog", at = @At("RETURN"), cancellable = true)
    private static void ryuzaki$modifyFog(
            Camera camera,
            BackgroundRenderer.FogType fogType,
            Vector4f color,
            float viewDistance,
            boolean thickFog,
            float tickDelta,
            CallbackInfoReturnable<Fog> cir) {

        try {
            // ── BetterWater — убираем подводный туман ─────────────────────
            BetterWaterModule bw = BetterWaterModule.INSTANCE;
            if (bw != null && bw.isEnabled() && bw.shouldRemoveWaterFog()) {
                MinecraftClient mc2 = MinecraftClient.getInstance();
                if (mc2 != null && mc2.player != null && mc2.player.isSubmergedInWater()) {
                    float wd = bw.getWaterFogDist();
                    cir.setReturnValue(getFogCached(wd * 0.7f, wd, FogShape.SPHERE, 0f, 0.2f, 0.5f));
                    return;
                }
            }

            // ── StaticFog ─────────────────────────────────────────────────
            StaticFogModule sfMod = StaticFogModule.INSTANCE;
            if (sfMod != null && sfMod.isEnabled()) {
                FogShape shape = sfMod.isSphere() ? FogShape.SPHERE : FogShape.CYLINDER;
                cir.setReturnValue(getFogCached(sfMod.getStart(), sfMod.getEnd(), shape,
                    sfMod.getR(), sfMod.getG(), sfMod.getB()));
                return;
            }

            // ── FogControl ────────────────────────────────────────────────
            FogControlModule fog = FogControlModule.INSTANCE;
            if (fog == null || !fog.isEnabled()) {
                // Только синхронизируем цвет с CustomSky если нужно
                CustomSkyModule skyOnly = CustomSkyModule.INSTANCE;
                if (skyOnly != null && skyOnly.isEnabled()) {
                    Fog cur2 = cir.getReturnValue();
                    if (cur2 != null) {
                        int[] hc2 = skyOnly.getHorizonColor();
                        cir.setReturnValue(getFogCached(cur2.start(), cur2.end(), cur2.shape(),
                            hc2[0] / 255f, hc2[1] / 255f, hc2[2] / 255f));
                    }
                }
                return;
            }

            Fog cur = cir.getReturnValue();
            if (cur == null) return;

            float baseR = cur.red(), baseG = cur.green(), baseB = cur.blue();
            CustomSkyModule sky = CustomSkyModule.INSTANCE;
            if (sky != null && sky.isEnabled()) {
                int[] hc = sky.getHorizonColor();
                baseR = hc[0] / 255f; baseG = hc[1] / 255f; baseB = hc[2] / 255f;
            }

            float[] sfArr = fog.getSmoothedFog(cur.start(), cur.end(), baseR, baseG, baseB);
            cir.setReturnValue(getFogCached(sfArr[0], sfArr[1], FogShape.SPHERE,
                sfArr[2], sfArr[3], sfArr[4]));

        } catch (Throwable e) {
            System.err.println("[Ryuzaki] fog crash: " + e);
        }
    }

    /**
     * Возвращает кэшированный Fog если параметры не изменились.
     * Fog — immutable record, безопасно переиспользовать.
     * Экономит new Fog() + GC на каждый кадр.
     */
    private static Fog getFogCached(float start, float end, FogShape shape, float r, float g, float b) {
        if (lastFog != null
                && Math.abs(lastStart - start) < 0.01f
                && Math.abs(lastEnd   - end)   < 0.01f
                && Math.abs(lastR - r) < 0.002f
                && Math.abs(lastG - g) < 0.002f
                && Math.abs(lastB - b) < 0.002f) {
            return lastFog; // возвращаем кэш — ноль аллокаций
        }
        lastStart = start; lastEnd = end;
        lastR = r; lastG = g; lastB = b;
        lastFog = new Fog(start, end, shape, r, g, b, 1f);
        return lastFog;
    }
}
