package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.NoHurtCamModule;
import ru.ryuzaki.module.modules.visual.AspectRatioModule;
import ru.ryuzaki.module.modules.visual.ZoomModule;
import ru.ryuzaki.util.RyuzakiRenderCache;

@Mixin(GameRenderer.class)
public class MixinGameRenderer {

    // ── Кэш кадра ────────────────────────────────────────────────────
    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void ryuzaki$frameStart(RenderTickCounter counter, boolean tick, CallbackInfo ci) {
        RyuzakiRenderCache.update();
    }

    @Inject(method = "render", at = @At("RETURN"), require = 0)
    private void ryuzaki$frameEnd(RenderTickCounter counter, boolean tick, CallbackInfo ci) {
        try {
            ru.ryuzaki.module.modules.visual.MotionBlurModule mb =
                ru.ryuzaki.module.modules.visual.MotionBlurModule.INSTANCE;
            if (mb != null && mb.isEnabled()) mb.onPostRender();
        } catch (Exception ignored) {}
    }

    // ── Zoom ─────────────────────────────────────────────────────────
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true, require = 0)
    private void ryuzaki$modifyFov(Camera camera, float tickDelta, boolean changingFov,
                                   CallbackInfoReturnable<Float> cir) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen != null) return;
        ZoomModule zoom = ru.ryuzaki.module.modules.visual.ZoomModule.INSTANCE;
        if (zoom != null && zoom.isEnabled() && zoom.isZooming())
            cir.setReturnValue(zoom.getFov(cir.getReturnValue()));
    }

    /**
     * AspectRatio — масштаб X в матрице проекции.
     * Портировано из Minced: realRatio / targetRatio = scaleX для m00.
     * Не требует @Shadow полей — работает только с возвращённой матрицей.
     */
    @Inject(method = "getBasicProjectionMatrix", at = @At("RETURN"), cancellable = true, require = 0)
    private void ryuzaki$aspectRatio(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        AspectRatioModule ar = ru.ryuzaki.module.modules.visual.AspectRatioModule.INSTANCE;
        if (ar == null || !ar.isEnabled()) return;
        float targetRatio = ar.getRatio();
        if (targetRatio <= 0) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getWindow() == null) return;

        float realRatio = (float) mc.getWindow().getFramebufferWidth()
                        / (float) mc.getWindow().getFramebufferHeight();
        if (Math.abs(targetRatio - realRatio) < 0.001f) return;

        // Корректируем m00 (масштаб X) матрицы проекции
        float scaleX = realRatio / targetRatio;
        Matrix4f mat = new Matrix4f(cir.getReturnValue());
        mat.m00(mat.m00() * scaleX);
        cir.setReturnValue(mat);
    }

    // ── NoHurtCam ─────────────────────────────────────────────────────
    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$noHurtCam(CallbackInfo ci) {
        NoHurtCamModule nhc = ru.ryuzaki.module.modules.misc.NoHurtCamModule.INSTANCE;
        if (nhc != null && nhc.isEnabled()) ci.cancel();
    }

    // ── Отменяем ванильный blur при GUI ──────────────────────────────
    @Inject(method = "renderBlur", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$cancelBlur(CallbackInfo ci) {
        ci.cancel();
    }
}
