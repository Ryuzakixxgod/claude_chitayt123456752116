package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.visual.TotemPopCounterModule;
import ru.ryuzaki.util.TpsCounter;

@Mixin(ClientPlayNetworkHandler.class)
public class MixinClientPlayNetworkHandler {

    // ── TPS расчёт ───────────────────────────────────────────────────
    @Inject(method = "onWorldTimeUpdate", at = @At("HEAD"), require = 0)
    private void ryuzaki$onWorldTime(WorldTimeUpdateS2CPacket packet, CallbackInfo ci) {
        TpsCounter.onWorldTimePacket();
    }

    // ── Totem Pop (status 35) ────────────────────────────────────────
    @Inject(method = "onEntityStatus", at = @At("HEAD"))
    private void ryuzaki$onEntityStatus(EntityStatusS2CPacket packet, CallbackInfo ci) {
        if (packet.getStatus() != 35) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;
        Entity entity = packet.getEntity(mc.world);
        if (!(entity instanceof PlayerEntity player)) return;
        TotemPopCounterModule totem = ModuleManager.getModule(TotemPopCounterModule.class);
        if (totem != null) totem.onTotemPop(player);
    }
}
