package ru.ryuzaki.mixin;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.particle.BlockStateParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.modules.misc.ParticleCullerModule;
import ru.ryuzaki.module.modules.misc.RyuzakiFpsOptimizer;

/**
 * MixinParticleManager — фильтрация частиц.
 * ОПТИМИЗАЦИИ:
 *  - Все проверки идут от самой дешёвой к самой дорогой
 *  - Identity comparison (==) вместо toString() — ноль String allocation
 *  - Статический INSTANCE кэш — один lookup, ноль повторов
 *  - Early return при отключённых модулях
 */
@Mixin(ParticleManager.class)
public class MixinParticleManager {

    // ── Статический кэш модулей ─────────────────────────────────────
    private static RyuzakiFpsOptimizer cachedFpsOpt;
    private static ParticleCullerModule cachedCuller;
    private static boolean modulesCached = false;
    private static long particleBudgetWindow = 0L;
    private static int particlesAcceptedInWindow = 0;

    private static void cacheModules() {
        if (modulesCached) return;
        cachedFpsOpt = RyuzakiFpsOptimizer.INSTANCE;
        cachedCuller = ParticleCullerModule.INSTANCE;
        modulesCached = true;
    }

    @Inject(method = "addParticle*", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$filterParticle(ParticleEffect params,
                                         double x, double y, double z,
                                         double vx, double vy, double vz,
                                         CallbackInfoReturnable<Particle> cir) {
        cacheModules();

        // ── FPS Optimizer — глобальное отключение частиц (самый быстрый выход) ──
        if (cachedFpsOpt != null && cachedFpsOpt.isEnabled() && cachedFpsOpt.noParticles.isEnabled()) {
            cir.setReturnValue(null);
            return;
        }

        if (cachedCuller == null || !cachedCuller.isEnabled()) return;

        // Жёсткий бюджет на создание частиц. Это не просто настройка в GUI:
        // на фермах/взрывах новые частицы перестают добавляться до следующей
        // секунды, вместо того чтобы раздувать очередь ParticleManager.
        long now = System.currentTimeMillis();
        if (now - particleBudgetWindow >= 1_000L) {
            particleBudgetWindow = now;
            particlesAcceptedInWindow = 0;
        }
        int maxParticles = cachedCuller.maxParticles.getValue().intValue();
        if (particlesAcceptedInWindow >= maxParticles) {
            cir.setReturnValue(null);
            return;
        }

        // ── Дешёвые проверки — identity comparison, ноль String allocation ──

        // Блок-частицы (копание, падение)
        if (cachedCuller.noBlockBreak.isEnabled() && params instanceof BlockStateParticleEffect) {
            cir.setReturnValue(null);
            return;
        }

        // Огонь/дым — прямое сравнение констант
        if (cachedCuller.noFire.isEnabled()) {
            var type = params.getType();
            if (type == ParticleTypes.FLAME || type == ParticleTypes.LARGE_SMOKE || type == ParticleTypes.SMOKE) {
                cir.setReturnValue(null);
                return;
            }
        }

        // Взрывы — identity comparison
        if (cachedCuller.noExplosion.isEnabled()) {
            var type = params.getType();
            if (type == ParticleTypes.EXPLOSION || type == ParticleTypes.EXPLOSION_EMITTER
                    || type == ParticleTypes.POOF || type == ParticleTypes.CLOUD) {
                cir.setReturnValue(null);
                return;
            }
        }

        // ── Пространственный culling — только если прошли выше ────────
        // RyuzakiRenderCache.isInFrustum использует кэш, нет тригонометрии
        if (!ru.ryuzaki.util.RyuzakiRenderCache.isInFrustum(x, y, z)) {
            cir.setReturnValue(null);
            return;
        }

        // Дистанция — без sqrt
        if (ru.ryuzaki.util.RyuzakiRenderCache.camDistSq(x, y, z) > 64.0 * 64.0) {
            cir.setReturnValue(null);
            return;
        }

        particlesAcceptedInWindow++;
    }
}
