package ru.ryuzaki.mixin;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.modules.misc.EntityCullerModule;
import ru.ryuzaki.module.modules.misc.SmartCullModule;

@Mixin(EntityRenderDispatcher.class)
public class MixinEntityRenderDispatcher {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private <E extends Entity> void ryuzaki$shouldRender(
            E entity, Frustum frustum,
            double cameraX, double cameraY, double cameraZ,
            CallbackInfoReturnable<Boolean> cir) {
        // null-safe: не крашимся при дисконнекте
        try {
            if (EntityCullerModule.shouldSkipRender(entity) || !SmartCullModule.shouldRender(entity)) {
                cir.setReturnValue(false);
            }
        } catch (Throwable ignored) {}
    }
}
