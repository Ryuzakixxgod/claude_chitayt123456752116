package ru.ryuzaki.mixin;
// src/main/java/ru/ryuzaki/mixin/MixinLivingEntity.java

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.modules.animation.StepAnimModule;
import ru.ryuzaki.module.modules.visual.*;
import ru.ryuzaki.module.modules.particles.*;

/**
 * MixinLivingEntity — события урона и лечения.
 * ОПТИМИЗАЦИЯ: Все INSTANCE кэшируются статически — ноль lookup-ов каждый тик.
 */
@Mixin(LivingEntity.class)
public class MixinLivingEntity {

    // ── Статический кэш модулей — один раз при первом использовании ──
    private static DamageNumbersModule cachedDmgNumbers;
    private static HitMarkerModule cachedHitMarker;
    private static CosmicCritModule cachedCrit;
    private static ScreenShakeModule cachedShake;
    private static ScreenEdgeGlowModule cachedEdgeGlow;
    private static HitFlashModule cachedHitFlash;
    private static KillEffectModule cachedKillFx;
    private static KillLightningModule cachedKillLight;
    private static boolean modulesCached = false;

    private static void cacheModules() {
        if (modulesCached) return;
        cachedDmgNumbers = DamageNumbersModule.INSTANCE;
        cachedHitMarker = HitMarkerModule.INSTANCE;
        cachedCrit = CosmicCritModule.INSTANCE;
        cachedShake = ScreenShakeModule.INSTANCE;
        cachedEdgeGlow = ScreenEdgeGlowModule.INSTANCE;
        cachedHitFlash = HitFlashModule.INSTANCE;
        cachedKillFx = KillEffectModule.INSTANCE;
        cachedKillLight = KillLightningModule.INSTANCE;
        modulesCached = true;
    }

    @Inject(method = "heal", at = @At("TAIL"), require = 0)
    private void ryuzaki$onHeal(float amount, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        LivingEntity self = (LivingEntity)(Object)this;
        if (self != mc.player && !(self instanceof net.minecraft.entity.player.PlayerEntity)) return;
        if (cachedDmgNumbers != null) cachedDmgNumbers.onHeal(self, amount);
    }

    @Inject(method = "getStepHeight", at = @At("RETURN"), cancellable = true)
    private void ryuzaki$stepHeight(CallbackInfoReturnable<Float> cir) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || (Object)this != mc.player) return;
        StepAnimModule m = StepAnimModule.INSTANCE;
        if (m != null && m.isEnabled())
            cir.setReturnValue(m.height.getValue().floatValue());
    }

    @Inject(method = "damage", at = @At("TAIL"), require = 0)
    private void ryuzaki$onDamage(ServerWorld world, DamageSource source,
                                   float amount, CallbackInfoReturnable<Boolean> cir) {
        if (!cir.getReturnValue()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        cacheModules();

        LivingEntity self = (LivingEntity)(Object)this;
        boolean isKill = self.getHealth() <= 0;
        boolean isCrit = source.getAttacker() == mc.player
                && mc.player.fallDistance > 0
                && !mc.player.isOnGround()
                && !mc.player.isClimbing();

        // ── Урон нанесли МЫ ─────────────────────────────────────────
        if (source.getAttacker() == mc.player) {
            if (cachedHitMarker != null) cachedHitMarker.onHit(isKill);
            if (cachedDmgNumbers != null) cachedDmgNumbers.onDamage(self, amount, isCrit);
            if (cachedCrit != null) cachedCrit.spawnCrit(self.getPos());
        }

        // ── МЫ получили урон ─────────────────────────────────────────
        if (self == mc.player) {
            if (cachedShake != null) cachedShake.triggerShake();
            if (cachedEdgeGlow != null && cachedEdgeGlow.isEnabled()) cachedEdgeGlow.onDamage();
            if (cachedHitFlash != null) cachedHitFlash.onHit(0f);
        }

        // ── Kill effect modules ─────────────────────────────────────
        if (isKill && source.getAttacker() == mc.player) {
            if (cachedKillFx != null) cachedKillFx.spawnAt(self.getPos());
            if (cachedKillLight != null) cachedKillLight.onKill(self.getPos());
        }
    }
}
