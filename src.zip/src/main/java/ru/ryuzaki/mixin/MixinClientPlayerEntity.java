package ru.ryuzaki.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.ryuzaki.module.modules.combat.KillAuraModule;

@Mixin(ClientPlayerEntity.class)
public class MixinClientPlayerEntity {

    /**
     * Camera Freedom: разделяем визуальную ротацию и серверную.
     * Redirect перехватывает getYaw/getPitch внутри sendMovementPackets.
     * Сервер получает фейковую ротацию на цель, визуально игрок видит свою.
     *
     * Camera Freedom ВКЛ = сервер видит фейковую ротацию (KillAura)
     * Camera Freedom ВЫКЛ = сервер видит реальную ротацию игрока
     */
    @Redirect(
        method = "sendMovementPackets",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F")
    )
    private float ryuzaki$getYaw(ClientPlayerEntity instance) {
        if (KillAuraModule.isRotating() && KillAuraModule.INSTANCE != null
                && KillAuraModule.INSTANCE.свободаКамеры.isEnabled()) {
            return KillAuraModule.getTargetYaw();
        }
        return instance.getYaw();
    }

    @Redirect(
        method = "sendMovementPackets",
        at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F")
    )
    private float ryuzaki$getPitch(ClientPlayerEntity instance) {
        if (KillAuraModule.isRotating() && KillAuraModule.INSTANCE != null
                && KillAuraModule.INSTANCE.свободаКамеры.isEnabled()) {
            return KillAuraModule.getTargetPitch();
        }
        return instance.getPitch();
    }
}
