package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.ChunkCullingModule;
import ru.ryuzaki.module.modules.misc.ChunkThreadsModule;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * MixinChunkBuilder — три оптимизации:
 *
 * 1. Больше потоков сборки (было: max 1 на 8-ядерном CPU)
 * 2. Upload throttle при низком FPS — не заливаем GPU данными чанков
 *    когда он уже захлёбывается (причина stutter при загрузке мира)
 * 3. Priority rebuild — ограничиваем перестройки секций за кадр
 */
@Mixin(ChunkBuilder.class)
public class MixinChunkBuilder {

    // ── Потоки ────────────────────────────────────────────────────────
    @ModifyArg(
        method = "<init>",
        at = @At(value = "INVOKE",
                 target = "Ljava/util/concurrent/Executors;newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;"),
        index = 0,
        require = 0
    )
    private int ryuzaki$moreThreads(int original) {
        ChunkThreadsModule mod = ru.ryuzaki.module.modules.misc.ChunkThreadsModule.INSTANCE;
        if (mod == null || !mod.isEnabled()) return original;
        int wanted = mod.threads.getValue().intValue();
        return Math.max(original, Math.min(wanted, Runtime.getRuntime().availableProcessors()));
    }

    // ── Upload throttle ───────────────────────────────────────────────
    // upload() вызывается каждый кадр и может выгружать всю очередь
    // При загрузке нового мира это = 100+ VBO upload за кадр = stutter
    // Ограничиваем: при FPS < 30 пропускаем upload через кадр
    @Inject(method = "upload", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$throttleUpload(CallbackInfo ci) {
        // DISABLED: throttling at low FPS blocks initial world load (FPS=0 during loading)
        // caused silent native crash on world join
    }
}
