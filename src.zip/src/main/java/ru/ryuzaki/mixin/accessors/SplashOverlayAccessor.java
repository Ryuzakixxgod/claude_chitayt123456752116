package ru.ryuzaki.mixin.accessors;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.SplashOverlay;
import net.minecraft.resource.ResourceReload;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(value = SplashOverlay.class)
public interface SplashOverlayAccessor {
    @Accessor(value = "reload")
    ResourceReload getReload();

    @Accessor(value = "client")
    MinecraftClient getClient();

    @Accessor(value = "reloadCompleteTime")
    long getReloadCompleteTime();

    @Accessor(value = "reloadCompleteTime")
    void setReloadCompleteTime(long var1);
}
