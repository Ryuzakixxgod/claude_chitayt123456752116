package ru.ryuzaki.mixin;

import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.world.NoWeatherModule;

@Mixin(WorldRenderer.class)
public class MixinWorldRendererWeather {

    @Inject(method = "renderWeather", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$noWeather(FrameGraphBuilder fb, Vec3d pos,
                                    float tickDelta, Fog fog,
                                    CallbackInfo ci) {
        NoWeatherModule nw = ru.ryuzaki.module.modules.world.NoWeatherModule.INSTANCE;
        if (nw == null || !nw.isEnabled()) return;
        // Cancel all weather render (rain+snow+thunder all go through renderWeather)
        ci.cancel();
    }
}
