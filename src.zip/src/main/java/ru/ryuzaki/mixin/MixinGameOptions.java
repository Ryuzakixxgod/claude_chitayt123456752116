package ru.ryuzaki.mixin;

import net.minecraft.client.option.GameOptions;
import org.spongepowered.asm.mixin.Mixin;

/**
 * MixinGameOptions — отключён.
 * getAo() в 1.21.4 возвращает SimpleOption<Boolean>, чьё setValue() вызывает
 * WorldRenderer.reload() → delete VBOs → только render thread.
 * Вызов из chunk worker thread = IllegalStateException "wrong thread".
 */
@Mixin(GameOptions.class)
public class MixinGameOptions {
    // Пусто — NoAO теперь недоступен, зато не крашит
}
