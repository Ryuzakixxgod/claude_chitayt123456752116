package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.ArmorAlertModule;
import ru.ryuzaki.module.modules.misc.NoOverlayModule;
import ru.ryuzaki.module.modules.visual.*;
import ru.ryuzaki.module.modules.world.EnviroFXModule;

@Mixin(InGameHud.class)
public class MixinInGameHud {

    // ── Cached module refs (one HashMap lookup ever, not per frame) ──
    private static WaypointsModule      s_wp;
    private static TotemPopCounterModule s_totem;
    private static VisualRangeModule    s_vr;
    private static TargetESP            s_esp;
    private static ScreenEdgeGlowModule s_glow;
    private static CrosshairFXModule    s_cross;
    private static HitMarkerModule      s_hit;
    private static EnviroFXModule       s_enviro;
    private static ArmorAlertModule     s_armor;
    private static NoOverlayModule      s_overlay;
    private static CrosshairFXModule    s_chfx;
    private static boolean              s_ready = false;

    private static void cache() {
        if (s_ready) return;
        s_wp      = ModuleManager.getModule(WaypointsModule.class);
        s_totem   = ModuleManager.getModule(TotemPopCounterModule.class);
        s_vr      = ModuleManager.getModule(VisualRangeModule.class);
        s_esp     = ModuleManager.getModule(TargetESP.class);
        s_glow    = ModuleManager.getModule(ScreenEdgeGlowModule.class);
        s_cross   = ModuleManager.getModule(CrosshairFXModule.class);
        s_hit     = ModuleManager.getModule(HitMarkerModule.class);
        s_enviro  = ModuleManager.getModule(EnviroFXModule.class);
        s_armor   = ModuleManager.getModule(ArmorAlertModule.class);
        s_overlay = ModuleManager.getModule(NoOverlayModule.class);
        s_chfx    = s_cross;
        s_ready   = true;
    }

    @Inject(method="renderOverlay", at=@At("HEAD"), cancellable=true)
    private void ryuzaki$cancelOverlay(DrawContext ctx, Identifier texture, float opacity, CallbackInfo ci){
        cache();
        if (s_overlay == null || !s_overlay.isEnabled()) return;
        String p = texture.getPath();
        if (p.contains("fire")    && s_overlay.noFire.isEnabled())    { ci.cancel(); return; }
        if (p.contains("totem")   && s_overlay.noTotem.isEnabled())   { ci.cancel(); return; }
        if (p.contains("portal")  && s_overlay.noPortal.isEnabled())  { ci.cancel(); return; }
        if (p.contains("pumpkin") && s_overlay.noPumpkin.isEnabled()) { ci.cancel(); return; }
        if (p.contains("snow")    && s_overlay.noSnow.isEnabled())    { ci.cancel(); return; }
        if (p.contains("water")   && s_overlay.noWater.isEnabled())   { ci.cancel(); return; }
    }

    @Inject(method="renderCrosshair", at=@At("HEAD"), cancellable=true)
    private void ryuzaki$cancelCrosshair(DrawContext ctx, RenderTickCounter counter, CallbackInfo ci){
        cache();
        if (s_chfx != null && s_chfx.isEnabled()) ci.cancel();
    }

    @Inject(method="render", at=@At("RETURN"))
    private void ryuzaki$onRender(DrawContext ctx, RenderTickCounter counter, CallbackInfo ci){
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        cache();

        try {
            int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
            float td = counter.getTickDelta(false);

            if (s_wp    != null && s_wp.isEnabled())    s_wp.renderHud(ctx, sw, sh);
            if (s_totem != null && s_totem.isEnabled()) s_totem.renderHud(ctx, sw, sh);
            if (s_vr    != null && s_vr.isEnabled())    s_vr.renderHud(ctx);
            if (s_esp   != null && s_esp.isEnabled())   s_esp.renderHud(ctx, sw, sh, td);
            if (s_glow  != null && s_glow.isEnabled())  s_glow.render(ctx, sw, sh);
            if (s_cross != null && s_cross.isEnabled()) s_cross.render(ctx);
            if (s_hit   != null && s_hit.isEnabled())   s_hit.render(ctx, sw, sh);
            if (s_enviro!= null && s_enviro.isEnabled())s_enviro.render(ctx);
            if (s_armor != null && s_armor.isEnabled()) s_armor.renderAlert(ctx, sw, sh);
        } catch (Throwable e) {
            System.err.println("[Ryuzaki] Legacy HUD overlay crash: " + e);
        }
    }
}
