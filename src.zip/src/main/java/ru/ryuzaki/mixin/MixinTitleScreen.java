package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.gui.AltManagerScreen;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Mixin(TitleScreen.class)
public abstract class MixinTitleScreen extends net.minecraft.client.gui.screen.Screen {

    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final DateTimeFormatter DATE_FMT = DateTimeFormatter.ofPattern("dd.MM.yyyy");

    private static boolean nebInit = false;
    private static final float[] NEB_PX = new float[8], NEB_PY = new float[8], NEB_RAD = new float[8];
    private static final int[] NEB_RGB = new int[8];

    private static final int COMET_N = 12;
    private static final float[] C_SPEED = new float[COMET_N], C_ANGLE = new float[COMET_N],
            C_TAIL = new float[COMET_N], C_T = new float[COMET_N],
            C_SX = new float[COMET_N], C_SY = new float[COMET_N];
    private static final int[] C_HUE = new int[COMET_N];
    private static boolean cometInit = false;
    private static long lastMs = 0;

    protected MixinTitleScreen() { super(Text.literal("")); }

    @Inject(method = "init", at = @At("HEAD"), require = 0)
    private void ryuzaki$resetTime(CallbackInfo ci) {
        lastMs = 0;
    }

    @Inject(method = "init", at = @At("TAIL"), require = 0)
    private void ryuzaki$init(CallbackInfo ci) {
        for (net.minecraft.client.gui.Element el : new java.util.ArrayList<>(this.children())) {
            if (el instanceof ButtonWidget btn && btn.getMessage().getString().contains("Realms")) {
                int bx=btn.getX(), by=btn.getY(), bw=btn.getWidth(), bh=btn.getHeight();
                this.remove(btn);
                this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("✦ Alt Manager"),
                        b -> MinecraftClient.getInstance().setScreen(new AltManagerScreen((TitleScreen)(Object)this))
                ).dimensions(bx, by, bw, bh).build());
                break;
            }
        }
    }

    // Отменяем панораму и рисуем ВЕСЬ наш фон + кометы здесь
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void ryuzaki$bg(DrawContext ctx, int mx, int my, float delta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        renderCosmicBg(ctx, w, h);
        ci.cancel();
    }

    // Рисуем время и лого поверх всего
    @Inject(method = "render", at = @At("TAIL"), require = 0)
    private void ryuzaki$overlay(DrawContext ctx, int mx, int my, float delta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth();
        LocalDateTime now = LocalDateTime.now();
        String time = now.format(TIME_FMT), date = now.format(DATE_FMT);
        int tw = mc.textRenderer.getWidth(time) * 2, cx = w/2 - tw/2;

        ctx.fill(cx-10, 4, cx+tw+10, 34, rgba(3,2,10,170));
        ctx.fill(cx-10, 4, cx+tw+10, 5, rgba(140,40,230,200));
        ctx.getMatrices().push();
        ctx.getMatrices().scale(2f,2f,1f);
        ctx.drawText(mc.textRenderer, Text.literal("§f"+time), cx/2, 9, rgba(210,160,255,255), true);
        ctx.getMatrices().pop();
        ctx.drawText(mc.textRenderer, Text.literal("§8"+date), cx+tw+14, 16, rgba(130,90,210,200), false);

        String logo = "✦ RYUZAKI ✦";
        int lw = mc.textRenderer.getWidth(logo);
        for (int i=3;i>=1;i--)
            ctx.drawText(mc.textRenderer, Text.literal("§5"+logo), w/2-lw/2-i, 38-i, rgba(80,10,160,35*i), false);
        ctx.drawText(mc.textRenderer, Text.literal("§d"+logo), w/2-lw/2, 38, rgba(190,70,255,255), true);
    }

    private void renderCosmicBg(DrawContext ctx, int w, int h) {
        long now = System.currentTimeMillis();
        float dtSec = (lastMs == 0) ? 0.016f : Math.min(0.05f, (now - lastMs) / 1000f);
        lastMs = now;

        ctx.fill(0, 0, w, h, rgba(2,3,14,255));

        if (!nebInit) {
            java.util.Random r = new java.util.Random(777);
            for (int i=0;i<8;i++) {
                NEB_PX[i]=0.05f+r.nextFloat()*0.9f; NEB_PY[i]=0.05f+r.nextFloat()*0.9f;
                NEB_RAD[i]=50+r.nextFloat()*100;
                float hue=r.nextFloat()<0.6f?0.65f+r.nextFloat()*0.15f:0.55f+r.nextFloat()*0.08f;
                int[] c=hsvToRgb(hue,0.5f+r.nextFloat()*0.4f,0.7f);
                NEB_RGB[i]=(c[0]<<16)|(c[1]<<8)|c[2];
            }
            nebInit=true;
        }
        for (int n=0;n<8;n++) {
            int nx=(int)(w*NEB_PX[n]), ny=(int)(h*NEB_PY[n]);
            float fr=NEB_RAD[n]*(1f+0.04f*(float)Math.sin(now/4000.0+n));
            int nr=(NEB_RGB[n]>>16)&0xFF, ng=(NEB_RGB[n]>>8)&0xFF, nb2=NEB_RGB[n]&0xFF;
            for (int s=(int)(fr/3);s>=1;s--) {
                float p=s*3/fr; int a=(int)(30*(1-p)); if(a<=0) continue;
                int r2=(int)(fr*(1-p));
                ctx.fill(nx-r2,ny-(int)(r2*.55f),nx+r2,ny+(int)(r2*.55f),rgba(nr,ng,nb2,a));
            }
        }

        java.util.Random rD=new java.util.Random(42);
        for (int i=0;i<200;i++){int sx=rD.nextInt(w),sy=rD.nextInt(h);float p=(float)Math.abs(Math.sin(now/2500.0+i*0.4));ctx.fill(sx,sy,sx+1,sy+1,rgba(160,180,255,(int)(p*110+20)));}
        java.util.Random rM=new java.util.Random(123);
        for (int i=0;i<70;i++){int sx=rM.nextInt(w),sy=rM.nextInt(h);float p=(float)Math.abs(Math.sin(now/1800.0+i*0.6));ctx.fill(sx,sy,sx+2,sy+2,rgba(210,225,255,(int)(p*180+30)));}
        java.util.Random rB=new java.util.Random(321);
        for (int i=0;i<20;i++){int sx=rB.nextInt(w),sy=rB.nextInt(h);float p=(float)Math.abs(Math.sin(now/1200.0+i));int a=(int)(p*255);ctx.fill(sx-2,sy,sx+3,sy+1,rgba(255,255,255,a/2));ctx.fill(sx,sy-2,sx+1,sy+3,rgba(255,255,255,a/2));ctx.fill(sx,sy,sx+1,sy+1,rgba(220,235,255,a));}

        if (!cometInit) {
            java.util.Random rc=new java.util.Random(System.nanoTime());
            for (int i=0;i<COMET_N;i++){C_SPEED[i]=0.08f+rc.nextFloat()*0.12f;C_ANGLE[i]=0.25f+rc.nextFloat()*0.55f;C_TAIL[i]=40+rc.nextFloat()*70;C_T[i]=rc.nextFloat();C_SX[i]=rc.nextFloat();C_SY[i]=rc.nextFloat()*0.5f;float hue=0.58f+rc.nextFloat()*0.32f;int[]cc=hsvToRgb(hue,0.5f,1f);C_HUE[i]=(cc[0]<<16)|(cc[1]<<8)|cc[2];}
            cometInit=true;
        }

        for (int i=0;i<COMET_N;i++) {
            C_T[i]+=C_SPEED[i]*dtSec;
            if (C_T[i]>1f){C_T[i]=0f;java.util.Random rc=new java.util.Random();C_SX[i]=rc.nextFloat();C_SY[i]=rc.nextFloat()*0.5f;C_SPEED[i]=0.08f+rc.nextFloat()*0.12f;C_TAIL[i]=40+rc.nextFloat()*70;float hue=0.58f+rc.nextFloat()*0.32f;int[]cc=hsvToRgb(hue,0.5f,1f);C_HUE[i]=(cc[0]<<16)|(cc[1]<<8)|cc[2];}
            float t=C_T[i], alpha=t<0.1f?t/0.1f:t>0.85f?(1f-t)/0.15f:1f;
            int hcx=(int)(C_SX[i]*w+t*w*0.35f*(float)Math.cos(C_ANGLE[i]));
            int hcy=(int)(C_SY[i]*h+t*h*0.25f*(float)Math.sin(C_ANGLE[i]));
            int nr=(C_HUE[i]>>16)&0xFF,ng=(C_HUE[i]>>8)&0xFF,nb=C_HUE[i]&0xFF,tail=(int)C_TAIL[i];
            for (int j=0;j<tail;j++){float tp=j/(float)tail;int tx=(int)(hcx-j*Math.cos(C_ANGLE[i])),ty=(int)(hcy-j*Math.sin(C_ANGLE[i]));if(tx<0||tx>=w||ty<0||ty>=h)continue;ctx.fill(tx,ty,tx+1,ty+1,rgba(nr,ng,nb,(int)((1-tp)*180*alpha)));}
            ctx.fill(hcx-1,hcy-1,hcx+2,hcy+2,rgba(255,255,255,(int)(230*alpha)));
        }
    }

    private static int rgba(int r,int g,int b,int a){return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int[] hsvToRgb(float h,float s,float v){float r,g,b;if(s==0){r=g=b=v;}else{h*=6;int i=(int)h;float f=h-i,p=v*(1-s),q=v*(1-s*f),t=v*(1-s*(1-f));switch(i%6){case 0:r=v;g=t;b=p;break;case 1:r=q;g=v;b=p;break;case 2:r=p;g=v;b=t;break;case 3:r=p;g=q;b=v;break;case 4:r=t;g=p;b=v;break;default:r=v;g=p;b=q;break;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}