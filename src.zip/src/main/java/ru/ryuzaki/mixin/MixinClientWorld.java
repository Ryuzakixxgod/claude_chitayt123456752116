package ru.ryuzaki.mixin;
// src/main/java/ru/ryuzaki/mixin/MixinClientWorld.java
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.world.NoWeatherModule;

@Mixin(World.class)
public class MixinClientWorld {
    @Inject(method="getRainGradient", require = 0, at=@At("RETURN"), cancellable=true)
    private void ryuzaki$noRain(float delta, CallbackInfoReturnable<Float> cir){
        NoWeatherModule nw=ru.ryuzaki.module.modules.world.NoWeatherModule.INSTANCE;
        if(nw!=null&&nw.isEnabled()&&nw.noRain.isEnabled()) cir.setReturnValue(0.0f);
    }
    @Inject(method="getThunderGradient", require = 0, at=@At("RETURN"), cancellable=true)
    private void ryuzaki$noThunder(float delta, CallbackInfoReturnable<Float> cir){
        NoWeatherModule nw=ru.ryuzaki.module.modules.world.NoWeatherModule.INSTANCE;
        if(nw!=null&&nw.isEnabled()&&nw.noThunder.isEnabled()) cir.setReturnValue(0.0f);
    }
}