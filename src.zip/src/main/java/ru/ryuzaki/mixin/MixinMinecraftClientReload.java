package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Перехватываем MinecraftClient.reloadResources — SplashOverlay
 * автоматически покажется, мы просто добавим GIF поверх через MixinSplashOverlay.
 */
@Mixin(MinecraftClient.class)
public class MixinMinecraftClientReload {

    // SplashOverlay уже показывается при reloadResources автоматически
    // Наш MixinSplashOverlay добавит GIF поверх ванильной анимации
}
