package ru.ryuzaki.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.world.CustomSkyModule;

/**
 * MixinWorldRendererSky — перехватываем renderSky и рисуем СВОЁ небо
 * в том же месте что и ванилла: ДО рендера мира, с правильной матрицей.
 *
 * Ключевые правила неба:
 * - depthMask = false  (не пишем глубину — небо "за" всем)
 * - depthTest = false  (небо не тестирует глубину)
 * - MatrixStack = ТОЛЬКО вращение камеры, БЕЗ трансляции
 * - Купол рисуем вокруг НУЛЯ, а не вокруг позиции игрока
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRendererSky {

    @Inject(
        method = "renderSky(Lnet/minecraft/client/render/FrameGraphBuilder;Lnet/minecraft/client/render/Camera;FLnet/minecraft/client/render/Fog;)V",
        at = @At("HEAD"), cancellable = true, require = 0
    )
    private void ryuzaki$replaceSky(
            FrameGraphBuilder frameGraphBuilder,
            Camera camera,
            float tickDelta,
            Fog fog,
            CallbackInfo ci) {

        CustomSkyModule sky = ru.ryuzaki.module.modules.world.CustomSkyModule.INSTANCE;
        if (sky == null || !sky.isEnabled()) return;

        // Отменяем ванильный рендер неба
        ci.cancel();

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null) return;

        // ── Создаём матрицу: ТОЛЬКО вращение камеры ──────────────────
        // Camera.getRotation() возвращает Quaternionf совмещённого pitch+yaw
        // Это именно то что использует ванильный SkyRenderer
        MatrixStack ms = new MatrixStack();
        ms.multiply(camera.getRotation());

        // ── Рендер ───────────────────────────────────────────────────
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        sky.renderSkyGeometry(ms, mc, System.currentTimeMillis());

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }
}
