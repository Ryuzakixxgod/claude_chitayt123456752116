package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.animation.SwingModule;

@Mixin(HeldItemRenderer.class)
public class MixinHandRenderer {

    // ── ViewModel offset ──────────────────────────────────────────────
    @Inject(method = "renderFirstPersonItem",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                     shift = At.Shift.AFTER),
            require = 0)
    private void ryuzaki$viewmodel(AbstractClientPlayerEntity player,
                                   float tickDelta, float pitch,
                                   Hand hand, float swingProgress,
                                   ItemStack item, float equipProgress,
                                   MatrixStack matrices,
                                   VertexConsumerProvider provider,
                                   int light, CallbackInfo ci) {
        SwingModule swing = SwingModule.INSTANCE;
        if (swing == null || !swing.isEnabled()) return;

        if (swing.noSwing.isEnabled()) { matrices.scale(0f,0f,0f); return; }

        float px=swing.getPositionX(),py=swing.getPositionY(),pz=swing.getPositionZ();
        if(Math.abs(px)>.001f||Math.abs(py)>.001f||Math.abs(pz)>.001f)
            matrices.translate(px,py,pz);

        float rx=swing.getRotationX(),ry=swing.getRotationY(),rz=swing.getRotationZ();
        if(Math.abs(rx)>.01f) matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(rx)));
        if(Math.abs(ry)>.01f) matrices.multiply(new Quaternionf().rotateY((float)Math.toRadians(ry)));
        if(Math.abs(rz)>.01f) matrices.multiply(new Quaternionf().rotateZ((float)Math.toRadians(rz)));

        float sc=swing.getScale();
        if(Math.abs(sc-1f)>.01f) matrices.scale(sc,sc,sc);
    }

    // ── Swing animation ───────────────────────────────────────────────
    @Inject(method = "swingArm",
            at = @At("HEAD"),
            cancellable = true,
            require = 0)
    private void ryuzaki$swingArm(float swingProgress, float equipProgress,
                                   MatrixStack matrices, int armX, Arm arm,
                                   CallbackInfo ci) {
        SwingModule swing = SwingModule.INSTANCE;
        if (swing == null || !swing.isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        if (swing.isMainHandOnly() && arm != mc.player.getMainArm()) return;

        ci.cancel();

        String p = swing.preset.getCurrent();
        // All presets including "Custom" go through the same preset system
        swing.applyPresetSwing(matrices, swingProgress, armX);
    }
}
