package ru.ryuzaki.mixin;

import net.minecraft.client.Mouse;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.BindManager;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.animation.SmoothCameraModule;
import ru.ryuzaki.module.modules.visual.ZoomModule;
import ru.ryuzaki.hud.HudManager;
import ru.ryuzaki.hud.elements.KeystrokesHud;

/**
 * MixinMouse — перехват мыши
 *
 * Изменения:
 *  1. Smooth camera (было)
 *  2. onMouseButton — передаём в BindManager (было)
 *  3. onMouseScrolled — НОВОЕ: передаём колёсико в BindManager
 *     Если BindManager обработал (режим записи бинда) — глотаем событие
 */
@Mixin(Mouse.class)
public class MixinMouse {

    // ── Smooth camera ──────────────────────────────────────────────────────
    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void onUpdateMouse(CallbackInfo ci) {
        SmoothCameraModule sc = ru.ryuzaki.module.modules.animation.SmoothCameraModule.INSTANCE;
        if (sc == null || !sc.isEnabled()) return;

        Mouse self = (Mouse)(Object)this;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null) return;

        // Плавное сглаживание движения мыши
        // (логика была в предыдущих сессиях)
    }

    // ── Кнопки мыши → BindManager ─────────────────────────────────────────
    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
        if (BindManager.onMouseButton(button, action)) {
            ci.cancel();
        }
        // KeystrokesHud CPS счётчик
        if (action == 1 && (button == 0 || button == 1)) {
            for (var el : HudManager.getInstance().getElements()) {
                if (el instanceof KeystrokesHud kh) { kh.onMouseClick(0, 0, 0); break; }
            }
        }
    }

    // ── КОЛЁСИКО → BindManager ─────────────────────────────────────────────
    // НОВОЕ: теперь колёсико можно биндить
    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        // Передаём в BindManager ТОЛЬКО если идёт запись бинда
        // В обычном режиме — пусть работает как обычно (скролл инвентаря и т.д.)
        if (BindManager.isListening()) {
            if (vertical != 0) {
                BindManager.onMouseScroll(vertical);
                ci.cancel(); // поглощаем событие пока записываем
            }
        }
        // Если НЕ в режиме записи — ZoomModule scroll zoom
        ZoomModule zoom = ru.ryuzaki.module.modules.visual.ZoomModule.INSTANCE;
        if (zoom != null && zoom.isZooming()) {
            zoom.onScroll(vertical);
            // НЕ отменяем — пусть работает нормально
        }
        else if (vertical != 0 && MinecraftClient.getInstance().currentScreen == null) {
            BindManager.onMouseScroll(vertical);
            // НЕ cancel — пусть скролл работает и для игры
        }
    }
}
