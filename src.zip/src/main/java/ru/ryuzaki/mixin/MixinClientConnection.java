package ru.ryuzaki.mixin;

import net.minecraft.network.ClientConnection;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.misc.NetworkOptimizerModule;
import com.professor.cyberhacks.*;

@Mixin(ClientConnection.class)
public class MixinClientConnection {

    private int pendingPackets = 0;
    private static final int FLUSH_THRESHOLD = 4;

    @Inject(
        method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;)V",
        at = @At("HEAD"), require = 0
    )
    private void ryuzaki$onSendPacket(Packet packet, PacketCallbacks callbacks, CallbackInfo ci) {
        if (!MC.inGame() || !NetworkDebugger.isEnabled()) return;
        NetworkDebugger.logPacketDirection(true, packet.getClass().getSimpleName(), -1);
    }

    @Inject(
        method = "send(Lnet/minecraft/network/packet/Packet;Lnet/minecraft/network/PacketCallbacks;)V",
        at = @At("RETURN"), require = 0
    )
    private void ryuzaki$batchFlush(Packet<?> packet, PacketCallbacks callbacks, CallbackInfo ci) {
        NetworkOptimizerModule mod = ru.ryuzaki.module.modules.misc.NetworkOptimizerModule.INSTANCE;
        if (mod == null || !mod.isEnabled()) return;
        pendingPackets++;
        if (pendingPackets >= FLUSH_THRESHOLD) {
            pendingPackets = 0;
        }
    }
}
