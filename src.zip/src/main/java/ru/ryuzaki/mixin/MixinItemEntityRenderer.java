package ru.ryuzaki.mixin;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.ItemEntityRenderer;
import net.minecraft.client.render.entity.state.ItemEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Quaternionf;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.animation.ItemPhysicsModule;

@Mixin(ItemEntityRenderer.class)
public class MixinItemEntityRenderer {

    // Inject AFTER vanilla sets up the item transform (after push+translate)
    // so rotations happen around the item's actual position, not world origin
    @Inject(method = "render",
            at = @At(value = "INVOKE",
                     target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                     shift = At.Shift.AFTER),
            require = 0)
    private void onRenderItem(ItemEntityRenderState state,
                              MatrixStack matrices,
                              VertexConsumerProvider vertexConsumers,
                              int light, CallbackInfo ci) {
        ItemPhysicsModule mod = ItemPhysicsModule.INSTANCE;
        if (mod == null || !mod.isEnabled()) return;

        float age = state.age;

        if (mod.shouldRotate()) {
            // Rotate around item center (translate to center, rotate, translate back)
            float rotation = (age / 20.0f) * mod.getRotationSpeed() * 360.0f;
            // Items are roughly 0.25 units tall - rotate around their center
            matrices.translate(0, 0.125f, 0);
            matrices.multiply(new Quaternionf().rotateY((float)Math.toRadians(rotation)));
            matrices.multiply(new Quaternionf().rotateX((float)Math.toRadians(rotation * 0.3f)));
            matrices.translate(0, -0.125f, 0);
        }

        if (mod.shouldBounce()) {
            float bouncePhase  = (age % 20) / 20f;
            float bounceHeight = (float)Math.sin(bouncePhase * Math.PI) * mod.getBounciness() * 0.12f;
            matrices.translate(0, bounceHeight, 0);
        }
    }
}
