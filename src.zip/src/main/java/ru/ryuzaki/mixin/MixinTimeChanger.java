package ru.ryuzaki.mixin;
// src/main/java/ru/ryuzaki/mixin/MixinTimeChanger.java

import net.minecraft.world.dimension.DimensionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.world.TimeChangerModule;

// В MC 1.21.4 getSkyAngle — статический метод DimensionType(long time)
// World вызывает: this.getDimension().getSkyAngle(this.getTimeOfDay())
@Mixin(DimensionType.class)
public class MixinTimeChanger {

    @Inject(method = "getSkyAngle", at = @At("RETURN"), cancellable = true)
    private static void ryuzaki$changeSkyAngle(long time,
                                               CallbackInfoReturnable<Float> cir) {
        TimeChangerModule tc = ru.ryuzaki.module.modules.world.TimeChangerModule.INSTANCE;
        if (tc != null && tc.isEnabled()) {
            // Переводим время (0-24000) в угол неба (0.0-1.0)
            cir.setReturnValue(tc.time.getValue().floatValue() / 24000f);
        }
    }
}