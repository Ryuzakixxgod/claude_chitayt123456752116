package ru.ryuzaki.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.ryuzaki.module.modules.combat.VelocityModule;

/**
 * Scales client-side knockback through the Velocity module.
 */
@Mixin(LivingEntity.class)
public class MixinEntity {

    @Inject(method = "takeKnockback", at = @At("HEAD"), cancellable = true)
    private void ryuzaki$velocity(double strength, double x, double z, CallbackInfo ci) {
        VelocityModule vm = VelocityModule.INSTANCE;
        if (vm == null || !vm.isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        LivingEntity self = (LivingEntity)(Object)this;
        if (mc.player == null || self != mc.player) return;

        VelocityModule.KnockbackMultipliers multipliers = vm.getKnockbackMultipliers(self, 0.0F);
        if (multipliers.isVanilla()) return;

        double adjustedStrength = strength * (1.0 - self.getAttributeValue(EntityAttributes.KNOCKBACK_RESISTANCE));
        if (adjustedStrength <= 0.0) {
            ci.cancel();
            return;
        }

        Vec3d current = self.getVelocity();
        while (x * x + z * z < 1.0E-5F) {
            x = (Math.random() - Math.random()) * 0.01;
            z = (Math.random() - Math.random()) * 0.01;
        }

        Vec3d horizontal = new Vec3d(x, 0.0, z).normalize().multiply(adjustedStrength);
        double nextY = self.isOnGround()
            ? Math.min(0.4, current.y / 2.0 + adjustedStrength * multipliers.vertical())
            : current.y;

        self.velocityDirty = true;
        self.setVelocity(
            current.x / 2.0 - horizontal.x * multipliers.horizontal(),
            nextY,
            current.z / 2.0 - horizontal.z * multipliers.horizontal()
        );
        ci.cancel();
    }
}
