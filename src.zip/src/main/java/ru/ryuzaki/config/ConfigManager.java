package ru.ryuzaki.config;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.hud.HudManager;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;

/**
 * ConfigManager — JSON сериализация настроек модулей.
 *
 * Фикс: добавлено версионирование конфига.
 * При добавлении новых настроек в модуль старый конфиг не ломается —
 * отсутствующие ключи просто пропускаются, значения остаются дефолтными.
 *
 * Формат файла:
 * {
 *   "_version": 2,
 *   "ModuleName": {
 *     "enabled": true,
 *     "settings": { "key": value, ... }
 *   }
 * }
 */
public class ConfigManager {

    private static final int    CONFIG_VERSION = 2;
    private static final Path   CONFIG_DIR =
        FabricLoader.getInstance().getConfigDir().resolve("ryuzaki");
    private static final Gson   GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String DEFAULT = "default";

    // ── Сохранение ────────────────────────────────────────────────────
    public static void save(String name) {
        try {
            Files.createDirectories(CONFIG_DIR);
            Path file = CONFIG_DIR.resolve(name + ".json");
            try (Writer w = new OutputStreamWriter(
                    new FileOutputStream(file.toFile()), StandardCharsets.UTF_8)) {
                GSON.toJson(buildSnapshot(), w);
            }
        } catch (Exception e) {
            System.err.println("[Ryuzaki] Config save error: " + e.getMessage());
        }
    }

    // ── Асинхронное сохранение (не фризит игру) ───────────────────────
    public static void autoSave() {
        // Снимок делаем на текущем потоке, копируя данные
        JsonObject snapshot = buildSnapshotSafe();
        Thread t = new Thread(() -> {
            try {
                Files.createDirectories(CONFIG_DIR);
                Path file = CONFIG_DIR.resolve(DEFAULT + ".json");
                // Атомарная запись: пишем во временный файл, потом переименовываем
                Path tmp = CONFIG_DIR.resolve(DEFAULT + ".json.tmp");
                try (Writer w = new OutputStreamWriter(
                        new FileOutputStream(tmp.toFile()), StandardCharsets.UTF_8)) {
                    GSON.toJson(snapshot, w);
                }
                Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING,
                                      StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception e) {
                System.err.println("[Ryuzaki] Async config save error: " + e.getMessage());
            }
        }, "Ryuzaki-ConfigSave");
        t.setDaemon(true);
        t.start();
    }

    // ── Загрузка ──────────────────────────────────────────────────────
    public static void load(String name) {
        try {
            Path file = CONFIG_DIR.resolve(name + ".json");
            if (!Files.exists(file)) return;

            JsonObject root;
            try (Reader r = new InputStreamReader(
                    new FileInputStream(file.toFile()), StandardCharsets.UTF_8)) {
                root = JsonParser.parseReader(r).getAsJsonObject();
            }

            // Версионирование — предупреждение при несовпадении, но не отказ
            if (root.has("_version")) {
                int fileVersion = root.get("_version").getAsInt();
                if (fileVersion < CONFIG_VERSION) {
                    System.out.println("[Ryuzaki] Config version " + fileVersion
                        + " → " + CONFIG_VERSION + " (старые настройки сохранены)");
                }
            }

            for (Module m : ModuleManager.modules) {
                if (!root.has(m.name)) continue;
                JsonElement el = root.get(m.name);
                if (!el.isJsonObject()) continue;
                JsonObject mObj = el.getAsJsonObject();

                if (mObj.has("enabled")) {
                    boolean en = mObj.get("enabled").getAsBoolean();
                    if (en != m.isEnabled()) m.toggle();
                }

                if (!mObj.has("settings")) continue;
                JsonObject settings = mObj.getAsJsonObject("settings");

                for (Setting s : m.getAllSettings()) {
                    if (!settings.has(s.getName())) continue; // новые поля = дефолт
                    try {
                        applySettingValue(s, settings.get(s.getName()));
                    } catch (Exception ignored) {
                        // битое значение = дефолт, не ломаем загрузку
                    }
                }
            }
            // Load HUD elements
            if (root.has("_hud")) {
                JsonObject hudObj = root.getAsJsonObject("_hud");
                for (HudElement el : HudManager.getInstance().getElements()) {
                    if (!hudObj.has(el.name)) continue;
                    JsonObject elObj = hudObj.getAsJsonObject(el.name);
                    if (elObj.has("enabled")) el.enabled = elObj.get("enabled").getAsBoolean();
                    if (elObj.has("x") && elObj.has("y")) {
                        el.dragging.setX(elObj.get("x").getAsFloat());
                        el.dragging.setY(elObj.get("y").getAsFloat());
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("[Ryuzaki] Config load error: " + e.getMessage());
        }
    }

    private static void applySettingValue(Setting s, JsonElement val) {
        if      (s instanceof BooleanSetting bs) bs.setValue(val.getAsBoolean());
        else if (s instanceof NumberSetting  ns) ns.setValue(val.getAsDouble());
        else if (s instanceof ModeSetting    ms) ms.set(val.getAsString());
        else if (s instanceof BindSetting    bs) bs.setKey(val.getAsInt());
        else if (s instanceof ColorSetting   cs && val.isJsonObject()) {
            JsonObject c = val.getAsJsonObject();
            cs.setColor(new ColorRGBA(
                c.get("r").getAsInt(), c.get("g").getAsInt(),
                c.get("b").getAsInt(), c.get("a").getAsInt()));
        }
    }

    // ── Список конфигов ───────────────────────────────────────────────
    public static List<String> listConfigs() {
        try {
            if (!Files.exists(CONFIG_DIR)) return List.of();
            return Files.list(CONFIG_DIR)
                .filter(p -> p.toString().endsWith(".json"))
                .filter(p -> !p.getFileName().toString().endsWith(".tmp"))
                .map(p -> { String fn = p.getFileName().toString(); return fn.substring(0, fn.length()-5); })
                .toList();
        } catch (Exception e) { return List.of(); }
    }

    // ── Сериализация ──────────────────────────────────────────────────
    private static JsonObject buildSnapshot() {
        JsonObject root = new JsonObject();
        root.addProperty("_version", CONFIG_VERSION);
        for (Module m : ModuleManager.modules) {
            JsonObject mObj = new JsonObject();
            mObj.addProperty("enabled", m.isEnabled());
            JsonObject settings = new JsonObject();
            for (Setting s : m.getAllSettings()) {
                if      (s instanceof BooleanSetting bs) settings.addProperty(s.getName(), bs.isEnabled());
                else if (s instanceof NumberSetting  ns) settings.addProperty(s.getName(), ns.getValue());
                else if (s instanceof ModeSetting    ms) settings.addProperty(s.getName(), ms.getCurrent());
                else if (s instanceof BindSetting    bs) settings.addProperty(s.getName(), bs.getKey());
                else if (s instanceof ColorSetting   cs) {
                    ColorRGBA c = cs.getColor();
                    if (c != null) {
                        JsonObject cObj = new JsonObject();
                        cObj.addProperty("r", c.getRed());   cObj.addProperty("g", c.getGreen());
                        cObj.addProperty("b", c.getBlue());  cObj.addProperty("a", c.getAlpha());
                        settings.add(s.getName(), cObj);
                    }
                }
            }
            mObj.add("settings", settings);
            root.add(m.name, mObj);
        }
        // Save HUD elements
        JsonObject hudObj = new JsonObject();
        for (HudElement el : HudManager.getInstance().getElements()) {
            JsonObject elObj = new JsonObject();
            elObj.addProperty("enabled", el.enabled);
            elObj.addProperty("x", el.getX());
            elObj.addProperty("y", el.getY());
            hudObj.add(el.name, elObj);
        }
        root.add("_hud", hudObj);
        return root;
    }

    // Безопасный снимок: копируем список модулей перед итерацией
    // чтобы избежать ConcurrentModificationException
    private static JsonObject buildSnapshotSafe() {
        JsonObject root = new JsonObject();
        root.addProperty("_version", CONFIG_VERSION);
        // Копируем ссылку на список — ArrayList итерация thread-safe если нет модификаций
        List<Module> snapshot = new ArrayList<>(ModuleManager.modules);
        for (Module m : snapshot) {
            JsonObject mObj = new JsonObject();
            mObj.addProperty("enabled", m.isEnabled());
            JsonObject settings = new JsonObject();
            for (Setting s : m.getAllSettings()) {
                if      (s instanceof BooleanSetting bs) settings.addProperty(s.getName(), bs.isEnabled());
                else if (s instanceof NumberSetting  ns) settings.addProperty(s.getName(), ns.getValue());
                else if (s instanceof ModeSetting    ms) settings.addProperty(s.getName(), ms.getCurrent());
                else if (s instanceof BindSetting    bs) settings.addProperty(s.getName(), bs.getKey());
                else if (s instanceof ColorSetting   cs) {
                    ColorRGBA c = cs.getColor();
                    if (c != null) {
                        JsonObject cObj = new JsonObject();
                        cObj.addProperty("r", c.getRed());   cObj.addProperty("g", c.getGreen());
                        cObj.addProperty("b", c.getBlue());  cObj.addProperty("a", c.getAlpha());
                        settings.add(s.getName(), cObj);
                    }
                }
            }
            mObj.add("settings", settings);
            root.add(m.name, mObj);
        }
        // Save HUD elements
        JsonObject hudObj = new JsonObject();
        List<HudElement> hudSnapshot = new ArrayList<>(HudManager.getInstance().getElements());
        for (HudElement el : hudSnapshot) {
            JsonObject elObj = new JsonObject();
            elObj.addProperty("enabled", el.enabled);
            elObj.addProperty("x", el.getX());
            elObj.addProperty("y", el.getY());
            hudObj.add(el.name, elObj);
        }
        root.add("_hud", hudObj);
        return root;
    }
}
