package ru.ryuzaki.render;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;

/**
 * GlassmorphismHelper — рисует стеклянные панели с blur + tint.
 *
 * Использование в GUI:
 *   GlassmorphismHelper.drawGlassPanel(ctx, x, y, w, h, tintARGB, radius);
 *
 * Слои (снизу вверх):
 *   1. Размытое содержимое экрана (BlurFramebuffer)
 *   2. Полупрозрачный тинт (цвет темы)
 *   3. Верхний блик (градиент белого сверху)
 *   4. Нижняя рамка (тонкая светлая линия)
 */
public final class GlassmorphismHelper {

    private GlassmorphismHelper() {}

    /**
     * Рисует стеклянную панель.
     *
     * @param ctx       DrawContext
     * @param x,y       позиция
     * @param w,h       размер
     * @param tintARGB  цвет тинта поверх blur (обычно полупрозрачный)
     * @param borderARGB цвет рамки
     * @param blurAlpha прозрачность blur слоя [0..255]
     */
    public static void drawGlassPanel(DrawContext ctx,
                                       int x, int y, int w, int h,
                                       int tintARGB, int borderARGB,
                                       int blurAlpha) {
        MatrixStack ms = ctx.getMatrices();

        // ── 1. Blur слой ───────────────────────────────────────────────
        if (BlurFramebuffer.isReady()) {
            BlurFramebuffer.drawBlur(ms, x, y, w, h, blurAlpha);
        }

        // ── 2. Тинт поверх blur ────────────────────────────────────────
        ctx.fill(x, y, x + w, y + h, tintARGB);

        // ── 3. Верхний блик (glassmorphism белая линия сверху) ─────────
        // Яркая линия 1px сверху
        ctx.fill(x + 1, y, x + w - 1, y + 1, 0x22FFFFFF);
        // Второй ряд чуть темнее
        ctx.fill(x + 1, y + 1, x + w - 1, y + 2, 0x0EFFFFFF);

        // ── 4. Рамка ───────────────────────────────────────────────────
        // Верх
        ctx.fill(x,         y,         x + w,     y + 1,     borderARGB);
        // Низ
        ctx.fill(x,         y + h - 1, x + w,     y + h,     scaleAlpha(borderARGB, 0.4f));
        // Лево
        ctx.fill(x,         y + 1,     x + 1,     y + h - 1, scaleAlpha(borderARGB, 0.6f));
        // Право
        ctx.fill(x + w - 1, y + 1,     x + w,     y + h - 1, scaleAlpha(borderARGB, 0.3f));
    }

    /**
     * Стеклянная панель со скруглёнными углами.
     * Использует scissor для clip + рисует blur прямоугольником.
     */
    public static void drawGlassPanelRounded(DrawContext ctx,
                                              int x, int y, int w, int h,
                                              int tintARGB, int borderARGB,
                                              int blurAlpha, int radius) {
        MatrixStack ms = ctx.getMatrices();

        // Blur — всегда прямоугольный (scissor clip сделает скругление визуально)
        ctx.enableScissor(x, y, x + w, y + h);
        if (BlurFramebuffer.isReady()) {
            BlurFramebuffer.drawBlur(ms, x, y, w, h, blurAlpha);
        }
        ctx.disableScissor();

        // Тинт со скруглением
        fillRound(ctx, x, y, x + w, y + h, tintARGB, radius);

        // Блик
        ctx.fill(x + radius, y + 1, x + w - radius, y + 2, 0x20FFFFFF);

        // Рамка
        borderRound(ctx, x, y, x + w, y + h, borderARGB, radius);
    }

    // ── Утилиты ───────────────────────────────────────────────────────

    private static int scaleAlpha(int argb, float scale) {
        int a = (int)(((argb >> 24) & 0xFF) * scale);
        return (argb & 0x00FFFFFF) | ((a & 0xFF) << 24);
    }

    // Скруглённый прямоугольник (дублируем логику из GUI для независимости)
    public static void fillRound(DrawContext ctx, int x, int y, int x2, int y2, int c, int r) {
        if (x2 <= x || y2 <= y) return;
        r = Math.min(r, Math.min((x2 - x) / 2, (y2 - y) / 2));
        if (r <= 0) { ctx.fill(x, y, x2, y2, c); return; }
        ctx.fill(x + r, y,     x2 - r, y2,     c);
        ctx.fill(x,     y + r, x + r,  y2 - r, c);
        ctx.fill(x2-r,  y + r, x2,     y2 - r, c);
        for (int i = 0; i < r; i++) {
            int w = r - (int)Math.round(Math.sqrt(Math.max(0.0, (double)r*r-(double)(r-1-i)*(r-1-i))));
            ctx.fill(x+w,   y+i,     x+r,   y+i+1,   c);
            ctx.fill(x2-r,  y+i,     x2-w,  y+i+1,   c);
            ctx.fill(x+w,   y2-i-1,  x+r,   y2-i,    c);
            ctx.fill(x2-r,  y2-i-1,  x2-w,  y2-i,    c);
        }
    }

    public static void borderRound(DrawContext ctx, int x, int y, int x2, int y2, int c, int r) {
        if (x2 <= x || y2 <= y) return;
        r = Math.min(r, Math.min((x2-x)/2, (y2-y)/2));
        ctx.fill(x+r, y,     x2-r, y+1,   c);
        ctx.fill(x+r, y2-1,  x2-r, y2,    c);
        ctx.fill(x,   y+r,   x+1,  y2-r,  c);
        ctx.fill(x2-1,y+r,   x2,   y2-r,  c);
        for (int i = 0; i < r; i++) {
            int w = r - (int)Math.round(Math.sqrt(Math.max(0.0,(double)r*r-(double)(r-1-i)*(r-1-i))));
            ctx.fill(x+w,    y+i,     x+w+1,  y+i+1,   c);
            ctx.fill(x2-w-1, y+i,     x2-w,   y+i+1,   c);
            ctx.fill(x+w,    y2-i-1,  x+w+1,  y2-i,    c);
            ctx.fill(x2-w-1, y2-i-1,  x2-w,   y2-i,    c);
        }
    }
}
