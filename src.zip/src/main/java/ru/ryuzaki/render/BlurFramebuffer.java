package ru.ryuzaki.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30;

/**
 * BlurFramebuffer — двухпроходное сепарабельное гауссово размытие
 * для glassmorphism эффекта в GUI.
 *
 * В 1.21.4 ShaderProgram конструктор принимает только int (shader id),
 * кастомные шейдеры грузятся через отдельный механизм.
 * Поэтому реализуем blur через multi-pass копирование с накоплением:
 * это не настоящий gaussian blur, но визуально неотличим при малых радиусах
 * и работает без кастомных шейдеров.
 *
 * ОПТИМИЗАЦИИ:
 * - Debounce resize: не создаём новые framebuffer-ы каждый кадр
 * - Кэш размеров: lastW/lastH проверяются ДО создания
 * - early return: если размер не изменился — не пересоздаём
 * - capture() защищён от повторного вызова за кадр
 */
public final class BlurFramebuffer {

    private BlurFramebuffer() {}

    private static Framebuffer srcFBO  = null;
    private static Framebuffer blurFBO = null;
    private static int lastW = -1, lastH = -1;

    // ── Защита от повторного capture() за кадр ─────────────────────
    private static boolean captured = false;
    private static long lastCaptureFrame = -1;
    private static final long FRAME_DEBOUNCE_MS = 16; // ~60 FPS cap

    // ── Ensure framebuffers match current screen size — с debounce ─
    private static void ensureBuffers(int w, int h) {
        // Debounce: не пересоздаём если размер не изменился
        if (w == lastW && h == lastH && srcFBO != null && blurFBO != null) {
            return;
        }

        // Cleanup старые буферы если размер изменился
        if (w != lastW || h != lastH) {
            cleanup();
        }

        lastW = w; lastH = h;

        // Предвыделяем буферы — GPU allocate один раз
        try {
            srcFBO  = new SimpleFramebuffer(w, h, true);
            blurFBO = new SimpleFramebuffer(w, h, true);
            srcFBO .setClearColor(0f, 0f, 0f, 0f);
            blurFBO.setClearColor(0f, 0f, 0f, 0f);
        } catch (Exception e) {
            // Fallback: очищаем ссылки, blur будет пропущен
            System.err.println("[Ryuzaki] BlurFramebuffer init failed: " + e.getMessage());
            srcFBO = null;
            blurFBO = null;
        }
    }

    /**
     * Capture the current game framebuffer.
     * Call BEFORE the GUI starts rendering.
     * Защищён от повторного вызова за кадр через debounce.
     */
    public static void capture() {
        // Debounce: пропускаем если уже capture за этот кадр
        if (captured || RenderSystem.isOnRenderThread() == false) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        Framebuffer main = mc.getFramebuffer();
        int w = main.textureWidth, h = main.textureHeight;

        // early return если размер не изменился
        if (w == lastW && h == lastH && srcFBO != null) {
            captured = true;
            return;
        }

        ensureBuffers(w, h);
        if (srcFBO == null || blurFBO == null) return;

        // Blit main → srcFBO
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, main.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, srcFBO.fbo);
        GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, w, h,
            GL30.GL_COLOR_BUFFER_BIT, GL30.GL_LINEAR);

        // Simple blur: blit srcFBO → blurFBO with a tiny downscale+upscale
        // Это даёт дешёвую аппроксимацию blur без кастомных шейдеров
        int hw = Math.max(1, w / 4), hh = Math.max(1, h / 4);

        // Downscale
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, srcFBO.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, blurFBO.fbo);
        GL30.glBlitFramebuffer(0, 0, w, h, 0, 0, hw, hh,
            GL30.GL_COLOR_BUFFER_BIT, GL30.GL_LINEAR);

        // Upscale back — linear filter spread pixels = blur effect
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, blurFBO.fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, blurFBO.fbo);
        GL30.glBlitFramebuffer(0, 0, hw, hh, 0, 0, w, h,
            GL30.GL_COLOR_BUFFER_BIT, GL30.GL_LINEAR);

        // Restore main FBO
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, main.fbo);
        captured = true;
    }

    /**
     * Draw the blurred framebuffer region under a GUI element.
     * Call from within a DrawContext render phase.
     *
     * @param ms    MatrixStack from DrawContext
     * @param x,y   screen coordinates
     * @param w,h   size in screen pixels
     * @param alpha opacity of the blur layer [0..255]
     */
    public static void drawBlur(MatrixStack ms, int x, int y, int w, int h, int alpha) {
        if (!captured || blurFBO == null) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        int sw = mc.getFramebuffer().textureWidth;
        int sh = mc.getFramebuffer().textureHeight;

        // UV coords — flip Y because OpenGL framebuffer is bottom-up
        float u0 = (float) x / sw,        u1 = (float)(x + w) / sw;
        float v0 = 1f - (float)(y + h) / sh, v1 = 1f - (float) y / sh;

        float a = alpha / 255f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, blurFBO.getColorAttachment());
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

        Matrix4f mat = ms.peek().getPositionMatrix();
        BufferBuilder buf = Tessellator.getInstance()
            .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        buf.vertex(mat, x,     y,     0).texture(u0, v1).color(1f, 1f, 1f, a);
        buf.vertex(mat, x,     y + h, 0).texture(u0, v0).color(1f, 1f, 1f, a);
        buf.vertex(mat, x + w, y + h, 0).texture(u1, v0).color(1f, 1f, 1f, a);
        buf.vertex(mat, x + w, y,     0).texture(u1, v1).color(1f, 1f, 1f, a);

        try {
            BufferRenderer.drawWithGlobalProgram(buf.end());
        } catch (Exception ignored) {}

        RenderSystem.disableBlend();
    }

    /** Delete framebuffers and reset state. Call when GUI closes. */
    public static void cleanup() {
        if (srcFBO  != null) { srcFBO.delete();  srcFBO  = null; }
        if (blurFBO != null) { blurFBO.delete(); blurFBO = null; }
        captured = false;
        lastW = lastH = -1;
    }

    /**
     * Сброс capture на новый кадр. Вызывать в начале каждого рендера GUI.
     * Это позволяет capture() работать корректно между кадрами.
     */
    public static void onFrameStart() {
        captured = false;
    }

    public static boolean isReady() { return captured && blurFBO != null; }
}
