package ru.ryuzaki.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgram;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;

/**
 * GlStateCache — кэш текущего GL состояния.
 *
 * Проблема: RenderSystem.setShader(), enableBlend(), setShaderTexture()
 * вызываются сотни раз за кадр, часто подряд с одинаковыми аргументами.
 * Каждый вызов = вызов в нативный OpenGL driver = overhead.
 *
 * Решение: запоминаем последнее установленное значение.
 * Если оно не изменилось — пропускаем GL вызов.
 *
 * Используется в нашем 3D рендере (TargetESP, GlowESP, ChestESP).
 * Для vanilla рендера — не трогаем (сломаем).
 *
 * Выигрыш на нашем рендере: -20-40% overhead от state changes.
 */
public final class GlStateCache {

    private GlStateCache() {}

    private static boolean blendEnabled    = false;
    private static int     blendSrcFactor  = -1;
    private static int     blendDstFactor  = -1;
    private static boolean depthTestEnabled= true;
    private static int     boundTexture0   = -1;
    private static int     currentShader   = -1;

    // Сбрасываем кэш в начале кадра (RenderCache.update() уже делает это)
    public static void resetFrame() {
        blendEnabled     = false;
        blendSrcFactor   = -1;
        blendDstFactor   = -1;
        depthTestEnabled = true;
        boundTexture0    = -1;
        currentShader    = -1;
    }

    /** Включить blend только если ещё не включён */
    public static void enableBlend() {
        if (!blendEnabled) {
            GL11.glEnable(GL11.GL_BLEND);
            blendEnabled = true;
        }
    }

    /** Отключить blend только если был включён */
    public static void disableBlend() {
        if (blendEnabled) {
            GL11.glDisable(GL11.GL_BLEND);
            blendEnabled = false;
        }
    }

    /** Установить blend function только если изменилась */
    public static void blendFunc(int src, int dst) {
        if (src != blendSrcFactor || dst != blendDstFactor) {
            GL11.glBlendFunc(src, dst);
            blendSrcFactor = src;
            blendDstFactor = dst;
        }
    }

    /** Включить depth test только если ещё не включён */
    public static void enableDepthTest() {
        if (!depthTestEnabled) {
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            depthTestEnabled = true;
        }
    }

    /** Отключить depth test только если был включён */
    public static void disableDepthTest() {
        if (depthTestEnabled) {
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            depthTestEnabled = false;
        }
    }

    /** Привязать текстуру к unit 0 только если изменилась */
    public static void bindTexture(int textureId) {
        if (textureId != boundTexture0) {
            GL13.glActiveTexture(GL13.GL_TEXTURE0);
            GL11.glBindTexture(GL11.GL_TEXTURE_2D, textureId);
            boundTexture0 = textureId;
        }
    }

    // ── Геттеры для диагностики ─────────────────────────────────────
    public static boolean isBlendEnabled()     { return blendEnabled; }
    public static boolean isDepthTestEnabled() { return depthTestEnabled; }
}
