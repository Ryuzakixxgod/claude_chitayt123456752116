package ru.ryuzaki.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

/**
 * RyuzakiRenderBatch — пре-аллоцированный буфер для батчинга draw calls.
 *
 * Проблема ваниллы и нашего кода:
 *   Tessellator.begin() → fill vertices → buf.end() → drawWithGlobalProgram()
 *   = 1 draw call на каждый вызов = GPU driver overhead × N
 *
 * Решение: накапливаем все вершины одного типа в один буфер,
 * флашим один раз в конце кадра.
 *
 * Использование:
 *   RyuzakiRenderBatch.QUADS.vertex(mat, x, y, z).color(r,g,b,a);
 *   ... (много вершин)
 *   RyuzakiRenderBatch.flush(ms); // один draw call
 *
 * Экономия: вместо 50 draw calls → 2-3 (по одному на тип геометрии).
 */
public final class RyuzakiRenderBatch {

    // Максимум вершин в одном батче (4 вершины × 65536 = 262144 bytes)
    private static final int MAX_VERTS = 65536;

    // Три буфера — для основных типов геометрии наших модулей
    public static final Batch QUADS  = new Batch(VertexFormat.DrawMode.QUADS);
    public static final Batch TRIFAN = new Batch(VertexFormat.DrawMode.TRIANGLE_FAN);
    public static final Batch LINES  = new Batch(VertexFormat.DrawMode.DEBUG_LINES);

    private RyuzakiRenderBatch(){}

    public static class Batch {
        private final VertexFormat.DrawMode mode;
        // Pre-allocated float array — ноль GC при добавлении вершин
        // [x, y, z, r, g, b, a] × MAX_VERTS
        private final float[] data = new float[MAX_VERTS * 7];
        private int count = 0; // текущее кол-во вершин
        private Matrix4f matrix = null;

        private Batch(VertexFormat.DrawMode mode){ this.mode=mode; }

        /** Добавить вершину. Возвращает this для chaining. */
        public Batch vertex(Matrix4f mat, float x, float y, float z){
            if(count >= MAX_VERTS-4) flush(); // автофлаш при переполнении
            if(matrix==null) matrix=mat;
            int i=count*7;
            data[i]=x; data[i+1]=y; data[i+2]=z;
            data[i+3]=1; data[i+4]=1; data[i+5]=1; data[i+6]=1; // temp color
            count++;
            return this;
        }

        public void color(int r, int g, int b, int a){
            if(count==0) return;
            int i=(count-1)*7;
            data[i+3]=r/255f; data[i+4]=g/255f; data[i+5]=b/255f; data[i+6]=a/255f;
        }

        public boolean isEmpty(){ return count==0; }

        /** Флашим накопленный буфер одним draw call */
        public void flush(){
            if(count<(mode==VertexFormat.DrawMode.QUADS?4:mode==VertexFormat.DrawMode.TRIANGLE_FAN?3:2)) {
                count=0; matrix=null; return;
            }
            try {
                BufferBuilder buf = Tessellator.getInstance()
                    .begin(mode, VertexFormats.POSITION_COLOR);
                Matrix4f mat = matrix;
                for(int i=0; i<count; i++){
                    int idx=i*7;
                    buf.vertex(mat, data[idx], data[idx+1], data[idx+2])
                       .color((int)(data[idx+3]*255),(int)(data[idx+4]*255),
                              (int)(data[idx+5]*255),(int)(data[idx+6]*255));
                }
                BufferRenderer.drawWithGlobalProgram(buf.end());
            } catch(Exception ignored){}
            count=0; matrix=null;
        }
    }

    /** Флашим все буферы */
    public static void flushAll(){
        QUADS.flush();
        TRIFAN.flush();
        LINES.flush();
    }
}
