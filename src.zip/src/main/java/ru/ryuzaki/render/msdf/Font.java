package ru.ryuzaki.render.msdf;

public record Font(MsdfFont font) {

    public Instance getFont(float size) {
        return new Instance(font, size);
    }

    public float getWidth(String text, float size) {
        return font.getWidth(text, size);
    }

    public float getHeight(float size) {
        return font.getHeight(size);
    }

    public float getLineHeight(float size) {
        return font.getLineHeight(size);
    }

    /** Represents a font at a specific size, used for rendering */
    public record Instance(MsdfFont font, float size) {
        public float getWidth(String text) { return font.getWidth(text, size); }
        public float getHeight() { return font.getHeight(size); }
        public float getLineHeight() { return font.getLineHeight(size); }
    }
}
