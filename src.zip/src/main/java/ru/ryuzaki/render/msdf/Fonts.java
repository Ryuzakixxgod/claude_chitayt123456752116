package ru.ryuzaki.render.msdf;

import net.minecraft.util.Identifier;
import ru.ryuzaki.render.providers.ResourceProvider;

/**
 * SF Pro шрифты — порт из Plintus/Minced.
 * Загружаются из assets/ryuzaki/fonts/
 */
public final class Fonts {

    public static Font BOLD;
    public static Font MEDIUM;

    private static boolean initialized = false;
    private static String lastFailureMessage = "";

    public static void init() {
        if (initialized) return;
        ResourceProvider.init();
        if (!ResourceProvider.isReady()) return;
        try {
            BOLD   = loadFont("sf-pro-bold");
            MEDIUM = loadFont("sf-pro-medium");
            initialized = true;
            lastFailureMessage = "";
        } catch (Exception e) {
            String message = String.valueOf(e.getMessage());
            if (!message.equals(lastFailureMessage)) {
                System.err.println("[Ryuzaki] Font load failed: " + message);
                lastFailureMessage = message;
            }
            BOLD = null; MEDIUM = null;
        }
    }

    public static boolean isInitialized() {
        return initialized;
    }

    private static Font loadFont(String name) {
        MsdfFont msdf = MsdfFont.builder()
            .atlas(Identifier.of("ryuzaki", "fonts/" + name + ".png"))
            .data(Identifier.of("ryuzaki", "fonts/" + name + ".json"))
            .build();
        return new Font(msdf);
    }

    public static float getWidth(String text, float size, boolean bold) {
        Font f = bold ? BOLD : MEDIUM;
        if (f == null) return net.minecraft.client.MinecraftClient.getInstance().textRenderer.getWidth(text);
        return f.getWidth(text, size);
    }

    public static float getHeight(float size, boolean bold) {
        Font f = bold ? BOLD : MEDIUM;
        if (f == null) return 8f;
        return f.getHeight(size);
    }
}
