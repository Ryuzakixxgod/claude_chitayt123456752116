package ru.ryuzaki.render.scissor.api;

public interface Producer<T> {
    T create();
}