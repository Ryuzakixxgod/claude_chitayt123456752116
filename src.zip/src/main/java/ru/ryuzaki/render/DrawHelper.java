package ru.ryuzaki.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Defines;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gl.ShaderProgramKey;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import ru.ryuzaki.render.builders.Builder;
import ru.ryuzaki.render.builders.states.*;

import java.awt.Color;

/**
 * Main render utility — скруглённые прямоугольники через GLSL шейдер,
 * текст, блюр. Порт DrawHelper из Plintus/Minced.
 */
public final class DrawHelper {

    private DrawHelper() {}

    // ── Rounded Rectangle (через GLSL шейдер из client2) ────────────
    /** Fast overload - avoids Color object allocation */
    public static void drawRect(MatrixStack ms, float x, float y, float w, float h, float r, int argb) {
        int a=(argb>>24)&0xFF,r2=(argb>>16)&0xFF,g=(argb>>8)&0xFF,b=argb&0xFF;
        drawRect(ms,x,y,w,h,r,new Color(r2,g,b,a));
    }
    public static void drawOutline(MatrixStack ms, float x, float y, float w, float h, float r, int argb, float t) {
        int a=(argb>>24)&0xFF,r2=(argb>>16)&0xFF,g=(argb>>8)&0xFF,b=argb&0xFF;
        drawOutline(ms,x,y,w,h,r,new Color(r2,g,b,a),t);
    }

    public static void drawRect(MatrixStack ms, float x, float y, float w, float h, float r, Color color) {
        Builder.rectangle()
            .size(new SizeState(w, h))
            .color(new QuadColorState(color))
            .radius(new QuadRadiusState(Math.max(0, r - 2)))
            .smoothness(1.0f)
            .build()
            .render(ms.peek().getPositionMatrix(), x, y);
    }

    public static void drawRect(MatrixStack ms, float x, float y, float w, float h, float r, Color c1, Color c2, Color c3, Color c4) {
        Builder.rectangle()
            .size(new SizeState(w, h))
            .color(new QuadColorState(c1, c2, c3, c4))
            .radius(new QuadRadiusState(Math.max(0, r - 2)))
            .smoothness(1.0f)
            .build()
            .render(ms.peek().getPositionMatrix(), x, y);
    }

    public static void drawRect(MatrixStack ms, float x, float y, float w, float h, Color color) {
        drawRect(ms, x, y, w, h, 0, color);
    }

    // Gradient top-bottom
    public static void drawRectGradient(MatrixStack ms, float x, float y, float w, float h, float r, Color top, Color bottom) {
        drawRect(ms, x, y, w, h, r, top, top, bottom, bottom);
    }

    // Outline (border only)
    public static void drawOutline(MatrixStack ms, float x, float y, float w, float h, float r, Color color, float thickness) {
        Builder.outline()
            .size(new SizeState(w, h))
            .radius(new QuadRadiusState(Math.max(0, r - 2)))
            .color(new QuadColorState(color))
            .thickness(thickness)
            .smoothness(1.0f)
            .build()
            .render(ms.peek().getPositionMatrix(), x, y, 0);
    }

    // Circle
    public static void drawCircle(MatrixStack ms, float cx, float cy, float radius, Color color) {
        Builder.circle()
            .size(new SizeState(radius * 2, radius * 2))
            .color(new QuadColorState(color))
            .smoothness(1.0f)
            .build()
            .render(ms.peek().getPositionMatrix(), cx - radius, cy - radius);
    }

    // Blur (background blur effect)
    public static void drawBlur(MatrixStack ms, float x, float y, float w, float h, float r, Color color, float blurRadius) {
        try {
            Builder.blur()
                .size(new SizeState(w, h))
                .radius(new QuadRadiusState(Math.max(0, r - 2)))
                .color(new QuadColorState(color))
                .blurRadius(blurRadius)
                .smoothness(1.0f)
                .build()
                .render(ms.peek().getPositionMatrix(), x, y, 0);
        } catch (Exception ignored) {
            // Blur not always available
        }
    }

    // ── Text via MSDF font ───────────────────────────────────────────
    public static void drawText(Matrix4f matrix, ru.ryuzaki.render.msdf.Font.Instance fontInstance, String text, float x, float y, Color color) {
        if (fontInstance == null || text == null || text.isEmpty()) return;
        try {
            Builder.text()
                .font(fontInstance)
                .text(text)
                .color(color.getRGB())
                .build()
                .render(matrix, x, y, 0);
        } catch (Exception ignored) {}
    }

    // Convenience: draw with MC text renderer (fallback)
    public static void drawMCText(MatrixStack ms, String text, float x, float y, int color, boolean shadow) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.textRenderer == null) return;
        ms.push();
        mc.textRenderer.draw(
            net.minecraft.text.Text.literal(text),
            x, y, color, shadow,
            ms.peek().getPositionMatrix(),
            mc.getBufferBuilders().getEntityVertexConsumers(),
            net.minecraft.client.font.TextRenderer.TextLayerType.NORMAL,
            0, 0xF000F0
        );
        mc.getBufferBuilders().getEntityVertexConsumers().draw();
        ms.pop();
    }

    // ── Color helpers ────────────────────────────────────────────────
    public static Color withAlpha(Color color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }

    public static Color lerp(Color a, Color b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        float it = 1 - t;
        return new Color(
            Math.max(0, Math.min(255, (int)(a.getRed()   * it + b.getRed()   * t))),
            Math.max(0, Math.min(255, (int)(a.getGreen() * it + b.getGreen() * t))),
            Math.max(0, Math.min(255, (int)(a.getBlue()  * it + b.getBlue()  * t))),
            Math.max(0, Math.min(255, (int)(a.getAlpha() * it + b.getAlpha() * t)))
        );
    }

    // Standard Plintus colors
    /** Fast alpha blend without Color object allocation */
    public static int withAlphaInt(int argb, int alpha) {
        return (argb & 0x00FFFFFF) | ((alpha & 0xFF) << 24);
    }
    /** Mix two ARGB ints - avoid Color allocation */
    public static int blendArgb(int a, int b, float t) {
        int ar=(a>>16)&0xFF,ag=(a>>8)&0xFF,ab=a&0xFF;
        int br=(b>>16)&0xFF,bg=(b>>8)&0xFF,bb2=b&0xFF;
        int aa=(a>>24)&0xFF,ba=(b>>24)&0xFF;
        return (((int)(aa+(ba-aa)*t))<<24)|(((int)(ar+(br-ar)*t))<<16)|(((int)(ag+(bg-ag)*t))<<8)|((int)(ab+(bb2-ab)*t));
    }

    public static final Color ORANGE     = new Color(0xFF, 0x99, 0x00);
    public static final Color BG         = new Color(8, 8, 8, 210);
    public static final Color BG_DARK    = new Color(5, 5, 5, 225);
    public static final Color WHITE      = new Color(255, 255, 255, 255);
    public static final Color GRAY       = new Color(180, 180, 180, 255);
    public static final Color GRAY_DIM   = new Color(120, 120, 120, 255);
    public static final Color SEPARATOR  = new Color(255, 255, 255, 25);
    public static final Color KEY_PRESS  = new Color(200, 95, 0, 210);
    public static final Color CELL_BG    = new Color(35, 35, 35, 190);
}
