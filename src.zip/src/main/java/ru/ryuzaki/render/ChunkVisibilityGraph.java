package ru.ryuzaki.render;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkSectionPos;
import net.minecraft.util.math.Direction;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.util.ArrayDeque;
import java.util.BitSet;
import java.util.HashMap;

/**
 * ChunkVisibilityGraph — Sodium-style BFS occlusion culling.
 *
 * Реальная проверка непрозрачности границ секций + frustum.
 * Секции за каменными стенами не рендерятся.
 *
 * Оптимизации против наивной реализации:
 * 1. passabilityCache — результат isBoundaryPassable() кэшируется
 *    Ключ: (sx,sy,sz,dir). Сбрасывается только при изменении чанка.
 *    Без кэша: 16 getBlockState() на каждую BFS пару × все пары = тысячи вызовов.
 *    С кэшем: 16 вызовов один раз, потом O(1) lookup.
 *
 * 2. Time budget: BFS останавливается если потратил > 1ms.
 *    Нет полного результата → текущий visibleSet (неполный) лучше чем пропуск.
 *    Следующий кадр дорисует остальное.
 *
 * 3. Обновление только при движении камеры > 1.5° или > 1 блок.
 */
public final class ChunkVisibilityGraph {

    private static ChunkVisibilityGraph instance;
    public static ChunkVisibilityGraph get() {
        if (instance == null) instance = new ChunkVisibilityGraph();
        return instance;
    }

    private static final int MAX_DIM      = 64;
    private static final int MAX_SECTIONS = MAX_DIM * MAX_DIM * MAX_DIM;
    private static final int BOUNDARY_STEP = 4; // проверяем каждый 4-й блок на границе

    private final BitSet visibleSet  = new BitSet(MAX_SECTIONS);
    private final ArrayDeque<Long> bfsQueue = new ArrayDeque<>(4096);

    // Кэш проходимости: Long ключ (sx,sy,sz,dir) → Boolean
    // Сбрасывается при смене секции камеры или render distance
    private final HashMap<Long, Boolean> passCache = new HashMap<>(8192);

    private int   lastSectionX    = Integer.MAX_VALUE;
    private int   lastSectionY    = Integer.MAX_VALUE;
    private int   lastSectionZ    = Integer.MAX_VALUE;
    private float lastYaw         = Float.MAX_VALUE;
    private float lastPitch       = Float.MAX_VALUE;
    private int   lastRenderDist  = -1;

    private int worldMinSectionY = -4;
    private int renderDist       = 8;

    public void update() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        int camSX = ChunkSectionPos.getSectionCoord(RyuzakiRenderCache.camPosX);
        int camSY = ChunkSectionPos.getSectionCoord(RyuzakiRenderCache.camPosY);
        int camSZ = ChunkSectionPos.getSectionCoord(RyuzakiRenderCache.camPosZ);
        float yaw   = RyuzakiRenderCache.camYaw;
        float pitch = RyuzakiRenderCache.camPitch;
        int   rd    = mc.options.getViewDistance().getValue();

        boolean moved = camSX != lastSectionX || camSY != lastSectionY || camSZ != lastSectionZ
            || Math.abs(yaw - lastYaw) > 1.5f || Math.abs(pitch - lastPitch) > 1.5f;

        boolean rdChanged = rd != lastRenderDist;

        if (!moved && !rdChanged) return;

        if (rdChanged || camSX != lastSectionX || camSY != lastSectionY || camSZ != lastSectionZ) {
            // При смене позиции секции или render distance — сбрасываем кэш passability
            // (блоки могли измениться)
            passCache.clear();
        }

        lastSectionX = camSX; lastSectionY = camSY; lastSectionZ = camSZ;
        lastYaw = yaw; lastPitch = pitch; lastRenderDist = rd;

        renderDist       = rd;
        worldMinSectionY = mc.world.getBottomSectionCoord();

        rebuildVisibility(camSX, camSY, camSZ, mc);
    }

    private void rebuildVisibility(int camX, int camY, int camZ, MinecraftClient mc) {
        visibleSet.clear();
        bfsQueue.clear();

        long startKey = sectionKey(camX, camY, camZ);
        if (startKey < 0) return;

        visibleSet.set((int) startKey);
        bfsQueue.add(startKey);

        Direction[] dirs = Direction.values();
        long timeBudget  = System.nanoTime() + 1_000_000L; // 1ms бюджет

        while (!bfsQueue.isEmpty()) {
            // Превышен бюджет — останавливаемся (неполный результат лучше зависания)
            if ((bfsQueue.size() & 15) == 0 && System.nanoTime() > timeBudget) break;

            long key = bfsQueue.poll();
            int sx = keyX(key), sy = keyY(key), sz = keyZ(key);

            for (int di = 0; di < dirs.length; di++) {
                Direction dir = dirs[di];
                int nx = sx + dir.getOffsetX();
                int ny = sy + dir.getOffsetY();
                int nz = sz + dir.getOffsetZ();

                long nkey = sectionKey(nx, ny, nz);
                if (nkey < 0) continue;
                if (visibleSet.get((int) nkey)) continue;

                // Дистанция
                int dx = nx - camX, dy = ny - camY, dz = nz - camZ;
                if (dx*dx + dy*dy + dz*dz > renderDist * renderDist) continue;

                // Frustum через кэш
                double wx = nx*16.0+8.0, wy = ny*16.0+8.0, wz = nz*16.0+8.0;
                if (!RyuzakiRenderCache.isInFrustum(wx, wy, wz)) continue;

                // Occlusion: есть ли проход через границу?
                if (!isBoundaryPassableCached(sx, sy, sz, nx, ny, nz, di, mc)) continue;

                visibleSet.set((int) nkey);
                bfsQueue.add(nkey);
            }
        }
    }

    private boolean isBoundaryPassableCached(int sx, int sy, int sz,
                                              int nx, int ny, int nz,
                                              int dirIndex, MinecraftClient mc) {
        // Ключ: упаковываем координаты и направление в long
        // Используем sx/sy/sz (источник) + dirIndex
        long cacheKey = ((long)(sx + 1024) << 40) | ((long)(sy + 1024) << 28)
                      | ((long)(sz + 1024) << 16) | dirIndex;

        Boolean cached = passCache.get(cacheKey);
        if (cached != null) return cached;

        boolean result = isBoundaryPassable(sx, sy, sz, nx, ny, nz,
                                             Direction.values()[dirIndex], mc);
        passCache.put(cacheKey, result);
        return result;
    }

    private boolean isBoundaryPassable(int sx, int sy, int sz,
                                        int nx, int ny, int nz,
                                        Direction dir, MinecraftClient mc) {
        if (mc.world == null) return true;

        int baseX = nx*16, baseY = ny*16, baseZ = nz*16;

        switch (dir) {
            case EAST, WEST -> {
                int bx = (dir == Direction.EAST) ? baseX : sx*16+15;
                for (int by = baseY; by < baseY+16; by += BOUNDARY_STEP)
                    for (int bz = baseZ; bz < baseZ+16; bz += BOUNDARY_STEP)
                        if (isAirOrTransparent(mc, bx, by, bz)) return true;
            }
            case UP, DOWN -> {
                int by = (dir == Direction.UP) ? baseY : sy*16+15;
                for (int bx = baseX; bx < baseX+16; bx += BOUNDARY_STEP)
                    for (int bz = baseZ; bz < baseZ+16; bz += BOUNDARY_STEP)
                        if (isAirOrTransparent(mc, bx, by, bz)) return true;
            }
            case SOUTH, NORTH -> {
                int bz = (dir == Direction.SOUTH) ? baseZ : sz*16+15;
                for (int bx = baseX; bx < baseX+16; bx += BOUNDARY_STEP)
                    for (int by = baseY; by < baseY+16; by += BOUNDARY_STEP)
                        if (isAirOrTransparent(mc, bx, by, bz)) return true;
            }
        }
        return false;
    }

    private boolean isAirOrTransparent(MinecraftClient mc, int x, int y, int z) {
        try {
            BlockState bs = mc.world.getBlockState(new BlockPos(x, y, z));
            return bs.isAir() || !bs.isOpaque();
        } catch (Exception e) {
            return true;
        }
    }

    public boolean isSectionVisible(int sx, int sy, int sz) {
        long key = sectionKey(sx, sy, sz);
        if (key < 0) return true;
        return visibleSet.get((int) key);
    }

    private long sectionKey(int sx, int sy, int sz) {
        int ox = sx + 32, oy = sy - worldMinSectionY, oz = sz + 32;
        if (ox < 0 || ox >= MAX_DIM || oy < 0 || oy >= MAX_DIM || oz < 0 || oz >= MAX_DIM) return -1;
        return ox * MAX_DIM * MAX_DIM + oy * MAX_DIM + oz;
    }

    private int keyX(long k) { return (int)(k / (MAX_DIM * MAX_DIM)) - 32; }
    private int keyY(long k) { return (int)((k / MAX_DIM) % MAX_DIM) + worldMinSectionY; }
    private int keyZ(long k) { return (int)(k % MAX_DIM) - 32; }
}
