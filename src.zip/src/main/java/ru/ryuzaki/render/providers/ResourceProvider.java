package ru.ryuzaki.render.providers;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

public final class ResourceProvider {

	private static ResourceManager RESOURCE_MANAGER;
	public static void init() { RESOURCE_MANAGER = MinecraftClient.getInstance().getResourceManager(); }
	public static boolean isReady() { return RESOURCE_MANAGER != null; }
	private static final Gson GSON = new Gson();
	
	public static Identifier getShaderIdentifier(String name) {
		return Identifier.of("ryuzaki", "core/" + name);
	}

	public static JsonObject toJson(Identifier identifier) {
		return JsonParser.parseString(toString(identifier)).getAsJsonObject();
	}

	public static <T> T fromJsonToInstance(Identifier identifier, Class<T> clazz) {
		return GSON.fromJson(toString(identifier), clazz);
	}

	public static String toString(Identifier identifier) {
		return toString(identifier, "\n");
	}
	
	public static String toString(Identifier identifier, String delimiter) {
		if (RESOURCE_MANAGER == null) {
			init();
		}
		if (RESOURCE_MANAGER == null) {
			throw new IllegalStateException("Resource manager is not ready yet");
		}
		try(InputStream inputStream = RESOURCE_MANAGER.open(identifier);
				BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
			return reader.lines().collect(Collectors.joining(delimiter));
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
	}

}
