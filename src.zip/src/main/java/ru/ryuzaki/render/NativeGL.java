package ru.ryuzaki.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.*;

import java.nio.FloatBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * NativeGL — zero-overhead 3D renderer.
 *
 * Bypasses MC's Tessellator/BufferBuilder/BuiltBuffer chain entirely.
 * Uses direct OpenGL VAO+VBO with pre-allocated FloatBuffers.
 *
 * ИНИЦИАЛИЗАЦИЯ ОТЛОЖЕНА до первого вызова begin()/flush() —
 * это решает краш EXCEPTION_ACCESS_VIOLATION при старте,
 * когда OpenGL контекст ещё не создан.
 */
public final class NativeGL {

    private NativeGL() {}

    // ── Persistent VBO ─────────────────────────────────────────────
    private static int vao = -1;
    private static int vbo = -1;
    private static boolean initialized = false;

    // Pre-allocated vertex buffer — 65536 floats = 16384 vertices (x,y,z,r,g,b,a)
    private static final int MAX_VERTS = 16384;
    private static final int STRIDE    = 7; // x y z r g b a
    private static FloatBuffer buf;

    /**
     * Отложенная инициализация VAO/VBO.
     * БЕЗОПАСНО вызывать в любой момент — инициализация
     * произойдёт только когда OpenGL контекст готов.
     */
    private static void ensureInitialized() {
        if (initialized) return;

        // Создаём буфер сразу (CPU-side, не требует GL контекста)
        buf = BufferUtils.createFloatBuffer(MAX_VERTS * STRIDE);

        // Создаём VAO/VBO — требует активного GL контекста
        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        // Allocate GPU buffer once, update with glBufferSubData
        glBufferData(GL_ARRAY_BUFFER, (long)MAX_VERTS * STRIDE * 4, GL_DYNAMIC_DRAW);
        // Vertex attribs: attrib 0 = xyz, attrib 1 = rgba
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 3, GL_FLOAT, false, STRIDE * 4, 0L);
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 4, GL_FLOAT, false, STRIDE * 4, 3L * 4);
        glBindVertexArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, 0);
        initialized = true;
    }

    /** Begin collecting vertices into the pre-allocated buffer */
    public static void begin() {
        ensureInitialized();
        buf.clear();
    }

    /** Add vertex: world position + RGBA color (0-255) */
    public static void vertex(float x, float y, float z, int r, int g, int b, int a) {
        if (buf.remaining() < STRIDE) return; // overflow guard
        buf.put(x).put(y).put(z)
           .put(r / 255f).put(g / 255f).put(b / 255f).put(a / 255f);
    }

    /** Add vertex: world position + pre-packed ARGB color */
    public static void vertex(float x, float y, float z, int argb) {
        vertex(x, y, z, (argb>>16)&0xFF, (argb>>8)&0xFF, argb&0xFF, (argb>>24)&0xFF);
    }

    /**
     * Flush buffer to GPU and draw.
     * mode: GL_LINES, GL_TRIANGLES, GL_LINE_LOOP, GL_TRIANGLE_STRIP etc.
     * modelView: current MatrixStack peek positionMatrix
     */
    public static void flush(int mode, Matrix4f modelView) {
        if (!initialized || buf.position() == 0) return;
        buf.flip();
        int count = buf.limit() / STRIDE;

        // Get current VAO state
        int prevVAO = glGetInteger(GL_VERTEX_ARRAY_BINDING);
        int prevArrayBuffer = glGetInteger(GL_ARRAY_BUFFER_BINDING);

        // Load data into our VBO
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferSubData(GL_ARRAY_BUFFER, 0, buf);

        // Set up OpenGL state for rendering
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();

        // Bind our VAO and draw
        glBindVertexArray(vao);
        glDrawArrays(mode, 0, count);
        glBindVertexArray(0);

        // Restore previous GL state
        glBindBuffer(GL_ARRAY_BUFFER, prevArrayBuffer);
        glBindVertexArray(prevVAO);
    }

    /**
     * Fast line between two world points.
     * Single begin/flush = 1 draw call for the whole batch.
     * Caller must begin(), add lines, then flush().
     */
    public static void line(float x1,float y1,float z1, float x2,float y2,float z2,
                            int r,int g,int b,int a) {
        vertex(x1,y1,z1,r,g,b,a);
        vertex(x2,y2,z2,r,g,b,0);
    }

    /** Ring/circle in the XZ plane — adds segments to current buffer */
    public static void ring(float cx, float cy, float cz, float radius,
                             int segments, int r, int g, int b, int a) {
        float prev_x = cx + radius;
        float prev_z = cz;
        float step = (float)(Math.PI * 2 / segments);
        for (int i = 1; i <= segments; i++) {
            float ang = i * step;
            float nx = cx + (float)Math.cos(ang) * radius;
            float nz = cz + (float)Math.sin(ang) * radius;
            vertex(prev_x, cy, prev_z, r,g,b,a);
            vertex(nx, cy, nz, r,g,b,a);
            prev_x = nx; prev_z = nz;
        }
    }

    /** Box outline — 12 edges, adds to current buffer */
    public static void boxOutline(float x1,float y1,float z1,
                                   float x2,float y2,float z2,
                                   int r,int g,int b,int a) {
        // Bottom
        vertex(x1,y1,z1,r,g,b,a); vertex(x2,y1,z1,r,g,b,a);
        vertex(x2,y1,z1,r,g,b,a); vertex(x2,y1,z2,r,g,b,a);
        vertex(x2,y1,z2,r,g,b,a); vertex(x1,y1,z2,r,g,b,a);
        vertex(x1,y1,z2,r,g,b,a); vertex(x1,y1,z1,r,g,b,a);
        // Top
        vertex(x1,y2,z1,r,g,b,a); vertex(x2,y2,z1,r,g,b,a);
        vertex(x2,y2,z1,r,g,b,a); vertex(x2,y2,z2,r,g,b,a);
        vertex(x2,y2,z2,r,g,b,a); vertex(x1,y2,z2,r,g,b,a);
        vertex(x1,y2,z2,r,g,b,a); vertex(x1,y2,z1,r,g,b,a);
        // Pillars
        vertex(x1,y1,z1,r,g,b,a); vertex(x1,y2,z1,r,g,b,a);
        vertex(x2,y1,z1,r,g,b,a); vertex(x2,y2,z1,r,g,b,a);
        vertex(x2,y1,z2,r,g,b,a); vertex(x2,y2,z2,r,g,b,a);
        vertex(x1,y1,z2,r,g,b,a); vertex(x1,y2,z2,r,g,b,a);
    }

    /** Corner-only box outline (L-brackets at each corner) */
    public static void boxCorners(float x1,float y1,float z1,
                                   float x2,float y2,float z2,
                                   int r,int g,int b,int a) {
        float lx = Math.min((x2-x1)*.25f, .4f);
        float ly = Math.min((y2-y1)*.25f, .4f);
        float lz = Math.min((z2-z1)*.25f, .4f);
        // Each of 8 corners: 3 edges
        float[][] corners = {
            {x1,y1,z1}, {x2,y1,z1}, {x1,y1,z2}, {x2,y1,z2},
            {x1,y2,z1}, {x2,y2,z1}, {x1,y2,z2}, {x2,y2,z2}
        };
        float[][] dx = {{lx,0,0},{-lx,0,0},{lx,0,0},{-lx,0,0},{lx,0,0},{-lx,0,0},{lx,0,0},{-lx,0,0}};
        float[][] dy = {{0,ly,0},{0,ly,0},{0,ly,0},{0,ly,0},{0,-ly,0},{0,-ly,0},{0,-ly,0},{0,-ly,0}};
        float[][] dz = {{0,0,lz},{0,0,lz},{0,0,-lz},{0,0,-lz},{0,0,lz},{0,0,lz},{0,0,-lz},{0,0,-lz}};
        for (int i=0;i<8;i++) {
            float cx=corners[i][0],cy=corners[i][1],cz=corners[i][2];
            vertex(cx,cy,cz,r,g,b,a); vertex(cx+dx[i][0],cy,cz,r,g,b,a);
            vertex(cx,cy,cz,r,g,b,a); vertex(cx,cy+dy[i][1],cz,r,g,b,a);
            vertex(cx,cy,cz,r,g,b,a); vertex(cx,cy,cz+dz[i][2],r,g,b,a);
        }
    }

    public static void cleanup() {
        if (vao != -1) { glDeleteVertexArrays(vao); vao=-1; }
        if (vbo != -1) { glDeleteBuffers(vbo); vbo=-1; }
        initialized = false;
    }
}
