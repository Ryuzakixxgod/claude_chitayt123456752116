package ru.ryuzaki.command;
// src/main/java/ru/ryuzaki/command/CommandManager.java
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.command.commands.*;
import java.util.ArrayList;
import java.util.List;

public class CommandManager {
    private static CommandManager instance;
    private final List<Command> commands = new ArrayList<>();
    public static final String PREFIX = ".";
    private CommandManager() {}
    public static CommandManager getInstance() { if(instance==null)instance=new CommandManager();return instance; }

    public void init() {
        commands.add(new HelpCommand());
        commands.add(new WaypointCommand());
        commands.add(new ConfigCommand());
        commands.add(new FriendCommand()); // пункт 20
    }

    public boolean handleMessage(String message) {
        if (!message.startsWith(PREFIX)) return false;
        String[] parts = message.substring(PREFIX.length()).trim().split(" ");
        if (parts.length == 0) return false;
        String[] args = new String[parts.length-1];
        System.arraycopy(parts, 1, args, 0, parts.length-1);
        for (Command cmd : commands) {
            if (cmd.getName().equalsIgnoreCase(parts[0])) { cmd.execute(args); return true; }
        }
        var mc = MinecraftClient.getInstance();
        if (mc.player != null) mc.player.sendMessage(Text.literal("§b[Ryuzaki]§r Неизвестная команда. §a.help§r - список."), false);
        return true;
    }
}