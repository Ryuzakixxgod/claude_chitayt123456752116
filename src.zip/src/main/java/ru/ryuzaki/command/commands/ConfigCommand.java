package ru.ryuzaki.command.commands;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.command.Command;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.settings.*;

import java.io.*;
import java.util.*;

public class ConfigCommand implements Command {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public String getName() { return "cfg"; }
    public String getDescription() { return ".cfg save/load/list/dir <name>"; }

    public void execute(String[] args) {
        if (args.length == 0) { msg("§7.cfg <save|load|list|dir> [name]"); return; }
        switch (args[0].toLowerCase()) {
            case "save" -> {
                String name = args.length > 1 ? args[1] : "default";
                saveConfig(name);
                msg("§aСохранено: §f" + name);
            }
            case "load" -> {
                String name = args.length > 1 ? args[1] : "default";
                if (loadConfig(name)) msg("§aЗагружено: §f" + name);
                else msg("§cНе найдено: §f" + name);
            }
            case "list" -> {
                File[] files = getConfigDir().listFiles((d,n) -> n.endsWith(".json"));
                if (files == null || files.length == 0) { msg("§7Нет конфигов"); return; }
                msg("§bКонфиги:");
                for (File f : files) msg("  §f" + f.getName().replace(".json",""));
            }
            case "dir" -> {
                File dir = getConfigDir();
                dir.mkdirs();
                try {
                    String os = System.getProperty("os.name").toLowerCase();
                    if (os.contains("win"))       new ProcessBuilder("explorer", dir.getAbsolutePath()).start();
                    else if (os.contains("mac"))  new ProcessBuilder("open",     dir.getAbsolutePath()).start();
                    else                          new ProcessBuilder("xdg-open", dir.getAbsolutePath()).start();
                    msg("§aПапка: §f" + dir.getAbsolutePath());
                } catch (Exception e) { msg("§7" + dir.getAbsolutePath()); }
            }
            default -> msg("§7.cfg <save|load|list|dir> [name]");
        }
    }

    private void saveConfig(String name) {
        JsonObject root = new JsonObject();
        for (Module m : ModuleManager.modules) {
            JsonObject mObj = new JsonObject();
            mObj.addProperty("enabled", m.isEnabled());
            mObj.addProperty("key", m.key);
            JsonObject settings = new JsonObject();
            for (Setting s : m.getSettings()) {
                if (s instanceof BooleanSetting bs)
                    settings.addProperty(s.name, bs.isEnabled());
                else if (s instanceof NumberSetting ns)
                    settings.addProperty(s.name, ns.getValue());
                else if (s instanceof ModeSetting ms)
                    settings.addProperty(s.name, ms.getCurrent());
            }
            mObj.add("settings", settings);
            root.add(m.name, mObj);
        }
        File dir = getConfigDir();
        dir.mkdirs();
        try (Writer w = new FileWriter(new File(dir, name + ".json"))) {
            gson.toJson(root, w);
        } catch (Exception e) { e.printStackTrace(); }
    }

    private boolean loadConfig(String name) {
        File f = new File(getConfigDir(), name + ".json");
        if (!f.exists()) return false;
        try (Reader r = new FileReader(f)) {
            JsonObject root = JsonParser.parseReader(r).getAsJsonObject();
            for (Module m : ModuleManager.modules) {
                if (!root.has(m.name)) continue;
                JsonObject mObj = root.getAsJsonObject(m.name);
                if (mObj.has("enabled")) m.setEnabled(mObj.get("enabled").getAsBoolean());
                if (mObj.has("key"))     m.key = mObj.get("key").getAsInt();
                if (!mObj.has("settings")) continue;
                JsonObject settings = mObj.getAsJsonObject("settings");
                for (Setting s : m.getSettings()) {
                    if (!settings.has(s.name)) continue;
                    if (s instanceof BooleanSetting bs)
                        bs.setValue(settings.get(s.name).getAsBoolean());
                    else if (s instanceof NumberSetting ns)
                        ns.setValue(settings.get(s.name).getAsDouble());
                    else if (s instanceof ModeSetting ms)
                        ms.setCurrent(settings.get(s.name).getAsString());
                }
            }
            return true;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    private File getConfigDir() {
        return new File(FabricLoader.getInstance().getConfigDir().toFile(), "ryuzaki/configs");
    }

    private void msg(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§b[CFG]§r " + s), false);
    }
}