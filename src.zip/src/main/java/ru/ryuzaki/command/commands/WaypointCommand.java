package ru.ryuzaki.command.commands;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.command.Command;
import ru.ryuzaki.module.modules.visual.WaypointsModule;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * .way — управление вейпоинтами.
 * .way here [name]
 * .way add <name> [x y z]
 * .way remove <name>
 * .way list
 * .way clear
 */
public class WaypointCommand implements Command {
    private final MinecraftClient mc = MinecraftClient.getInstance();

    @Override public String getName()        { return "way"; }
    @Override public String getDescription() { return "Waypoints: .way here/add/remove/list/clear"; }

    @Override
    public void execute(String[] args) {
        WaypointsModule wm = WaypointsModule.INSTANCE;
        if (wm == null || mc.player == null) return;

        if (args.length == 0) { help(); return; }

        switch (args[0].toLowerCase()) {
            case "here" -> {
                String name = args.length > 1 ? args[1] : "Home";
                wm.add(name, mc.player.getX(), mc.player.getY(), mc.player.getZ(),
                    randomColor(), false, null);
            }
            case "add" -> {
                if (args.length < 2) { msg("§c.way add <name> [x y z]"); return; }
                String name = args[1];
                double x=mc.player.getX(), y=mc.player.getY(), z=mc.player.getZ();
                if (args.length >= 5) {
                    try { x=Double.parseDouble(args[2]); y=Double.parseDouble(args[3]); z=Double.parseDouble(args[4]); }
                    catch(NumberFormatException e){ msg("§cInvalid coordinates"); return; }
                }
                wm.add(name, x, y, z, randomColor(), false, null);
            }
            case "remove","rm","del" -> {
                if (args.length < 2) { msg("§c.way remove <name>"); return; }
                wm.remove(args[1]);
            }
            case "clear" -> wm.clear();
            case "list" -> {
                var all = wm.getAll();
                if (all.isEmpty()) { msg("§7No waypoints saved."); return; }
                msg("§a§lWaypoints (" + all.size() + "):");
                all.values().forEach(w -> msg(String.format("§7• §f%s §8(%.0f, %.0f, %.0f)",
                    w.name, w.pos.x, w.pos.y, w.pos.z)));
            }
            default -> help();
        }
    }

    private void help() {
        msg("§a.way here [name]     §8— save current position");
        msg("§a.way add <n> [x y z] §8— add waypoint");
        msg("§a.way remove <n>      §8— remove waypoint");
        msg("§a.way list / clear");
    }

    private void msg(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), false);
    }

    private int randomColor() {
        float h = (float)Math.random();
        int[] rgb = RyuzakiRenderCache.hsv(h, 0.8f, 1f);
        return (0xFF<<24)|(rgb[0]<<16)|(rgb[1]<<8)|rgb[2];
    }
}
