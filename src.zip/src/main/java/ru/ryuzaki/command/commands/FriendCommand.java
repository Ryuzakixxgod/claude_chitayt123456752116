package ru.ryuzaki.command.commands;
// src/main/java/ru/ryuzaki/command/commands/FriendCommand.java
// ВАЖНО: файл должен называться именно FriendCommand.java (с большой F и C)
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.command.Command;
import ru.ryuzaki.util.FriendManager;

public class FriendCommand implements Command {
    @Override public String getName() { return "friend"; }
    @Override public String getDescription() { return ".friend add/remove/list <ник>"; }

    @Override
    public void execute(String[] args) {
        if (args.length == 0) { msg("§7.friend <add|remove|list> [ник]"); return; }
        switch (args[0].toLowerCase()) {
            case "add" -> {
                if (args.length < 2) { msg("§7Укажи ник: .friend add <ник>"); return; }
                FriendManager.add(args[1]);
                msg("§aДобавлен: §f" + args[1]);
            }
            case "remove", "rm", "del" -> {
                if (args.length < 2) { msg("§7Укажи ник: .friend remove <ник>"); return; }
                FriendManager.remove(args[1]);
                msg("§cУдалён: §f" + args[1]);
            }
            case "list" -> {
                var list = FriendManager.getFriends();
                if (list.isEmpty()) { msg("§7Список пуст"); return; }
                msg("§bДрузья (" + list.size() + "):");
                list.forEach(f -> msg("  §f" + f));
            }
            default -> msg("§7.friend <add|remove|list> [ник]");
        }
    }

    private void msg(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null)
            mc.player.sendMessage(Text.literal("§b[Friend]§r " + s), false);
    }
}