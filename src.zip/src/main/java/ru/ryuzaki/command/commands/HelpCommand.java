package ru.ryuzaki.command.commands;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.command.Command;

public class HelpCommand implements Command {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    public String getName() { return "help"; }
    public String getDescription() { return "Показывает все команды"; }

    public void execute(String[] args) {
        msg("§b========= Ryuzaki Commands =========");
        msg("§a.help §7- Показывает все команды");
        msg("§a.waypoint add <name> §7- Добавить точку");
        msg("§a.waypoint remove <name> §7- Удалить точку");
        msg("§a.waypoint list §7- Список точек");
        msg("§a.cfg save §7- Сохранить конфиг");
        msg("§a.cfg load §7- Загрузить конфиг");
        msg("§a.cfg open §7- Открыть папку конфига");
        msg("§b====================================");
    }

    private void msg(String s) {
        if (mc.player != null) mc.player.sendMessage(Text.literal(s), false);
    }
}