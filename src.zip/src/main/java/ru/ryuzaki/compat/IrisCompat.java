package ru.ryuzaki.compat;

import net.fabricmc.loader.api.FabricLoader;

/**
 * IrisCompat — мост между Ryuzaki и Iris Shaders.
 *
 * Используем рефлексию чтобы не было hard dependency на Iris.
 * Если Iris не установлен — всё работает как раньше.
 *
 * Поддерживаемые шейдеры: Iris 1.7+, также работает с Oculus (Forge port).
 */
public final class IrisCompat {

    private IrisCompat() {}

    // Iris присутствует в classpath?
    private static final boolean IRIS_PRESENT =
        FabricLoader.getInstance().isModLoaded("iris") ||
        FabricLoader.getInstance().isModLoaded("oculus");

    // Кешируем методы через рефлексию при первом вызове
    private static java.lang.reflect.Method methodShadersEnabled   = null;
    private static java.lang.reflect.Method methodCurrentShaderName = null;
    private static boolean reflectionInitialized = false;

    private static void initReflection() {
        if (reflectionInitialized) return;
        reflectionInitialized = true;
        if (!IRIS_PRESENT) return;
        try {
            // Iris API класс (Iris 1.7+)
            Class<?> irisApi = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
            java.lang.reflect.Method getInstance = irisApi.getMethod("getInstance");
            Object api = getInstance.invoke(null);

            methodShadersEnabled    = api.getClass().getMethod("isShaderPackInUse");
            methodCurrentShaderName = api.getClass().getMethod("getCurrentPackName");

            // Сохраняем instance
            cachedApiInstance = api;
        } catch (Exception e) {
            // Старая версия Iris или другой API — пробуем fallback
            tryFallbackReflection();
        }
    }

    private static Object cachedApiInstance = null;

    private static void tryFallbackReflection() {
        try {
            // Iris < 1.7 fallback: IrisApi через другой путь
            Class<?> cls = Class.forName("net.coderbot.iris.Iris");
            methodShadersEnabled = cls.getMethod("isShadersEnabled");
        } catch (Exception ignored) {}
    }

    /**
     * Iris установлен в игре?
     */
    public static boolean isIrisPresent() {
        return IRIS_PRESENT;
    }

    /**
     * Шейдерпак сейчас активен?
     * Возвращает false если Iris не установлен или шейдеры выключены.
     */
    public static boolean areShadersActive() {
        if (!IRIS_PRESENT) return false;
        initReflection();
        if (methodShadersEnabled == null) return false;
        try {
            Object target = cachedApiInstance != null ? cachedApiInstance : null;
            return (boolean) methodShadersEnabled.invoke(target);
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Название активного шейдерпака.
     * Возвращает null если шейдеры не активны.
     */
    public static String getCurrentShaderName() {
        if (!areShadersActive()) return null;
        initReflection();
        if (methodCurrentShaderName == null) return "Unknown";
        try {
            Object result = methodCurrentShaderName.invoke(cachedApiInstance);
            return result != null ? result.toString() : "Unknown";
        } catch (Exception e) {
            return "Unknown";
        }
    }

    /**
     * Нужно ли отключить наш кастомный рендер?
     *
     * Когда Iris шейдеры активны — они сами рендерят bloom, glow и т.д.
     * Наши эффекты поверх шейдеров выглядят некорректно.
     * Модули должны вызывать этот метод перед рендером своих эффектов.
     */
    public static boolean shouldDisableCustomRendering() {
        return areShadersActive();
    }
}
