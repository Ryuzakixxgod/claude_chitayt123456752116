package ru.ryuzaki.lang;

import net.minecraft.client.MinecraftClient;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * LanguageManager — система локализации Ryuzaki
 *
 * Поддерживает: Русский (RU) и English (EN)
 * Настройка сохраняется в .minecraft/ryuzaki/language.txt
 */
public class LanguageManager {

    public enum Lang { RU, EN }

    private static Lang current = Lang.RU;
    private static boolean firstLaunch = true;
    private static Path savePath;

    // ═══════════════════════════════════════════════════════════════════════
    //  ИНИЦИАЛИЗАЦИЯ
    // ═══════════════════════════════════════════════════════════════════════
    public static void init() {
        MinecraftClient mc = MinecraftClient.getInstance();
        savePath = mc.runDirectory.toPath().resolve("ryuzaki").resolve("language.txt");

        if (Files.exists(savePath)) {
            try {
                String saved = Files.readString(savePath).trim().toUpperCase();
                current = Lang.valueOf(saved);
                firstLaunch = false;
            } catch (Exception ignored) {
                firstLaunch = true;
            }
        } else {
            firstLaunch = true;
        }
    }

    public static boolean isFirstLaunch() { return firstLaunch; }
    public static Lang    getCurrent()     { return current; }
    public static boolean isRU()           { return current == Lang.RU; }
    public static boolean isEN()           { return current == Lang.EN; }

    public static void setLanguage(Lang lang) {
        current     = lang;
        firstLaunch = false;
        save();
    }

    private static void save() {
        try {
            Files.createDirectories(savePath.getParent());
            Files.writeString(savePath, current.name());
        } catch (Exception ignored) {}
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ПЕРЕВОДЫ — все строки мода
    // ═══════════════════════════════════════════════════════════════════════
    public static String t(String key) {
        return current == Lang.EN ? EN.getOrDefault(key, key) : RU.getOrDefault(key, key);
    }

    // ── Русский ───────────────────────────────────────────────────────────
    private static final Map<String,String> RU = new LinkedHashMap<>();
    // ── English ───────────────────────────────────────────────────────────
    private static final Map<String,String> EN = new LinkedHashMap<>();

    static {
        // ── Категории ──────────────────────────────────────────────────
        put("cat.visual",     "Визуал",       "Visual");
        put("cat.animation",  "Анимация",     "Animation");
        put("cat.particles",  "Частицы",      "Particles");
        put("cat.world",      "Мир",          "World");
        put("cat.player",     "Игрок",        "Player");
        put("cat.misc",       "Прочее",       "Misc");

        // ── GUI общее ──────────────────────────────────────────────────
        put("gui.search",     "⌕ Поиск",      "⌕ Search");
        put("gui.no_module",  "← Выбери модуль", "← Select module");
        put("gui.rmb_list",   "ПКМ в списке",    "RMB in list");
        put("gui.no_settings","Нет настроек",    "No settings");
        put("gui.theme",      "Тема",            "Theme");
        put("gui.themes",     "Выбор темы",      "Choose Theme");
        put("gui.themes_cnt", "20 тем",          "20 themes");
        put("gui.no_desc",    "Нет описания",    "No description");

        // ── Настройки ──────────────────────────────────────────────────
        put("set.style",      "Стиль",        "Style");
        put("set.color",      "Цвет",         "Color");
        put("set.size",       "Размер",       "Size");
        put("set.speed",      "Скорость",     "Speed");
        put("set.intensity",  "Интенсивность","Intensity");
        put("set.rainbow",    "Радуга",       "Rainbow");
        put("set.players",    "Игроки",       "Players");
        put("set.mobs",       "Мобы",         "Mobs");
        put("set.animals",    "Животные",     "Animals");
        put("set.bosses",     "Боссы",        "Bosses");
        put("set.glow",       "Свечение",     "Glow");
        put("set.particles",  "Частицы",      "Particles");
        put("set.distance",   "Дистанция",    "Distance");
        put("set.armor",      "Броня",        "Armor");
        put("set.show_armor", "Показывать броню","Show Armor");
        put("set.show_dist",  "Показывать дист.","Show Distance");
        put("set.bind",       "Бинд",         "Bind");
        put("set.none",       "Нет",          "None");
        put("set.press",      "● Нажми...",   "● Press...");
        put("set.on",         "Вкл",          "On");
        put("set.off",        "Выкл",         "Off");
        put("set.scale",      "Масштаб",      "Scale");
        put("set.opacity",    "Прозрачность", "Opacity");
        put("set.duration",   "Длит-сть",     "Duration");
        put("set.chance",     "Шанс",         "Chance");
        put("set.strength",   "Сила",         "Strength");
        put("set.density",    "Плотность",    "Density");
        put("set.smooth",     "Плавность",    "Smoothness");
        put("set.fog_start",  "Нач. тумана",  "Fog Start");
        put("set.fog_end",    "Конец тумана", "Fog End");
        put("set.fog_r",      "Туман R",      "Fog R");
        put("set.fog_g",      "Туман G",      "Fog G");
        put("set.fog_b",      "Туман B",      "Fog B");

        // ── Тулитипы модулей ───────────────────────────────────────────
        put("tip.Bloom",          "Свечение вокруг ярких объектов и краёв",
                                  "Glow around bright objects and edges");
        put("tip.MotionBlur",     "Размытие в движении — эффект скорости",
                                  "Motion blur — speed effect");
        put("tip.ScreenShake",    "Экран трясётся при получении урона",
                                  "Screen shakes when taking damage");
        put("tip.Trajectory",     "Траектория полёта снарядов и стрел",
                                  "Trajectory of projectiles and arrows");
        put("tip.Waypoints",      "Метки в мире — не потеряйся",
                                  "World markers — don't get lost");
        put("tip.AspectRatio",    "Меняет соотношение сторон экрана",
                                  "Changes screen aspect ratio");
        put("tip.GlitchEffect",   "Глитч-искажение в кибер-стиле",
                                  "Glitch distortion in cyber style");
        put("tip.ScreenEdgeGlow", "Светящийся ореол по краям экрана",
                                  "Glowing halo around screen edges");
        put("tip.Zoom",           "Приближение камеры — клавиша C",
                                  "Camera zoom — key C");
        put("tip.NameTags",       "Имена и HP игроков над головами",
                                  "Player names and HP above heads");
        put("tip.HitFlash",       "Вспышка экрана при нанесении урона",
                                  "Screen flash when dealing damage");
        put("tip.CompassHud",     "Компас с направлениями на экране",
                                  "Compass with directions on screen");
        put("tip.SpeedLines",     "Линии скорости при быстром движении",
                                  "Speed lines when moving fast");
        put("tip.PlayerOutline",  "Обводка игроков сквозь стены",
                                  "Player outline through walls");
        put("tip.HologramPlayer", "Голограмма другого игрока рядом",
                                  "Hologram of another player nearby");
        put("tip.CrosshairFX",    "Анимированный кастомный прицел",
                                  "Animated custom crosshair");
        put("tip.BlockOutline",   "Красивая обводка блоков при наведении",
                                  "Beautiful block outline on hover");
        put("tip.TargetESP",      "Визуальный маркер твоей цели",
                                  "Visual marker of your target");
        put("tip.Hitbox",         "Хитбоксы существ",
                                  "Entity hitboxes");
        put("tip.Swing",          "Кастомная анимация удара рукой",
                                  "Custom hand swing animation");
        put("tip.ItemPhysics",    "Физика предметов на земле",
                                  "Physics for items on ground");
        put("tip.CapePhysics",    "Плащ с физикой — развевается",
                                  "Cape with physics — it flows");
        put("tip.SmoothCamera",   "Плавное инерционное движение камеры",
                                  "Smooth inertial camera movement");
        put("tip.Trail",          "Красивый след из частиц за тобой",
                                  "Beautiful particle trail behind you");
        put("tip.AuraParticle",   "Аура из частиц вокруг персонажа",
                                  "Particle aura around character");
        put("tip.JumpParticle",   "Частицы при прыжке",
                                  "Particles on jump");
        put("tip.KillEffect",     "Взрыв частиц при убийстве врага",
                                  "Particle burst when killing an enemy");
        put("tip.CosmicCrit",     "Космические криты — заменяют стандартные",
                                  "Cosmic crits — replace standard ones");
        put("tip.AmbientParticle","Фоновые частицы в воздухе",
                                  "Ambient particles in the air");
        put("tip.CustomSky",      "Кастомное небо с цветами",
                                  "Custom sky with colors");
        put("tip.FogControl",     "Управление туманом и видимостью",
                                  "Fog and visibility control");
        put("tip.DynamicLights",  "Предметы в руках светятся",
                                  "Items in hands emit light");
        put("tip.BetterWater",    "Улучшенная вода",
                                  "Improved water");
        put("tip.TimeChanger",    "Время суток только у тебя",
                                  "Time of day only for you");
        put("tip.EnviroFX",       "Эффекты окружающей среды",
                                  "Environmental effects");
        put("tip.Fullbright",     "Полная яркость в темноте",
                                  "Full brightness in the dark");
        put("tip.HitSound",       "Звук при попадании по врагу",
                                  "Sound when hitting an enemy");
        put("tip.NoOverlay",      "Убирает огонь, тотем и другие оверлеи",
                                  "Removes fire, totem and other overlays");
        put("tip.FPS Boost",      "Буст ФПС через оптимизацию",
                                  "FPS boost through optimization");
        put("tip.Anti Lag",       "Автоснижение настроек при просадке ФПС",
                                  "Auto-lower settings on FPS drop");
        put("tip.NoHurtCam",      "Убирает покачивание камеры от урона",
                                  "Removes camera shake from damage");
        put("tip.NoWeather",      "Убирает дождь и снег визуально",
                                  "Removes rain and snow visually");
        put("tip.ChatHighlight",  "Подсвечивает твоё имя в чате",
                                  "Highlights your name in chat");
        put("tip.ArmorAlert",     "Уведомление когда броня почти сломана",
                                  "Alert when armor is almost broken");

        // ── TargetESP ──────────────────────────────────────────────────
        put("esp.player_col",  "Цвет игроков",     "Player Color");
        put("esp.mob_col",     "Цвет мобов",        "Mob Color");
        put("esp.animal_col",  "Цвет животных",     "Animal Color");
        put("esp.boss_col",    "Цвет боссов",       "Boss Color");

        // ── Экран первого запуска ──────────────────────────────────────
        put("first.subtitle",  "Визуальный мод",    "Visual Mod");
        put("first.desc",      "Выбери язык интерфейса", "Choose interface language");
        put("first.confirm",   "Продолжить",        "Continue");
    }

    private static void put(String key, String ru, String en) {
        RU.put(key, ru);
        EN.put(key, en);
    }
}
