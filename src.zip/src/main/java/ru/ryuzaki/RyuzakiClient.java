package ru.ryuzaki;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import com.professor.cyberhacks.MC;
import com.professor.cyberhacks.RotationManager;
import com.professor.cyberhacks.PacketQueue;
import ru.ryuzaki.command.CommandManager;
import ru.ryuzaki.config.ConfigManager;
import ru.ryuzaki.gui.HudEditorScreen;
import ru.ryuzaki.gui.IntroScreen;
import ru.ryuzaki.gui.MusicPlayerScreen;
import ru.ryuzaki.gui.AltManagerScreen;
import ru.ryuzaki.gui.FriendListScreen;
import ru.ryuzaki.gui.LanguageSelectScreen;
import ru.ryuzaki.hud.HudManager;
import ru.ryuzaki.client.hud.NotificationManager;
import ru.ryuzaki.module.BindManager;
import ru.ryuzaki.render.NativeGL;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.render.providers.ResourceProvider;
import ru.ryuzaki.lang.LanguageManager;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.InGameInventoryModule;
import ru.ryuzaki.module.modules.particles.AuraParticleModule;
import ru.ryuzaki.module.modules.particles.JumpParticleModule;
import ru.ryuzaki.module.modules.particles.TrailModule;
import ru.ryuzaki.module.modules.visual.*;
import ru.ryuzaki.module.modules.misc.MusicPlayerModule;
import ru.ryuzaki.module.modules.misc.FriendsModule;
import ru.ryuzaki.module.modules.movement.FlightModule;
import ru.ryuzaki.module.modules.movement.SpeedModule;
import ru.ryuzaki.module.modules.movement.NoSlowModule;
import ru.ryuzaki.module.modules.combat.VelocityModule;
import ru.ryuzaki.module.modules.combat.AutoClickerModule;
import ru.ryuzaki.module.modules.combat.ReachModule;
import ru.ryuzaki.module.modules.player.SprintModule;
import ru.ryuzaki.module.modules.player.NoFallModule;
import ru.ryuzaki.module.modules.world.DynamicLightsModule;
import ru.ryuzaki.util.IntroSoundHelper;
import ru.ryuzaki.util.MediaUtil;
import ru.ryuzaki.util.TargetManager;
import ru.ryuzaki.util.TpsCounter;
import ru.ryuzaki.waypoints.WaypointManager;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import net.minecraft.util.Identifier;

public class RyuzakiClient implements ClientModInitializer {

    public static final String MOD_ID = "ryuzaki";
    private static RyuzakiClient instance;
    private KeyBinding keyGui, keyHud, keyAlt, keyMusic;
    private boolean wasOnGround = false;
    private boolean fontsInitialized = false;
    private int fontsRetryTicks = 0;

    // ══════════════════════════════════════════════════════════════════
    //  КЭШ КУРСОРА — избегаем GLFW.glfwGetCursorPos() каждый тик
    //  Было: 2 GLFW вызова + деление scaleFactor каждый tick
    //  Стало: 2 GLFW вызова только при реальном движении мыши
    // ══════════════════════════════════════════════════════════════════
    private int  cachedMouseX = Integer.MIN_VALUE;
    private int  cachedMouseY = Integer.MIN_VALUE;
    private long lastMouseMoveTime = 0;
    private static final long MOUSE_CACHE_TTL_MS = 16; // ~60 FPS cap

    // ── Кэш активных модулей — обновляется только когда список меняется ──
    private final List<Module> activeModules  = new ArrayList<>(32);
    private int  activeCheckHash  = 0;
    private int  activeCheckTimer = 0;

    @Override
    public void onInitializeClient() {
        instance = this;
        com.professor.cyberhacks.MC.set(MinecraftClient.getInstance());
        LanguageManager.init();
        ModuleManager.init();
        HudManager.getInstance().init();
        tryInitFonts();
        CommandManager.getInstance().init();
        WaypointManager.getInstance();
        ConfigManager.load("default");

        keyGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ryuzaki.open_gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.ryuzaki"));
        keyHud = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ryuzaki.hud_editor", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_ALT, "key.categories.ryuzaki"));
        keyAlt = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ryuzaki.alt_manager", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F10, "key.categories.ryuzaki"));
        keyMusic = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.ryuzaki.music", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F9, "key.categories.ryuzaki"));

        // ── При входе в мир используется SplashOverlay с reloading=true
        // ── Наш GIF добавляется через MixinSplashOverlay автоматически
        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            IntroSoundHelper.reset();
            TpsCounter.reset();
            ConfigManager.autoSave();
            MediaUtil.shutdown();
            MusicPlayerScreen.shutdown();
            BindManager.clearCallbacks();
            NativeGL.cleanup();
            activeModules.clear();
            activeCheckHash = 0;
        });

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            tryInitFonts();
            if (mc.player == null) return;
            IntroSoundHelper.tryPlay(mc);

            while (keyGui.wasPressed())   mc.execute(() -> toggleClickGui(mc));
            while (keyHud.wasPressed())   mc.execute(() -> mc.setScreen(new HudEditorScreen()));
            while (keyAlt.wasPressed())   mc.execute(() -> mc.setScreen(new ru.ryuzaki.gui.AltManagerScreen(mc.currentScreen)));
            while (keyMusic.wasPressed()) mc.execute(() -> mc.setScreen(new ru.ryuzaki.gui.MusicPlayerScreen(mc.currentScreen)));
            NotificationManager.tick();

            // ── onUpdate — через кэшированный список активных модулей ──
            if (++activeCheckTimer >= 5) {
                activeCheckTimer = 0;
                rebuildActiveModules();
            }
            for (int i = 0; i < activeModules.size(); i++) {
                Module m = activeModules.get(i);
                try { m.onUpdate(); }
                catch (Throwable e) { System.err.println("[Ryuzaki] onUpdate crash in " + m.getClass().getSimpleName() + ": " + e); }
            }

            TargetManager.getInstance().updateTarget();

            // ── CyberHacks core systems ──
            RotationManager.updateDynamicParameters();
            PacketQueue.tick();

            // ── Ryuzaki movement modules ──
            get(FlightModule.class,     f -> f.onUpdate());
            get(SpeedModule.class,       s -> s.onUpdate());
            get(NoSlowModule.class,     n -> n.onUpdate());
            get(VelocityModule.class,    v -> v.onUpdate());
            get(AutoClickerModule.class, a -> a.onUpdate());
            get(NoFallModule.class,      n -> n.onTick());
            get(SprintModule.class,     s -> s.onUpdate());

            get(TrailModule.class,           t -> t.tick());
            get(AuraParticleModule.class,    a -> a.onTick());
            get(DynamicLightsModule.class,   d -> d.onTick());
            get(ZoomModule.class,            z -> z.onTick());
            get(GlitchEffectModule.class,    g -> g.onTick());
            get(EnderBlackHoleModule.class,  e -> e.onTick());
            get(BreadcrumbsModule.class,     b -> b.tick());
            get(VisualRangeModule.class,     v -> v.onTick());
            get(TotemPopCounterModule.class, t -> t.onTick());
            get(ScreenEdgeGlowModule.class,  s -> s.onTick());
            get(HitFlashModule.class,        h -> h.onTick());
            get(BlockOutlineModule.class,    b -> b.onUpdate());
            get(ru.ryuzaki.module.modules.world.CustomSkyModule.class, s -> s.onUpdate());

            boolean onGround = mc.player.isOnGround();
            if (wasOnGround && !onGround)
                get(JumpParticleModule.class, j -> j.onPlayerJump(mc.player.getPos()));
            wasOnGround = onGround;

            if (mc.currentScreen != null) {
                // ── Кэш курсора: используем MouseMoveEvent callback вместо GLFW каждый тик ─
                // Было: GLFW.glfwGetCursorPos + деление scaleFactor КАЖДЫЙ tick
                // Стало: кэш обновляется через afterMouseClick/afterMouseClick + TTL
                long now = System.currentTimeMillis();
                if (now - lastMouseMoveTime > MOUSE_CACHE_TTL_MS) {
                    // Cache expired — обновляем из GLFW (редко)
                    long win = mc.getWindow().getHandle();
                    double[] cx = new double[1], cy = new double[1];
                    GLFW.glfwGetCursorPos(win, cx, cy);
                    double scale = mc.getWindow().getScaleFactor();
                    cachedMouseX = (int)(cx[0] / scale);
                    cachedMouseY = (int)(cy[0] / scale);
                    lastMouseMoveTime = now;
                }
                HudManager.getInstance().onMouseDrag(cachedMouseX, cachedMouseY);
            }
        });

        net.fabricmc.fabric.api.client.screen.v1.ScreenEvents.AFTER_INIT.register((client, screen, sw, sh) -> {
            net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.afterMouseClick(screen)
                    .register((scr, mx, my, btn) -> HudManager.getInstance().onMouseClick((int)mx, (int)my, (int)btn));
            net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents.afterMouseRelease(screen)
                    .register((scr, mx, my, btn) -> HudManager.getInstance().onMouseRelease((int)btn));
        });

        // ── Кэш ссылок на 3D-модули ──────────────────────────────────
        final TargetESP            r3_esp  = ModuleManager.getModule(TargetESP.class);
        final TrajectoryModule     r3_traj = ModuleManager.getModule(TrajectoryModule.class);
        final BlockOutlineModule   r3_bo   = ModuleManager.getModule(BlockOutlineModule.class);
        final HologramPlayerModule r3_hp   = ModuleManager.getModule(HologramPlayerModule.class);
        final EnderBlackHoleModule r3_ebh  = ModuleManager.getModule(EnderBlackHoleModule.class);
        final NameTagsModule       r3_nt   = ModuleManager.getModule(NameTagsModule.class);
        final DamageNumbersModule  r3_dn   = ModuleManager.getModule(DamageNumbersModule.class);
        final GlowESPModule        r3_glw  = ModuleManager.getModule(GlowESPModule.class);
        final PlayerOutlineModule  r3_po   = ModuleManager.getModule(PlayerOutlineModule.class);
        final ru.ryuzaki.module.modules.world.ChestESPModule r3_cesp =
                ModuleManager.getModule(ru.ryuzaki.module.modules.world.ChestESPModule.class);
        final ru.ryuzaki.module.modules.world.BlockHighlightModule r3_bh =
                ModuleManager.getModule(ru.ryuzaki.module.modules.world.BlockHighlightModule.class);
        final JumpParticleModule r3_jump = ModuleManager.getModule(JumpParticleModule.class);

        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            MatrixStack ms = ctx.matrixStack();
            float td = ctx.tickCounter().getTickDelta(true);
            try {
                if (r3_esp  != null && r3_esp.isEnabled())  r3_esp.render3D(ms, td);
                if (r3_traj != null && r3_traj.isEnabled()) r3_traj.render3D(ms, td);
                if (r3_bo   != null && r3_bo.isEnabled())   r3_bo.render3D(ms, td);
                if (r3_hp   != null && r3_hp.isEnabled())   r3_hp.render3D(ms, td);
                if (r3_ebh  != null && r3_ebh.isEnabled())  r3_ebh.render3D(ms, td);
                if (r3_nt   != null && r3_nt.isEnabled())   r3_nt.render3D(ms, td);
                if (r3_dn   != null && r3_dn.isEnabled())   r3_dn.render3D(ms, td);
                if (r3_glw  != null && r3_glw.isEnabled())  r3_glw.render3D(ms, td);
                if (r3_po   != null && r3_po.isEnabled())   r3_po.render3D(ms, td);
                if (r3_cesp != null && r3_cesp.isEnabled()) r3_cesp.render3D(ms, td);
                if (r3_bh   != null && r3_bh.isEnabled())   r3_bh.render3D(ms, td);
            } catch (Throwable e) {
                System.err.println("[Ryuzaki] render3D crash: " + e);
            }
        });

        WorldRenderEvents.AFTER_TRANSLUCENT.register(ctx -> {
            MatrixStack ms = ctx.matrixStack();
            float td = ctx.tickCounter().getTickDelta(true);
            if (r3_jump != null && r3_jump.isEnabled())
                try { r3_jump.render3D(ms, td); } catch (Throwable ignored) {}
        });

    }

    private void toggleClickGui(MinecraftClient mc) {
        if (mc.currentScreen instanceof ru.ryuzaki.gui.nextgen.NextGenClickGuiScreen) {
            mc.setScreen(null);
        } else {
            mc.setScreen(new ru.ryuzaki.gui.nextgen.NextGenClickGuiScreen(mc.currentScreen));
        }
    }

    private void tryInitFonts() {
        if (fontsInitialized) return;
        if (fontsRetryTicks > 0) {
            fontsRetryTicks--;
            return;
        }
        try {
            ResourceProvider.init();
            Fonts.init();
            rich.util.render.font.Fonts.init();
            fontsInitialized = Fonts.isInitialized();
        } catch (Exception e) {
            fontsRetryTicks = 20;
            System.err.println("[Ryuzaki] Fonts init failed: " + e.getMessage());
        }
        if (!fontsInitialized) {
            fontsRetryTicks = 20;
        }
    }

    private void rebuildActiveModules() {
        int hash = 0;
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled()) hash = hash * 31 + System.identityHashCode(m);
        }
        if (hash == activeCheckHash) return;
        activeCheckHash = hash;
        activeModules.clear();
        for (Module m : ModuleManager.modules) {
            if (m.isEnabled()) activeModules.add(m);
        }
    }

    private <T extends Module> void get(Class<T> cls, Consumer<T> action) {
        T m = ModuleManager.getModule(cls);
        if (m != null && m.isEnabled()) action.accept(m);
    }

    public static RyuzakiClient getInstance() { return instance; }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
}
