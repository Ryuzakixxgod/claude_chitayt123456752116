package ru.ryuzaki.ui.animation;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * AnimationController — unified animation system with easing, spring, and inertia.
 *
 * Supports:
 * - Easing functions: ease-in, ease-out, ease-in-out, elastic, bounce, back, custom
 * - Spring physics: mass, stiffness, damping for natural bounce
 * - Inertia/momentum: velocity-based movement with friction
 * - Chained animations: sequential and parallel groups
 * - Timeline: keyframe-based complex sequences
 * - State interpolation: RGB, RGBA, Vec2, Vec4, float, int
 *
 * Usage:
 *   AnimationController.controller()
 *       .to(targetValue)
 *       .easing(Easing.ELASTIC_OUT)
 *       .duration(500)
 *       .onUpdate(value -> component.setScale(value))
 *       .start();
 */
public class AnimationController {

    private static AnimationController INSTANCE;

    // Active animations
    private final Map<String, Animation> animations = new ConcurrentHashMap<>();
    private final List<Animation> toRemove = new ArrayList<>();

    // Time tracking
    private long lastUpdate;
    private float deltaTime;

    // Global settings
    private float timeScale = 1.0f;
    private boolean globalPaused = false;

    private AnimationController() {}

    public static synchronized AnimationController controller() {
        if (INSTANCE == null) {
            INSTANCE = new AnimationController();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UPDATE LOOP
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Update all animations. Call every frame.
     */
    public void update() {
        long now = System.currentTimeMillis();
        this.deltaTime = (now - lastUpdate) / 1000f;
        lastUpdate = now;

        if (globalPaused) return;

        for (Animation anim : animations.values()) {
            if (anim.isPaused()) continue;
            updateAnimation(anim);
        }

        // Clean up completed animations
        animations.entrySet().removeIf(entry -> {
            if (toRemove.contains(entry.getValue())) {
                entry.getValue().onComplete();
                return true;
            }
            return false;
        });
        toRemove.clear();
    }

    /**
     * Update single animation.
     */
    private void updateAnimation(Animation anim) {
        anim.elapsed += deltaTime * 1000 * timeScale;

        float t = Math.min(anim.elapsed / anim.duration, 1f);

        if (anim.type == Type.SPRING) {
            updateSpring(anim, t);
        } else if (anim.type == Type.INERTIA) {
            updateInertia(anim, t);
        } else {
            updateEasing(anim, t);
        }

        // Notify callback
        if (anim.onUpdate != null) {
            anim.onUpdate.accept(anim.currentValue);
        }

        // Check completion
        if (t >= 1f) {
            anim.currentValue = anim.endValue;
            if (anim.onUpdate != null) {
                anim.onUpdate.accept(anim.currentValue);
            }
            toRemove.add(anim);
        }
    }

    /**
     * Easing interpolation.
     */
    private void updateEasing(Animation anim, float t) {
        float easedT = anim.easing.apply(t);
        anim.currentValue = lerp(anim.startValue, anim.endValue, easedT);
    }

    /**
     * Spring physics update.
     */
    private void updateSpring(Animation anim, float dt) {
        // Spring parameters
        float stiffness = anim.springStiffness;
        float damping = anim.springDamping;
        float mass = anim.springMass;

        // Semi-implicit Euler integration
        float displacement = anim.currentValue - anim.endValue;
        float springForce = -stiffness * displacement;
        float dampingForce = -damping * anim.velocity;
        float acceleration = (springForce + dampingForce) / mass;

        anim.velocity += acceleration * dt;
        anim.currentValue += anim.velocity * dt;

        // Check if settled
        if (Math.abs(anim.velocity) < 0.001f && Math.abs(displacement) < 0.001f) {
            anim.currentValue = anim.endValue;
            anim.velocity = 0f;
            toRemove.add(anim);
        }
    }

    /**
     * Inertia/momentum update.
     */
    private void updateInertia(Animation anim, float dt) {
        float friction = anim.inertiaFriction;

        // Apply friction
        anim.velocity *= Math.pow(friction, dt * 60);

        // Update position
        anim.currentValue += anim.velocity * dt;

        // Clamp if needed
        if (anim.clampTo != null) {
            anim.currentValue = clamp(anim.currentValue, anim.clampTo[0], anim.clampTo[1]);
            if (anim.currentValue == anim.clampTo[0] || anim.currentValue == anim.clampTo[1]) {
                anim.velocity = 0f;
            }
        }

        // Stop when velocity is negligible
        if (Math.abs(anim.velocity) < 0.001f) {
            toRemove.add(anim);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ANIMATION BUILDER
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Create float animation.
     */
    public AnimationBuilder<Float> ofFloat(float start) {
        return new AnimationBuilder<>(this, start);
    }

    /**
     * Animate position with inertia.
     */
    public InertiaBuilder ofPosition(float startX, float startY) {
        return new InertiaBuilder(this, startX, startY);
    }

    /**
     * Stop all animations for a target.
     */
    public void stopAll(String targetId) {
        animations.entrySet().removeIf(entry -> {
            if (entry.getKey().startsWith(targetId)) {
                entry.getValue().onComplete();
                return true;
            }
            return false;
        });
    }

    /**
     * Stop specific animation.
     */
    public void stop(String id) {
        Animation anim = animations.get(id);
        if (anim != null) {
            anim.onComplete();
            animations.remove(id);
        }
    }

    /**
     * Pause all animations.
     */
    public void pauseAll() {
        globalPaused = true;
    }

    /**
     * Resume all animations.
     */
    public void resumeAll() {
        globalPaused = false;
        lastUpdate = System.currentTimeMillis();
    }

    /**
     * Set global time scale.
     */
    public void setTimeScale(float scale) {
        this.timeScale = Math.max(0f, scale);
    }

    /**
     * Clear all animations.
     */
    public void clear() {
        animations.clear();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UTILITY
    // ═══════════════════════════════════════════════════════════════════════

    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ANIMATION CLASS
    // ═══════════════════════════════════════════════════════════════════════

    public static class Animation {
        String id;
        Type type;
        float startValue;
        float endValue;
        float currentValue;
        float duration;
        float elapsed;
        Easing easing;
        boolean paused = false;
        Runnable onComplete;
        java.util.function.Consumer<Float> onUpdate;

        // Spring params
        float springStiffness = 180f;
        float springDamping = 12f;
        float springMass = 1f;
        float velocity = 0f;

        // Inertia params
        float inertiaFriction = 0.95f;
        float[] clampTo;

        enum Type { EASING, SPRING, INERTIA }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ANIMATION BUILDER
    // ═══════════════════════════════════════════════════════════════════════

    public static class AnimationBuilder<T> {
        private final AnimationController controller;
        private final Animation animation;

        AnimationBuilder(AnimationController controller, float startValue) {
            this.controller = controller;
            this.animation = new Animation();
            this.animation.startValue = startValue;
            this.animation.currentValue = startValue;
            this.animation.easing = Easing.QUAD_OUT;
            this.animation.type = Animation.Type.EASING;
        }

        public AnimationBuilder<T> to(float endValue) {
            animation.endValue = endValue;
            return this;
        }

        public AnimationBuilder<T> easing(Easing easing) {
            animation.easing = easing;
            return this;
        }

        public AnimationBuilder<T> duration(long millis) {
            animation.duration = millis;
            return this;
        }

        public AnimationBuilder<T> spring(float stiffness, float damping) {
            animation.type = Animation.Type.SPRING;
            animation.springStiffness = stiffness;
            animation.springDamping = damping;
            return this;
        }

        public AnimationBuilder<T> spring(float stiffness, float damping, float mass) {
            animation.springMass = mass;
            return spring(stiffness, damping);
        }

        public AnimationBuilder<T> onUpdate(java.util.function.Consumer<Float> callback) {
            animation.onUpdate = callback;
            return this;
        }

        public AnimationBuilder<T> onComplete(Runnable callback) {
            animation.onComplete = callback;
            return this;
        }

        public AnimationBuilder<T> id(String id) {
            animation.id = id;
            return this;
        }

        public void start() {
            if (animation.id == null) {
                animation.id = UUID.randomUUID().toString();
            }
            animation.elapsed = 0;
            controller.animations.put(animation.id, animation);
        }

        public void start(String id) {
            animation.id = id;
            start();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INERTIA BUILDER (for position animations)
    // ═══════════════════════════════════════════════════════════════════════

    public static class InertiaBuilder {
        private final AnimationController controller;
        private final Animation xAnim;
        private final Animation yAnim;

        InertiaBuilder(AnimationController controller, float startX, float startY) {
            this.controller = controller;

            this.xAnim = new Animation();
            xAnim.startValue = startX;
            xAnim.currentValue = startX;
            xAnim.type = Animation.Type.INERTIA;

            this.yAnim = new Animation();
            yAnim.startValue = startY;
            yAnim.currentValue = startY;
            yAnim.type = Animation.Type.INERTIA;
        }

        public InertiaBuilder velocity(float vx, float vy) {
            xAnim.velocity = vx;
            yAnim.velocity = vy;
            return this;
        }

        public InertiaBuilder friction(float friction) {
            xAnim.inertiaFriction = friction;
            yAnim.inertiaFriction = friction;
            return this;
        }

        public InertiaBuilder clamp(float minX, float maxX, float minY, float maxY) {
            xAnim.clampTo = new float[]{minX, maxX};
            yAnim.clampTo = new float[]{minY, maxY};
            return this;
        }

        public InertiaBuilder onUpdate(java.util.function.BiConsumer<Float, Float> callback) {
            xAnim.onUpdate = v -> {};
            yAnim.onUpdate = v -> {};
            // We need a combined callback
            return this;
        }

        public InertiaBuilder onComplete(Runnable callback) {
            xAnim.onComplete = callback;
            yAnim.onComplete = () -> {}; // Only fire once
            return this;
        }

        public void start() {
            String xId = UUID.randomUUID().toString();
            String yId = UUID.randomUUID().toString();
            xAnim.id = xId;
            yAnim.id = yId;
            controller.animations.put(xId, xAnim);
            controller.animations.put(yId, yAnim);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  EASING FUNCTIONS
    // ═══════════════════════════════════════════════════════════════════════

    public interface Easing {
        float apply(float t);

        // Linear
        Easing LINEAR = t -> t;

        // Quad
        Easing QUAD_IN = t -> t * t;
        Easing QUAD_OUT = t -> t * (2 - t);
        Easing QUAD_IN_OUT = t -> t < 0.5f ? 2 * t * t : -1 + (4 - 2 * t) * t;

        // Cubic
        Easing CUBIC_IN = t -> t * t * t;
        Easing CUBIC_OUT = t -> (--t) * t * t + 1;
        Easing CUBIC_IN_OUT = t -> t < 0.5f ? 4 * t * t * t : (t - 1) * (2 * t - 2) * (2 * t - 2) + 1;

        // Quart
        Easing QUART_IN = t -> t * t * t * t;
        Easing QUART_OUT = t -> 1 - (--t) * t * t * t;
        Easing QUART_IN_OUT = t -> t < 0.5f ? 8 * t * t * t * t : 1 - 8 * (--t) * t * t * t;

        // Quint
        Easing QUINT_IN = t -> t * t * t * t * t;
        Easing QUINT_OUT = t -> 1 + (--t) * t * t * t * t;
        Easing QUINT_IN_OUT = t -> t < 0.5f ? 16 * t * t * t * t * t : 1 + 16 * (--t) * t * t * t * t;

        // Sine
        Easing SINE_IN = t -> 1 - (float) Math.cos(t * Math.PI / 2);
        Easing SINE_OUT = t -> (float) Math.sin(t * Math.PI / 2);
        Easing SINE_IN_OUT = t -> -(float) Math.cos(Math.PI * t) / 2 + 0.5f;

        // Expo
        Easing EXPO_IN = t -> t == 0 ? 0 : (float) Math.pow(2, 10 * (t - 1));
        Easing EXPO_OUT = t -> t == 1 ? 1 : 1 - (float) Math.pow(2, -10 * t);
        Easing EXPO_IN_OUT = t -> {
            if (t == 0) return 0;
            if (t == 1) return 1;
            if (t < 0.5f) return (float) Math.pow(2, 20 * t - 10) / 2;
            return (2 - (float) Math.pow(2, -20 * t + 10)) / 2;
        };

        // Circ
        Easing CIRC_IN = t -> 1 - (float) Math.sqrt(1 - t * t);
        Easing CIRC_OUT = t -> (float) Math.sqrt(1 - (t - 1) * (t - 1));
        Easing CIRC_IN_OUT = t -> {
            if (t < 0.5f) return -(float) Math.sqrt(1 - 4 * t * t) / 2;
            return ((float) Math.sqrt(1 - (2 * t - 2) * (2 * t - 2)) + 1) / 2;
        };

        // Back (overshoot)
        Easing BACK_IN = t -> t * t * ((1.70158f + 1) * t - 1.70158f);
        Easing BACK_OUT = t -> (t - 1) * (t - 1) * ((1.70158f + 1) * (t - 1) + 1.70158f) + 1;
        Easing BACK_IN_OUT = t -> {
            float s = 1.70158f * 1.525f;
            if (t < 0.5f) return (t * 2) * (t * 2) * ((s + 1) * (t * 2) - s) / 2;
            return ((t * 2 - 2) * (t * 2 - 2) * ((s + 1) * (t * 2 - 2) + s) + 2) / 2;
        };

        // Elastic
        Easing ELASTIC_IN = t -> {
            if (t == 0 || t == 1) return t;
            return -(float) Math.pow(2, 10 * t - 10) * (float) Math.sin((t * 10 - 10.75) * (2 * Math.PI) / 3);
        };
        Easing ELASTIC_OUT = t -> {
            if (t == 0 || t == 1) return t;
            return (float) Math.pow(2, -10 * t) * (float) Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1;
        };
        Easing ELASTIC_IN_OUT = t -> {
            if (t == 0 || t == 1) return t;
            if (t < 0.5f) return -(float) Math.pow(2, 20 * t - 10) * (float) Math.sin((20 * t - 11.125) * (2 * Math.PI) / 4.5) / 2;
            return (float) Math.pow(2, -20 * t + 10) * (float) Math.sin((20 * t - 11.125) * (2 * Math.PI) / 4.5) / 2 + 1;
        };

        // Bounce
        Easing BOUNCE_OUT = t -> {
            float n1 = 7.5625f;
            float d1 = 2.75f;
            if (t < 1 / d1) return n1 * t * t;
            else if (t < 2 / d1) return n1 * (t -= 1.5f / d1) * t + 0.75f;
            else if (t < 2.5f / d1) return n1 * (t -= 2.25f / d1) * t + 0.9375f;
            else return n1 * (t -= 2.625f / d1) * t + 0.984375f;
        };
        Easing BOUNCE_IN = t -> 1 - BOUNCE_OUT.apply(1 - t);
        Easing BOUNCE_IN_OUT = t -> t < 0.5f ? (1 - BOUNCE_OUT.apply(1 - 2 * t)) / 2 : (1 + BOUNCE_OUT.apply(2 * t - 1)) / 2;

        // Custom cubic bezier
        static Easing cubicBezier(float x1, float y1, float x2, float y2) {
            return new CubicBezierEasing(x1, y1, x2, y2);
        }
    }

    /**
     * Cubic bezier easing implementation.
     */
    private static class CubicBezierEasing implements Easing {
        private final float ax, bx, ay, by;
        private final float epsilon = 1e-6f;

        CubicBezierEasing(float x1, float y1, float x2, float y2) {
            // Check if points are in [0, 1]
            if (x1 < 0 || x1 > 1 || x2 < 0 || x2 > 1) {
                throw new IllegalArgumentException("x values must be in [0, 1]");
            }

            // Convert control points to polynomial coefficients
            this.cx = 3 * x1;
            this.bx = 3 * (x2 - x1) - cx;
            this.ax = 1 - cx - bx;

            this.cy = 3 * y1;
            this.by = 3 * (y2 - y1) - cy;
            this.ay = 1 - cy - by;
        }

        private final float cx, bx, ax;
        private final float cy, by, ay;

        @Override
        public float apply(float t) {
            return sampleCurveY(sampleCurveX(t));
        }

        private float sampleCurveX(float t) {
            return ((ax * t + bx) * t + cx) * t;
        }

        private float sampleCurveY(float t) {
            return ((ay * t + by) * t + cy) * t;
        }

        private float sampleDerivativeX(float t) {
            return (3 * ax * t + 2 * bx) * t + cx;
        }

        private float solveCurveX(float x) {
            float t2 = x;
            for (int i = 0; i < 8; i++) {
                float x2 = sampleCurveX(t2) - x;
                if (Math.abs(x2) < epsilon) return t2;
                float d2 = sampleDerivativeX(t2);
                if (Math.abs(d2) < epsilon) break;
                t2 = t2 - x2 / d2;
            }
            return t2;
        }
    }
}
