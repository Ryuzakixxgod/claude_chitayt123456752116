package ru.ryuzaki.ui.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;
import net.minecraft.util.math.MathHelper;

import java.util.Random;

/**
 * GlassRenderer — physically-based glass material rendering.
 *
 * Implements:
 * - Fresnel reflections (Schlick approximation)
 * - Refraction with IOR = 1.52 (crown glass)
 * - Chromatic aberration (RGB channel separation)
 * - Specular highlights (Blinn-Phong)
 * - Edge glow (rim lighting)
 * - Animated caustic patterns
 * - Environment reflection approximation
 * - Alpha compositing with depth
 *
 * PHYSICS:
 * - IOR: 1.52 (borosilicate glass)
 * - Fresnel: F0 = ((n1-n2)/(n1+n2))^2 = 0.04
 * - Refraction offset: 2-4 pixels based on thickness
 * - Chromatic aberration: 0.5-2px RGB separation
 *
 * RENDER ORDER:
 * 1. Refracted background (with chromatic aberration)
 * 2. Glass base color
 * 3. Specular highlights
 * 4. Edge glow
 * 5. Caustic patterns
 */
public class GlassRenderer {

    private static GlassRenderer INSTANCE;

    // Physics constants
    private static final float IOR_AIR = 1.0f;
    private static final float IOR_GLASS = 1.52f;
    private static final float FRESNEL_F0 = 0.04f; // ((1.0-1.52)/(1.0+1.52))^2

    // Glass properties
    private float thickness = 0.5f;
    private float chromaticAberration = 1.0f;
    private float specularPower = 64.0f;
    private float rimGlowIntensity = 0.6f;

    // Animation
    private long startTime;
    private float animationTime = 0f;
    private float mouseInfluenceX = 0f;
    private float mouseInfluenceY = 0f;

    // Caustic noise
    private final Random noise = new Random(12345);

    // Color constants from spec
    private static final int GLASS_BASE_COLOR = 0x8B5CFF;
    private static final int GLASS_EDGE_COLOR = 0xA78BFF;
    private static final int HIGHLIGHT_COLOR = 0xFFFFFF;

    private GlassRenderer() {
        this.startTime = System.currentTimeMillis();
    }

    public static synchronized GlassRenderer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GlassRenderer();
        }
        return INSTANCE;
    }

    /**
     * Update mouse influence for interactive glass.
     */
    public void updateMousePosition(float x, float y, float screenWidth, float screenHeight) {
        this.mouseInfluenceX = x / screenWidth;
        this.mouseInfluenceY = y / screenHeight;
    }

    /**
     * Update animation time.
     */
    private void updateAnimation() {
        animationTime = (System.currentTimeMillis() - startTime) / 1000.0f;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  FRESNEL REFLECTION (Schlick approximation)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Calculate Fresnel reflection coefficient.
     *
     * F(θ) = F0 + (1 - F0) * (1 - cos(θ))^5
     *
     * @param cosTheta Cosine of angle between view vector and surface normal
     * @return Fresnel coefficient [0, 1]
     */
    private float fresnel(float cosTheta) {
        float min = MathHelper.clamp(cosTheta, 0f, 1f);
        return FRESNEL_F0 + (1f - FRESNEL_F0) * (float) Math.pow(1f - min, 5f);
    }

    /**
     * Calculate Fresnel with metallic tint.
     */
    private float fresnelMetallic(float cosTheta, float metallic) {
        float f = fresnel(cosTheta);
        return MathHelper.lerp(f, 1f, metallic * 0.5f);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  REFRACTION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Calculate refraction direction using Snell's law.
     *
     * η1 * sin(θ1) = η2 * sin(θ2)
     *
     * @param normal Surface normal
     * @param viewDir View direction
     * @param etaRatio η1/η2 (IOR ratio)
     * @return Refracted direction
     */
    private Vec3f refract(Vec3f normal, Vec3f viewDir, float etaRatio) {
        float cosI = dot(normal, viewDir);
        float sinT2 = etaRatio * etaRatio * (1f - cosI * cosI);

        if (sinT2 > 1f) {
            // Total internal reflection
            return reflect(normal, viewDir);
        }

        float cosT = (float) Math.sqrt(1f - sinT2);
        return new Vec3f(
                etaRatio * viewDir.getX() + (etaRatio * cosI - cosT) * normal.getX(),
                etaRatio * viewDir.getY() + (etaRatio * cosI - cosT) * normal.getY(),
                etaRatio * viewDir.getZ() + (etaRatio * cosI - cosT) * normal.getZ()
        );
    }

    /**
     * Calculate reflection direction.
     */
    private Vec3f reflect(Vec3f normal, Vec3f viewDir) {
        float factor = 2f * dot(normal, viewDir);
        return new Vec3f(
                viewDir.getX() - factor * normal.getX(),
                viewDir.getY() - factor * normal.getY(),
                viewDir.getZ() - factor * normal.getZ()
        );
    }

    /**
     * Dot product of two vectors.
     */
    private float dot(Vec3f a, Vec3f b) {
        return a.getX() * b.getX() + a.getY() * b.getY() + a.getZ() * b.getZ();
    }

    /**
     * Get refraction offset in pixels.
     */
    private float getRefractionOffset(float edgeDistance, float glassThickness) {
        // Thicker glass = more refraction
        // Edge of glass = more refraction
        float thicknessFactor = glassThickness * 3f;
        float edgeFactor = edgeDistance < 0.2f ? 1f - edgeDistance / 0.2f : 0f;

        return (thicknessFactor + edgeFactor) * 3f * chromaticAberration;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CHROMATIC ABERRATION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Calculate RGB channel offsets for chromatic aberration.
     */
    private float[] getChromaticOffsets(float intensity) {
        float offset = intensity * chromaticAberration;
        return new float[] {
                -offset,        // R offset
                0f,             // G offset
                offset          // B offset
        };
    }

    /**
     * Apply chromatic aberration to color channels.
     */
    private int applyChromaticAberration(int baseColor, float intensity) {
        float r = ((baseColor >> 16) & 0xFF) / 255f;
        float g = ((baseColor >> 8) & 0xFF) / 255f;
        float b = (baseColor & 0xFF) / 255f;

        // Shift channels
        float rShifted = r + intensity * 0.1f * chromaticAberration;
        float gShifted = g;
        float bShifted = b - intensity * 0.1f * chromaticAberration;

        // Clamp
        rShifted = MathHelper.clamp(rShifted, 0f, 1f);
        gShifted = MathHelper.clamp(gShifted, 0f, 1f);
        bShifted = MathHelper.clamp(bShifted, 0f, 1f);

        return ColorHelper.getArgb(
                (int) (255),
                (int) (rShifted * 255),
                (int) (gShifted * 255),
                (int) (bShifted * 255)
        );
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SPECULAR HIGHLIGHTS (Blinn-Phong)
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Calculate Blinn-Phong specular highlight.
     *
     * H = normalize(V + L)
     * spec = pow(max(dot(N, H), 0), specularPower)
     *
     * @param normal Surface normal
     * @param viewDir View direction
     * @param lightDir Light direction
     * @param specularPower Glossiness exponent
     * @return Specular intensity [0, 1]
     */
    private float blinnPhongSpecular(Vec3f normal, Vec3f viewDir, Vec3f lightDir, float specularPower) {
        // Half vector
        Vec3f hv = new Vec3f(
                viewDir.getX() + lightDir.getX(),
                viewDir.getY() + lightDir.getY(),
                viewDir.getZ() + lightDir.getZ()
        );
        float hLen = (float) Math.sqrt(hv.getX() * hv.getX() + hv.getY() * hv.getY() + hv.getZ() * hv.getZ());
        hv = new Vec3f(hv.getX() / hLen, hv.getY() / hLen, hv.getZ() / hLen);

        // Specular
        float spec = Math.max(dot(normal, hv), 0f);
        return (float) Math.pow(spec, specularPower);
    }

    /**
     * Get highlight position based on mouse.
     */
    private Vec3f getLightDirection(float x, float y, float width, float height) {
        // Light comes from top-right
        float lx = 0.7f;
        float ly = 0.2f;

        // Mouse influences light position slightly
        lx += (mouseInfluenceX - 0.5f) * 0.3f;
        ly += (mouseInfluenceY - 0.5f) * 0.2f;

        // Calculate direction from point to light
        float px = (x / width - 0.5f) * 2f;
        float py = (y / height - 0.5f) * 2f;

        float dx = lx - px;
        float dy = ly - py;
        float dz = 0.5f;

        float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        return new Vec3f(dx / len, dy / len, dz / len);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDER METHODS
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Render glass material with all effects.
     */
    public void renderGlass(DrawContext context, float x, float y, float width, float height,
                           float depthLayer, float thickness, boolean hovered, boolean active) {
        updateAnimation();

        MatrixStack matrices = context.getMatrices();
        matrices.push();

        // Apply transforms
        matrices.translate(x, y, 0);

        // Calculate local mouse position
        float localMouseX = mouseInfluenceX * MinecraftClient.getInstance().getWindow().getFramebufferWidth() - x;
        float localMouseY = mouseInfluenceY * MinecraftClient.getInstance().getWindow().getFramebufferHeight() - y;

        // Interactive intensity
        float mouseDistance = distance(localMouseX, localMouseY, width / 2, height / 2);
        float maxDist = (float) Math.sqrt(width * width + height * height) / 2;
        float mouseIntensity = 1f - MathHelper.clamp(mouseDistance / maxDist, 0f, 1f);

        // Hover/active modifiers
        float hoverBoost = hovered ? 1.3f : 1f;
        float activeBoost = active ? 1.5f : 1f;
        float intensity = mouseIntensity * hoverBoost * activeBoost;

        // Render passes
        renderRefraction(context, matrices, width, height, intensity);
        renderGlassBase(context, matrices, width, height, intensity);
        renderSpecularHighlight(context, matrices, width, height, intensity);
        renderEdgeGlow(context, matrices, width, height, intensity);
        renderCaustics(context, matrices, width, height, intensity);

        matrices.pop();
    }

    /**
     * Render refracted background (chromatic aberration).
     */
    private void renderRefraction(DrawContext context, MatrixStack matrices,
                                 float width, float height, float intensity) {
        float[] offsets = getChromaticOffsets(intensity);

        // Refraction is simulated by offset color sampling
        // In a full implementation, this would sample from a captured framebuffer
        // with shifted UVs per RGB channel

        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        float offsetAmount = offsets[0] * 2f * intensity;

        // Slightly shifted vertices for refraction effect
        bufferBuilder.vertex(-offsetAmount, height + offsetAmount, 0)
                .color(0.54f, 0.36f, 1f, 0.3f * intensity);
        bufferBuilder.vertex(width - offsetAmount, height + offsetAmount, 0)
                .color(0.54f, 0.36f, 1f, 0.3f * intensity);
        bufferBuilder.vertex(width - offsetAmount, -offsetAmount, 0)
                .color(0.54f, 0.36f, 1f, 0.3f * intensity);
        bufferBuilder.vertex(-offsetAmount, -offsetAmount, 0)
                .color(0.54f, 0.36f, 1f, 0.3f * intensity);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Render glass base with Fresnel tint.
     */
    private void renderGlassBase(DrawContext context, MatrixStack matrices,
                                float width, float height, float intensity) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Fresnel-based transparency
        // Center is more transparent, edges are more opaque
        float centerFresnel = fresnel(1f);
        float edgeFresnel = fresnel(0f);

        float alpha = 0.15f + (edgeFresnel - centerFresnel) * 0.2f * intensity;

        // Base glass color with Fresnel tint
        float r = 0.545f * (0.8f + edgeFresnel * 0.2f);
        float g = 0.361f * (0.8f + edgeFresnel * 0.2f);
        float b = 1f * (0.8f + edgeFresnel * 0.2f);

        bufferBuilder.vertex(0, height, 0).color(r, g, b, alpha);
        bufferBuilder.vertex(width, height, 0).color(r, g, b, alpha);
        bufferBuilder.vertex(width, 0, 0).color(r, g, b, alpha);
        bufferBuilder.vertex(0, 0, 0).color(r, g, b, alpha);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Render specular highlight.
     */
    private void renderSpecularHighlight(DrawContext context, MatrixStack matrices,
                                        float width, float height, float intensity) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Specular position follows mouse
        float specX = width * (0.7f + (mouseInfluenceX - 0.5f) * 0.3f);
        float specY = height * (0.2f + (mouseInfluenceY - 0.5f) * 0.2f);

        float specSize = Math.min(width, height) * 0.3f * intensity;

        // Highlight gradient
        float alpha = 0.4f * intensity;

        // Top-left highlight
        bufferBuilder.vertex(specX - specSize, specY - specSize, 0)
                .color(1f, 1f, 1f, alpha);
        bufferBuilder.vertex(specX + specSize * 0.3f, specY - specSize, 0)
                .color(1f, 1f, 1f, alpha * 0.5f);
        bufferBuilder.vertex(specX + specSize * 0.3f, specY + specSize * 0.3f, 0)
                .color(1f, 1f, 1f, alpha * 0.2f);
        bufferBuilder.vertex(specX - specSize, specY + specSize * 0.3f, 0)
                .color(1f, 1f, 1f, alpha * 0.5f);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Render edge glow (rim lighting).
     */
    private void renderEdgeGlow(DrawContext context, MatrixStack matrices,
                               float width, float height, float intensity) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        float glowWidth = 8f;
        float glowIntensity = rimGlowIntensity * intensity;

        // Animated pulse
        float pulse = (float) Math.sin(animationTime * 2f) * 0.5f + 0.5f;
        glowIntensity *= 0.8f + pulse * 0.4f;

        // Top edge
        bufferBuilder.vertex(0, glowWidth, 0).color(0.655f, 0.545f, 1f, glowIntensity);
        bufferBuilder.vertex(width, glowWidth, 0).color(0.655f, 0.545f, 1f, glowIntensity);
        bufferBuilder.vertex(width, 0, 0).color(0.655f, 0.545f, 1f, 0f);
        bufferBuilder.vertex(0, 0, 0).color(0.655f, 0.545f, 1f, 0f);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Render animated caustic patterns.
     */
    private void renderCaustics(DrawContext context, MatrixStack matrices,
                              float width, float height, float intensity) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Procedural caustic pattern using noise
        float causticIntensity = 0.15f * intensity;

        // Animated caustic phase
        float phase = animationTime * 0.5f;

        // Generate caustic pattern using interference of sine waves
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                float cellX = (i + 0.5f) * width / 4f;
                float cellY = (j + 0.5f) * height / 4f;

                // Noise pattern
                float noise = simplexNoise(
                        cellX * 0.02f + phase,
                        cellY * 0.02f + phase * 0.7f
                );

                if (noise > 0.3f) {
                    float cellSize = width / 8f * noise;
                    float alpha = causticIntensity * noise;

                    bufferBuilder.vertex(cellX - cellSize, cellY - cellSize, 0)
                            .color(1f, 1f, 1f, alpha);
                    bufferBuilder.vertex(cellX + cellSize, cellY - cellSize, 0)
                            .color(1f, 1f, 1f, alpha);
                    bufferBuilder.vertex(cellX + cellSize, cellY + cellSize, 0)
                            .color(1f, 1f, 1f, alpha);
                    bufferBuilder.vertex(cellX - cellSize, cellY + cellSize, 0)
                            .color(1f, 1f, 1f, alpha);
                }
            }
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Simple noise function for caustics.
     */
    private float simplexNoise(float x, float y) {
        // Simplified noise using sine waves
        float n1 = (float) Math.sin(x * 12.9898f + y * 78.233f) * 43758.5453f;
        n1 = n1 - (float) Math.floor(n1);

        float n2 = (float) Math.sin(x * 78.233f + y * 12.9898f) * 43758.5453f;
        n2 = n2 - (float) Math.floor(n2);

        return (n1 + n2) * 0.5f;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UTILITY
    // ═══════════════════════════════════════════════════════════════════════

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Set glass thickness (affects refraction).
     */
    public void setThickness(float thickness) {
        this.thickness = MathHelper.clamp(thickness, 0.1f, 1f);
    }

    /**
     * Set chromatic aberration intensity.
     */
    public void setChromaticAberration(float intensity) {
        this.chromaticAberration = MathHelper.clamp(intensity, 0f, 2f);
    }

    /**
     * Set specular power (glossiness).
     */
    public void setSpecularPower(float power) {
        this.specularPower = MathHelper.clamp(power, 8f, 256f);
    }

    /**
     * Set rim glow intensity.
     */
    public void setRimGlowIntensity(float intensity) {
        this.rimGlowIntensity = MathHelper.clamp(intensity, 0f, 1f);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  VECTOR CLASS
    // ═══════════════════════════════════════════════════════════════════════

    private static class Vec3f {
        private float x, y, z;

        Vec3f(float x, float y, float z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        float getX() { return x; }
        float getY() { return y; }
        float getZ() { return z; }
    }
}
