package ru.ryuzaki.ui.render.effect;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import org.lwjgl.opengl.GL30;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * KawaseBlurRenderer — dual Kawase blur implementation.
 *
 * Kawase blur is a technique used in HDR rendering for high-quality bloom.
 * It samples in a diamond pattern and averages, providing a soft blur
 * that spreads bright areas into neighboring pixels.
 *
 * Algorithm:
 * Pass 1: Each pixel samples corners and averages
 * Pass 2: Offset sampling pattern for wider spread
 *
 * Advantages over Gaussian:
 * - Works on half-resolution buffers
 * - Fewer texture samples per pass
 * - Produces wider, softer glow
 * - Excellent for bloom extraction
 *
 * Pipeline:
 *   Input → KawaseDown → KawaseUp → Output
 */
public class KawaseBlurRenderer {

    private static KawaseBlurRenderer INSTANCE;

    // Shader programs
    private int kawaseDownProgram;
    private int kawaseUpProgram;

    // Uniform locations
    private int downTexelSizeLoc;
    private int downHalfPixelLoc;
    private int upTexelSizeLoc;
    private int upHalfPixelLoc;
    private int upBloomIntensityLoc;

    // Vertex buffer for fullscreen quad
    private int quadVao;
    private int quadVbo;

    // Current state
    private boolean initialized = false;
    private int currentWidth;
    private int currentHeight;

    private KawaseBlurRenderer() {}

    public static synchronized KawaseBlurRenderer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new KawaseBlurRenderer();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Initialize shader programs and buffers.
     */
    public void initialize() {
        if (initialized) return;

        initializeShaders();
        initializeBuffers();

        initialized = true;
    }

    private void initializeShaders() {
        // Kawase Down shader - samples corners
        String downVert = "#version 330 core\n" +
            "layout(location = 0) in vec2 aPosition;\n" +
            "layout(location = 1) in vec2 aTexCoord;\n" +
            "out vec2 vTexCoord;\n" +
            "void main() {\n" +
            "    gl_Position = vec4(aPosition, 0.0, 1.0);\n" +
            "    vTexCoord = aTexCoord;\n" +
            "}";

        String downFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uTexture;\n" +
            "uniform vec2 uTexelSize;\n" +
            "uniform vec2 uHalfPixel;\n" +
            "void main() {\n" +
            "    vec2 uv = vTexCoord;\n" +
            "    vec2 hp = uHalfPixel * uTexelSize;\n" +
            "    vec4 sum = vec4(0.0);\n" +
            "    sum += texture(uTexture, uv + vec2(-hp.x, -hp.y));\n" +
            "    sum += texture(uTexture, uv + vec2( hp.x, -hp.y));\n" +
            "    sum += texture(uTexture, uv + vec2(-hp.x,  hp.y));\n" +
            "    sum += texture(uTexture, uv + vec2( hp.x,  hp.y));\n" +
            "    sum *= 0.25;\n" +
            "    fragColor = sum;\n" +
            "}";

        // Kawase Up shader - shifts samples outward
        String upVert = downVert;

        String upFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uTexture;\n" +
            "uniform vec2 uTexelSize;\n" +
            "uniform vec2 uHalfPixel;\n" +
            "uniform float uBloomIntensity;\n" +
            "void main() {\n" +
            "    vec2 uv = vTexCoord;\n" +
            "    vec2 hp = uHalfPixel * uTexelSize;\n" +
            "    vec4 sum = vec4(0.0);\n" +
            "    sum += texture(uTexture, uv + vec2(-hp.x * 1.5, -hp.y * 1.5));\n" +
            "    sum += texture(uTexture, uv + vec2( hp.x * 1.5, -hp.y * 1.5));\n" +
            "    sum += texture(uTexture, uv + vec2(-hp.x * 1.5,  hp.y * 1.5));\n" +
            "    sum += texture(uTexture, uv + vec2( hp.x * 1.5,  hp.y * 1.5));\n" +
            "    sum += texture(uTexture, uv);\n" +
            "    sum *= 0.2;\n" +
            "    fragColor = sum * uBloomIntensity;\n" +
            "}";

        kawaseDownProgram = createShaderProgram(downVert, downFrag);
        kawaseUpProgram = createShaderProgram(upVert, upFrag);

        // Get uniform locations
        downTexelSizeLoc = glGetUniformLocation(kawaseDownProgram, "uTexelSize");
        downHalfPixelLoc = glGetUniformLocation(kawaseDownProgram, "uHalfPixel");
        upTexelSizeLoc = glGetUniformLocation(kawaseUpProgram, "uTexelSize");
        upHalfPixelLoc = glGetUniformLocation(kawaseUpProgram, "uHalfPixel");
        upBloomIntensityLoc = glGetUniformLocation(kawaseUpProgram, "uBloomIntensity");
    }

    private int createShaderProgram(String vertSrc, String fragSrc) {
        int vert = compileShader(GL_VERTEX_SHADER, vertSrc);
        int frag = compileShader(GL_FRAGMENT_SHADER, fragSrc);

        int program = glCreateProgram();
        glAttachShader(program, vert);
        glAttachShader(program, frag);
        glLinkProgram(program);

        if (glGetProgrami(program, GL_LINK_STATUS) == GL_FALSE) {
            System.err.println("[KawaseBlur] Program link error: " + glGetProgramInfoLog(program));
        }

        // Clean up shaders after linking
        glDeleteShader(vert);
        glDeleteShader(frag);

        return program;
    }

    private int compileShader(int type, String source) {
        int shader = glCreateShader(type);
        glShaderSource(shader, source);
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
            System.err.println("[KawaseBlur] Shader compile error: " + glGetShaderInfoLog(shader));
            glDeleteShader(shader);
            return 0;
        }

        return shader;
    }

    private void initializeBuffers() {
        // Fullscreen quad vertices: position (2) + texcoord (2)
        float[] vertices = {
            // Positions    // TexCoords
            -1.0f,  1.0f,   0.0f, 1.0f,
            -1.0f, -1.0f,   0.0f, 0.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
            -1.0f,  1.0f,   0.0f, 1.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
             1.0f,  1.0f,   1.0f, 1.0f
        };

        quadVao = glGenVertexArrays();
        quadVbo = glGenBuffers();

        glBindVertexArray(quadVao);
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo);
        glBufferData(GL_ARRAY_BUFFER, vertices, GL_STATIC_DRAW);

        // Position attribute
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * 4, 0);

        // TexCoord attribute
        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * 4, 2 * 4);

        glBindVertexArray(0);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  BLUR EXECUTION
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Execute Kawase blur on input texture.
     *
     * @param inputTex Input texture ID
     * @param outputTex Output framebuffer texture
     * @param width Buffer width
     * @param height Buffer height
     * @param iterations Number of blur passes (4-6 recommended)
     * @param intensity Bloom intensity multiplier
     */
    public void execute(int inputTex, int outputTex, int width, int height,
                        int iterations, float intensity) {
        if (!initialized) {
            initialize();
        }

        this.currentWidth = width;
        this.currentHeight = height;

        // Store current state
        int prevFBO = glGetInteger(GL_FRAMEBUFFER_BINDING);
        int prevViewport[] = new int[4];
        glGetIntegerv(GL_VIEWPORT, prevViewport);

        // Downsample pass
        executeDownPass(inputTex, width, height, iterations);

        // Upsample pass
        executeUpPass(outputTex, width, height, iterations, intensity);

        // Restore state
        glBindFramebuffer(GL_FRAMEBUFFER, prevFBO);
        glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
    }

    /**
     * Down pass — reduces resolution while blurring.
     */
    private void executeDownPass(int inputTex, int width, int height, int passes) {
        glUseProgram(kawaseDownProgram);
        glBindVertexArray(quadVao);

        // Bind input texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, inputTex);
        glUniform1i(glGetUniformLocation(kawaseDownProgram, "uTexture"), 0);

        // Setup uniforms
        float texelSize[] = new float[]{1.0f / width, 1.0f / height};
        glUniform2fv(downTexelSizeLoc, texelSize);

        // Progressively downsample
        int currentTex = inputTex;
        int currentWidth = width;
        int currentHeight = height;

        for (int i = 0; i < passes; i++) {
            // Create temporary FBO for downsampled result
            int fbo = glGenFramebuffers();
            int tex = createRenderTexture(currentWidth / 2, currentHeight / 2);

            glBindFramebuffer(GL_FRAMEBUFFER, fbo);
            glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, tex, 0);

            // Half the resolution each pass
            int newWidth = Math.max(1, currentWidth / 2);
            int newHeight = Math.max(1, currentHeight / 2);

            glViewport(0, 0, newWidth, newHeight);

            // Half pixel offset increases with each iteration
            float halfPixel[] = new float[]{1.0f + i * 0.5f, 1.0f + i * 0.5f};
            glUniform2fv(downHalfPixelLoc, halfPixel);

            // Draw
            glDrawArrays(GL_TRIANGLES, 0, 6);

            // Next iteration uses this texture
            if (i < passes - 1) {
                glBindTexture(GL_TEXTURE_2D, tex);
                currentWidth = newWidth;
                currentHeight = newHeight;
            }

            // Clean up FBO (keep texture for next pass input)
            glDeleteFramebuffers(fbo);
        }

        glBindVertexArray(0);
    }

    /**
     * Up pass — restores resolution while combining with original.
     */
    private void executeUpPass(int outputTex, int width, int height,
                                int iterations, float intensity) {
        glUseProgram(kawaseUpProgram);
        glBindVertexArray(quadVao);

        // Bind output
        glBindFramebuffer(GL_FRAMEBUFFER, 0);
        glViewport(0, 0, width, height);

        // Bind final input texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, outputTex);
        glUniform1i(glGetUniformLocation(kawaseUpProgram, "uTexture"), 0);

        // Setup uniforms
        float texelSize[] = new float[]{1.0f / width, 1.0f / height};
        glUniform2fv(upTexelSizeLoc, texelSize);
        glUniform1f(upBloomIntensityLoc, intensity);

        // Sample in diamond pattern
        float halfPixel[] = new float[]{1.0f, 1.0f};
        glUniform2fv(upHalfPixelLoc, halfPixel);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindVertexArray(0);
    }

    /**
     * Single Kawase blur iteration for bloom.
     */
    public void blur(int inputTex, int outputFBO, int width, int height, boolean isDown) {
        if (!initialized) {
            initialize();
        }

        glUseProgram(isDown ? kawaseDownProgram : kawaseUpProgram);
        glBindVertexArray(quadVao);

        // Bind framebuffer
        glBindFramebuffer(GL_FRAMEBUFFER, outputFBO);
        glViewport(0, 0, width, height);

        // Bind texture
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, inputTex);

        int texLoc = glGetUniformLocation(isDown ? kawaseDownProgram : kawaseUpProgram, "uTexture");
        int tsLoc = isDown ? downTexelSizeLoc : upTexelSizeLoc;
        int hpLoc = isDown ? downHalfPixelLoc : upHalfPixelLoc;

        glUniform1i(texLoc, 0);
        glUniform2f(tsLoc, 1.0f / width, 1.0f / height);
        glUniform2f(hpLoc, 1.0f, 1.0f);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindVertexArray(0);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UTILITY
    // ═══════════════════════════════════════════════════════════════════════

    private int createRenderTexture(int width, int height) {
        int tex = glGenTextures();
        glBindTexture(GL_TEXTURE_2D, tex);
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA16F, width, height, 0, GL_RGBA, GL_HALF_FLOAT, 0);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        return tex;
    }

    /**
     * Cleanup GPU resources.
     */
    public void cleanup() {
        if (quadVao != 0) {
            glDeleteVertexArrays(quadVao);
            quadVao = 0;
        }
        if (quadVbo != 0) {
            glDeleteBuffers(quadVbo);
            quadVbo = 0;
        }
        if (kawaseDownProgram != 0) {
            glDeleteProgram(kawaseDownProgram);
            kawaseDownProgram = 0;
        }
        if (kawaseUpProgram != 0) {
            glDeleteProgram(kawaseUpProgram);
            kawaseUpProgram = 0;
        }
        initialized = false;
    }
}
