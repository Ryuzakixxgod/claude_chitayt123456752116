package ru.ryuzaki.ui.render.effect;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Vector3f;

import java.util.*;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * BackgroundAtmosphereRenderer — volumetric atmospheric effects.
 *
 * Implements:
 * - Exponential height fog
 * - Volumetric light rays (god rays)
 * - Animated noise-based fog
 * - Depth-aware atmospheric perspective
 * - World-space fog calculation
 *
 * Visual features:
 * - Cinematic fog with depth
 * - Light scattering simulation
 * - Animated atmosphere particles
 * - Horizon glow
 * - Distance fog
 *
 * This creates the immersive background that makes UI panels
 * feel like they're floating in a real 3D space.
 */
public class BackgroundAtmosphereRenderer {

    private static BackgroundAtmosphereRenderer INSTANCE;

    // Shader programs
    private int fogProgram;
    private int godRayProgram;
    private int compositeProgram;

    // Uniforms
    private int fogColorLoc;
    private int fogDensityLoc;
    private int cameraPosLoc;
    private int timeLoc;
    private int noiseScaleLoc;

    // Vertex buffer
    private int quadVao;
    private int quadVbo;

    // Volumetric data
    private float time = 0.0f;
    private float fogDensity = 0.015f;
    private Vector3f fogColor = new Vector3f(0.5f, 0.6f, 0.9f);
    private Vector3f lightDir = new Vector3f(0.5f, 0.8f, 0.3f).normalize();

    // Ray data
    private static final int NUM_RAYS = 8;
    private float[] rayAngles = new float[NUM_RAYS];
    private float[] rayIntensities = new float[NUM_RAYS];

    // Noise texture
    private int noiseTexture;

    // State
    private boolean initialized = false;

    private BackgroundAtmosphereRenderer() {
        initializeRayAngles();
    }

    public static synchronized BackgroundAtmosphereRenderer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new BackgroundAtmosphereRenderer();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════

    public void initialize() {
        if (initialized) return;

        initializeShaders();
        initializeBuffers();
        initializeNoiseTexture();

        initialized = true;
    }

    private void initializeRayAngles() {
        for (int i = 0; i < NUM_RAYS; i++) {
            rayAngles[i] = (float) Math.toRadians(360.0f / NUM_RAYS * i);
            rayIntensities[i] = 1.0f;
        }
    }

    private void initializeShaders() {
        // Atmospheric fog shader
        String fogVert = "#version 330 core\n" +
            "layout(location = 0) in vec2 aPosition;\n" +
            "layout(location = 1) in vec2 aTexCoord;\n" +
            "out vec2 vTexCoord;\n" +
            "out vec2 vPosition;\n" +
            "void main() {\n" +
            "    gl_Position = vec4(aPosition, 0.0, 1.0);\n" +
            "    vTexCoord = aTexCoord;\n" +
            "    vPosition = aPosition;\n" +
            "}";

        String fogFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "in vec2 vPosition;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec3 uFogColor;\n" +
            "uniform float uFogDensity;\n" +
            "uniform vec3 uCameraPos;\n" +
            "uniform float uTime;\n" +
            "uniform float uNoiseScale;\n" +
            "uniform sampler2D uNoiseTexture;\n" +
            "uniform float uAspectRatio;\n" +
            "float hash(vec2 p) {\n" +
            "    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n" +
            "}\n" +
            "float noise(vec2 p) {\n" +
            "    vec2 i = floor(p);\n" +
            "    vec2 f = fract(p);\n" +
            "    f = f * f * (3.0 - 2.0 * f);\n" +
            "    float a = hash(i);\n" +
            "    float b = hash(i + vec2(1.0, 0.0));\n" +
            "    float c = hash(i + vec2(0.0, 1.0));\n" +
            "    float d = hash(i + vec2(1.0, 1.0));\n" +
            "    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);\n" +
            "}\n" +
            "float fbm(vec2 p) {\n" +
            "    float sum = 0.0;\n" +
            "    float amp = 0.5;\n" +
            "    for (int i = 0; i < 4; i++) {\n" +
            "        sum += noise(p) * amp;\n" +
            "        p *= 2.0;\n" +
            "        amp *= 0.5;\n" +
            "    }\n" +
            "    return sum;\n" +
            "}\n" +
            "void main() {\n" +
            "    vec2 uv = vTexCoord;\n" +
            "    vec2 screenPos = vPosition * 0.5 + 0.5;\n" +
            "    float dist = length(screenPos - vec2(0.5));\n" +
            "    float depth = smoothstep(0.0, 1.0, dist);\n" +
            "    vec2 noiseUV = uv * uNoiseScale + vec2(uTime * 0.02, uTime * 0.01);\n" +
            "    float n = fbm(noiseUV);\n" +
            "    float fogAmount = uFogDensity * depth * (0.5 + n * 0.5);\n" +
            "    float fogFactor = 1.0 - exp(-fogAmount * fogAmount);\n" +
            "    fogFactor = smoothstep(0.0, 1.0, fogFactor);\n" +
            "    vec3 color = mix(vec3(0.02, 0.02, 0.05), uFogColor, fogFactor);\n" +
            "    color += n * 0.05 * fogFactor;\n" +
            "    fragColor = vec4(color, 1.0 - fogFactor * 0.5);\n" +
            "}";

        // God rays shader
        String godRayVert = fogVert;

        String godRayFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform vec3 uLightDir;\n" +
            "uniform float uTime;\n" +
            "uniform vec2 uResolution;\n" +
            "uniform int uNumRays;\n" +
            "uniform float uRayAngles[8];\n" +
            "uniform float uRayIntensities[8];\n" +
            "float hash(float n) {\n" +
            "    return fract(sin(n) * 43758.5453);\n" +
            "}\n" +
            "void main() {\n" +
            "    vec2 uv = vTexCoord;\n" +
            "    vec2 center = vec2(0.5, 0.6);\n" +
            "    vec2 delta = uv - center;\n" +
            "    float angle = atan(delta.y, delta.x);\n" +
            "    float dist = length(delta);\n" +
            "    float raySum = 0.0;\n" +
            "    for (int i = 0; i < 8; i++) {\n" +
            "        if (i >= uNumRays) break;\n" +
            "        float rayAngle = uRayAngles[i];\n" +
            "        float angleDiff = abs(mod(angle - rayAngle + 3.14159, 6.28318) - 3.14159);\n" +
            "        float rayFactor = exp(-angleDiff * angleDiff * 50.0);\n" +
            "        float rayDist = exp(-dist * 2.0);\n" +
            "        float flicker = 0.8 + 0.2 * sin(uTime * 3.0 + hash(float(i)) * 6.28);\n" +
            "        raySum += rayFactor * rayDist * uRayIntensities[i] * flicker;\n" +
            "    }\n" +
            "    vec3 rayColor = vec3(1.0, 0.9, 0.7);\n" +
            "    fragColor = vec4(rayColor * raySum * 0.3, raySum * 0.5);\n" +
            "}";

        // Composite shader
        String compositeVert = fogVert;

        String compositeFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uScene;\n" +
            "uniform sampler2D uAtmosphere;\n" +
            "uniform float uBlend;\n" +
            "void main() {\n" +
            "    vec4 scene = texture(uScene, vTexCoord);\n" +
            "    vec4 atmosphere = texture(uAtmosphere, vTexCoord);\n" +
            "    fragColor = mix(scene, atmosphere, uBlend * atmosphere.a);\n" +
            "}";

        fogProgram = createShaderProgram(fogVert, fogFrag);
        godRayProgram = createShaderProgram(godRayVert, godRayFrag);
        compositeProgram = createShaderProgram(compositeVert, compositeFrag);

        // Get uniforms
        fogColorLoc = glGetUniformLocation(fogProgram, "uFogColor");
        fogDensityLoc = glGetUniformLocation(fogProgram, "uFogDensity");
        cameraPosLoc = glGetUniformLocation(fogProgram, "uCameraPos");
        timeLoc = glGetUniformLocation(fogProgram, "uTime");
        noiseScaleLoc = glGetUniformLocation(fogProgram, "uNoiseScale");

        // Setup arrays
        glUseProgram(godRayProgram);
        int rayAnglesLoc = glGetUniformLocation(godRayProgram, "uRayAngles");
        int rayIntensitiesLoc = glGetUniformLocation(godRayProgram, "uRayIntensities");
        glUniform1iv(rayAnglesLoc, rayAngles);
        glUniform1fv(rayIntensitiesLoc, rayIntensities);
    }

    private int createShaderProgram(String vertSrc, String fragSrc) {
        int vert = compileShader(GL_VERTEX_SHADER, vertSrc);
        int frag = compileShader(GL_FRAGMENT_SHADER, fragSrc);

        int program = glCreateProgram();
        glAttachShader(program, vert);
        glAttachShader(program, frag);
        glLinkProgram(program);

        if (glGetProgrami(program, GL_LINK_STATUS) == GL_FALSE) {
            System.err.println("[Atmosphere] Program link error: " + glGetProgramInfoLog(program));
        }

        glDeleteShader(vert);
        glDeleteShader(frag);

        return program;
    }

    private int compileShader(int type, String source) {
        int shader = glCreateShader(type);
        glShaderSource(shader, source);
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
            System.err.println("[Atmosphere] Shader compile error: " + glGetShaderInfoLog(shader));
            glDeleteShader(shader);
            return 0;
        }

        return shader;
    }

    private void initializeBuffers() {
        float[] vertices = {
            -1.0f,  1.0f,   0.0f, 1.0f,
            -1.0f, -1.0f,   0.0f, 0.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
            -1.0f,  1.0f,   0.0f, 1.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
             1.0f,  1.0f,   1.0f, 1.0f
        };

        quadVao = glGenVertexArrays();
        quadVbo = glGenBuffers();

        glBindVertexArray(quadVao);
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo);
        glBufferData(GL_ARRAY_BUFFER, vertices, GL_STATIC_DRAW);

        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * 4, 0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * 4, 2 * 4);

        glBindVertexArray(0);
    }

    private void initializeNoiseTexture() {
        noiseTexture = glGenTextures();
        glBindTexture(GL_TEXTURE_2D, noiseTexture);

        // Generate 256x256 noise
        byte[] data = new byte[256 * 256 * 4];
        java.util.Random random = new java.util.Random(12345);
        for (int i = 0; i < data.length; i++) {
            data[i] = (byte) (random.nextFloat() * 255);
        }

        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDER
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Render atmospheric fog pass.
     */
    public void renderAtmosphere(int outputFBO, int width, int height, int sceneTexture) {
        if (!initialized) {
            initialize();
        }

        // Store state
        int prevFBO = glGetInteger(GL_FRAMEBUFFER_BINDING);
        int prevViewport[] = new int[4];
        glGetIntegerv(GL_VIEWPORT, prevViewport);
        boolean prevBlend = glIsEnabled(GL_BLEND);

        // Update time
        time += 0.016f;

        glBindFramebuffer(GL_FRAMEBUFFER, outputFBO);
        glViewport(0, 0, width, height);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        // Draw fog
        glUseProgram(fogProgram);
        glBindVertexArray(quadVao);

        glUniform3f(fogColorLoc, fogColor.x, fogColor.y, fogColor.z);
        glUniform1f(fogDensityLoc, fogDensity);
        glUniform3f(cameraPosLoc, 0.0f, 0.0f, 0.0f);
        glUniform1f(timeLoc, time);
        glUniform1f(noiseScaleLoc, 4.0f);
        glUniform1f(glGetUniformLocation(fogProgram, "uAspectRatio"), (float) width / height);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, noiseTexture);
        glUniform1i(glGetUniformLocation(fogProgram, "uNoiseTexture"), 0);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Draw god rays
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE);

        glUseProgram(godRayProgram);
        glUniform3f(glGetUniformLocation(godRayProgram, "uLightDir"),
                   lightDir.x, lightDir.y, lightDir.z);
        glUniform1f(glGetUniformLocation(godRayProgram, "uTime"), time);
        glUniform2f(glGetUniformLocation(godRayProgram, "uResolution"), width, height);
        glUniform1i(glGetUniformLocation(godRayProgram, "uNumRays"), NUM_RAYS);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        // Restore state
        glBindVertexArray(0);
        glBindFramebuffer(GL_FRAMEBUFFER, prevFBO);
        glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);

        if (!prevBlend) {
            glDisable(GL_BLEND);
        }
    }

    /**
     * Composite atmosphere with scene.
     */
    public void composite(int outputFBO, int width, int height,
                          int sceneTexture, int atmosphereTexture) {
        int prevFBO = glGetInteger(GL_FRAMEBUFFER_BINDING);

        glBindFramebuffer(GL_FRAMEBUFFER, outputFBO);
        glViewport(0, 0, width, height);
        glDisable(GL_BLEND);

        glUseProgram(compositeProgram);
        glBindVertexArray(quadVao);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sceneTexture);
        glUniform1i(glGetUniformLocation(compositeProgram, "uScene"), 0);

        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, atmosphereTexture);
        glUniform1i(glGetUniformLocation(compositeProgram, "uAtmosphere"), 1);

        glUniform1f(glGetUniformLocation(compositeProgram, "uBlend"), 0.7f);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindVertexArray(0);
        glBindFramebuffer(GL_FRAMEBUFFER, prevFBO);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SETTINGS
    // ═══════════════════════════════════════════════════════════════════════

    public void setFogDensity(float density) {
        this.fogDensity = density;
    }

    public void setFogColor(float r, float g, float b) {
        this.fogColor.set(r, g, b);
    }

    public void setLightDirection(float x, float y, float z) {
        this.lightDir.set(x, y, z).normalize();
    }

    public void setRayIntensity(int rayIndex, float intensity) {
        if (rayIndex >= 0 && rayIndex < NUM_RAYS) {
            this.rayIntensities[rayIndex] = intensity;
        }
    }

    /**
     * Update ray angles for animated god rays.
     */
    public void updateRayAngles(float deltaTime) {
        for (int i = 0; i < NUM_RAYS; i++) {
            rayAngles[i] += deltaTime * 0.1f * (i % 2 == 0 ? 1 : -1);
        }

        // Update shader
        glUseProgram(godRayProgram);
        int rayAnglesLoc = glGetUniformLocation(godRayProgram, "uRayAngles");
        glUniform1iv(rayAnglesLoc, rayAngles);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CLEANUP
    // ═══════════════════════════════════════════════════════════════════════

    public void cleanup() {
        if (noiseTexture != 0) {
            glDeleteTextures(noiseTexture);
            noiseTexture = 0;
        }
        if (quadVao != 0) {
            glDeleteVertexArrays(quadVao);
            quadVao = 0;
        }
        if (quadVbo != 0) {
            glDeleteBuffers(quadVbo);
            quadVbo = 0;
        }
        if (fogProgram != 0) {
            glDeleteProgram(fogProgram);
            fogProgram = 0;
        }
        if (godRayProgram != 0) {
            glDeleteProgram(godRayProgram);
            godRayProgram = 0;
        }
        if (compositeProgram != 0) {
            glDeleteProgram(compositeProgram);
            compositeProgram = 0;
        }
        initialized = false;
    }
}
