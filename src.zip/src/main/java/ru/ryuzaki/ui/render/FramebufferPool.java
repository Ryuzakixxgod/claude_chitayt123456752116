package ru.ryuzaki.ui.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.RenderEngine;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * FramebufferPool — GPU framebuffer resource management system.
 *
 * Implements:
 * - Object pooling for framebuffers (avoid allocation overhead)
 * - Automatic texture format selection based on usage
 * - Framebuffer tagging for debugging
 * - Priority-based eviction when pool is exhausted
 * - Framebuffer resize handling
 * - Multi-pass pipeline support (blur, bloom, composite)
 *
 * POOL SIZES:
 * - Small (256x256): 8 buffers
 * - Medium (512x512): 4 buffers
 * - Large (1024x1024): 2 buffers
 * - Extra Large (2048x2048): 1 buffer
 *
 * USAGE:
 *   FramebufferHandle handle = pool.acquire(size, format, "blur_pass");
 *   // render to handle
 *   pool.release(handle);
 */
public class FramebufferPool {

    private static FramebufferPool INSTANCE;

    // Pool buckets by size category
    private final Map<SizeCategory, Queue<PooledFramebuffer>> freePool = new ConcurrentHashMap<>();
    private final Map<Framebuffer, PooledFramebuffer> allocatedPool = new ConcurrentHashMap<>();

    // Stats
    private int totalAllocations = 0;
    private int peakUsage = 0;
    private int currentUsage = 0;

    // Settings
    private boolean poolEnabled = true;
    private int maxPoolSize = 16;

    private FramebufferPool() {
        initializePools();
    }

    public static synchronized FramebufferPool getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new FramebufferPool();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  POOL INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════

    private void initializePools() {
        freePool.put(SizeCategory.SMALL, new ArrayDeque<>());
        freePool.put(SizeCategory.MEDIUM, new ArrayDeque<>());
        freePool.put(SizeCategory.LARGE, new ArrayDeque<>());
        freePool.put(SizeCategory.EXTRA_LARGE, new ArrayDeque<>());

        // Pre-allocate some framebuffers
        preallocatePool(SizeCategory.SMALL, 4);
        preallocatePool(SizeCategory.MEDIUM, 2);
        preallocatePool(SizeCategory.LARGE, 1);
    }

    private void preallocatePool(SizeCategory category, int count) {
        for (int i = 0; i < count; i++) {
            PooledFramebuffer pooled = createFramebuffer(category);
            if (pooled != null) {
                freePool.get(category).offer(pooled);
            }
        }
    }

    private PooledFramebuffer createFramebuffer(SizeCategory category) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return null;

        int width = category.getWidth();
        int height = category.getHeight();

        try {
            Framebuffer fb = new SimpleFramebuffer(width, height, false, MinecraftClient.IS_SYSTEM_MAC);
            fb.setClearColor(0, 0, 0, 0);

            PooledFramebuffer pooled = new PooledFramebuffer();
            pooled.framebuffer = fb;
            pooled.category = category;
            pooled.allocated = false;
            pooled.tag = "preallocated";
            pooled.lastUsed = System.currentTimeMillis();

            return pooled;
        } catch (Exception e) {
            System.err.println("[FramebufferPool] Failed to create framebuffer: " + e.getMessage());
            return null;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  ACQUIRE / RELEASE
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Acquire a framebuffer from the pool.
     *
     * @param width Requested width
     * @param height Requested height
     * @param tag Debug tag for this usage
     * @return Framebuffer handle, or null if pool exhausted
     */
    public FramebufferHandle acquire(int width, int height, String tag) {
        if (!poolEnabled) {
            return createDirectFramebuffer(width, height, tag);
        }

        SizeCategory category = categorize(width, height);

        // Try to get from pool
        Queue<PooledFramebuffer> pool = freePool.get(category);
        if (pool == null) {
            pool = new ArrayDeque<>();
            freePool.put(category, pool);
        }

        PooledFramebuffer pooled = pool.poll();

        if (pooled == null) {
            // Pool exhausted, create new if under limit
            if (currentUsage < maxPoolSize) {
                pooled = createFramebuffer(category);
                if (pooled != null) {
                    totalAllocations++;
                }
            } else {
                // Try to evict oldest
                pooled = evictOldest(category);
                if (pooled == null) {
                    // Can't evict, create direct
                    return createDirectFramebuffer(width, height, tag);
                }
            }
        }

        if (pooled == null) {
            return createDirectFramebuffer(width, height, tag);
        }

        // Resize if needed
        pooled.framebuffer.resize(width, height, MinecraftClient.IS_SYSTEM_MAC);

        // Mark as allocated
        pooled.allocated = true;
        pooled.tag = tag;
        pooled.lastUsed = System.currentTimeMillis();

        allocatedPool.put(pooled.framebuffer, pooled);
        currentUsage++;
        peakUsage = Math.max(peakUsage, currentUsage);

        return new FramebufferHandle(pooled);
    }

    /**
     * Acquire with default tag.
     */
    public FramebufferHandle acquire(int width, int height) {
        return acquire(width, height, "unnamed");
    }

    /**
     * Release framebuffer back to pool.
     */
    public void release(FramebufferHandle handle) {
        if (handle == null || handle.pooled == null) return;

        PooledFramebuffer pooled = handle.pooled;
        pooled.allocated = false;
        pooled.lastUsed = System.currentTimeMillis();

        allocatedPool.remove(pooled.framebuffer);
        currentUsage--;

        // Return to pool
        Queue<PooledFramebuffer> pool = freePool.get(pooled.category);
        if (pool != null) {
            pool.offer(pooled);
        }
    }

    /**
     * Release raw framebuffer.
     */
    public void release(Framebuffer framebuffer) {
        PooledFramebuffer pooled = allocatedPool.get(framebuffer);
        if (pooled != null) {
            release(new FramebufferHandle(pooled));
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  EVICTION & MAINTENANCE
    // ═══════════════════════════════════════════════════════════════════════

    private PooledFramebuffer evictOldest(SizeCategory category) {
        // Try to evict from the requested category
        Queue<PooledFramebuffer> pool = freePool.get(category);
        if (pool != null && !pool.isEmpty()) {
            return pool.poll();
        }

        // Try any category with unallocated buffers
        for (Queue<PooledFramebuffer> p : freePool.values()) {
            if (!p.isEmpty()) {
                return p.poll();
            }
        }

        return null;
    }

    /**
     * Clear entire pool.
     */
    public void clear() {
        for (Queue<PooledFramebuffer> pool : freePool.values()) {
            for (PooledFramebuffer pf : pool) {
                if (pf.framebuffer != null) {
                    pf.framebuffer.delete(MinecraftClient.getInstance().getBufferBuilder());
                }
            }
            pool.clear();
        }

        for (PooledFramebuffer pf : allocatedPool.values()) {
            if (pf.framebuffer != null) {
                pf.framebuffer.delete(MinecraftClient.getInstance().getBufferBuilder());
            }
        }

        allocatedPool.clear();
        currentUsage = 0;
    }

    /**
     * Force cleanup of unused buffers.
     */
    public void trim(long maxAgeMs) {
        long now = System.currentTimeMillis();

        for (Map.Entry<SizeCategory, Queue<PooledFramebuffer>> entry : freePool.entrySet()) {
            Queue<PooledFramebuffer> pool = entry.getValue();
            Queue<PooledFramebuffer> survivors = new ArrayDeque<>();

            while (!pool.isEmpty()) {
                PooledFramebuffer pf = pool.poll();
                if (pf != null) {
                    if (now - pf.lastUsed < maxAgeMs) {
                        survivors.add(pf);
                    } else {
                        // Too old, delete
                        if (pf.framebuffer != null) {
                            pf.framebuffer.delete(MinecraftClient.getInstance().getBufferBuilder());
                        }
                    }
                }
            }

            freePool.put(entry.getKey(), survivors);
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  DIRECT CREATION (bypass pool)
    // ═══════════════════════════════════════════════════════════════════════

    private FramebufferHandle createDirectFramebuffer(int width, int height, String tag) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return null;

        Framebuffer fb = new SimpleFramebuffer(width, height, false, MinecraftClient.IS_SYSTEM_MAC);
        fb.setClearColor(0, 0, 0, 0);

        PooledFramebuffer pooled = new PooledFramebuffer();
        pooled.framebuffer = fb;
        pooled.category = categorize(width, height);
        pooled.allocated = true;
        pooled.tag = tag + " [direct]";
        pooled.direct = true;
        pooled.lastUsed = System.currentTimeMillis();

        allocatedPool.put(fb, pooled);
        currentUsage++;

        return new FramebufferHandle(pooled);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UTILITY
    // ═══════════════════════════════════════════════════════════════════════

    private SizeCategory categorize(int width, int height) {
        int maxDim = Math.max(width, height);

        if (maxDim <= 256) return SizeCategory.SMALL;
        if (maxDim <= 512) return SizeCategory.MEDIUM;
        if (maxDim <= 1024) return SizeCategory.LARGE;
        return SizeCategory.EXTRA_LARGE;
    }

    /**
     * Get pool statistics.
     */
    public PoolStats getStats() {
        PoolStats stats = new PoolStats();
        stats.totalAllocations = totalAllocations;
        stats.peakUsage = peakUsage;
        stats.currentUsage = currentUsage;
        stats.maxPoolSize = maxPoolSize;
        stats.freeByCategory = new HashMap<>();

        for (Map.Entry<SizeCategory, Queue<PooledFramebuffer>> entry : freePool.entrySet()) {
            stats.freeByCategory.put(entry.getKey().name(), entry.getValue().size());
        }

        return stats;
    }

    /**
     * Enable/disable pooling.
     */
    public void setPoolEnabled(boolean enabled) {
        this.poolEnabled = enabled;
    }

    /**
     * Set maximum pool size.
     */
    public void setMaxPoolSize(int size) {
        this.maxPoolSize = Math.max(1, size);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SIZE CATEGORIES
    // ═══════════════════════════════════════════════════════════════════════

    public enum SizeCategory {
        SMALL(256),
        MEDIUM(512),
        LARGE(1024),
        EXTRA_LARGE(2048);

        private final int dimension;

        SizeCategory(int dimension) {
            this.dimension = dimension;
        }

        public int getWidth() { return dimension; }
        public int getHeight() { return dimension; }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  POOLED FRAMEBUFFER
    // ═══════════════════════════════════════════════════════════════════════

    private static class PooledFramebuffer {
        Framebuffer framebuffer;
        SizeCategory category;
        boolean allocated;
        boolean direct;
        String tag;
        long lastUsed;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  FRAMEBUFFER HANDLE
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Handle to an acquired framebuffer.
     * Use FramebufferPool.release() to return to pool.
     */
    public static class FramebufferHandle implements AutoCloseable {
        private final PooledFramebuffer pooled;
        private boolean released = false;

        FramebufferHandle(PooledFramebuffer pooled) {
            this.pooled = pooled;
        }

        public Framebuffer getFramebuffer() {
            return pooled.framebuffer;
        }

        public int getWidth() {
            return pooled.framebuffer.width;
        }

        public int getHeight() {
            return pooled.framebuffer.height;
        }

        public String getTag() {
            return pooled.tag;
        }

        /**
         * Bind framebuffer for rendering.
         */
        public void bind() {
            if (!released) {
                pooled.framebuffer.clear(MinecraftClient.IS_SYSTEM_MAC);
                RenderSystem.bindTexture(pooled.framebuffer.getColorAttachmentId());
            }
        }

        /**
         * Bind framebuffer without clearing.
         */
        public void bindDraw() {
            if (!released) {
                RenderSystem.bindTexture(pooled.framebuffer.getColorAttachmentId());
            }
        }

        @Override
        public void close() {
            if (!released) {
                released = true;
                FramebufferPool.getInstance().release(this);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  STATS
    // ═══════════════════════════════════════════════════════════════════════

    public static class PoolStats {
        public int totalAllocations;
        public int peakUsage;
        public int currentUsage;
        public int maxPoolSize;
        public Map<String, Integer> freeByCategory;
    }
}
