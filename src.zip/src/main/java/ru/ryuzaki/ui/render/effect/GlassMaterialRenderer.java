package ru.ryuzaki.ui.render.effect;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.*;
import org.joml.Matrix4f;
import org.joml.Vector4f;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * GlassMaterialRenderer — glass material with refraction and reflection.
 *
 * Implements physically-based glass material for UI panels:
 * - Real-time refraction using screen-space UV distortion
 * - Fresnel-based reflection intensity
 * - Chromatic aberration at edges
 * - Blur through glass (frosted glass effect)
 * - Animated surface distortion
 * - Multiple reflection bounces
 *
 * Visual features:
 * - Frosted/etched glass option
 * - Iridescent edge highlights
 * - Caustic-like light patterns
 * - Depth-based refraction intensity
 * - Edge glow based on view angle
 *
 * This makes UI panels look like floating glass surfaces
 * with realistic light interaction.
 */
public class GlassMaterialRenderer {

    private static GlassMaterialRenderer INSTANCE;

    // Shader programs
    private int glassProgram;
    private int refractionProgram;
    private int frostedGlassProgram;
    private int compositeProgram;

    // Uniforms
    private int sceneTextureLoc;
    private int depthTextureLoc;
    private int normalTextureLoc;
    private int timeLoc;
    private int viewAngleLoc;
    private int distortionStrengthLoc;
    private int fresnelPowerLoc;
    private int frostedAmountLoc;
    private int chromaticAberrationLoc;

    // Vertex buffer
    private int quadVao;
    private int quadVbo;

    // Chromatic aberration offsets per channel
    private static final float CA_OFFSET = 0.003f;

    // State
    private boolean initialized = false;
    private float time = 0.0f;
    private float currentViewAngle = 0.0f;

    // Settings
    private GlassSettings settings = new GlassSettings();

    private GlassMaterialRenderer() {}

    public static synchronized GlassMaterialRenderer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new GlassMaterialRenderer();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════

    public void initialize() {
        if (initialized) return;

        initializeShaders();
        initializeBuffers();

        initialized = true;
    }

    private void initializeShaders() {
        // Main glass shader with fresnel
        String glassVert = "#version 330 core\n" +
            "layout(location = 0) in vec2 aPosition;\n" +
            "layout(location = 1) in vec2 aTexCoord;\n" +
            "out vec2 vTexCoord;\n" +
            "out vec2 vPosition;\n" +
            "out vec3 vViewDir;\n" +
            "uniform vec3 uViewPos;\n" +
            "uniform mat4 uInverseViewProjection;\n" +
            "void main() {\n" +
            "    gl_Position = vec4(aPosition, 0.0, 1.0);\n" +
            "    vTexCoord = aTexCoord;\n" +
            "    vPosition = aPosition;\n" +
            "    vec4 clipPos = vec4(aPosition, 1.0, 1.0);\n" +
            "    vec4 worldPos = uInverseViewProjection * clipPos;\n" +
            "    vViewDir = normalize(uViewPos - worldPos.xyz / worldPos.w);\n" +
            "}";

        String glassFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "in vec2 vPosition;\n" +
            "in vec3 vViewDir;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uSceneTexture;\n" +
            "uniform sampler2D uDepthTexture;\n" +
            "uniform float uTime;\n" +
            "uniform float uViewAngle;\n" +
            "uniform float uDistortion;\n" +
            "uniform float uFresnelPower;\n" +
            "uniform float uChromaticAberration;\n" +
            "uniform float uFrosted;\n" +
            "uniform vec2 uResolution;\n" +
            "float hash(vec2 p) {\n" +
            "    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n" +
            "}\n" +
            "float noise(vec2 p) {\n" +
            "    vec2 i = floor(p);\n" +
            "    vec2 f = fract(p);\n" +
            "    f = f * f * (3.0 - 2.0 * f);\n" +
            "    return mix(mix(hash(i), hash(i + vec2(1,0)), f.x),\n" +
            "               mix(hash(i + vec2(0,1)), hash(i + vec2(1,1)), f.x), f.y);\n" +
            "}\n" +
            "void main() {\n" +
            "    vec2 uv = vTexCoord;\n" +
            "    vec2 screenUV = vPosition * 0.5 + 0.5;\n" +
            "    float depth = texture(uDepthTexture, screenUV).r;\n" +
            "    vec3 viewDir = normalize(vViewDir);\n" +
            "    vec3 normal = vec3(0.0, 0.0, 1.0);\n" +
            "    float fresnel = pow(1.0 - max(dot(normal, viewDir), 0.0), uFresnelPower);\n" +
            "    vec2 distortion = vec2(0.0);\n" +
            "    if (uDistortion > 0.0) {\n" +
            "        float n1 = noise(uv * 20.0 + uTime * 0.5);\n" +
            "        float n2 = noise(uv * 30.0 - uTime * 0.3);\n" +
            "        distortion = vec2(n1 - 0.5, n2 - 0.5) * uDistortion;\n" +
            "        distortion *= (1.0 + fresnel * 2.0);\n" +
            "    }\n" +
            "    float ca = uChromaticAberration;\n" +
            "    vec2 uvR = screenUV + distortion + vec2(ca, 0.0);\n" +
            "    vec2 uvG = screenUV + distortion;\n" +
            "    vec2 uvB = screenUV + distortion - vec2(ca, 0.0);\n" +
            "    float r = texture(uSceneTexture, uvR).r;\n" +
            "    float g = texture(uSceneTexture, uvG).g;\n" +
            "    float b = texture(uSceneTexture, uvB).b;\n" +
            "    vec3 refracted = vec3(r, g, b);\n" +
            "    if (uFrosted > 0.0) {\n" +
            "        float blur = uFrosted * 0.01;\n" +
            "        float blurR = 0.0;\n" +
            "        float blurG = 0.0;\n" +
            "        float blurB = 0.0;\n" +
            "        for (int x = -2; x <= 2; x++) {\n" +
            "            for (int y = -2; y <= 2; y++) {\n" +
            "                vec2 offset = vec2(float(x), float(y)) * blur;\n" +
            "                float w = 1.0 / (1.0 + length(vec2(x, y)));\n" +
            "                blurR += texture(uSceneTexture, uvR + offset).r * w;\n" +
            "                blurG += texture(uSceneTexture, uvG + offset).g * w;\n" +
            "                blurB += texture(uSceneTexture, uvB + offset).b * w;\n" +
            "            }\n" +
            "        }\n" +
            "        blurR /= 25.0;\n" +
            "        blurG /= 25.0;\n" +
            "        blurB /= 25.0;\n" +
            "        refracted = vec3(blurR, blurG, blurB);\n" +
            "    }\n" +
            "    vec3 reflectionColor = vec3(0.95, 0.98, 1.0);\n" +
            "    vec3 glassColor = vec3(0.9, 0.95, 1.0);\n" +
            "    vec3 color = mix(refracted * glassColor, reflectionColor, fresnel * 0.5);\n" +
            "    color += vec3(0.1, 0.15, 0.2) * fresnel;\n" +
            "    float alpha = 0.85 + fresnel * 0.15;\n" +
            "    fragColor = vec4(color, alpha);\n" +
            "}";

        // Frosted glass shader
        String frostedFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "in vec2 vPosition;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uSceneTexture;\n" +
            "uniform float uTime;\n" +
            "uniform float uFrostedAmount;\n" +
            "uniform vec2 uResolution;\n" +
            "float noise(vec2 p) {\n" +
            "    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n" +
            "}\n" +
            "void main() {\n" +
            "    vec2 uv = vPosition * 0.5 + 0.5;\n" +
            "    float strength = uFrostedAmount * 0.02;\n" +
            "    vec2 offset = vec2(0.0);\n" +
            "    for (int i = 0; i < 8; i++) {\n" +
            "        float fi = float(i);\n" +
            "        vec2 noiseOffset = vec2(\n" +
            "            noise(uv * 100.0 + fi + uTime * 0.1),\n" +
            "            noise(uv * 100.0 - fi + uTime * 0.15)\n" +
            "        );\n" +
            "        offset += (noiseOffset - 0.5) * strength;\n" +
            "    }\n" +
            "    vec3 color = texture(uSceneTexture, uv + offset).rgb;\n" +
            "    color = mix(color, vec3(0.95, 0.97, 1.0), uFrostedAmount * 0.3);\n" +
            "    fragColor = vec4(color, 0.9);\n" +
            "}";

        // Refraction shader
        String refractFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "in vec2 vPosition;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uSceneTexture;\n" +
            "uniform float uIOR;\n" +
            "uniform vec2 uResolution;\n" +
            "void main() {\n" +
            "    vec2 uv = vPosition * 0.5 + 0.5;\n" +
            "    vec2 center = vec2(0.5, 0.5);\n" +
            "    float dist = length(uv - center);\n" +
            "    float distortion = dist * dist * (uIOR - 1.0) * 0.1;\n" +
            "    vec2 refractedUV = uv + normalize(center - uv) * distortion;\n" +
            "    vec3 color = texture(uSceneTexture, refractedUV).rgb;\n" +
            "    fragColor = vec4(color, 1.0);\n" +
            "}";

        // Composite shader
        String compositeVert = "#version 330 core\n" +
            "layout(location = 0) in vec2 aPosition;\n" +
            "layout(location = 1) in vec2 aTexCoord;\n" +
            "out vec2 vTexCoord;\n" +
            "void main() {\n" +
            "    gl_Position = vec4(aPosition, 0.0, 1.0);\n" +
            "    vTexCoord = aTexCoord;\n" +
            "}";

        String compositeFrag = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uBackground;\n" +
            "uniform sampler2D uGlass;\n" +
            "uniform float uOpacity;\n" +
            "void main() {\n" +
            "    vec4 bg = texture(uBackground, vTexCoord);\n" +
            "    vec4 glass = texture(uGlass, vTexCoord);\n" +
            "    vec3 color = mix(bg.rgb, glass.rgb, glass.a * uOpacity);\n" +
            "    fragColor = vec4(color, max(bg.a, glass.a));\n" +
            "}";

        glassProgram = createShaderProgram(glassVert, glassFrag);
        frostedGlassProgram = createShaderProgram(glassVert, frostedFrag);
        refractionProgram = createShaderProgram(glassVert, refractFrag);
        compositeProgram = createShaderProgram(compositeVert, compositeFrag);

        // Get uniform locations
        sceneTextureLoc = glGetUniformLocation(glassProgram, "uSceneTexture");
        depthTextureLoc = glGetUniformLocation(glassProgram, "uDepthTexture");
        timeLoc = glGetUniformLocation(glassProgram, "uTime");
        viewAngleLoc = glGetUniformLocation(glassProgram, "uViewAngle");
        distortionStrengthLoc = glGetUniformLocation(glassProgram, "uDistortion");
        fresnelPowerLoc = glGetUniformLocation(glassProgram, "uFresnelPower");
        frostedAmountLoc = glGetUniformLocation(glassProgram, "uFrosted");
        chromaticAberrationLoc = glGetUniformLocation(glassProgram, "uChromaticAberration");
    }

    private int createShaderProgram(String vertSrc, String fragSrc) {
        int vert = compileShader(GL_VERTEX_SHADER, vertSrc);
        int frag = compileShader(GL_FRAGMENT_SHADER, fragSrc);

        int program = glCreateProgram();
        glAttachShader(program, vert);
        glAttachShader(program, frag);
        glLinkProgram(program);

        if (glGetProgrami(program, GL_LINK_STATUS) == GL_FALSE) {
            System.err.println("[GlassRenderer] Program link error: " + glGetProgramInfoLog(program));
        }

        glDeleteShader(vert);
        glDeleteShader(frag);

        return program;
    }

    private int compileShader(int type, String source) {
        int shader = glCreateShader(type);
        glShaderSource(shader, source);
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
            System.err.println("[GlassRenderer] Shader compile error: " + glGetShaderInfoLog(shader));
            glDeleteShader(shader);
            return 0;
        }

        return shader;
    }

    private void initializeBuffers() {
        float[] vertices = {
            -1.0f,  1.0f,   0.0f, 1.0f,
            -1.0f, -1.0f,   0.0f, 0.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
            -1.0f,  1.0f,   0.0f, 1.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
             1.0f,  1.0f,   1.0f, 1.0f
        };

        quadVao = glGenVertexArrays();
        quadVbo = glGenBuffers();

        glBindVertexArray(quadVao);
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo);
        glBufferData(GL_ARRAY_BUFFER, vertices, GL_STATIC_DRAW);

        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * 4, 0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * 4, 2 * 4);

        glBindVertexArray(0);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDER
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Render glass material with refraction.
     */
    public void renderGlass(int outputFBO, int width, int height,
                           int sceneTexture, int depthTexture,
                           float viewAngle) {
        if (!initialized) {
            initialize();
        }

        time += 0.016f;
        currentViewAngle = viewAngle;

        int prevFBO = glGetInteger(GL_FRAMEBUFFER_BINDING);
        int prevViewport[] = new int[4];
        glGetIntegerv(GL_VIEWPORT, prevViewport);

        glBindFramebuffer(GL_FRAMEBUFFER, outputFBO);
        glViewport(0, 0, width, height);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glUseProgram(glassProgram);
        glBindVertexArray(quadVao);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sceneTexture);
        glUniform1i(sceneTextureLoc, 0);

        glActiveTexture(GL_TEXTURE1);
        glBindTexture(GL_TEXTURE_2D, depthTexture);
        glUniform1i(depthTextureLoc, 1);

        glUniform1f(timeLoc, time);
        glUniform1f(viewAngleLoc, viewAngle);
        glUniform1f(distortionStrengthLoc, settings.distortion);
        glUniform1f(fresnelPowerLoc, settings.fresnelPower);
        glUniform1f(frostedAmountLoc, settings.frostedAmount);
        glUniform1f(chromaticAberrationLoc, settings.chromaticAberration);
        glUniform2f(glGetUniformLocation(glassProgram, "uResolution"), width, height);
        glUniform3f(glGetUniformLocation(glassProgram, "uViewPos"), 0, 0, 5);
        glUniformMatrix4fv(glGetUniformLocation(glassProgram, "uInverseViewProjection"),
                          false, new float[]{1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1});

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindVertexArray(0);
        glBindFramebuffer(GL_FRAMEBUFFER, prevFBO);
        glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
    }

    /**
     * Render frosted glass effect.
     */
    public void renderFrostedGlass(int outputFBO, int width, int height,
                                  int sceneTexture) {
        if (!initialized) {
            initialize();
        }

        time += 0.016f;

        int prevFBO = glGetInteger(GL_FRAMEBUFFER_BINDING);
        int prevViewport[] = new int[4];
        glGetIntegerv(GL_VIEWPORT, prevViewport);

        glBindFramebuffer(GL_FRAMEBUFFER, outputFBO);
        glViewport(0, 0, width, height);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glUseProgram(frostedGlassProgram);
        glBindVertexArray(quadVao);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, sceneTexture);
        glUniform1i(glGetUniformLocation(frostedGlassProgram, "uSceneTexture"), 0);

        glUniform1f(glGetUniformLocation(frostedGlassProgram, "uTime"), time);
        glUniform1f(glGetUniformLocation(frostedGlassProgram, "uFrostedAmount"), settings.frostedAmount);
        glUniform2f(glGetUniformLocation(frostedGlassProgram, "uResolution"), width, height);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindVertexArray(0);
        glBindFramebuffer(GL_FRAMEBUFFER, prevFBO);
        glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SETTINGS
    // ═══════════════════════════════════════════════════════════════════════

    public GlassSettings getSettings() {
        return settings;
    }

    public void setSettings(GlassSettings settings) {
        this.settings = settings;
    }

    public void setDistortion(float distortion) {
        this.settings.distortion = distortion;
    }

    public void setFresnelPower(float power) {
        this.settings.fresnelPower = power;
    }

    public void setFrostedAmount(float amount) {
        this.settings.frostedAmount = Math.max(0, Math.min(1, amount));
    }

    public void setChromaticAberration(float amount) {
        this.settings.chromaticAberration = amount;
    }

    /**
     * Glass material settings.
     */
    public static class GlassSettings {
        // Refraction
        public float distortion = 0.02f;
        public float ior = 1.5f;  // Index of refraction

        // Fresnel (edge reflection)
        public float fresnelPower = 2.5f;
        public float fresnelIntensity = 0.5f;

        // Visual effects
        public float frostedAmount = 0.0f;  // 0 = clear, 1 = fully frosted
        public float chromaticAberration = 0.003f;

        // Color tint
        public float tintR = 0.95f;
        public float tintG = 0.97f;
        public float tintB = 1.0f;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CLEANUP
    // ═══════════════════════════════════════════════════════════════════════

    public void cleanup() {
        if (quadVao != 0) {
            glDeleteVertexArrays(quadVao);
            quadVao = 0;
        }
        if (quadVbo != 0) {
            glDeleteBuffers(quadVbo);
            quadVbo = 0;
        }
        if (glassProgram != 0) {
            glDeleteProgram(glassProgram);
            glassProgram = 0;
        }
        if (frostedGlassProgram != 0) {
            glDeleteProgram(frostedGlassProgram);
            frostedGlassProgram = 0;
        }
        if (refractionProgram != 0) {
            glDeleteProgram(refractionProgram);
            refractionProgram = 0;
        }
        if (compositeProgram != 0) {
            glDeleteProgram(compositeProgram);
            compositeProgram = 0;
        }
        initialized = false;
    }
}
