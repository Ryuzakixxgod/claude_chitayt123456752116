package ru.ryuzaki.ui.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgram;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ColorHelper;
import ru.ryuzaki.ui.base.*;

import java.util.*;

/**
 * BackgroundAtmosphere — realtime atmospheric rendering system.
 *
 * Implements:
 * - Volumetric ambient fog
 * - Cinematic gradient fields
 * - Animated atmospheric haze
 * - Soft procedural noise
 * - Bloom clouds
 * - Subtle light diffusion
 * - Animated glow fields
 * - Ambient particle drift
 * - Ultra-soft vignette
 * - Mouse-reactive lighting
 *
 * Background "breathes" — extremely subtle animation creates:
 * - Living depth
 * - Atmospheric immersion
 * - Physical lighting feel
 *
 * DEPTH LAYERS:
 * Layer 0: Background ambience
 * Layer 1: Fog/light diffusion
 * Layer 7: Bloom/light scattering
 */
public class BackgroundAtmosphere {

    private static BackgroundAtmosphere INSTANCE;

    // Timing
    private long startTime;
    private float time;
    private float mouseInfluenceX = 0f;
    private float mouseInfluenceY = 0f;

    // Atmospheric layers
    private float fogDensity = 0.15f;
    private float hazeIntensity = 0.08f;
    private float particleSpeed = 0.02f;
    private float vignetteStrength = 0.35f;

    // Color palette from spec
    private static final Color BG_CORE = new Color(0x050812);
    private static final Color BG_SECONDARY = new Color(0x0A1020);
    private static final Color ACCENT_PRIMARY = new Color(0x8B5CFF);
    private static final Color ACCENT_SECONDARY = new Color(0x6E7CFF);
    private static final Color BLOOM_COLOR = new Color(0x8B5CFF, 0.48f);

    // Gradient stops
    private final List<GradientStop> gradientStops = new ArrayList<>();
    private final Random noiseRandom = new Random(42);

    // Particle system
    private final List<AtmosphericParticle> particles = new ArrayList<>();
    private static final int PARTICLE_COUNT = 32;

    // Glow fields
    private final List<GlowField> glowFields = new ArrayList<>();

    private BackgroundAtmosphere() {
        this.startTime = System.currentTimeMillis();
        initGradientStops();
        initParticles();
        initGlowFields();
    }

    public static synchronized BackgroundAtmosphere getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new BackgroundAtmosphere();
        }
        return INSTANCE;
    }

    private void initGradientStops() {
        // Multi-stop gradient for atmospheric depth
        gradientStops.add(new GradientStop(0.0f, BG_CORE.toRGBA()));
        gradientStops.add(new GradientStop(0.3f, BG_SECONDARY.toRGBA()));
        gradientStops.add(new GradientStop(0.6f, new Color(0x0D1525).toRGBA()));
        gradientStops.add(new GradientStop(1.0f, BG_CORE.toRGBA()));
    }

    private void initParticles() {
        for (int i = 0; i < PARTICLE_COUNT; i++) {
            particles.add(new AtmosphericParticle(
                    noiseRandom.nextFloat(),
                    noiseRandom.nextFloat(),
                    0.3f + noiseRandom.nextFloat() * 0.7f,
                    0.002f + noiseRandom.nextFloat() * 0.003f
            ));
        }
    }

    private void initGlowFields() {
        // Primary glow field — top right
        glowFields.add(new GlowField(
                0.85f, 0.15f,
                0.4f,
                ACCENT_PRIMARY.toRGBA(),
                0.12f
        ));

        // Secondary glow field — bottom left
        glowFields.add(new GlowField(
                0.1f, 0.9f,
                0.35f,
                ACCENT_SECONDARY.toRGBA(),
                0.08f
        ));

        // Tertiary glow field — center
        glowFields.add(new GlowField(
                0.5f, 0.5f,
                0.5f,
                new Color(0x8B5CFF, 0.15f).toRGBA(),
                0.05f
        ));
    }

    /**
     * Update mouse influence for reactive lighting.
     */
    public void updateMousePosition(float x, float y, float screenWidth, float screenHeight) {
        // Normalize mouse position
        mouseInfluenceX = x / screenWidth;
        mouseInfluenceY = y / screenHeight;
    }

    /**
     * Render the full atmospheric background.
     *
     * Render order:
     * 1. Base gradient layer
     * 2. Fog/diffusion layer
     * 3. Glow fields
     * 4. Particles
     * 5. Volumetric haze
     * 6. Vignette
     */
    public void render(DrawContext context, float screenWidth, float screenHeight) {
        update();

        MatrixStack matrices = context.getMatrices();

        // Pass 1: Base gradient
        renderBaseGradient(context, matrices, screenWidth, screenHeight);

        // Pass 2: Volumetric fog/diffusion
        renderFogLayer(context, matrices, screenWidth, screenHeight);

        // Pass 3: Glow fields
        renderGlowFields(context, matrices, screenWidth, screenHeight);

        // Pass 4: Particles
        renderParticles(context, matrices, screenWidth, screenHeight);

        // Pass 5: Volumetric haze
        renderHazeLayer(context, matrices, screenWidth, screenHeight);

        // Pass 6: Vignette
        renderVignette(context, matrices, screenWidth, screenHeight);
    }

    private void update() {
        time = (System.currentTimeMillis() - startTime) / 1000.0f;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDER PASSES
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Pass 1: Base gradient layer
     */
    private void renderBaseGradient(DrawContext context, MatrixStack matrices,
                                   float width, float height) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Animated gradient shift
        float breathPhase = (float) Math.sin(time * 0.15) * 0.5f + 0.5f;
        float shift = breathPhase * 0.05f;

        // Build gradient mesh
        int stops = gradientStops.size();
        for (int i = 0; i < stops - 1; i++) {
            GradientStop current = gradientStops.get(i);
            GradientStop next = gradientStops.get(i + 1);

            float y1 = current.position * height;
            float y2 = next.position * height;

            int color1 = shiftColorAlpha(current.color, 1.0f - (current.position + shift) * 0.3f);
            int color2 = shiftColorAlpha(next.color, 1.0f - (next.position + shift) * 0.3f);
            int color3 = shiftColorAlpha(next.color, 1.0f - (next.position + shift) * 0.3f);
            int color4 = shiftColorAlpha(current.color, 1.0f - (current.position + shift) * 0.3f);

            bufferBuilder.vertex(0, y2, 0).color(getRed(color1), getGreen(color1), getBlue(color1), getAlpha(color1));
            bufferBuilder.vertex(width, y2, 0).color(getRed(color2), getGreen(color2), getBlue(color2), getAlpha(color2));
            bufferBuilder.vertex(width, y1, 0).color(getRed(color3), getGreen(color3), getBlue(color3), getAlpha(color3));
            bufferBuilder.vertex(0, y1, 0).color(getRed(color4), getGreen(color4), getBlue(color4), getAlpha(color4));
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Pass 2: Volumetric fog / light diffusion
     */
    private void renderFogLayer(DrawContext context, MatrixStack matrices,
                                float width, float height) {
        // Soft volumetric fog using radial gradient
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Animated fog density
        float fogPhase = (float) Math.sin(time * 0.08) * 0.5f + 0.5f;
        float density = fogDensity * (0.8f + fogPhase * 0.4f);

        // Fog center follows mouse subtly
        float centerX = width * (0.5f + mouseInfluenceX * 0.1f - 0.05f);
        float centerY = height * (0.3f + mouseInfluenceY * 0.1f - 0.05f);

        // Render fog in layers
        int fogLayers = 4;
        for (int layer = fogLayers - 1; layer >= 0; layer--) {
            float layerOffset = layer * 0.25f;
            float radius = Math.max(width, height) * (1.2f + layerOffset);

            // Soft radial gradient approximation using multiple quads
            for (int i = 0; i < 8; i++) {
                float angle = (i / 8f) * (float) Math.PI * 2;
                float nextAngle = ((i + 1) / 8f) * (float) Math.PI * 2;

                float r1 = radius * 0.3f;
                float r2 = radius;

                float x1 = centerX + (float) Math.cos(angle) * r1;
                float y1 = centerY + (float) Math.sin(angle) * r1;
                float x2 = centerX + (float) Math.cos(nextAngle) * r1;
                float y2 = centerY + (float) Math.sin(nextAngle) * r1;
                float x3 = centerX + (float) Math.cos(nextAngle) * r2;
                float y3 = centerY + (float) Math.sin(nextAngle) * r2;
                float x4 = centerX + (float) Math.cos(angle) * r2;
                float y4 = centerY + (float) Math.sin(angle) * r2;

                float alpha = density * (1f - layer / (float) fogLayers) * 0.5f;
                int color = ColorHelper.getArgb((int) (alpha * 255), 13, 20, 32);

                bufferBuilder.vertex(x1, y1, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
                bufferBuilder.vertex(x2, y2, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
                bufferBuilder.vertex(x3, y3, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
                bufferBuilder.vertex(x4, y4, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            }
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Pass 3: Glow fields
     */
    private void renderGlowFields(DrawContext context, MatrixStack matrices,
                                  float width, float height) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        for (GlowField field : glowFields) {
            float animX = field.x * width + (float) Math.sin(time * 0.1f + field.x * 10) * 10;
            float animY = field.y * height + (float) Math.cos(time * 0.08f + field.y * 10) * 8;

            // Mouse influence on glow
            float mouseDist = distance(animX / width, animY / height, mouseInfluenceX, mouseInfluenceY);
            float mouseBoost = Math.max(0, 1f - mouseDist) * 0.3f;

            float intensity = field.intensity + mouseBoost;
            float radius = Math.max(width, height) * field.radius * (1f + intensity * 0.2f);

            // Soft glow using multiple layers
            int glowLayers = 5;
            for (int layer = glowLayers - 1; layer >= 0; layer--) {
                float layerRadius = radius * (1f - layer * 0.15f);
                float layerAlpha = intensity * (1f - layer / (float) glowLayers) * 0.3f;

                float x1 = animX - layerRadius;
                float y1 = animY - layerRadius;
                float x2 = animX + layerRadius;
                float y2 = animY + layerRadius;

                int color = shiftColorAlpha(field.color, layerAlpha);

                bufferBuilder.vertex(x1, y1, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
                bufferBuilder.vertex(x2, y1, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
                bufferBuilder.vertex(x2, y2, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
                bufferBuilder.vertex(x1, y2, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            }
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Pass 4: Ambient particle drift
     */
    private void renderParticles(DrawContext context, MatrixStack matrices,
                                 float width, float height) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        for (AtmosphericParticle particle : particles) {
            // Update position with drift
            particle.update(time, particleSpeed);

            float x = particle.x * width;
            float y = particle.y * height;
            float size = particle.size * 2f;

            // Subtle glow around particle
            float glowAlpha = particle.brightness * 0.4f;
            int color = ColorHelper.getArgb(
                    (int) (glowAlpha * 255),
                    (int) (139 * particle.brightness),
                    (int) (92 * particle.brightness),
                    (int) (255 * particle.brightness)
            );

            // Draw soft particle
            float halfSize = size * 0.5f;
            bufferBuilder.vertex(x - halfSize, y - halfSize, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(x + halfSize, y - halfSize, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(x + halfSize, y + halfSize, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(x - halfSize, y + halfSize, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Pass 5: Volumetric haze overlay
     */
    private void renderHazeLayer(DrawContext context, MatrixStack matrices,
                                 float width, float height) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Animated haze bands
        float hazePhase = time * 0.03f;

        for (int i = 0; i < 3; i++) {
            float bandY = ((i + hazePhase) % 3f) / 3f * height;
            float bandHeight = height * 0.15f;
            float alpha = hazeIntensity * (1f - i * 0.2f);

            int color = ColorHelper.getArgb((int) (alpha * 255), 15, 19, 32);

            bufferBuilder.vertex(0, bandY + bandHeight, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(width, bandY + bandHeight, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(width, bandY, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(0, bandY, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    /**
     * Pass 6: Ultra-soft vignette
     */
    private void renderVignette(DrawContext context, MatrixStack matrices,
                               float width, float height) {
        BufferBuilder bufferBuilder = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS,
                VertexFormats.POSITION_COLOR);

        // Animated vignette intensity
        float vignettePhase = (float) Math.sin(time * 0.12) * 0.5f + 0.5f;
        float intensity = vignetteStrength * (0.9f + vignettePhase * 0.2f);

        // Radial vignette using quad strips
        int segments = 12;
        float centerX = width * 0.5f;
        float centerY = height * 0.5f;
        float maxRadius = (float) Math.sqrt(width * width + height * height) * 0.7f;

        for (int i = 0; i < segments; i++) {
            float angle1 = (i / (float) segments) * (float) Math.PI * 2;
            float angle2 = ((i + 1) / (float) segments) * (float) Math.PI * 2;

            float innerRadius = maxRadius * 0.5f;
            float outerRadius = maxRadius;

            // Inner vertices
            float x1 = centerX + (float) Math.cos(angle1) * innerRadius;
            float y1 = centerY + (float) Math.sin(angle1) * innerRadius;
            float x2 = centerX + (float) Math.cos(angle2) * innerRadius;
            float y2 = centerY + (float) Math.sin(angle2) * innerRadius;

            // Outer vertices
            float x3 = centerX + (float) Math.cos(angle2) * outerRadius;
            float y3 = centerY + (float) Math.sin(angle2) * outerRadius;
            float x4 = centerX + (float) Math.cos(angle1) * outerRadius;
            float y4 = centerY + (float) Math.sin(angle1) * outerRadius;

            int color = ColorHelper.getArgb((int) (intensity * 255), 0, 0, 0);

            bufferBuilder.vertex(x1, y1, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(x2, y2, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(x3, y3, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
            bufferBuilder.vertex(x4, y4, 0).color(getRed(color), getGreen(color), getBlue(color), getAlpha(color));
        }

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);

        BufferBuilder.drawWithGlobalPos(bufferBuilder, matrices.peek().getPositionMatrix(), 0, 0);

        RenderSystem.disableBlend();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UTILITY
    // ═══════════════════════════════════════════════════════════════════════

    private static float getRed(int color) {
        return (color >> 16 & 0xFF) / 255f;
    }

    private static float getGreen(int color) {
        return (color >> 8 & 0xFF) / 255f;
    }

    private static float getBlue(int color) {
        return (color & 0xFF) / 255f;
    }

    private static float getAlpha(int color) {
        return (color >> 24 & 0xFF) / 255f;
    }

    private static int shiftColorAlpha(int color, float alphaMultiplier) {
        int alpha = (int) ((color >> 24 & 0xFF) * alphaMultiplier);
        return (alpha << 24) | (color & 0x00FFFFFF);
    }

    private static float distance(float x1, float y1, float x2, float y2) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INNER CLASSES
    // ═══════════════════════════════════════════════════════════════════════

    private static class GradientStop {
        float position;
        int color;

        GradientStop(float position, int color) {
            this.position = position;
            this.color = color;
        }
    }

    private static class AtmosphericParticle {
        float x, y;
        float size;
        float brightness;
        float driftSpeed;
        float phase;

        AtmosphericParticle(float x, float y, float size, float driftSpeed) {
            this.x = x;
            this.y = y;
            this.size = size;
            this.driftSpeed = driftSpeed;
            this.phase = (float) Math.random() * (float) Math.PI * 2;
        }

        void update(float time, float globalSpeed) {
            // Gentle drift
            x += (float) Math.sin(time * driftSpeed + phase) * 0.0005f;
            y -= driftSpeed * 0.001f * globalSpeed * 50f;

            // Wrap around
            if (y < -0.1f) y = 1.1f;
            if (y > 1.1f) y = -0.1f;
            if (x < -0.1f) x = 1.1f;
            if (x > 1.1f) x = -0.1f;

            // Pulsing brightness
            brightness = 0.3f + (float) Math.sin(time * 0.5f + phase) * 0.3f;
        }
    }

    private static class GlowField {
        float x, y;
        float radius;
        int color;
        float intensity;

        GlowField(float x, float y, float radius, int color, float intensity) {
            this.x = x;
            this.y = y;
            this.radius = radius;
            this.color = color;
            this.intensity = intensity;
        }
    }
}
