package ru.ryuzaki.ui.render.effect;

import net.minecraft.client.MinecraftClient;

import java.util.Random;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * PostProcessRenderer — final post-processing effects.
 *
 * Effects:
 * - Vignette with configurable intensity and radius
 * - Film grain / noise
 * - Scanlines (CRT effect)
 * - Color grading (contrast, saturation, brightness)
 * - Tone mapping
 * - Color correction (temperature, tint)
 *
 * Quality features:
 * - Optimized for real-time
 * - Configurable intensity
 * - Animated grain for film-like feel
 * - Custom color LUT support (optional)
 * - Dithering to reduce banding
 *
 * Applied as the final pass before display.
 */
public class PostProcessRenderer {

    private static PostProcessRenderer INSTANCE;

    // Shader program
    private int postProcessProgram;
    private int quadVao;
    private int quadVbo;

    // Uniforms
    private int inputTextureLoc;
    private int timeLoc;
    private int resolutionLoc;
    private int vignetteIntensityLoc;
    private int vignetteRadiusLoc;
    private int grainIntensityLoc;
    private int scanlineIntensityLoc;
    private int contrastLoc;
    private int saturationLoc;
    private int brightnessLoc;
    private int temperatureLoc;
    private int tintRLoc;
    private int tintGLoc;

    // State
    private boolean initialized = false;
    private float time = 0.0f;
    private Random random = new Random();

    // Settings
    private float vignetteIntensity = 0.3f;
    private float vignetteRadius = 0.8f;
    private float grainIntensity = 0.02f;
    private float scanlineIntensity = 0.0f;
    private float contrast = 1.0f;
    private float saturation = 1.0f;
    private float brightness = 0.0f;
    private float temperature = 0.0f;
    private float tintR = 1.0f;
    private float tintG = 1.0f;

    private PostProcessRenderer() {}

    public static synchronized PostProcessRenderer getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new PostProcessRenderer();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INITIALIZATION
    // ═══════════════════════════════════════════════════════════════════════

    public void initialize() {
        if (initialized) return;

        initializeShaders();
        initializeBuffers();

        initialized = true;
    }

    private void initializeShaders() {
        String vertexShader = "#version 330 core\n" +
            "layout(location = 0) in vec2 aPosition;\n" +
            "layout(location = 1) in vec2 aTexCoord;\n" +
            "out vec2 vTexCoord;\n" +
            "void main() {\n" +
            "    gl_Position = vec4(aPosition, 0.0, 1.0);\n" +
            "    vTexCoord = aTexCoord;\n" +
            "}";

        String fragmentShader = "#version 330 core\n" +
            "precision highp float;\n" +
            "in vec2 vTexCoord;\n" +
            "out vec4 fragColor;\n" +
            "uniform sampler2D uInputTexture;\n" +
            "uniform float uTime;\n" +
            "uniform vec2 uResolution;\n" +
            "uniform float uVignetteIntensity;\n" +
            "uniform float uVignetteRadius;\n" +
            "uniform float uGrainIntensity;\n" +
            "uniform float uScanlineIntensity;\n" +
            "uniform float uContrast;\n" +
            "uniform float uSaturation;\n" +
            "uniform float uBrightness;\n" +
            "uniform float uTemperature;\n" +
            "uniform float uTintR;\n" +
            "uniform float uTintG;\n" +
            "float hash(vec2 p) {\n" +
            "    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);\n" +
            "}\n" +
            "float noise(vec2 p) {\n" +
            "    vec2 i = floor(p);\n" +
            "    vec2 f = fract(p);\n" +
            "    f = f * f * (3.0 - 2.0 * f);\n" +
            "    float a = hash(i);\n" +
            "    float b = hash(i + vec2(1.0, 0.0));\n" +
            "    float c = hash(i + vec2(0.0, 1.0));\n" +
            "    float d = hash(i + vec2(1.0, 1.0));\n" +
            "    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);\n" +
            "}\n" +
            "vec3 rgb2hsv(vec3 c) {\n" +
            "    vec4 K = vec4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);\n" +
            "    vec4 p = mix(vec4(c.bg, K.wz), vec4(c.gb, K.xy), step(c.b, c.g));\n" +
            "    vec4 q = mix(vec4(p.xyw, c.r), vec4(c.r, p.yzx), step(p.x, c.r));\n" +
            "    float d = q.x - min(q.w, q.y);\n" +
            "    float e = 1.0e-10;\n" +
            "    return vec3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);\n" +
            "}\n" +
            "vec3 hsv2rgb(vec3 c) {\n" +
            "    vec4 K = vec4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);\n" +
            "    vec3 p = abs(fract(c.xxx + K.xyz) * 6.0 - K.www);\n" +
            "    return c.z * mix(K.xxx, clamp(p - K.xxx, 0.0, 1.0), c.y);\n" +
            "}\n" +
            "vec3 applyTemperature(vec3 color, float temp) {\n" +
            "    vec3 warm = vec3(1.0, 0.9, 0.7);\n" +
            "    vec3 cool = vec3(0.7, 0.9, 1.0);\n" +
            "    vec3 blend = mix(cool, warm, temp * 0.5 + 0.5);\n" +
            "    return color * blend;\n" +
            "}\n" +
            "void main() {\n" +
            "    vec2 uv = vTexCoord;\n" +
            "    vec3 color = texture(uInputTexture, uv).rgb;\n" +
            "    // Contrast\n" +
            "    color = (color - 0.5) * uContrast + 0.5;\n" +
            "    // Brightness\n" +
            "    color += uBrightness;\n" +
            "    // Saturation\n" +
            "    vec3 hsv = rgb2hsv(color);\n" +
            "    hsv.y *= uSaturation;\n" +
            "    color = hsv2rgb(hsv);\n" +
            "    // Temperature\n" +
            "    color = applyTemperature(color, uTemperature);\n" +
            "    // Tint\n" +
            "    color.r *= uTintR;\n" +
            "    color.g *= uTintG;\n" +
            "    // Vignette\n" +
            "    if (uVignetteIntensity > 0.0) {\n" +
            "        vec2 center = uv - 0.5;\n" +
            "        float dist = length(center);\n" +
            "        float vignette = 1.0 - smoothstep(uVignetteRadius, uVignetteRadius + 0.5, dist);\n" +
            "        vignette = mix(1.0, vignette, uVignetteIntensity);\n" +
            "        color *= vignette;\n" +
            "    }\n" +
            "    // Film grain\n" +
            "    if (uGrainIntensity > 0.0) {\n" +
            "        float grain = hash(uv * uResolution + uTime * 100.0);\n" +
            "        grain = (grain - 0.5) * uGrainIntensity;\n" +
            "        color += grain;\n" +
            "    }\n" +
            "    // Scanlines\n" +
            "    if (uScanlineIntensity > 0.0) {\n" +
            "        float scanline = sin(uv.y * uResolution.y * 3.14159) * 0.5 + 0.5;\n" +
            "        scanline = pow(scanline, 1.5);\n" +
            "        color *= 1.0 - (scanline * uScanlineIntensity * 0.15);\n" +
            "    }\n" +
            "    // Clamp output\n" +
            "    color = clamp(color, 0.0, 1.0);\n" +
            "    fragColor = vec4(color, 1.0);\n" +
            "}";

        int vert = compileShader(GL_VERTEX_SHADER, vertexShader);
        int frag = compileShader(GL_FRAGMENT_SHADER, fragmentShader);

        postProcessProgram = glCreateProgram();
        glAttachShader(postProcessProgram, vert);
        glAttachShader(postProcessProgram, frag);
        glLinkProgram(postProcessProgram);

        if (glGetProgrami(postProcessProgram, GL_LINK_STATUS) == GL_FALSE) {
            System.err.println("[PostProcessRenderer] Program link error: " + glGetProgramInfoLog(postProcessProgram));
        }

        glDeleteShader(vert);
        glDeleteShader(frag);

        // Get uniform locations
        inputTextureLoc = glGetUniformLocation(postProcessProgram, "uInputTexture");
        timeLoc = glGetUniformLocation(postProcessProgram, "uTime");
        resolutionLoc = glGetUniformLocation(postProcessProgram, "uResolution");
        vignetteIntensityLoc = glGetUniformLocation(postProcessProgram, "uVignetteIntensity");
        vignetteRadiusLoc = glGetUniformLocation(postProcessProgram, "uVignetteRadius");
        grainIntensityLoc = glGetUniformLocation(postProcessProgram, "uGrainIntensity");
        scanlineIntensityLoc = glGetUniformLocation(postProcessProgram, "uScanlineIntensity");
        contrastLoc = glGetUniformLocation(postProcessProgram, "uContrast");
        saturationLoc = glGetUniformLocation(postProcessProgram, "uSaturation");
        brightnessLoc = glGetUniformLocation(postProcessProgram, "uBrightness");
        temperatureLoc = glGetUniformLocation(postProcessProgram, "uTemperature");
        tintRLoc = glGetUniformLocation(postProcessProgram, "uTintR");
        tintGLoc = glGetUniformLocation(postProcessProgram, "uTintG");
    }

    private int compileShader(int type, String source) {
        int shader = glCreateShader(type);
        glShaderSource(shader, source);
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == GL_FALSE) {
            System.err.println("[PostProcessRenderer] Shader compile error: " + glGetShaderInfoLog(shader));
            glDeleteShader(shader);
            return 0;
        }

        return shader;
    }

    private void initializeBuffers() {
        float[] vertices = {
            -1.0f,  1.0f,   0.0f, 1.0f,
            -1.0f, -1.0f,   0.0f, 0.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
            -1.0f,  1.0f,   0.0f, 1.0f,
             1.0f, -1.0f,   1.0f, 0.0f,
             1.0f,  1.0f,   1.0f, 1.0f
        };

        quadVao = glGenVertexArrays();
        quadVbo = glGenBuffers();

        glBindVertexArray(quadVao);
        glBindBuffer(GL_ARRAY_BUFFER, quadVbo);
        glBufferData(GL_ARRAY_BUFFER, vertices, GL_STATIC_DRAW);

        glEnableVertexAttribArray(0);
        glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * 4, 0);

        glEnableVertexAttribArray(1);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * 4, 2 * 4);

        glBindVertexArray(0);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDER
    // ═══════════════════════════════════════════════════════════════════════

    public void render(int fbo, int width, int height, int inputTexture) {
        if (!initialized) {
            initialize();
        }

        time += 0.016f;

        int prevFBO = glGetInteger(GL_FRAMEBUFFER_BINDING);
        int prevViewport[] = new int[4];
        glGetIntegerv(GL_VIEWPORT, prevViewport);

        glBindFramebuffer(GL_FRAMEBUFFER, fbo);
        glViewport(0, 0, width, height);
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);

        glUseProgram(postProcessProgram);
        glBindVertexArray(quadVao);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, inputTexture);
        glUniform1i(inputTextureLoc, 0);

        glUniform1f(timeLoc, time);
        glUniform2f(resolutionLoc, width, height);
        glUniform1f(vignetteIntensityLoc, vignetteIntensity);
        glUniform1f(vignetteRadiusLoc, vignetteRadius);
        glUniform1f(grainIntensityLoc, grainIntensity);
        glUniform1f(scanlineIntensityLoc, scanlineIntensity);
        glUniform1f(contrastLoc, contrast);
        glUniform1f(saturationLoc, saturation);
        glUniform1f(brightnessLoc, brightness);
        glUniform1f(temperatureLoc, temperature);
        glUniform1f(tintRLoc, tintR);
        glUniform1f(tintGLoc, tintG);

        glDrawArrays(GL_TRIANGLES, 0, 6);

        glBindVertexArray(0);
        glBindFramebuffer(GL_FRAMEBUFFER, prevFBO);
        glViewport(prevViewport[0], prevViewport[1], prevViewport[2], prevViewport[3]);
        glEnable(GL_DEPTH_TEST);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  SETTINGS
    // ═══════════════════════════════════════════════════════════════════════

    public float getVignetteIntensity() {
        return vignetteIntensity;
    }

    public void setVignetteIntensity(float intensity) {
        this.vignetteIntensity = Math.max(0, Math.min(1, intensity));
    }

    public float getVignetteRadius() {
        return vignetteRadius;
    }

    public void setVignetteRadius(float radius) {
        this.vignetteRadius = Math.max(0, Math.min(2, radius));
    }

    public float getGrainIntensity() {
        return grainIntensity;
    }

    public void setGrainIntensity(float intensity) {
        this.grainIntensity = Math.max(0, intensity);
    }

    public float getScanlineIntensity() {
        return scanlineIntensity;
    }

    public void setScanlineIntensity(float intensity) {
        this.scanlineIntensity = Math.max(0, Math.min(1, intensity));
    }

    public float getContrast() {
        return contrast;
    }

    public void setContrast(float contrast) {
        this.contrast = Math.max(0, contrast);
    }

    public float getSaturation() {
        return saturation;
    }

    public void setSaturation(float saturation) {
        this.saturation = Math.max(0, saturation);
    }

    public float getBrightness() {
        return brightness;
    }

    public void setBrightness(float brightness) {
        this.brightness = Math.max(-1, Math.min(1, brightness));
    }

    public float getTemperature() {
        return temperature;
    }

    public void setTemperature(float temperature) {
        this.temperature = Math.max(-1, Math.min(1, temperature));
    }

    public void setTint(float r, float g) {
        this.tintR = Math.max(0, r);
        this.tintG = Math.max(0, g);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PRESETS
    // ═══════════════════════════════════════════════════════════════════════

    public void applyCinematicPreset() {
        vignetteIntensity = 0.35f;
        vignetteRadius = 0.85f;
        grainIntensity = 0.015f;
        scanlineIntensity = 0.0f;
        contrast = 1.1f;
        saturation = 0.95f;
        brightness = 0.02f;
        temperature = 0.05f;
        tintR = 1.0f;
        tintG = 0.98f;
    }

    public void applyRetroPreset() {
        vignetteIntensity = 0.2f;
        vignetteRadius = 0.7f;
        grainIntensity = 0.08f;
        scanlineIntensity = 0.5f;
        contrast = 1.2f;
        saturation = 0.8f;
        brightness = -0.05f;
        temperature = 0.15f;
        tintR = 1.1f;
        tintG = 0.9f;
    }

    public void applyVibrantPreset() {
        vignetteIntensity = 0.15f;
        vignetteRadius = 0.9f;
        grainIntensity = 0.005f;
        scanlineIntensity = 0.0f;
        contrast = 1.05f;
        saturation = 1.2f;
        brightness = 0.05f;
        temperature = -0.05f;
        tintR = 0.98f;
        tintG = 1.02f;
    }

    public void applyMutedPreset() {
        vignetteIntensity = 0.25f;
        vignetteRadius = 0.8f;
        grainIntensity = 0.02f;
        scanlineIntensity = 0.0f;
        contrast = 0.95f;
        saturation = 0.7f;
        brightness = 0.0f;
        temperature = 0.0f;
        tintR = 1.0f;
        tintG = 1.0f;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CLEANUP
    // ═══════════════════════════════════════════════════════════════════════

    public void cleanup() {
        if (quadVao != 0) {
            glDeleteVertexArrays(quadVao);
            quadVao = 0;
        }
        if (quadVbo != 0) {
            glDeleteBuffers(quadVbo);
            quadVbo = 0;
        }
        if (postProcessProgram != 0) {
            glDeleteProgram(postProcessProgram);
            postProcessProgram = 0;
        }
        initialized = false;
    }
}
