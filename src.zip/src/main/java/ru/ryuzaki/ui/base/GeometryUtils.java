package ru.ryuzaki.ui.base;

import java.util.ArrayList;
import java.util.List;

/**
 * Geometry primitives and utilities — bezier curves, arcs, rounded rects, intersections.
 */
public final class GeometryUtils {

    private GeometryUtils() {}

    // ── Rounded rectangle path generation ─────────────────────────────────

    /**
     * Generate a rounded rectangle path as a list of vertices.
     * Uses cubic bezier approximations for circular corners.
     */
    public static Vec2[] roundedRectVertices(float x, float y, float w, float h,
                                              float r, int segments) {
        if (r <= 0f) {
            return new Vec2[]{
                    new Vec2(x, y), new Vec2(x + w, y),
                    new Vec2(x + w, y + h), new Vec2(x, y + h)
            };
        }

        r = Math.min(r, Math.min(w / 2f, h / 2f));
        List<Vec2> verts = new ArrayList<>(segments * 4 + 4);

        float k = 0.5522847498f; // cubic bezier circle approximation
        float kx = r * k;
        float ky = r * k;

        // Top-right corner
        verts.add(new Vec2(x + w - r, y));
        verts.add(new Vec2(x + w - r + kx, y));
        verts.add(new Vec2(x + w, y + r - ky));
        verts.add(new Vec2(x + w, y + r));

        // Bottom-right corner
        verts.add(new Vec2(x + w, y + h - r));
        verts.add(new Vec2(x + w, y + h - r + ky));
        verts.add(new Vec2(x + w - r + kx, y + h));
        verts.add(new Vec2(x + w - r, y + h));

        // Bottom-left corner
        verts.add(new Vec2(x + r, y + h));
        verts.add(new Vec2(x + r - kx, y + h));
        verts.add(new Vec2(x, y + h - r + ky));
        verts.add(new Vec2(x, y + h - r));

        // Top-left corner
        verts.add(new Vec2(x, y + r));
        verts.add(new Vec2(x, y + r - ky));
        verts.add(new Vec2(x + r - kx, y));
        verts.add(new Vec2(x + r, y));

        return verts.toArray(new Vec2[0]);
    }

    /**
     * Draw a filled rounded rectangle via a tessellator using the specified draw mode.
     * Returns vertex data as float array: [x, y, u, v, r, g, b, a] per vertex.
     */
    public static float[] roundedRectMesh(float x, float y, float w, float h,
                                          float r, int segments) {
        Vec2[] verts = roundedRectVertices(x, y, w, h, r, segments);
        int n = verts.length;
        float[] mesh = new float[n * 8]; // 8 floats per vertex
        for (int i = 0; i < n; i++) {
            mesh[i * 8 + 0] = verts[i].x;
            mesh[i * 8 + 1] = verts[i].y;
            mesh[i * 8 + 2] = verts[i].x / w; // simplified UV
            mesh[i * 8 + 3] = verts[i].y / h;
            mesh[i * 8 + 4] = 1f;
            mesh[i * 8 + 5] = 1f;
            mesh[i * 8 + 6] = 1f;
            mesh[i * 8 + 7] = 1f;
        }
        return mesh;
    }

    // ── Bezier curves ──────────────────────────────────────────────────────

    /**
     * Evaluate quadratic bezier at t ∈ [0,1].
     */
    public static Vec2 quadraticBezier(Vec2 p0, Vec2 p1, Vec2 p2, float t) {
        float mt = 1f - t;
        return new Vec2(
                mt * mt * p0.x + 2f * mt * t * p1.x + t * t * p2.x,
                mt * mt * p0.y + 2f * mt * t * p1.y + t * t * p2.y
        );
    }

    /**
     * Evaluate cubic bezier at t ∈ [0,1].
     */
    public static Vec2 cubicBezier(Vec2 p0, Vec2 p1, Vec2 p2, Vec2 p3, float t) {
        float mt = 1f - t;
        float mt2 = mt * mt;
        float t2 = t * t;
        return new Vec2(
                mt2 * mt * p0.x + 3f * mt2 * t * p1.x + 3f * mt * t2 * p2.x + t2 * t * p3.x,
                mt2 * mt * p0.y + 3f * mt2 * t * p1.y + 3f * mt * t2 * p2.y + t2 * t * p3.y
        );
    }

    /**
     * Sample a cubic bezier into N points.
     */
    public static Vec2[] sampleCubicBezier(Vec2 p0, Vec2 p1, Vec2 p2, Vec2 p3, int samples) {
        Vec2[] pts = new Vec2[samples + 1];
        for (int i = 0; i <= samples; i++) {
            pts[i] = cubicBezier(p0, p1, p2, p3, (float) i / samples);
        }
        return pts;
    }

    // ── Arc ─────────────────────────────────────────────────────────────────

    /**
     * Generate arc vertices. startAngle and endAngle in radians.
     * clockwise = true for clockwise, false for counter-clockwise.
     */
    public static Vec2[] arcVertices(float cx, float cy, float r,
                                     float startAngle, float endAngle,
                                     int segments, boolean clockwise) {
        if (!clockwise) {
            float tmp = startAngle;
            startAngle = endAngle;
            endAngle = tmp;
        }

        float sweep = normalizeAngle(endAngle - startAngle);
        if (sweep <= 0f) sweep += (float) (Math.PI * 2);

        int count = Math.max(2, (int) (segments * sweep / (Math.PI * 2)) + 1);
        Vec2[] pts = new Vec2[count];

        for (int i = 0; i < count; i++) {
            float a = startAngle + sweep * (float) i / (count - 1);
            pts[i] = new Vec2(cx + r * (float) Math.cos(a), cy + r * (float) Math.sin(a));
        }
        return pts;
    }

    private static float normalizeAngle(float a) {
        a = a % ((float) Math.PI * 2);
        if (a < 0) a += (float) (Math.PI * 2);
        return a;
    }

    // ── Segment intersection ───────────────────────────────────────────────

    /**
     * Line segment intersection. Returns intersection point or null.
     * Based on Cramer's rule.
     */
    public static Vec2 lineIntersection(Vec2 a1, Vec2 a2, Vec2 b1, Vec2 b2) {
        float dx1 = a2.x - a1.x;
        float dy1 = a2.y - a1.y;
        float dx2 = b2.x - b1.x;
        float dy2 = b2.y - b1.y;

        float denom = dx1 * dy2 - dy1 * dx2;
        if (Math.abs(denom) < 1e-9f) return null; // parallel

        float t = ((b1.x - a1.x) * dy2 - (b1.y - a1.y) * dx2) / denom;
        float u = ((b1.x - a1.x) * dy1 - (b1.y - a1.y) * dx1) / denom;

        if (t >= 0f && t <= 1f && u >= 0f && u <= 1f) {
            return new Vec2(a1.x + t * dx1, a1.y + t * dy1);
        }
        return null;
    }

    /**
     * Ray vs segment intersection.
     */
    public static Vec2 raySegmentIntersection(Vec2 origin, Vec2 dir,
                                              Vec2 s1, Vec2 s2) {
        float dx = s2.x - s1.x;
        float dy = s2.y - s1.y;
        float denom = dir.x * dy - dir.y * dx;
        if (Math.abs(denom) < 1e-9f) return null;
        float t = ((s1.x - origin.x) * dy - (s1.y - origin.y) * dx) / denom;
        float u = ((s1.x - origin.x) * dir.y - (s1.y - origin.y) * dir.x) / denom;
        if (t >= 0f && u >= 0f && u <= 1f) {
            return new Vec2(origin.x + t * dir.x, origin.y + t * dir.y);
        }
        return null;
    }

    // ── Point-in-polygon ──────────────────────────────────────────────────

    /**
     * Ray casting point-in-polygon test.
     */
    public static boolean pointInPolygon(Vec2 p, Vec2[] polygon) {
        boolean inside = false;
        int n = polygon.length;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            if (((polygon[i].y > p.y) != (polygon[j].y > p.y))
                    && (p.x < (polygon[j].x - polygon[i].x) * (p.y - polygon[i].y) / (polygon[j].y - polygon[i].y) + polygon[i].x)) {
                inside = !inside;
            }
        }
        return inside;
    }

    // ── Polygon area / centroid ────────────────────────────────────────────

    public static float polygonArea(Vec2[] polygon) {
        float area = 0f;
        int n = polygon.length;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            area += polygon[i].x * polygon[j].y;
            area -= polygon[j].x * polygon[i].y;
        }
        return Math.abs(area) * 0.5f;
    }

    public static Vec2 polygonCentroid(Vec2[] polygon) {
        float cx = 0f, cy = 0f;
        float area = 0f;
        int n = polygon.length;
        for (int i = 0, j = n - 1; i < n; j = i++) {
            float cross = polygon[j].x * polygon[i].y - polygon[i].x * polygon[j].y;
            area += cross;
            cx += (polygon[j].x + polygon[i].x) * cross;
            cy += (polygon[j].y + polygon[i].y) * cross;
        }
        area *= 0.5f;
        if (Math.abs(area) < 1e-9f) return new Vec2(0, 0);
        cx /= (6f * area);
        cy /= (6f * area);
        return new Vec2(cx, cy);
    }

    // ── Ellipse ────────────────────────────────────────────────────────────

    /**
     * Generate ellipse vertices.
     */
    public static Vec2[] ellipseVertices(float cx, float cy, float rx, float ry, int segments) {
        Vec2[] pts = new Vec2[segments];
        for (int i = 0; i < segments; i++) {
            float a = (float) (i * 2 * Math.PI / segments);
            pts[i] = new Vec2(cx + rx * (float) Math.cos(a), cy + ry * (float) Math.sin(a));
        }
        return pts;
    }

    /**
     * Check if point is inside ellipse.
     */
    public static boolean pointInEllipse(Vec2 p, float cx, float cy, float rx, float ry) {
        float dx = (p.x - cx) / rx;
        float dy = (p.y - cy) / ry;
        return dx * dx + dy * dy <= 1f;
    }

    // ── Transform helpers ─────────────────────────────────────────────────

    /**
     * Convert screen coords to local (relative to bounding box top-left).
     */
    public static Vec2 screenToLocal(Vec2 screenPos, BoundingBox local) {
        return new Vec2(screenPos.x - local.x1, screenPos.y - local.y1);
    }

    /**
     * Check if screen position is inside rotated rectangle.
     * Uses separating axis theorem.
     */
    public static boolean pointInRotatedRect(Vec2 p, BoundingBox rect, float angleDeg) {
        Vec2 center = rect.center();
        Vec2 half = rect.size().div(2f);

        Vec2 local = p.sub(center).rotateAround(0, -angleDeg * (float) Math.PI / 180f);
        return Math.abs(local.x) <= half.x && Math.abs(local.y) <= half.y;
    }
}
