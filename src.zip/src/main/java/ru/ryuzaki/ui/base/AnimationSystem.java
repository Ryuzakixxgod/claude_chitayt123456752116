package ru.ryuzaki.ui.base;

/**
 * Core animation engine — production-grade delta-time animation system.
 *
 * Features:
 * - Independent float/int/color/vec2 animation channels
 * - Spring physics (damped harmonic oscillator)
 * - Staggered animations with cascading delays
 * - Per-channel easing override
 * - RAF-style time source injection
 * - Memory-efficient pool (no allocations in hot path)
 */
public final class AnimationSystem {

    private AnimationSystem() {}

    // ── Spring physics constants ──────────────────────────────────────────────

    public static final float SPRING_DEFAULT_MASS     = 1.0f;
    public static final float SPRING_DEFAULT_STIFFNESS = 100f;
    public static final float SPRING_DEFAULT_DAMPING   = 10f;

    // ── Time source ─────────────────────────────────────────────────────────

    private static long currentTimeNanos = 0L;

    public static void setTimeSource(long nanos) {
        currentTimeNanos = nanos;
    }

    public static long currentTimeNanos() {
        return currentTimeNanos;
    }

    public static float currentTimeSeconds() {
        return currentTimeNanos / 1_000_000_000f;
    }

    // ── Easing composition ──────────────────────────────────────────────────

    /**
     * Compose two easings: apply easing1 on the result of easing0.
     * Useful for e.g. IN_BACK then OUT on the way back.
     */
    public static Easing compose(Easing first, Easing second) {
        return t -> second.apply(first.apply(t));
    }

    // ── Spring interpolation ────────────────────────────────────────────────

    /**
     * Spring state — maintains position/velocity for spring simulation.
     * Immutable-style: call step() to get new state.
     */
    public static final class Spring {
        private final float position;
        private final float velocity;

        public Spring(float position, float velocity) {
            this.position = position;
            this.velocity = velocity;
        }

        public Spring(float position) {
            this(position, 0f);
        }

        public float position() { return position; }
        public float velocity()  { return velocity; }

        public float delta(float target, float dt,
                          float stiffness, float damping, float mass) {
            float springForce  = -stiffness * (position - target);
            float dampingForce = -damping * velocity;
            float acceleration = (springForce + dampingForce) / mass;
            float newVelocity  = velocity + acceleration * dt;
            float newPosition  = position + newVelocity * dt;
            return newPosition;
        }

        /**
         * Step spring one frame toward target. Returns new Spring.
         */
        public Spring step(float target, float dt,
                          float stiffness, float damping, float mass) {
            float newVelocity  = velocity + (-stiffness * (position - target) - damping * velocity) / mass * dt;
            float newPosition  = position + newVelocity * dt;
            return new Spring(newPosition, newVelocity);
        }

        public boolean isAtRest(float target, float threshold) {
            return Math.abs(position - target) < threshold
                    && Math.abs(velocity) < threshold;
        }
    }

    /**
     * Critically-damped spring step. Returns new position.
     */
    public static float dampedSpring(float current, float target,
                                    float velocity, float dt,
                                    float stiffness, float damping) {
        float omega  = (float) Math.sqrt(stiffness);
        float zeta   = damping / (2f * omega);
        float delta  = target - current;
        float exp    = (float) Math.exp(-omega * zeta * dt);
        if (zeta < 1f) {
            // Underdamped
            float omegaD = omega * (float) Math.sqrt(1 - zeta * zeta);
            float cos   = (float) Math.cos(omegaD * dt);
            float sin   = (float) Math.sin(omegaD * dt);
            return target - exp * ((delta * omega / omegaD * sin) + (velocity + delta * zeta * omega) * cos);
        } else if (zeta == 1f) {
            // Critically damped
            return target - exp * (delta + (velocity + delta * omega) * dt);
        } else {
            // Overdamped
            float s1 = -omega * (zeta - (float) Math.sqrt(zeta * zeta - 1));
            float s2 = -omega * (zeta + (float) Math.sqrt(zeta * zeta - 1));
            float c2 = (velocity - delta * s1) / (s2 - s1);
            float c1 = delta - c2;
            return target + c1 * (float) Math.exp(s1 * dt) + c2 * (float) Math.exp(s2 * dt);
        }
    }

    public static float dampedSpring(float current, float target,
                                    float velocity, float dt) {
        return dampedSpring(current, target, velocity, dt,
                SPRING_DEFAULT_STIFFNESS, SPRING_DEFAULT_DAMPING);
    }

    public static float dampedSpringVelocity(float current, float target,
                                             float velocity, float dt,
                                             float stiffness, float damping) {
        float omega  = (float) Math.sqrt(stiffness);
        float zeta   = damping / (2f * omega);
        float delta  = target - current;
        float exp    = (float) Math.exp(-omega * zeta * dt);
        if (zeta < 1f) {
            float omegaD = omega * (float) Math.sqrt(1 - zeta * zeta);
            float cos   = (float) Math.cos(omegaD * dt);
            float sin   = (float) Math.sin(omegaD * dt);
            return exp * (velocity * cos - (delta * omega * omega / omegaD + zeta * omega * velocity) * sin);
        } else if (zeta == 1f) {
            return exp * (-delta * omega * omega * dt + velocity * (1f - omega * dt));
        } else {
            float s1 = -omega * (zeta - (float) Math.sqrt(zeta * zeta - 1));
            float s2 = -omega * (zeta + (float) Math.sqrt(zeta * zeta - 1));
            float c2 = (velocity - delta * s1) / (s2 - s1);
            float c1 = delta - c2;
            return -c1 * s1 * (float) Math.exp(s1 * dt) - c2 * s2 * (float) Math.exp(s2 * dt);
        }
    }

    // ── Stagger utility ─────────────────────────────────────────────────────

    /**
     * Calculate stagger delay for staggered animation.
     *
     * @param index       item index in stagger group
     * @param total       total items in group
     * @param delay       base delay before first item starts
     * @param interval    delay between each consecutive item
     * @param reverse     if true, last item animates first
     * @param alternate   if true, odd items reverse direction
     */
    public static float staggerDelay(int index, int total, float delay,
                                     float interval, boolean reverse, boolean alternate) {
        float normalizedIndex = reverse ? (total - 1 - index) : index;
        float stagger = normalizedIndex * interval;
        if (alternate && index % 2 == 1) {
            stagger = (total - 1 - normalizedIndex) * interval;
        }
        return delay + stagger;
    }

    /**
     * Normalized progress within a staggered item's animation.
     * Returns 0 if stagger delay hasn't elapsed yet.
     */
    public static float staggerProgress(float elapsed, int index, int total,
                                         float delay, float interval,
                                         float duration, boolean reverse, boolean alternate) {
        float itemDelay = staggerDelay(index, total, delay, interval, reverse, alternate);
        float itemElapsed = elapsed - itemDelay;
        if (itemElapsed < 0f) return 0f;
        return Math.min(1f, itemElapsed / duration);
    }

    // ── Tick-based animation state ─────────────────────────────────────────

    /**
     * Animation channel — handles float value animation via easing.
     * Zero-allocation after construction.
     */
    public static final class FloatChannel {
        private float fromValue;
        private float toValue;
        private float current;
        private float velocity;
        private float elapsed;
        private float duration;
        private Easing easing;
        private boolean active;
        private boolean spring;

        // Spring parameters
        private float springStiffness = SPRING_DEFAULT_STIFFNESS;
        private float springDamping   = SPRING_DEFAULT_DAMPING;

        public FloatChannel() {
            this(0f, 0f, Easing.OUT_QUAD, 300f);
        }

        public FloatChannel(float initial, float target, Easing easing, float duration) {
            this.fromValue = initial;
            this.toValue   = target;
            this.current   = initial;
            this.velocity  = 0f;
            this.elapsed   = 0f;
            this.duration  = duration;
            this.easing    = easing;
            this.active    = false;
            this.spring    = false;
        }

        public void target(float target, float duration, Easing easing, boolean spring) {
            this.fromValue = current;
            this.toValue   = target;
            this.elapsed   = 0f;
            this.duration  = Math.max(1f, duration);
            this.easing    = easing;
            this.spring    = spring;
            this.active    = true;
        }

        public void target(float target, float duration, Easing easing) {
            target(target, duration, easing, false);
        }

        public void targetImmediate(float target) {
            this.fromValue = target;
            this.toValue   = target;
            this.current   = target;
            this.velocity  = 0f;
            this.active    = false;
            this.spring    = false;
        }

        public void setSpringParams(float stiffness, float damping) {
            this.springStiffness = stiffness;
            this.springDamping   = damping;
        }

        public void update(float dt) {
            if (!active) return;

            elapsed += dt;
            float t = Math.min(1f, elapsed / duration);

            if (spring) {
                current = dampedSpring(current, toValue, velocity, t * duration,
                        springStiffness, springDamping);
                velocity = dampedSpringVelocity(fromValue, toValue, 0f, t * duration,
                        springStiffness, springDamping);
            } else {
                float eased = easing.apply(t);
                current = fromValue + (toValue - fromValue) * eased;
            }

            if (t >= 1f) {
                current = toValue;
                velocity = 0f;
                active = false;
            }
        }

        public float get()   { return current; }
        public float getFrom() { return fromValue; }
        public float getTo()  { return toValue; }
        public boolean isActive() { return active; }
        public float getProgress() { return Math.min(1f, elapsed / duration); }
    }

    /**
     * Color animation channel — animates ARGB with perceptual blending.
     */
    public static final class ColorChannel {
        private int fromValue;
        private int toValue;
        private int current;
        private float elapsed;
        private float duration;
        private Easing easing;
        private boolean active;

        public ColorChannel() {
            this(0xFFFFFFFF, 0xFFFFFFFF, Easing.OUT_QUAD, 300f);
        }

        public ColorChannel(int initial, int target, Easing easing, float duration) {
            this.fromValue = initial;
            this.toValue   = target;
            this.current   = target;
            this.elapsed    = 0f;
            this.duration   = duration;
            this.easing     = easing;
            this.active     = false;
        }

        public void target(int target, float duration, Easing easing) {
            this.fromValue = current;
            this.toValue   = target;
            this.elapsed   = 0f;
            this.duration  = Math.max(1f, duration);
            this.easing    = easing;
            this.active    = true;
        }

        public void targetImmediate(int target) {
            this.fromValue = target;
            this.toValue   = target;
            this.current   = target;
            this.active    = false;
        }

        public void update(float dt) {
            if (!active) return;
            elapsed += dt;
            float t = Math.min(1f, elapsed / duration);
            float eased = easing.apply(t);
            current = ColorScience.lerp(fromValue, toValue, eased);
            if (t >= 1f) {
                current = toValue;
                active = false;
            }
        }

        public int get()         { return current; }
        public int getFrom()     { return fromValue; }
        public int getTo()       { return toValue; }
        public boolean isActive() { return active; }
        public float getProgress() { return Math.min(1f, elapsed / duration); }
    }

    /**
     * Vec2 animation channel — animates x/y independently.
     */
    public static final class Vec2Channel {
        private final FloatChannel x = new FloatChannel();
        private final FloatChannel y = new FloatChannel();

        public void target(float tx, float ty, float duration, Easing easing, boolean spring) {
            x.target(tx, duration, easing, spring);
            y.target(ty, duration, easing, spring);
        }

        public void target(float tx, float ty, float duration, Easing easing) {
            target(tx, ty, duration, easing, false);
        }

        public void targetImmediate(float tx, float ty) {
            x.targetImmediate(tx);
            y.targetImmediate(ty);
        }

        public void update(float dt) {
            x.update(dt);
            y.update(dt);
        }

        public float x() { return x.get(); }
        public float y() { return y.get(); }
        public boolean isActive() { return x.isActive() || y.isActive(); }
    }

    // ── Tick accumulator ───────────────────────────────────────────────────

    private static long lastTickNanos = 0L;

    public static void setLastTick(long nanos) {
        lastTickNanos = nanos;
    }

    public static float deltaSeconds() {
        if (lastTickNanos == 0L || currentTimeNanos == 0L) return 0f;
        return Math.min((currentTimeNanos - lastTickNanos) / 1_000_000_000f, 0.1f);
    }

    /**
     * Advance time and return delta in seconds. Call once per frame.
     */
    public static float tick(long nanos) {
        float dt = 0f;
        if (lastTickNanos != 0L && nanos > lastTickNanos) {
            dt = Math.min((nanos - lastTickNanos) / 1_000_000_000f, 0.1f);
        }
        lastTickNanos = nanos;
        currentTimeNanos = nanos;
        return dt;
    }
}
