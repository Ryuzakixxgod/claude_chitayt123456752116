package ru.ryuzaki.ui.base;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.Vec2f;
import org.lwjgl.glfw.GLFW;

public final class Input {

    private static final MinecraftClient mc = MinecraftClient.getInstance();
    private static Vec2f mousePos = Vec2f.ZERO;
    private static Vec2f mouseDelta = Vec2f.ZERO;
    private static Vec2f scrollDelta = Vec2f.ZERO;
    private static long windowHandle = -1;

    private static final int KEY_COUNT = GLFW.GLFW_KEY_LAST + 1;
    private static final boolean[] keys = new boolean[KEY_COUNT];
    private static final boolean[] keysPressed = new boolean[KEY_COUNT];
    private static final boolean[] keysHeld = new boolean[KEY_COUNT];

    private static final int MB_COUNT = GLFW.GLFW_MOUSE_BUTTON_LAST + 1;
    private static final boolean[] mouse = new boolean[MB_COUNT];
    private static final boolean[] mousePressed = new boolean[MB_COUNT];
    private static final boolean[] mouseHeld = new boolean[MB_COUNT];

    public static void init() {
        windowHandle = mc.getWindow().getHandle();
        mousePos = new Vec2f((float) mc.mouse.getX(), (float) mc.mouse.getY());
    }

    public static void tick() {
        // Mouse position (screen coords, Y from top)
        double mx = mc.mouse.getX();
        double my = mc.mouse.getY();
        mouseDelta = new Vec2f((float) (mx - mousePos.x), (float) (my - mousePos.y));
        mousePos = new Vec2f((float) mx, (float) my);

        // Scroll accumulator
        scrollDelta = new Vec2f(scrollDelta.x, 0);

        // Key states
        for (int i = 0; i < KEY_COUNT; i++) {
            boolean now = InputUtil.isKeyPressed(windowHandle, i);
            keysPressed[i] = now && !keys[i];
            keysHeld[i] = now;
            keys[i] = now;
        }

        // Mouse button states
        for (int i = 0; i < MB_COUNT; i++) {
            boolean now = GLFW.glfwGetMouseButton(windowHandle, i) == GLFW.GLFW_PRESS;
            mousePressed[i] = now && !mouse[i];
            mouseHeld[i] = now;
            mouse[i] = now;
        }
    }

    // ── Mouse position ──────────────────────────────────────────────

    public static Vec2f mousePos() { return mousePos; }

    public static Vec2f mouseDelta() { return mouseDelta; }

    public static float mouseX() { return mousePos.x; }

    public static float mouseY() { return mousePos.y; }

    public static float mouseDX() { return mouseDelta.x; }

    public static float mouseDY() { return mouseDelta.y; }

    public static Vec2f scaledMousePos() {
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();
        float x = mouseX() / mc.getWindow().getWidth() * sw;
        float y = mouseY() / mc.getWindow().getHeight() * sh;
        return new Vec2f(x, y);
    }

    // ── Scroll ──────────────────────────────────────────────────────

    public static void addScroll(float dy) { scrollDelta = new Vec2f(scrollDelta.x, scrollDelta.y + dy); }

    public static float scrollY() { return scrollDelta.y; }

    public static float scrollX() { return scrollDelta.x; }

    public static boolean scrolling() { return Math.abs(scrollDelta.y) > 0.0001f; }

    // ── Keyboard ────────────────────────────────────────────────────

    public static boolean key(int keyCode) { return keyCode >= 0 && keyCode < KEY_COUNT && keys[keyCode]; }

    public static boolean keyPressed(int keyCode) { return keyCode >= 0 && keyCode < KEY_COUNT && keysPressed[keyCode]; }

    public static boolean keyHeld(int keyCode) { return keyCode >= 0 && keyCode < KEY_COUNT && keysHeld[keyCode]; }

    public static boolean key(int... codes) {
        for (int c : codes) if (key(c)) return true;
        return false;
    }

    public static boolean keyPressed(int... codes) {
        for (int c : codes) if (keyPressed(c)) return true;
        return false;
    }

    public static boolean ctrl() { return key(GLFW.GLFW_KEY_LEFT_CONTROL, GLFW.GLFW_KEY_RIGHT_CONTROL); }

    public static boolean shift() { return key(GLFW.GLFW_KEY_LEFT_SHIFT, GLFW.GLFW_KEY_RIGHT_SHIFT); }

    public static boolean alt() { return key(GLFW.GLFW_KEY_LEFT_ALT, GLFW.GLFW_KEY_RIGHT_ALT); }

    public static boolean ctrlPressed() { return keyPressed(GLFW.GLFW_KEY_LEFT_CONTROL, GLFW.GLFW_KEY_RIGHT_CONTROL); }

    public static boolean shiftPressed() { return keyPressed(GLFW.GLFW_KEY_LEFT_SHIFT, GLFW.GLFW_KEY_RIGHT_SHIFT); }

    public static boolean altPressed() { return keyPressed(GLFW.GLFW_KEY_LEFT_ALT, GLFW.GLFW_KEY_RIGHT_ALT); }

    public static boolean isTyping() {
        int code = getTypedKey();
        if (code == -1) return false;
        return (code >= 32 && code <= 96) || (code >= 256 && code <= 348);
    }

    public static int getTypedKey() {
        for (int i = 0; i < KEY_COUNT; i++) {
            if (keysPressed[i]) return i;
        }
        return -1;
    }

    // ── Mouse buttons ───────────────────────────────────────────────

    public static boolean mouse(int button) { return button >= 0 && button < MB_COUNT && mouse[button]; }

    public static boolean mousePressed(int button) { return button >= 0 && button < MB_COUNT && mousePressed[button]; }

    public static boolean mouseHeld(int button) { return button >= 0 && button < MB_COUNT && mouseHeld[button]; }

    public static boolean mouseMoved() { return Math.abs(mouseDelta.x) > 0.5f || Math.abs(mouseDelta.y) > 0.5f; }

    public static boolean scrolled() { return Math.abs(scrollDelta.y) > 0.0001f; }

    // ── Hover detection ─────────────────────────────────────────────

    public static boolean hovering(float x, float y, float w, float h) {
        Vec2f mp = scaledMousePos();
        return mp.x >= x && mp.x <= x + w && mp.y >= y && mp.y <= y + h;
    }

    public static boolean hovering(double x, double y, double w, double h) {
        return hovering((float) x, (float) y, (float) w, (float) h);
    }

    // ── Bindings ────────────────────────────────────────────────────

    public static boolean isBoundTo(int keyCode, KeyBinding binding) {
        return binding.getDefaultKey().getCode() == keyCode;
    }

    public static boolean isPressed(KeyBinding binding) { return binding.isPressed(); }

    public static boolean wasPressed(KeyBinding binding) {
        return keyPressed(binding.getDefaultKey().getCode());
    }

    // ── Key names ───────────────────────────────────────────────────

    public static String keyName(int keyCode) {
        if (keyCode < 0) return "?";
        String name = InputUtil.fromKeyCode(keyCode, -1).getLocalizedText().getString();
        return name.isEmpty() ? "Key" + keyCode : name;
    }

    public static String mouseButtonName(int button) {
        return switch (button) {
            case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "LMB";
            case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "RMB";
            case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "MMB";
            default -> "MB" + button;
        };
    }

    // ── Clipboard ───────────────────────────────────────────────────

    public static String getClipboard() {
        try { return GLFW.glfwGetClipboardString(windowHandle); } catch (Exception e) { return ""; }
    }

    public static void setClipboard(String text) {
        try { GLFW.glfwSetClipboardString(windowHandle, text); } catch (Exception ignored) {}
    }
}
