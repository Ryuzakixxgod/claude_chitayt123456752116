package ru.ryuzaki.ui.base;

/**
 * Easing functions for smooth animations.
 * All functions take t in [0, 1] and return a value in [0, 1].
 */
public final class Easing {

    private Easing() {}

    public static float linear(float t) { return t; }

    // ── Quad ──────────────────────────────────────────────────────────

    public static float easeInQuad(float t) { return t * t; }
    public static float easeOutQuad(float t) { return t * (2f - t); }
    public static float easeInOutQuad(float t) {
        return t < 0.5f ? 2f * t * t : -1f + (4f - 2f * t) * t;
    }

    // ── Cubic ─────────────────────────────────────────────────────────

    public static float easeInCubic(float t) { return t * t * t; }
    public static float easeOutCubic(float t) { return (t -= 1f) * t * t + 1f; }
    public static float easeInOutCubic(float t) {
        return t < 0.5f ? 4f * t * t * t : (t - 1f) * (2f * t - 2f) * (2f * t - 2f) + 1f;
    }

    // ── Quart ─────────────────────────────────────────────────────────

    public static float easeInQuart(float t) { return t * t * t * t; }
    public static float easeOutQuart(float t) { return 1f - (t -= 1f) * t * t * t; }
    public static float easeInOutQuart(float t) {
        return t < 0.5f ? 8f * t * t * t * t : 1f - 8f * (t -= 1f) * t * t * t;
    }

    // ── Quint ─────────────────────────────────────────────────────────

    public static float easeInQuint(float t) { return t * t * t * t * t; }
    public static float easeOutQuint(float t) { return 1f + (t -= 1f) * t * t * t * t; }
    public static float easeInOutQuint(float t) {
        return t < 0.5f ? 16f * t * t * t * t * t : 1f + 16f * (t -= 1f) * t * t * t * t;
    }

    // ── Sine ──────────────────────────────────────────────────────────

    public static float easeInSine(float t) { return 1f - (float) Math.cos(t * Math.PI * 0.5); }
    public static float easeOutSine(float t) { return (float) Math.sin(t * Math.PI * 0.5); }
    public static float easeInOutSine(float t) { return -0.5f * ((float) Math.cos(Math.PI * t) - 1f); }

    // ── Expo ───────────────────────────────────────────────────────────

    public static float easeInExpo(float t) { return t == 0f ? 0f : (float) Math.pow(2f, 10f * (t - 1f)); }
    public static float easeOutExpo(float t) { return t == 1f ? 1f : 1f - (float) Math.pow(2f, -10f * t); }
    public static float easeInOutExpo(float t) {
        if (t == 0f) return 0f;
        if (t == 1f) return 1f;
        return t < 0.5f
                ? (float) Math.pow(2f, 20f * t - 10f) * 0.5f
                : (2f - (float) Math.pow(2f, -20f * t + 10f)) * 0.5f;
    }

    // ── Circ ───────────────────────────────────────────────────────────

    public static float easeInCirc(float t) { return -((float) Math.sqrt(1f - t * t) - 1f); }
    public static float easeOutCirc(float t) { return (float) Math.sqrt(1f - (t -= 1f) * t); }
    public static float easeInOutCirc(float t) {
        return t < 0.5f
                ? -0.5f * ((float) Math.sqrt(1f - 4f * t * t) - 1f)
                : 0.5f * ((float) Math.sqrt(1f - (2f * t - 2f) * (2f * t - 2f)) + 1f);
    }

    // ── Back (overshoot) ──────────────────────────────────────────────

    public static float easeInBack(float t) {
        return (t -= 1f) * t * ((1.70158f + 1f) * t + 1.70158f) + 1f;
    }

    public static float easeOutBack(float t) {
        t = t / 1f - 1f;
        return t * t * ((1.70158f + 1f) * t + 1.70158f) + 1f;
    }

    public static float easeInOutBack(float t) {
        float s = 1.70158f * 1.525f;
        if (t < 0.5f) {
            t *= 2f;
            return 0.5f * t * t * ((s + 1f) * t - s);
        } else {
            t = t * 2f - 2f;
            return 0.5f * (t * t * ((s + 1f) * t + s) + 2f);
        }
    }

    // ── Elastic ───────────────────────────────────────────────────────

    public static float easeInElastic(float t) {
        if (t == 0f || t == 1f) return t;
        float p = 0.3f, a = 1f;
        float s = p / 4f;
        return -(a * (float) Math.pow(2f, 10f * (t -= 1f)) * (float) Math.sin((t - s) * (2f * Math.PI) / p));
    }

    public static float easeOutElastic(float t) {
        if (t == 0f || t == 1f) return t;
        float p = 0.3f, a = 1f;
        float s = p / 4f;
        return a * (float) Math.pow(2f, -10f * t) * (float) Math.sin((t - s) * (2f * Math.PI) / p) + 1f;
    }

    public static float easeInOutElastic(float t) {
        if (t == 0f || t == 1f) return t;
        float p = 0.45f, a = 1f;
        float s = p / 4f;
        return t < 0.5f
                ? -0.5f * a * (float) Math.pow(2f, 10f * (t -= 1f)) * (float) Math.sin((t - s) * (2f * Math.PI) / p)
                : a * (float) Math.pow(2f, -10f * (t -= 1f)) * (float) Math.sin((t - s) * (2f * Math.PI) / p) * 0.5f + 1f;
    }

    // ── Bounce ────────────────────────────────────────────────────────

    public static float easeOutBounce(float t) {
        if (t < 1f / 2.75f) return 7.5625f * t * t;
        if (t < 2f / 2.75f) { t -= 1.5f / 2.75f; return 7.5625f * t * t + 0.75f; }
        if (t < 2.5f / 2.75f) { t -= 2.25f / 2.75f; return 7.5625f * t * t + 0.9375f; }
        t -= 2.625f / 2.75f;
        return 7.5625f * t * t + 0.984375f;
    }

    public static float easeInBounce(float t) { return 1f - easeOutBounce(1f - t); }

    public static float easeInOutBounce(float t) {
        return t < 0.5f
                ? (1f - easeOutBounce(1f - 2f * t)) * 0.5f
                : (1f + easeOutBounce(2f * t - 1f)) * 0.5f;
    }

    // ── Spring ────────────────────────────────────────────────────────

    public static float spring(float t, float damping) {
        float omega = (float) Math.sqrt(damping);
        return (float) (1f - Math.exp(-omega * t * 6f) * Math.cos(omega * t * 20f));
    }

    // ── Utility ───────────────────────────────────────────────────────

    public static float invert(float t) { return 1f - t; }
    public static float reflect(float t) { return t < 0.5f ? t * 2f : 2f - t * 2f; }
}
