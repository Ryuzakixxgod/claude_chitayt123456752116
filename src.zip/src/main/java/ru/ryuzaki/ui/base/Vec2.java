package ru.ryuzaki.ui.base;

import java.util.Objects;

/**
 * Immutable 2D vector with float precision.
 * All mutation methods return new instances.
 */
public final class Vec2 {

    public static final Vec2 ZERO = new Vec2(0f, 0f);
    public static final Vec2 ONE = new Vec2(1f, 1f);
    public static final Vec2 NEG_ONE = new Vec2(-1f, -1f);
    public static final Vec2 LEFT = new Vec2(-1f, 0f);
    public static final Vec2 RIGHT = new Vec2(1f, 0f);
    public static final Vec2 UP = new Vec2(0f, -1f);
    public static final Vec2 DOWN = new Vec2(0f, 1f);

    public final float x, y;

    public Vec2(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public float x() { return x; }
    public float y() { return y; }
    public float r() { return x; }
    public float g() { return y; }
    public int xi() { return (int) x; }
    public int yi() { return (int) y; }

    // ── Basic math ──────────────────────────────────────────────────────

    public Vec2 add(float v) { return new Vec2(x + v, y + v); }
    public Vec2 add(Vec2 o) { return new Vec2(x + o.x, y + o.y); }
    public Vec2 add(float ox, float oy) { return new Vec2(x + ox, y + oy); }

    public Vec2 sub(float v) { return new Vec2(x - v, y - v); }
    public Vec2 sub(Vec2 o) { return new Vec2(x - o.x, y - o.y); }
    public Vec2 sub(float ox, float oy) { return new Vec2(x - ox, y - oy); }

    public Vec2 mul(float s) { return new Vec2(x * s, y * s); }
    public Vec2 mul(Vec2 o) { return new Vec2(x * o.x, y * o.y); }

    public Vec2 div(float s) {
        if (s == 0f) return new Vec2(Float.MAX_VALUE, Float.MAX_VALUE);
        return new Vec2(x / s, y / s);
    }

    public Vec2 div(Vec2 o) {
        return new Vec2(
                o.x == 0f ? Float.MAX_VALUE : x / o.x,
                o.y == 0f ? Float.MAX_VALUE : y / o.y
        );
    }

    public Vec2 neg() { return new Vec2(-x, -y); }
    public Vec2 abs() { return new Vec2(Math.abs(x), Math.abs(y)); }
    public Vec2 floor() { return new Vec2((float) Math.floor(x), (float) Math.floor(y)); }
    public Vec2 ceil() { return new Vec2((float) Math.ceil(x), (float) Math.ceil(y)); }
    public Vec2 round() { return new Vec2((float) Math.round(x), (float) Math.round(y)); }

    // ── Dot / cross ──────────────────────────────────────────────────────

    public float dot(Vec2 o) { return x * o.x + y * o.y; }
    public float cross(Vec2 o) { return x * o.y - y * o.x; }
    public float dot() { return x * x + y * y; }

    // ── Length / distance ───────────────────────────────────────────────

    public float length() { return (float) Math.sqrt(dot()); }
    public float lengthSquared() { return dot(); }
    public float lengthManhattan() { return Math.abs(x) + Math.abs(y); }

    public float dist(Vec2 o) { return sub(o).length(); }
    public float distSquared(Vec2 o) { return sub(o).lengthSquared(); }
    public float distManhattan(Vec2 o) { return sub(o).lengthManhattan(); }

    public Vec2 normalize() {
        float len = length();
        if (len < 1e-9f) return ZERO;
        return div(len);
    }

    public Vec2 limit(float max) {
        float len = length();
        if (len > max && len > 0f) return mul(max / len);
        return this;
    }

    public Vec2 clampLength(float min, float max) {
        float len = length();
        if (len < min) return normalize().mul(min);
        if (len > max) return normalize().mul(max);
        return this;
    }

    // ── Angle / rotation ────────────────────────────────────────────────

    public float angle() { return (float) Math.atan2(y, x); }
    public float angleTo(Vec2 o) { return (float) Math.atan2(o.y - y, o.x - x); }

    public Vec2 rotate(float radians) {
        float c = (float) Math.cos(radians);
        float s = (float) Math.sin(radians);
        return new Vec2(x * c - y * s, x * s + y * c);
    }

    public Vec2 rotateAround(Vec2 center, float radians) {
        return sub(center).rotate(radians).add(center);
    }

    public Vec2 rotateDegrees(float degrees) {
        return rotate((float) Math.toRadians(degrees));
    }

    public Vec2 rotateAroundDegrees(Vec2 center, float degrees) {
        return rotateAround(center, (float) Math.toRadians(degrees));
    }

    // ── Lerp / projection ───────────────────────────────────────────────

    public Vec2 lerp(Vec2 target, float t) {
        return new Vec2(
                x + (target.x - x) * t,
                y + (target.y - y) * t
        );
    }

    public Vec2 projectOnto(Vec2 onto) {
        float d = onto.dot(onto);
        if (d < 1e-9f) return ZERO;
        return onto.mul(dot(onto) / d);
    }

    public Vec2 reflect(Vec2 normal) {
        return sub(normal.mul(2f * dot(normal)));
    }

    public Vec2 perpendicular() { return new Vec2(-y, x); }

    // ── Swizzling ───────────────────────────────────────────────────────

    public Vec2 xx() { return new Vec2(x, x); }
    public Vec2 yy() { return new Vec2(y, y); }
    public Vec2 xy() { return new Vec2(x, y); }
    public Vec2 yx() { return new Vec2(y, x); }
    public Vec2 x0() { return new Vec2(x, 0f); }
    public Vec2 zeroY() { return new Vec2(0f, y); }

    // ── Comparison ──────────────────────────────────────────────────────

    public boolean fuzzyEquals(Vec2 o, float epsilon) {
        return Math.abs(x - o.x) <= epsilon && Math.abs(y - o.y) <= epsilon;
    }

    public int compareX(Vec2 o) { return Float.compare(x, o.x); }
    public int compareY(Vec2 o) { return Float.compare(y, o.y); }

    // ── Object ──────────────────────────────────────────────────────────

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Vec2 v)) return false;
        return Float.compare(v.x, x) == 0 && Float.compare(v.y, y) == 0;
    }

    @Override public int hashCode() { return Objects.hash(x, y); }

    @Override public String toString() {
        return String.format("Vec2(%.2f, %.2f)", x, y);
    }

    // ── Static factories ───────────────────────────────────────────────

    public static Vec2 fromAngle(float radians) {
        return new Vec2((float) Math.cos(radians), (float) Math.sin(radians));
    }

    public static Vec2 fromAngleDegrees(float degrees) {
        return fromAngle((float) Math.toRadians(degrees));
    }

    public static Vec2 lerp(Vec2 a, Vec2 b, float t) {
        return a.lerp(b, t);
    }

    public static Vec2 random(float range) {
        return new Vec2(
                (float) (Math.random() * 2 - 1) * range,
                (float) (Math.random() * 2 - 1) * range
        );
    }

    public static Vec2 randomUnit() {
        return fromAngle((float) (Math.random() * Math.PI * 2));
    }
}
