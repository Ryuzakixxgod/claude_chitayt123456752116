package ru.ryuzaki.ui.base;

import java.util.Objects;

/**
 * Axis-Aligned Bounding Box.
 * Uses top-left origin (standard for 2D rendering).
 * Stored as (x1, y1) = min corner, (x2, y2) = max corner.
 */
public final class BoundingBox {

    public float x1, y1, x2, y2;

    public BoundingBox() { set(0, 0, 0, 0); }

    public BoundingBox(float x1, float y1, float x2, float y2) { set(x1, y1, x2, y2); }

    public BoundingBox(Vec2 min, Vec2 max) { set(min.x, min.y, max.x, max.y); }

    public BoundingBox(Vec2 pos, Vec2 size) { set(pos.x, pos.y, pos.x + size.x, pos.y + size.y); }

    public BoundingBox(float x, float y, float w, float h) { set(x, y, x + w, y + h); }

    public void set(float x1, float y1, float x2, float y2) {
        this.x1 = x1;
        this.y1 = y1;
        this.x2 = x2;
        this.y2 = y2;
    }

    public void set(BoundingBox other) {
        this.x1 = other.x1;
        this.y1 = other.y1;
        this.x2 = other.x2;
        this.y2 = other.y2;
    }

    // ── Dimensions ──────────────────────────────────────────────────────

    public float x() { return x1; }
    public float y() { return y1; }
    public float w() { return x2 - x1; }
    public float h() { return y2 - y1; }
    public float width() { return x2 - x1; }
    public float height() { return y2 - y1; }
    public float area() { return w() * h(); }

    public Vec2 pos() { return new Vec2(x1, y1); }
    public Vec2 size() { return new Vec2(w(), h()); }
    public Vec2 center() { return new Vec2((x1 + x2) * 0.5f, (y1 + y2) * 0.5f); }
    public Vec2 min() { return pos(); }
    public Vec2 max() { return new Vec2(x2, y2); }

    public float left() { return x1; }
    public float right() { return x2; }
    public float top() { return y1; }
    public float bottom() { return y2; }

    public float centerX() { return (x1 + x2) * 0.5f; }
    public float centerY() { return (y1 + y2) * 0.5f; }

    // ── Mutate ─────────────────────────────────────────────────────────

    public BoundingBox translate(float dx, float dy) {
        return new BoundingBox(x1 + dx, y1 + dy, x2 + dx, y2 + dy);
    }

    public BoundingBox translate(Vec2 delta) {
        return translate(delta.x, delta.y);
    }

    public BoundingBox expand(float amount) {
        return new BoundingBox(x1 - amount, y1 - amount, x2 + amount, y2 + amount);
    }

    public BoundingBox expand(float dx, float dy) {
        return new BoundingBox(x1 - dx, y1 - dy, x2 + dx, y2 + dy);
    }

    public BoundingBox expand(Vec2 amount) {
        return expand(amount.x, amount.y);
    }

    public BoundingBox shrink(float amount) { return expand(-amount); }
    public BoundingBox shrink(float dx, float dy) { return expand(-dx, -dy); }
    public BoundingBox shrink(Vec2 amount) { return expand(amount.neg()); }

    public BoundingBox clampInside(BoundingBox container) {
        float nx1 = Math.max(x1, container.x1);
        float ny1 = Math.max(y1, container.y1);
        float nx2 = Math.min(x2, container.x2);
        float ny2 = Math.min(y2, container.y2);
        return new BoundingBox(nx1, ny1, Math.max(nx1, nx2), Math.max(ny1, ny2));
    }

    // ── Combine / intersect ─────────────────────────────────────────────

    public static BoundingBox combine(BoundingBox a, BoundingBox b) {
        return new BoundingBox(
                Math.min(a.x1, b.x1),
                Math.min(a.y1, b.y1),
                Math.max(a.x2, b.x2),
                Math.max(a.y2, b.y2)
        );
    }

    public BoundingBox union(BoundingBox other) { return combine(this, other); }

    public BoundingBox union(Vec2 point) {
        return new BoundingBox(
                Math.min(x1, point.x),
                Math.min(y1, point.y),
                Math.max(x2, point.x),
                Math.max(y2, point.y)
        );
    }

    public BoundingBox intersection(BoundingBox other) {
        float nx1 = Math.max(x1, other.x1);
        float ny1 = Math.max(y1, other.y1);
        float nx2 = Math.min(x2, other.x2);
        float ny2 = Math.min(y2, other.y2);
        if (nx1 > nx2 || ny1 > ny2) return new BoundingBox(0, 0, 0, 0);
        return new BoundingBox(nx1, ny1, nx2, ny2);
    }

    // ── Tests ───────────────────────────────────────────────────────────

    public boolean contains(float px, float py) {
        return px >= x1 && px <= x2 && py >= y1 && py <= y2;
    }

    public boolean contains(Vec2 p) { return contains(p.x, p.y); }

    public boolean contains(BoundingBox other) {
        return x1 <= other.x1 && y1 <= other.y1 && x2 >= other.x2 && y2 >= other.y2;
    }

    public boolean intersects(BoundingBox other) {
        return x1 < other.x2 && x2 > other.x1 && y1 < other.y2 && y2 > other.y1;
    }

    public boolean intersectsCircle(Vec2 center, float radius) {
        float nx = Math.max(x1, Math.min(center.x, x2));
        float ny = Math.max(y1, Math.min(center.y, y2));
        return center.distSquared(new Vec2(nx, ny)) <= radius * radius;
    }

    // ── Lerp / interpolate ──────────────────────────────────────────────

    public BoundingBox lerp(BoundingBox target, float t) {
        return new BoundingBox(
                x1 + (target.x1 - x1) * t,
                y1 + (target.y1 - y1) * t,
                x2 + (target.x2 - x2) * t,
                y2 + (target.y2 - y2) * t
        );
    }

    // ── Split ───────────────────────────────────────────────────────────

    public BoundingBox[] splitHorizontal(float ratio) {
        float mx = x1 + w() * ratio;
        return new BoundingBox[]{
                new BoundingBox(x1, y1, mx, y2),
                new BoundingBox(mx, y1, x2, y2)
        };
    }

    public BoundingBox[] splitVertical(float ratio) {
        float my = y1 + h() * ratio;
        return new BoundingBox[]{
                new BoundingBox(x1, y1, x2, my),
                new BoundingBox(x1, my, x2, y2)
        };
    }

    public BoundingBox subBox(float leftRatio, float topRatio, float rightRatio, float bottomRatio) {
        return new BoundingBox(
                x1 + w() * leftRatio,
                y1 + h() * topRatio,
                x1 + w() * (1f - rightRatio),
                y1 + h() * (1f - bottomRatio)
        );
    }

    // ── Corners ────────────────────────────────────────────────────────

    public Vec2 topLeft()     { return new Vec2(x1, y1); }
    public Vec2 topCenter()   { return new Vec2(centerX(), y1); }
    public Vec2 topRight()    { return new Vec2(x2, y1); }
    public Vec2 middleLeft() { return new Vec2(x1, centerY()); }
    public Vec2 middleCenter(){ return center(); }
    public Vec2 middleRight() { return new Vec2(x2, centerY()); }
    public Vec2 bottomLeft()  { return new Vec2(x1, y2); }
    public Vec2 bottomCenter(){ return new Vec2(centerX(), y2); }
    public Vec2 bottomRight() { return new Vec2(x2, y2); }

    // ── Object ─────────────────────────────────────────────────────────

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BoundingBox b)) return false;
        return Float.compare(b.x1, x1) == 0 && Float.compare(b.y1, y1) == 0
                && Float.compare(b.x2, x2) == 0 && Float.compare(b.y2, y2) == 0;
    }

    @Override public int hashCode() { return Objects.hash(x1, y1, x2, y2); }

    @Override public String toString() {
        return String.format("BoundingBox(%.1f, %.1f → %.1f, %.1f) [%.1fx%.1f]", x1, y1, x2, y2, w(), h());
    }

    public BoundingBox copy() { return new BoundingBox(x1, y1, x2, y2); }
}
