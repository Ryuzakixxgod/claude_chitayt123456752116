package ru.ryuzaki.ui.base;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.render.vertex.VertexFormat;
import net.minecraft.client.render.vertex.VertexFormatDrawer;
import net.minecraft.client.render.vertex.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vector4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL32;

public final class Draw {

    private static final MinecraftClient mc = MinecraftClient.getInstance();

    // ── Setup / State ───────────────────────────────────────────────

    public static void setup() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
    }

    public static void cleanup() {
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ── Quadrilaterals ──────────────────────────────────────────────

    public static void quad(Matrix4f matrix, float x1, float y1, float x2, float y2, Color c) {
        quad(matrix, x1, y1, x2, y2, c, c, c, c);
    }

    public static void quad(Matrix4f matrix, float x1, float y1, float x2, float y2, Color tl, Color tr, Color br, Color bl) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x1, y1, 0).color(tl.ri(), tl.gi(), tl.bi(), tl.ai());
        buf.vertex(matrix, x2, y1, 0).color(tr.ri(), tr.gi(), tr.bi(), tr.ai());
        buf.vertex(matrix, x2, y2, 0).color(br.ri(), br.gi(), br.bi(), br.ai());
        buf.vertex(matrix, x1, y2, 0).color(bl.ri(), bl.gi(), bl.bi(), bl.ai());
        draw(buf);
    }

    public static void quadTextured(Matrix4f matrix, float x1, float y1, float x2, float y2, float u1, float v1, float u2, float v2, Color c) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR_TEXTURE);
        buf.vertex(matrix, x1, y1, 0).color(c.ri(), c.gi(), c.bi(), c.ai()).texture(u1, v1);
        buf.vertex(matrix, x2, y1, 0).color(c.ri(), c.gi(), c.bi(), c.ai()).texture(u2, v1);
        buf.vertex(matrix, x2, y2, 0).color(c.ri(), c.gi(), c.bi(), c.ai()).texture(u2, v2);
        buf.vertex(matrix, x1, y2, 0).color(c.ri(), c.gi(), c.bi(), c.ai()).texture(u1, v2);
        draw(buf);
    }

    public static void quadTextured(Matrix4f matrix, float x1, float y1, float x2, float y2, Color tl, Color tr, Color br, Color bl, float u1, float v1, float u2, float v2) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR_TEXTURE);
        buf.vertex(matrix, x1, y1, 0).color(tl.ri(), tl.gi(), tl.bi(), tl.ai()).texture(u1, v1);
        buf.vertex(matrix, x2, y1, 0).color(tr.ri(), tr.gi(), tr.bi(), tr.ai()).texture(u2, v1);
        buf.vertex(matrix, x2, y2, 0).color(br.ri(), br.gi(), br.bi(), br.ai()).texture(u2, v2);
        buf.vertex(matrix, x1, y2, 0).color(bl.ri(), bl.gi(), bl.bi(), bl.ai()).texture(u1, v2);
        draw(buf);
    }

    // ── Rectangles ──────────────────────────────────────────────────

    public static void rect(Matrix4f matrix, float x, float y, float w, float h, Color c) {
        quad(matrix, x, y, x + w, y + h, c);
    }

    public static void rect(Matrix4f matrix, float x, float y, float w, float h, Color tl, Color tr, Color br, Color bl) {
        quad(matrix, x, y, x + w, y + h, tl, tr, br, bl);
    }

    public static void rectTextured(Matrix4f matrix, float x, float y, float w, float h, Identifier tex) {
        bindTexture(tex);
        quadTextured(matrix, x, y, x + w, y + h, 0, 0, 1, 1, Color.WHITE);
        unbindTexture();
    }

    // ── Gradient fills ──────────────────────────────────────────────

    public static void gradientH(Matrix4f matrix, float x, float y, float w, float h, Color left, Color right) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x, y, 0).color(left.ri(), left.gi(), left.bi(), left.ai());
        buf.vertex(matrix, x + w, y, 0).color(right.ri(), right.gi(), right.bi(), right.ai());
        buf.vertex(matrix, x + w, y + h, 0).color(right.ri(), right.gi(), right.bi(), right.ai());
        buf.vertex(matrix, x, y + h, 0).color(left.ri(), left.gi(), left.bi(), left.ai());
        drawBlend(buf);
    }

    public static void gradientV(Matrix4f matrix, float x, float y, float w, float h, Color top, Color bottom) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x, y, 0).color(top.ri(), top.gi(), top.bi(), top.ai());
        buf.vertex(matrix, x + w, y, 0).color(top.ri(), top.gi(), top.bi(), top.ai());
        buf.vertex(matrix, x + w, y + h, 0).color(bottom.ri(), bottom.gi(), bottom.bi(), bottom.ai());
        buf.vertex(matrix, x, y + h, 0).color(bottom.ri(), bottom.gi(), bottom.bi(), bottom.ai());
        drawBlend(buf);
    }

    public static void gradient4(Matrix4f matrix, float x, float y, float w, float h, Color tl, Color tr, Color br, Color bl) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x, y, 0).color(tl.ri(), tl.gi(), tl.bi(), tl.ai());
        buf.vertex(matrix, x + w, y, 0).color(tr.ri(), tr.gi(), tr.bi(), tr.ai());
        buf.vertex(matrix, x + w, y + h, 0).color(br.ri(), br.gi(), br.bi(), br.ai());
        buf.vertex(matrix, x, y + h, 0).color(bl.ri(), bl.gi(), bl.bi(), bl.ai());
        drawBlend(buf);
    }

    public static void gradientDiagonal(Matrix4f matrix, float x, float y, float w, float h, Color c1, Color c2) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x, y, 0).color(c1.ri(), c1.gi(), c1.bi(), c1.ai());
        buf.vertex(matrix, x + w, y, 0).color(c1.ri(), c1.gi(), c1.bi(), c1.ai());
        buf.vertex(matrix, x + w, y + h, 0).color(c2.ri(), c2.gi(), c2.bi(), c2.ai());
        buf.vertex(matrix, x, y + h, 0).color(c2.ri(), c2.gi(), c2.bi(), c2.ai());
        drawBlend(buf);
    }

    // ── Rounded rectangles ──────────────────────────────────────────

    public static void roundRect(Matrix4f matrix, float x, float y, float w, float h, float r, Color c) {
        if (r <= 0f) { rect(matrix, x, y, w, h, c); return; }
        float r2 = Math.min(r, w * 0.5f);
        float r3 = Math.min(r2, h * 0.5f);
        setup();
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);

        // Top-left arc
        arcVertices(buf, matrix, x + r3, y + r3, r3, 3.14159265f, 0f, c);
        // Top-right arc
        arcVertices(buf, matrix, x + w - r3, y + r3, r3, 0f, 1.5707963f, c);
        // Bottom-right arc
        arcVertices(buf, matrix, x + w - r3, y + h - r3, r3, 1.5707963f, 3.14159265f, c);
        // Bottom-left arc
        arcVertices(buf, matrix, x + r3, y + h - r3, r3, 3.14159265f, 4.712389f, c);

        draw(buf);
        cleanup();
    }

    public static void roundRectTextured(Matrix4f matrix, float x, float y, float w, float h, float r, Identifier tex) {
        bindTexture(tex);
        roundRectTextured0(matrix, x, y, w, h, r, Color.WHITE);
        unbindTexture();
    }

    private static void roundRectTextured0(Matrix4f matrix, float x, float y, float w, float h, float r, Color c) {
        if (r <= 0f) { rect(matrix, x, y, w, h, c); return; }
        float r2 = Math.min(r, w * 0.5f);
        float r3 = Math.min(r2, h * 0.5f);
        setup();
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR_TEXTURE);

        arcVerticesTextured(buf, matrix, x + r3, y + r3, r3, 3.14159265f, 0f, c);
        arcVerticesTextured(buf, matrix, x + w - r3, y + r3, r3, 0f, 1.5707963f, c);
        arcVerticesTextured(buf, matrix, x + w - r3, y + h - r3, r3, 1.5707963f, 3.14159265f, c);
        arcVerticesTextured(buf, matrix, x + r3, y + h - r3, r3, 3.14159265f, 4.712389f, c);

        draw(buf);
        cleanup();
    }

    // ── Lines ────────────────────────────────────────────────────────

    public static void line(Matrix4f matrix, float x1, float y1, float x2, float y2, float width, Color c) {
        setup();
        RenderSystem.lineWidth(width);
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x1, y1, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x2, y2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        draw(buf);
        cleanup();
    }

    public static void line(Matrix4f matrix, float x1, float y1, float x2, float y2, Color c) {
        line(matrix, x1, y1, x2, y2, 1f, c);
    }

    // ── Circles / Arcs ───────────────────────────────────────────────

    public static void circle(Matrix4f matrix, float cx, float cy, float r, Color c) {
        ellipse(matrix, cx, cy, r, r, c);
    }

    public static void ellipse(Matrix4f matrix, float cx, float cy, float rx, float ry, Color c) {
        if (rx <= 0f || ry <= 0f) return;
        setup();
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, cx, cy, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        int segments = (int) (Math.max(rx, ry) * 2f);
        segments = Math.max(segments, 12);
        for (int i = 0; i <= segments; i++) {
            float angle = (float) (i * 2f * Math.PI / segments);
            buf.vertex(matrix, cx + (float) Math.cos(angle) * rx, cy + (float) Math.sin(angle) * ry, 0)
               .color(c.ri(), c.gi(), c.bi(), c.ai());
        }
        draw(buf);
        cleanup();
    }

    public static void arcVertices(BufferBuilder buf, Matrix4f matrix, float cx, float cy, float r, float startAngle, float endAngle, Color c) {
        int segments = Math.max((int) (Math.abs(endAngle - startAngle) * r), 4);
        for (int i = 0; i <= segments; i++) {
            float angle = startAngle + (i * (endAngle - startAngle) / segments);
            buf.vertex(matrix, cx + (float) Math.cos(angle) * r, cy + (float) Math.sin(angle) * r, 0)
               .color(c.ri(), c.gi(), c.bi(), c.ai());
        }
    }

    public static void arcVerticesTextured(BufferBuilder buf, Matrix4f matrix, float cx, float cy, float r, float startAngle, float endAngle, Color c) {
        int segments = Math.max((int) (Math.abs(endAngle - startAngle) * r), 4);
        for (int i = 0; i <= segments; i++) {
            float angle = startAngle + (i * (endAngle - startAngle) / segments);
            float u = (float) Math.cos(angle) * 0.5f + 0.5f;
            float v = (float) Math.sin(angle) * 0.5f + 0.5f;
            buf.vertex(matrix, cx + (float) Math.cos(angle) * r, cy + (float) Math.sin(angle) * r, 0)
               .color(c.ri(), c.gi(), c.bi(), c.ai()).texture(u, v);
        }
    }

    // ── Triangles ───────────────────────────────────────────────────

    public static void triangle(Matrix4f matrix, float x1, float y1, float x2, float y2, float x3, float y3, Color c) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x1, y1, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x2, y2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x3, y3, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        draw(buf);
    }

    public static void triangle(Matrix4f matrix, float x1, float y1, float x2, float y2, float x3, float y3, Color c1, Color c2, Color c3) {
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, x1, y1, 0).color(c1.ri(), c1.gi(), c1.bi(), c1.ai());
        buf.vertex(matrix, x2, y2, 0).color(c2.ri(), c2.gi(), c2.bi(), c2.ai());
        buf.vertex(matrix, x3, y3, 0).color(c3.ri(), c3.gi(), c3.bi(), c3.ai());
        draw(buf);
    }

    // ── Polygons ────────────────────────────────────────────────────

    public static void polygon(Matrix4f matrix, float cx, float cy, float r, int sides, Color c) {
        if (sides < 3 || r <= 0f) return;
        setup();
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.TRIANGLE_FAN, VertexFormats.POSITION_COLOR);
        buf.vertex(matrix, cx, cy, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        for (int i = 0; i <= sides; i++) {
            float angle = (float) (i * 2f * Math.PI / sides);
            buf.vertex(matrix, cx + (float) Math.cos(angle) * r, cy + (float) Math.sin(angle) * r, 0)
               .color(c.ri(), c.gi(), c.bi(), c.ai());
        }
        draw(buf);
        cleanup();
    }

    // ── Outline / Stroke ────────────────────────────────────────────

    public static void rectOutline(Matrix4f matrix, float x, float y, float w, float h, float thickness, Color c) {
        setup();
        float t2 = thickness * 0.5f;
        BufferBuilder buf = Tessellator.getInstance().getBuffer();
        buf.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

        // Top edge
        buf.vertex(matrix, x, y + t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w, y + t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w, y - t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x, y - t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());

        // Bottom edge
        buf.vertex(matrix, x, y + h + t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w, y + h + t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w, y + h - t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x, y + h - t2, 0).color(c.ri(), c.gi(), c.bi(), c.ai());

        // Left edge
        buf.vertex(matrix, x + t2, y, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + t2, y + h, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x - t2, y + h, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x - t2, y, 0).color(c.ri(), c.gi(), c.bi(), c.ai());

        // Right edge
        buf.vertex(matrix, x + w + t2, y, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w + t2, y + h, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w - t2, y + h, 0).color(c.ri(), c.gi(), c.bi(), c.ai());
        buf.vertex(matrix, x + w - t2, y, 0).color(c.ri(), c.gi(), c.bi(), c.ai());

        draw(buf);
        cleanup();
    }

    // ── Texture helpers ─────────────────────────────────────────────

    public static void bindTexture(Identifier id) {
        RenderSystem.setShaderTexture(0, id);
    }

    public static void unbindTexture() {
        RenderSystem.setShaderTexture(0, new Identifier("minecraft", "textures/block/air.png"));
    }

    // ── Draw buffer ─────────────────────────────────────────────────

    private static void draw(BufferBuilder buf) {
        buf.end();
        BufferRenderer.drawWithGlobalProgram(buf);
    }

    private static void drawBlend(BufferBuilder buf) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        buf.end();
        BufferRenderer.drawWithGlobalProgram(buf);
    }

    // ── String rendering ────────────────────────────────────────────

    public static float textWidth(String text, float scale) {
        return mc.textRenderer.getWidth(text) * scale;
    }

    public static void text(Matrix4f matrix, String text, float x, float y, Color color, float scale, boolean shadow) {
        mc.textRenderer.draw(text, x, y, color.argbInt(), shadow, matrix,
                BufferBuilder.DrawMode.QUADS, 0, 0xF000F0);
    }

    public static void text(Matrix4f matrix, String text, float x, float y, Color color, float scale) {
        text(matrix, text, x, y, color, scale, false);
    }

    public static void textCentered(Matrix4f matrix, String text, float cx, float y, Color color, float scale, boolean shadow) {
        float w = textWidth(text, scale) * 0.5f;
        text(matrix, text, cx - w, y, color, scale, shadow);
    }

    public static void textCentered(Matrix4f matrix, String text, float cx, float y, Color color, float scale) {
        textCentered(matrix, text, cx, y, color, scale, false);
    }

    public static void textCenteredY(Matrix4f matrix, String text, float x, float cy, Color color, float scale, boolean shadow) {
        float h = mc.textRenderer.fontHeight * scale;
        text(matrix, text, x, cy - h * 0.5f, color, scale, shadow);
    }

    public static void textCenteredY(Matrix4f matrix, String text, float x, float cy, Color color, float scale) {
        textCenteredY(matrix, text, x, cy, color, scale, false);
    }

    public static void textCenteredBoth(Matrix4f matrix, String text, float cx, float cy, Color color, float scale, boolean shadow) {
        float w = textWidth(text, scale) * 0.5f;
        float h = mc.textRenderer.fontHeight * scale;
        text(matrix, text, cx - w, cy - h * 0.5f, color, scale, shadow);
    }

    public static void textCenteredBoth(Matrix4f matrix, String text, float cx, float cy, Color color, float scale) {
        textCenteredBoth(matrix, text, cx, cy, color, scale, false);
    }

    // ── Scissor / Clip ───────────────────────────────────────────────

    public static void scissor(float x, float y, float w, float h) {
        double scale = mc.getWindow().getScaleFactor();
        int ix = (int) (x * scale);
        int iy = (int) (mc.getWindow().getScaledHeight() - y * scale - h * scale);
        int iw = (int) (w * scale);
        int ih = (int) (h * scale);
        GL11.glScissor(ix, iy, iw, ih);
    }

    public static void enableScissor() {
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
    }

    public static void disableScissor() {
        GL11.glDisable(GL11.GL_SCISSOR_TEST);
    }

    // ── Depth / Blend state ────────────────────────────────────────

    public static void enableDepth() {
        RenderSystem.enableDepthTest();
    }

    public static void disableDepth() {
        RenderSystem.disableDepthTest();
    }

    public static void enableAlpha() {
        GL11.glEnable(GL11.GL_ALPHA_TEST);
    }

    public static void disableAlpha() {
        GL11.glDisable(GL11.GL_ALPHA_TEST);
    }

    public static void alphaFunc(int func, float ref) {
        GL11.glAlphaFunc(func, ref);
    }

    public static void enableStencil() {
        GL32.glEnable(GL32.GL_STENCIL_TEST);
    }

    public static void disableStencil() {
        GL32.glDisable(GL32.GL_STENCIL_TEST);
    }

    public static void stencilFunc(int func, int ref, int mask) {
        GL32.glStencilFunc(func, ref, mask);
    }

    public static void stencilOp(int fail, int zfail, int zpass) {
        GL32.glStencilOp(fail, zfail, zpass);
    }

    public static void clearStencil() {
        GL32.glClear(GL32.GL_STENCIL_BUFFER_BIT);
    }

    public static void stencilMask(int mask) {
        GL32.glStencilMask(mask);
    }
}
