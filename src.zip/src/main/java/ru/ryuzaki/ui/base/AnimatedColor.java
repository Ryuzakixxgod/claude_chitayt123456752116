package ru.ryuzaki.ui.base;

import java.util.Objects;

/**
 * RGBA color with built-in animation support.
 * All values are in [0, 1] range for easy multiplication.
 */
public final class AnimatedColor {

    private int r, g, b, a;
    private float animProgress = 1f;
    private AnimatedColor target;

    public AnimatedColor() {
        set(255, 255, 255, 255);
    }

    public AnimatedColor(int r, int g, int b, int a) {
        set(r, g, b, a);
    }

    public AnimatedColor(int r, int g, int b) {
        set(r, g, b, 255);
    }

    public AnimatedColor(float r, float g, float b, float a) {
        set((int)(r * 255), (int)(g * 255), (int)(b * 255), (int)(a * 255));
    }

    public AnimatedColor(int rgb) {
        set(rgb, 255);
    }

    public AnimatedColor(int rgb, int a) {
        set(
                (rgb >> 16) & 0xFF,
                (rgb >> 8) & 0xFF,
                rgb & 0xFF,
                a
        );
    }

    public void set(int r, int g, int b, int a) {
        this.r = clampInt(r);
        this.g = clampInt(g);
        this.b = clampInt(b);
        this.a = clampInt(a);
    }

    public void set(int r, int g, int b) { set(r, g, b, 255); }

    public void set(int rgb) {
        set(
                (rgb >> 16) & 0xFF,
                (rgb >> 8) & 0xFF,
                rgb & 0xFF,
                255
        );
    }

    public void set(int rgb, int a) {
        set(
                (rgb >> 16) & 0xFF,
                (rgb >> 8) & 0xFF,
                rgb & 0xFF,
                a
        );
    }

    public void set(AnimatedColor other) {
        this.r = other.r;
        this.g = other.g;
        this.b = other.b;
        this.a = other.a;
    }

    public int r() { return r; }
    public int g() { return g; }
    public int b() { return b; }
    public int a() { a = Math.max(0, Math.min(255, a)); return a; }

    public float rf() { return r / 255f; }
    public float gf() { return g / 255f; }
    public float bf() { return b / 255f; }
    public float af() { return a / 255f; }

    public int argb() { return (a << 24) | (r << 16) | (g << 8) | b; }
    public int rgb()  { return (r << 16) | (g << 8) | b; }
    public int bgra() { return (b << 24) | (g << 16) | (r << 8) | a; }

    public AnimatedColor copy() {
        return new AnimatedColor(r, g, b, a);
    }

    public AnimatedColor withAlpha(int alpha) {
        return new AnimatedColor(r, g, b, alpha);
    }

    public AnimatedColor withAlpha(float alpha) {
        return new AnimatedColor(r, g, b, (int)(alpha * 255));
    }

    public AnimatedColor mul(float s) {
        return new AnimatedColor(
                (int)(r * s), (int)(g * s), (int)(b * s), (int)(a * s)
        );
    }

    public AnimatedColor add(AnimatedColor o) {
        return new AnimatedColor(
                Math.min(255, r + o.r),
                Math.min(255, g + o.g),
                Math.min(255, b + o.b),
                Math.min(255, a + o.a)
        );
    }

    public AnimatedColor sub(AnimatedColor o) {
        return new AnimatedColor(
                Math.max(0, r - o.r),
                Math.max(0, g - o.g),
                Math.max(0, b - o.b),
                Math.max(0, a - o.a)
        );
    }

    public AnimatedColor mix(AnimatedColor other, float t) {
        t = clampFloat(t);
        return new AnimatedColor(
                (int)(r + (other.r - r) * t),
                (int)(g + (other.g - g) * t),
                (int)(b + (other.b - b) * t),
                (int)(a + (other.a - a) * t)
        );
    }

    public AnimatedColor lighten(float amount) {
        return mix(new AnimatedColor(255, 255, 255), clampFloat(amount));
    }

    public AnimatedColor darken(float amount) {
        return mix(new AnimatedColor(0, 0, 0), clampFloat(amount));
    }

    public AnimatedColor saturate(float amount) {
        float gray = (r + g + b) / 3f;
        return new AnimatedColor(
                (int)(r + (gray - r) * (1f - clampFloat(amount))),
                (int)(g + (gray - g) * (1f - clampFloat(amount))),
                (int)(b + (gray - b) * (1f - clampFloat(amount))),
                a
        );
    }

    public AnimatedColor hueShift(float degrees) {
        float[] hsv = toHSV();
        hsv[0] = (hsv[0] + degrees / 360f) % 1f;
        if (hsv[0] < 0) hsv[0] += 1f;
        return fromHSV(hsv[0], hsv[1], hsv[2], af());
    }

    public float[] toHSV() {
        float rf = rf(), gf = gf(), bf = bf();
        float max = Math.max(rf, Math.max(gf, bf));
        float min = Math.min(rf, Math.min(gf, bf));
        float delta = max - min;
        float h = 0f, s = max == 0f ? 0f : delta / max, v = max;
        if (delta > 0f) {
            if (max == rf) h = (gf - bf) / delta;
            else if (max == gf) h = 2f + (bf - rf) / delta;
            else h = 4f + (rf - gf) / delta;
            h /= 6f;
            if (h < 0f) h += 1f;
        }
        return new float[]{h, s, v};
    }

    public static AnimatedColor fromHSV(float h, float s, float v) {
        return fromHSV(h, s, v, 1f);
    }

    public static AnimatedColor fromHSV(float h, float s, float v, float alpha) {
        if (s <= 0f) {
            int g = (int)(v * 255);
            return new AnimatedColor(g, g, g, (int)(alpha * 255));
        }
        h = ((h % 1f) + 1f) % 1f;
        int i = (int)(h * 6f);
        float f = h * 6f - i;
        float p = v * (1f - s);
        float q = v * (1f - f * s);
        float t = v * (1f - (1f - f) * s);
        switch (i) {
            default:
            case 0: return new AnimatedColor(v, t, p, alpha);
            case 1: return new AnimatedColor(q, v, p, alpha);
            case 2: return new AnimatedColor(p, v, t, alpha);
            case 3: return new AnimatedColor(p, q, v, alpha);
            case 4: return new AnimatedColor(t, p, v, alpha);
            case 5: return new AnimatedColor(v, p, q, alpha);
        }
    }

    // ── Animation ─────────────────────────────────────────────────────────

    public void animateTo(AnimatedColor target, float speed) {
        this.target = target.copy();
        this.animProgress = 0f;
    }

    public boolean update(float dt, float speed) {
        if (target == null || animProgress >= 1f) return false;
        animProgress = Math.min(1f, animProgress + dt * speed);
        float t = Easing.easeInOutCubic(animProgress);
        set(mix(target, t));
        if (animProgress >= 1f) {
            target = null;
        }
        return true;
    }

    public boolean isAnimating() { return target != null && animProgress < 1f; }
    public float getAnimProgress() { return animProgress; }

    // ── Presets ──────────────────────────────────────────────────────────

    public static AnimatedColor hex(int hex) { return new AnimatedColor(hex); }
    public static AnimatedColor hex(int hex, int alpha) { return new AnimatedColor(hex, alpha); }
    public static AnimatedColor rgb(int r, int g, int b) { return new AnimatedColor(r, g, b); }
    public static AnimatedColor rgba(int r, int g, int b, int a) { return new AnimatedColor(r, g, b, a); }

    // ── Object ───────────────────────────────────────────────────────────

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof AnimatedColor c)) return false;
        return c.r == r && c.g == g && c.b == b && c.a == a;
    }

    @Override public int hashCode() { return Objects.hash(r, g, b, a); }

    @Override public String toString() {
        return String.format("AnimatedColor(#%06X:%02X)", rgb(), a());
    }

    private static int clampInt(int v) { return Math.max(0, Math.min(255, v)); }
    private static float clampFloat(float v) { return Math.max(0f, Math.min(1f, v)); }
}
