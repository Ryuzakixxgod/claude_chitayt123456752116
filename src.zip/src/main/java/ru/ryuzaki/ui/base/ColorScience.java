package ru.ryuzaki.ui.base;

import java.util.function.FloatBinaryOperator;
import java.util.function.FloatUnaryOperator;

/**
 * ColorScience — наука о цветах для AAA UI.
 *
 * Обеспечивает:
 * - Цветовые пространства (sRGB, linear, perceptual)
 * - Контраст по WCAG 2.1
 * - Генерация палитр из seed
 * - Easing цветами
 * - Perceptual blending
 * - Temperature-based adjustments
 */
public final class ColorScience {

    private ColorScience() {}

    // ── Constants ──────────────────────────────────────────────────────────────

    public static final float[] WCAG_RELATIVE_LUMINANCE_BLACK = {0f, 0f, 0f};
    public static final float[] WCAG_RELATIVE_LUMINANCE_WHITE = {1f, 1f, 1f};

    // ── sRGB ↔ Linear conversion ─────────────────────────────────────────────

    /**
     * Convert sRGB component [0..255] to linear RGB [0..1].
     * Uses IEC 61966-2-1 nonlinear transform.
     */
    public static float srgbToLinear(int srgb) {
        float c = srgb / 255f;
        return c <= 0.04045f
                ? c / 12.92f
                : (float) Math.pow((c + 0.055) / 1.055, 2.4);
    }

    /**
     * Convert linear RGB [0..1] to sRGB [0..255].
     */
    public static int linearToSrgb(float linear) {
        float c = linear <= 0.0031308f
                ? 12.92f * linear
                : (float) (1.055 * Math.pow(linear, 1/2.4) - 0.055);
        return Math.round(Math.max(0f, Math.min(1f, c)) * 255f);
    }

    /**
     * Decompose ARGB int to linear RGB float[3].
     */
    public static float[] argbToLinear(int argb) {
        return new float[] {
                srgbToLinear((argb >> 16) & 0xFF),
                srgbToLinear((argb >>  8) & 0xFF),
                srgbToLinear( argb        & 0xFF)
        };
    }

    /**
     * Compose linear RGB float[3] to ARGB int.
     */
    public static int linearToArgb(float r, float g, float b, int alpha) {
        return (alpha << 24)
                | (linearToSrgb(Math.max(0f, Math.min(1f, r))) << 16)
                | (linearToSrgb(Math.max(0f, Math.min(1f, g))) <<  8)
                |  linearToSrgb(Math.max(0f, Math.min(1f, b)));
    }

    // ── WCAG Contrast ─────────────────────────────────────────────────────────

    /**
     * Calculate WCAG 2.1 relative luminance.
     * Returns value in [0..1].
     */
    public static float wcagLuminance(int argb) {
        float[] lin = argbToLinear(argb);
        return 0.2126f * lin[0] + 0.7152f * lin[1] + 0.0722f * lin[2];
    }

    /**
     * Calculate WCAG 2.1 contrast ratio between two ARGB colors.
     * Returns value >= 1 (1 = no contrast, 21 = max contrast black/white).
     */
    public static float wcagContrastRatio(int argb1, int argb2) {
        float l1 = wcagLuminance(argb1);
        float l2 = wcagLuminance(argb2);
        float lighter   = Math.max(l1, l2);
        float darker    = Math.min(l1, l2);
        return (lighter + 0.05f) / (darker + 0.05f);
    }

    /**
     * Check if contrast meets WCAG AA for normal text (4.5:1).
     */
    public static boolean meetsWcagAA(int foreground, int background) {
        return wcagContrastRatio(foreground, background) >= 4.5f;
    }

    /**
     * Check if contrast meets WCAG AAA for normal text (7:1).
     */
    public static boolean meetsWcagAAA(int foreground, int background) {
        return wcagContrastRatio(foreground, background) >= 7.0f;
    }

    /**
     * Suggest accessible foreground color from two options.
     * Returns the one with higher contrast against background.
     */
    public static int accessibleForeground(int fg1, int fg2, int background) {
        float c1 = wcagContrastRatio(fg1, background);
        float c2 = wcagContrastRatio(fg2, background);
        return c1 >= c2 ? fg1 : fg2;
    }

    // ── Color Blending ─────────────────────────────────────────────────────────

    /**
     * Linear blend between two ARGB colors in linear RGB space.
     * Produces more perceptually correct results than naive ARGB lerp.
     *
     * @param t interpolation factor [0..1], 0 = start, 1 = end
     */
    public static int lerp(int startArgb, int endArgb, float t) {
        t = Math.max(0f, Math.min(1f, t));
        float[] s = argbToLinear(startArgb);
        float[] e = argbToLinear(endArgb);
        int sa = (startArgb >> 24) & 0xFF;
        int ea = ( endArgb >> 24) & 0xFF;
        return linearToArgb(
                s[0] + (e[0] - s[0]) * t,
                s[1] + (e[1] - s[1]) * t,
                s[2] + (e[2] - s[2]) * t,
                Math.round(sa + (ea - sa) * t)
        );
    }

    /**
     * Chroma-preserving hue shift in HSL space.
     */
    public static int withHueShift(int argb, float degrees) {
        float[] rgb = {
                srgbToLinear((argb >> 16) & 0xFF),
                srgbToLinear((argb >>  8) & 0xFF),
                srgbToLinear( argb        & 0xFF)
        };
        float max = Math.max(rgb[0], Math.max(rgb[1], rgb[2]));
        float min = Math.min(rgb[0], Math.min(rgb[1], rgb[2]));
        float l = (max + min) / 2f;
        float h = 0f, s = 0f;

        if (max != min) {
            float d = max - min;
            s = l > 0.5f ? d / (2f - max - min) : d / (max + min);
            if (max == rgb[0]) {
                h = (rgb[1] - rgb[2]) / d + (rgb[1] < rgb[2] ? 6f : 0f);
            } else if (max == rgb[1]) {
                h = (rgb[2] - rgb[0]) / d + 2f;
            } else {
                h = (rgb[0] - rgb[1]) / d + 4f;
            }
            h /= 6f;
        }

        h = (h + degrees / 360f) % 1f;
        if (h < 0f) h += 1f;

        return hslToArgb(h, s, l, (argb >> 24) & 0xFF);
    }

    /**
     * Convert HSL to ARGB.
     */
    public static int hslToArgb(float h, float s, float l, int alpha) {
        h = ((h % 1f) + 1f) % 1f;
        s = Math.max(0f, Math.min(1f, s));
        l = Math.max(0f, Math.min(1f, l));

        float q = l < 0.5f ? l * (1f + s) : l + s - l * s;
        float p = 2f * l - q;
        float r = hueToRgb(p, q, h + 1f/3f);
        float g = hueToRgb(p, q, h);
        float b = hueToRgb(p, q, h - 1f/3f);

        return ((alpha & 0xFF) << 24)
                | ((int)(r * 255) << 16)
                | ((int)(g * 255) <<  8)
                |  (int)(b * 255);
    }

    private static float hueToRgb(float p, float q, float t) {
        if (t < 0f) t += 1f;
        if (t > 1f) t -= 1f;
        if (t < 1f/6f) return p + (q - p) * 6f * t;
        if (t < 0.5f) return q;
        if (t < 2f/3f) return p + (q - p) * (2f/3f - t) * 6f;
        return p;
    }

    // ── Alpha compositing ─────────────────────────────────────────────────────

    /**
     * Premultiplied alpha compositing (Porter-Duff "over" operator).
     * Returns src OVER dst.
     */
    public static int over(int src, int dst) {
        float sa = ((src >> 24) & 0xFF) / 255f;
        float sr = srgbToLinear((src >> 16) & 0xFF);
        float sg = srgbToLinear((src >>  8) & 0xFF);
        float sb = srgbToLinear( src        & 0xFF);

        float da = ((dst >> 24) & 0xFF) / 255f;
        float dr = srgbToLinear((dst >> 16) & 0xFF);
        float dg = srgbToLinear((dst >>  8) & 0xFF);
        float db = srgbToLinear( dst        & 0xFF);

        float outA = sa + da * (1f - sa);
        if (outA < 0.001f) return 0x00000000;

        float outR = (sr * sa + dr * da * (1f - sa)) / outA;
        float outG = (sg * sa + dg * da * (1f - sa)) / outA;
        float outB = (sb * sa + db * da * (1f - sa)) / outA;

        return ((int)(outA * 255) << 24)
                | (linearToSrgb(outR) << 16)
                | (linearToSrgb(outG) <<  8)
                |  linearToSrgb(outB);
    }

    // ── ARGB utilities ────────────────────────────────────────────────────────

    public static int alpha(int argb) { return (argb >> 24) & 0xFF; }
    public static int red(int argb)   { return (argb >> 16) & 0xFF; }
    public static int green(int argb) { return (argb >>  8) & 0xFF; }
    public static int blue(int argb)  { return  argb        & 0xFF; }

    public static int setAlpha(int argb, int alpha) {
        return ((alpha & 0xFF) << 24) | (argb & 0x00FFFFFF);
    }

    public static int scaleAlpha(int argb, float scale) {
        int a = Math.round(((argb >> 24) & 0xFF) * scale);
        return ((a & 0xFF) << 24) | (argb & 0x00FFFFFF);
    }

    // ── Gradient palette generation ─────────────────────────────────────────

    /**
     * Generate harmonious palette from base color using color theory.
     * Returns array of 5 colors: base, complement, triadic[0], triadic[1], analogous.
     */
    public static int[] harmonyPalette(int baseArgb, float analogousSpread) {
        float h = rgbToHue(baseArgb);
        int a = alpha(baseArgb);
        float s = rgbToSaturation(baseArgb);
        float l = rgbToLightness(baseArgb);

        float[] hues = {
                h,
                (h + 0.5f) % 1f,                          // complementary
                (h + 1f/3f) % 1f,                         // triadic 1
                (h + 2f/3f) % 1f,                         // triadic 2
                (h + analogousSpread) % 1f                 // analogous
        };

        int[] palette = new int[hues.length];
        for (int i = 0; i < hues.length; i++) {
            palette[i] = hslToArgb(hues[i], s, l, a);
        }
        return palette;
    }

    public static float rgbToHue(int argb) {
        float r = srgbToLinear((argb >> 16) & 0xFF);
        float g = srgbToLinear((argb >>  8) & 0xFF);
        float b = srgbToLinear( argb        & 0xFF);
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        if (max == min) return 0f;
        float d = max - min;
        float h;
        if (max == r)      h = (g - b) / d + (g < b ? 6f : 0f);
        else if (max == g) h = (b - r) / d + 2f;
        else               h = (r - g) / d + 4f;
        return (h / 6f) % 1f;
    }

    public static float rgbToSaturation(int argb) {
        float r = srgbToLinear((argb >> 16) & 0xFF);
        float g = srgbToLinear((argb >>  8) & 0xFF);
        float b = srgbToLinear( argb        & 0xFF);
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float l = (max + min) / 2f;
        if (max == min) return 0f;
        float d = max - min;
        return l > 0.5f ? d / (2f - max - min) : d / (max + min);
    }

    public static float rgbToLightness(int argb) {
        float r = srgbToLinear((argb >> 16) & 0xFF);
        float g = srgbToLinear((argb >>  8) & 0xFF);
        float b = srgbToLinear( argb        & 0xFF);
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        return (max + min) / 2f;
    }

    // ── Seeded procedural palette ─────────────────────────────────────────────

    /**
     * Generate deterministic color from seed (MurmurHash-like).
     * Useful for per-user/persistent color generation.
     */
    public static int seedColor(long seed, int alpha) {
        long h = seed ^ (seed >>> 33);
        h = (h * 0xFF51AFD7) >>> 0;
        h ^= (h >>> 15);
        h = (h * 0x735A2D) >>> 0;

        float hue   = (h & 0xFFFF) / 65535f;
        float sat   = 0.5f + ((h >>> 16) & 0xFF) / 511f;
        float light = 0.4f + ((h >>> 24) & 0xFF) / 511f;

        return hslToArgb(hue, sat, light, alpha);
    }
}
