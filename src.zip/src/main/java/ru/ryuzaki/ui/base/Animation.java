package ru.ryuzaki.ui.base;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public final class Animation {

    public enum State { IDLE, RUNNING, PAUSED, FINISHED }

    private State state = State.IDLE;
    private final EasingFunc easing;
    private final float duration;
    private float elapsed;
    private float progress;
    private boolean autoReverse;
    private boolean reversed;
    private int repeatCount;
    private int currentRepeat;
    private final List<Consumer<Animation>> onUpdate = new ArrayList<>();
    private final List<Consumer<Animation>> onComplete = new ArrayList<>();
    private final List<Consumer<Animation>> onRepeat = new ArrayList<>();

    @FunctionalInterface
    public interface EasingFunc {
        float apply(float t);
    }

    public Animation(float duration, EasingFunc easing) {
        this.duration = Math.max(0f, duration);
        this.easing = easing != null ? easing : Easing::linear;
    }

    public static Animation of(float duration) { return new Animation(duration, null); }
    public static Animation of(float duration, EasingFunc easing) { return new Animation(duration, easing); }

    public Animation onUpdate(Consumer<Animation> callback) { onUpdate.add(callback); return this; }
    public Animation onComplete(Consumer<Animation> callback) { onComplete.add(callback); return this; }
    public Animation onRepeat(Consumer<Animation> callback) { onRepeat.add(callback); return this; }

    public Animation autoReverse() { this.autoReverse = true; return this; }
    public Animation repeat(int count) { this.repeatCount = count; return this; }
    public Animation repeatForever() { this.repeatCount = Integer.MAX_VALUE; return this; }

    public void start() {
        if (state == State.RUNNING) return;
        state = State.RUNNING;
        if (elapsed == 0f) currentRepeat = 0;
    }

    public void pause() { if (state == State.RUNNING) state = State.PAUSED; }
    public void resume() { if (state == State.PAUSED) state = State.RUNNING; }
    public void stop() { state = State.IDLE; elapsed = 0f; progress = 0f; reversed = false; currentRepeat = 0; }
    public void reset() { stop(); }

    public void tick(float delta) {
        if (state != State.RUNNING) return;
        if (duration == 0f) {
            progress = 1f;
            finish();
            return;
        }

        elapsed += delta;
        float raw = Math.min(elapsed / duration, 1f);
        progress = reversed ? 1f - raw : raw;

        if (elapsed >= duration) {
            if (autoReverse && !reversed) {
                reversed = true;
                elapsed = 0f;
            } else {
                currentRepeat++;
                if (currentRepeat <= repeatCount) {
                    onRepeat.forEach(c -> c.accept(this));
                    elapsed = 0f;
                    reversed = false;
                } else {
                    progress = reversed ? 0f : 1f;
                    finish();
                    return;
                }
            }
        }

        onUpdate.forEach(c -> c.accept(this));
    }

    private void finish() {
        state = State.FINISHED;
        onComplete.forEach(c -> c.accept(this));
    }

    public State state() { return state; }
    public float progress() { return progress; }
    public float easedProgress() { return easing.apply(progress); }
    public float duration() { return duration; }
    public float elapsed() { return elapsed; }
    public boolean isRunning() { return state == State.RUNNING; }
    public boolean isFinished() { return state == State.FINISHED; }
    public int currentRepeat() { return currentRepeat; }
}

// ── Tween ─────────────────────────────────────────────────────────────────

public final class Tween {

    private final Supplier<Float> getter;
    private final Consumer<Float> setter;
    private final float target;
    private final Animation anim;
    private float startValue;

    public Tween(Supplier<Float> getter, Consumer<Float> setter, float target, float duration, Animation.EasingFunc easing) {
        this.getter = getter;
        this.setter = setter;
        this.target = target;
        this.anim = new Animation(duration, easing);
        this.anim.onUpdate(a -> setter.accept(startValue + (target - startValue) * a.easedProgress()));
        this.anim.onComplete(a -> setter.accept(target));
    }

    public static Tween to(Supplier<Float> getter, Consumer<Float> setter, float target, float duration) {
        return new Tween(getter, setter, target, duration, Easing::easeOutCubic);
    }

    public static Tween to(Supplier<Float> getter, Consumer<Float> setter, float target, float duration, Animation.EasingFunc easing) {
        return new Tween(getter, setter, target, duration, easing);
    }

    public Tween autoReverse() { anim.autoReverse(); return this; }
    public Tween repeat(int count) { anim.repeat(count); return this; }
    public Tween onUpdate(Consumer<Animation> callback) { anim.onUpdate(callback); return this; }
    public Tween onComplete(Consumer<Animation> callback) { anim.onComplete(callback); return this; }

    public void start() { startValue = getter.get(); anim.start(); }
    public void tick(float delta) { anim.tick(delta); }
    public void stop() { anim.stop(); setter.accept(target); }
    public boolean isRunning() { return anim.isRunning(); }
    public boolean isFinished() { return anim.isFinished(); }
}

// ── TweenManager ─────────────────────────────────────────────────────────

public final class TweenManager {

    private final List<Tween> tweens = new ArrayList<>();

    public void add(Tween tween) { tweens.add(tween); }

    public Tween create(Supplier<Float> getter, Consumer<Float> setter, float target, float duration, Animation.EasingFunc easing) {
        Tween t = Tween.to(getter, setter, target, duration, easing);
        tweens.add(t);
        return t;
    }

    public void tick(float delta) {
        Iterator<Tween> it = tweens.iterator();
        while (it.hasNext()) {
            Tween t = it.next();
            t.tick(delta);
            if (t.isFinished()) it.remove();
        }
    }

    public void clear() { tweens.clear(); }
    public int size() { return tweens.size(); }
}
