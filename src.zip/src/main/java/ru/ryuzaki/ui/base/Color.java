package ru.ryuzaki.ui.base;

import java.util.Objects;

/**
 * Immutable RGBA color with float precision (0-1).
 * Supports HSV conversion, blending, and formatting.
 */
public final class Color {

    public static final Color CLEAR     = new Color(0, 0, 0, 0);
    public static final Color BLACK     = new Color(0, 0, 0, 1);
    public static final Color WHITE     = new Color(1, 1, 1, 1);
    public static final Color RED       = new Color(1, 0, 0, 1);
    public static final Color GREEN     = new Color(0, 1, 0, 1);
    public static final Color BLUE      = new Color(0, 0, 1, 1);
    public static final Color CYAN      = new Color(0, 1, 1, 1);
    public static final Color MAGENTA   = new Color(1, 0, 1, 1);
    public static final Color YELLOW    = new Color(1, 1, 0, 1);
    public static final Color GRAY      = new Color(0.5f, 0.5f, 0.5f, 1);

    public final float r, g, b, a;

    public Color(float r, float g, float b, float a) {
        this.r = clamp01(r);
        this.g = clamp01(g);
        this.b = clamp01(b);
        this.a = clamp01(a);
    }

    public Color(float r, float g, float b) { this(r, g, b, 1f); }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }

    public float r() { return r; }
    public float g() { return g; }
    public float b() { return b; }
    public float a() { return a; }

    public int ri() { return (int) (r * 255f); }
    public int gi() { return (int) (g * 255f); }
    public int bi() { return (int) (b * 255f); }
    public int ai() { return (int) (a * 255f); }
    public int argbInt() { return (ai() << 24) | (ri() << 16) | (gi() << 8) | bi(); }
    public int rgbaInt() { return (ri() << 24) | (gi() << 16) | (bi() << 8) | ai(); }

    // ── With channels ─────────────────────────────────────────────────

    public Color withR(float nr) { return new Color(nr, g, b, a); }
    public Color withG(float ng) { return new Color(r, ng, b, a); }
    public Color withB(float nb) { return new Color(r, g, nb, a); }
    public Color withA(float na) { return new Color(r, g, b, na); }

    public Color withAlpha(float alpha) { return withA(alpha); }

    // ── Lerp ─────────────────────────────────────────────────────────

    public Color lerp(Color target, float t) {
        float tr = r + (target.r - r) * t;
        float tg = g + (target.g - g) * t;
        float tb = b + (target.b - b) * t;
        float ta = a + (target.a - a) * t;
        return new Color(tr, tg, tb, ta);
    }

    // ── Blend modes ──────────────────────────────────────────────────

    public Color multiply(Color other) {
        return new Color(r * other.r, g * other.g, b * other.b, a * other.a);
    }

    public Color screen(Color other) {
        return new Color(1f - (1f - r) * (1f - other.r),
                         1f - (1f - g) * (1f - other.g),
                         1f - (1f - b) * (1f - other.b),
                         1f - (1f - a) * (1f - other.a));
    }

    public Color overlay(Color other) {
        return new Color(
                r < 0.5f ? 2f * r * other.r : 1f - 2f * (1f - r) * (1f - other.r),
                g < 0.5f ? 2f * g * other.g : 1f - 2f * (1f - g) * (1f - other.g),
                b < 0.5f ? 2f * b * other.b : 1f - 2f * (1f - b) * (1f - other.b),
                a
        );
    }

    public Color add(Color other) {
        return new Color(Math.min(1f, r + other.r),
                         Math.min(1f, g + other.g),
                         Math.min(1f, b + other.b),
                         Math.min(1f, a + other.a));
    }

    public Color subtract(Color other) {
        return new Color(Math.max(0f, r - other.r),
                         Math.max(0f, g - other.g),
                         Math.max(0f, b - other.b),
                         Math.max(0f, a - other.a));
    }

    // ── Brightness / contrast ────────────────────────────────────────

    public Color brightness(float factor) {
        return new Color(r * factor, g * factor, b * factor, a);
    }

    public Color contrast(float factor, float midpoint) {
        float m = (midpoint >= 0f && midpoint <= 1f) ? midpoint : 0.5f;
        return new Color((r - m) * factor + m,
                         (g - m) * factor + m,
                         (b - m) * factor + m,
                         a);
    }

    public Color saturate(float factor) {
        float gray = 0.2126f * r + 0.7152f * g + 0.0722f * b;
        return new Color(gray + (r - gray) * factor,
                         gray + (g - gray) * factor,
                         gray + (b - gray) * factor,
                         a);
    }

    public float luminance() { return 0.2126f * r + 0.7152f * g + 0.0722f * b; }

    public Color invert() { return new Color(1f - r, 1f - g, 1f - b, a); }

    public Color tint(Color tintColor) {
        return multiply(tintColor);
    }

    public Color shade(Color shadeColor) {
        return screen(shadeColor);
    }

    // ── Premultiplied alpha ─────────────────────────────────────────

    public Color premultiplied() {
        return new Color(r * a, g * a, b * a, a);
    }

    public Color straight() {
        if (a == 0f) return new Color(r, g, b, a);
        return new Color(r / a, g / a, b / a, a);
    }

    // ── From/To hex ─────────────────────────────────────────────────

    public static Color fromHex(String hex) {
        String clean = hex.startsWith("#") ? hex.substring(1) : hex;
        int len = clean.length();
        int rgb;
        float a = 1f;
        if (len == 6) {
            rgb = (int) Long.parseLong(clean, 16);
        } else if (len == 8) {
            int full = (int) Long.parseLong(clean, 16);
            rgb = (full >> 8) & 0xFFFFFF;
            a = ((full & 0xFF) / 255f);
        } else {
            return WHITE;
        }
        return new Color(
                ((rgb >> 16) & 0xFF) / 255f,
                ((rgb >> 8) & 0xFF) / 255f,
                (rgb & 0xFF) / 255f,
                a
        );
    }

    public String toHex(boolean includeAlpha) {
        if (includeAlpha) {
            return String.format("#%02X%02X%02X%02X", ri(), gi(), bi(), ai());
        }
        return String.format("#%02X%02X%02X", ri(), gi(), bi());
    }

    public String toHex() { return toHex(false); }

    // ── HSV conversion ───────────────────────────────────────────────

    public static Color fromHSV(float h, float s, float v, float alpha) {
        h = ((h % 1f) + 1f) % 1f;
        s = Math.max(0f, Math.min(1f, s));
        v = Math.max(0f, Math.min(1f, v));

        float c = v * s;
        float x = c * (1f - Math.abs(((h * 6f) % 2f) - 1f));
        float m = v - c;

        float r1, g1, b1;
        int hi = (int) (h * 6f) % 6;
        switch (hi) {
            case 0 -> { r1 = c; g1 = x; b1 = 0f; }
            case 1 -> { r1 = x; g1 = c; b1 = 0f; }
            case 2 -> { r1 = 0f; g1 = c; b1 = x; }
            case 3 -> { r1 = 0f; g1 = x; b1 = c; }
            case 4 -> { r1 = x; g1 = 0f; b1 = c; }
            default -> { r1 = c; g1 = 0f; b1 = x; }
        }
        return new Color(r1 + m, g1 + m, b1 + m, alpha);
    }

    public static Color fromHSV(float h, float s, float v) { return fromHSV(h, s, v, 1f); }

    public float[] toHSV() {
        float maxC = Math.max(r, Math.max(g, b));
        float minC = Math.min(r, Math.min(g, b));
        float delta = maxC - minC;

        float h = 0f, s = 0f;
        if (delta != 0f) {
            s = delta / maxC;
            if (maxC == r) h = ((g - b) / delta) % 6f;
            else if (maxC == g) h = (b - r) / delta + 2f;
            else h = (r - g) / delta + 4f;
            h /= 6f;
            if (h < 0f) h += 1f;
        }

        return new float[]{ h, s, maxC };
    }

    public Color withHue(float hue) { return fromHSV(hue, toHSV()[1], toHSV()[2], a); }
    public Color withSaturation(float s) { float[] hsv = toHSV(); return fromHSV(hsv[0], s, hsv[2], a); }
    public Color withValue(float v) { float[] hsv = toHSV(); return fromHSV(hsv[0], hsv[1], v, a); }

    // ── Object ──────────────────────────────────────────────────────

    @Override public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Color c)) return false;
        return Float.compare(c.r, r) == 0 && Float.compare(c.g, g) == 0
                && Float.compare(c.b, b) == 0 && Float.compare(c.a, a) == 0;
    }

    @Override public int hashCode() { return Objects.hash(r, g, b, a); }

    @Override public String toString() {
        if (a < 1f) return String.format("Color(%.2f, %.2f, %.2f, %.2f)", r, g, b, a);
        return String.format("Color(%.2f, %.2f, %.2f)", r, g, b);
    }

    // ── Static factories ─────────────────────────────────────────────

    public static Color rgbInt(int rgb) {
        return new Color(((rgb >> 16) & 0xFF) / 255f,
                         ((rgb >> 8) & 0xFF) / 255f,
                         (rgb & 0xFF) / 255f,
                         1f);
    }

    public static Color argbInt(int argb) {
        return new Color(((argb >> 16) & 0xFF) / 255f,
                         ((argb >> 8) & 0xFF) / 255f,
                         (argb & 0xFF) / 255f,
                         ((argb >> 24) & 0xFF) / 255f);
    }

    public static Color lerp(Color a, Color b, float t) { return a.lerp(b, t); }

    public static Color random() {
        return new Color((float) Math.random(), (float) Math.random(), (float) Math.random(), 1f);
    }
}
