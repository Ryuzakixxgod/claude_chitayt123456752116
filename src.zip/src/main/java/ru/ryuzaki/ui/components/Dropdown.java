package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;
import ru.ryuzaki.ui.core.UIContainer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Dropdown extends UIComponent {

    private List<String> options = new ArrayList<>();
    private int selectedIndex = -1;
    private String selectedOption = "";

    private boolean isOpen = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;
    private boolean isAnimating = false;

    private float openProgress = 0f;
    private float hoverScale = 1f;
    private float itemRevealOffset = 0f;
    private float chevronRotation = 0f;

    private float width = 200f;
    private float height = 36f;
    private float itemHeight = 32f;
    private float borderRadius = 6f;
    private float borderWidth = 1.5f;
    private float chevronSize = 10f;
    private float padding = 12f;

    private int backgroundColor = 0xFFF5F5F5;
    private int hoverColor = 0xFFEEEEEE;
    private int openColor = 0xFFE0E0E0;
    private int selectedColor = 0xFF4CAF50;
    private int disabledColor = 0xFFFAFAFA;
    private int disabledTextColor = 0xFFBDBDBD;

    private int borderColor = 0xFFBDBDBD;
    private int borderHoverColor = 0xFF9E9E9E;
    private int borderOpenColor = 0xFF4CAF50;
    private int borderDisabledColor = 0xFFDDDDDD;

    private int textColor = 0xFF333333;
    private int selectedTextColor = 0xFFFFFFFF;
    private int itemHoverColor = 0xFFE8F5E9;
    private int itemTextColor = 0xFF333333;

    private boolean useGradient = false;
    private int gradientStartColor = 0xFF4CAF50;
    private int gradientEndColor = 0xFF8BC34A;

    private boolean glowEnabled = false;
    private float glowIntensity = 0f;
    private int glowColor = 0x804CAF50;

    private boolean showSearch = false;
    private boolean searchFocused = false;
    private String searchQuery = "";
    private float searchProgress = 0f;

    private boolean showScrollbar = false;
    private float scrollbarWidth = 6f;
    private float scrollPosition = 0f;
    private float scrollThumbSize = 30f;
    private float maxVisibleItems = 5f;

    private String placeholder = "Select...";
    private int placeholderColor = 0xFF999999;

    private Consumer<Dropdown> onSelect = dropdown -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;
    private Supplier<Integer> selectedIndexSupplier = () -> selectedIndex;

    private List<UIComponent> itemRenderers = new ArrayList<>();

    public Dropdown() {
        super();
        setClickable(true);
        updateDimensions();
    }

    public Dropdown(String... options) {
        this();
        setOptions(options);
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateDimensions();
    }

    private void updateDimensions() {
        float totalHeight = height;
        if (isOpen) {
            float maxDropdownHeight = itemHeight * maxVisibleItems;
            float dropdownHeight = Math.min(options.size() * itemHeight, maxDropdownHeight);
            if (showSearch) dropdownHeight += itemHeight;
            totalHeight += dropdownHeight + 4f;
        }
        setMinSize(width, totalHeight);
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        selectedIndex = selectedIndexSupplier.get();
        if (selectedIndex >= 0 && selectedIndex < options.size()) {
            selectedOption = options.get(selectedIndex);
        }

        isDisabled = isDisabledSupplier.get();

        boolean newHovered = isMouseOver() && !isDisabled;
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        float targetProgress = isOpen ? 1f : 0f;
        openProgress = Easing.lerp(openProgress, targetProgress, 0.2f);

        if (openProgress > 0.01f) {
            isAnimating = true;
        } else {
            isAnimating = false;
        }

        float targetScale = isHovered && !isDisabled && !isOpen ? 1.02f : 1f;
        hoverScale = Easing.lerp(hoverScale, targetScale, 0.15f);

        float targetRotation = isOpen ? 180f : 0f;
        chevronRotation = Easing.lerp(chevronRotation, targetRotation, 0.25f);

        if (showSearch) {
            float targetSearch = searchFocused || !searchQuery.isEmpty() ? 1f : 0f;
            searchProgress = Easing.lerp(searchProgress, targetSearch, 0.2f);
        }

        if (isOpen && options.size() > maxVisibleItems) {
            showScrollbar = true;
            scrollThumbSize = Math.max(20f, (maxVisibleItems / options.size()) * (maxVisibleItems * itemHeight));
        } else {
            showScrollbar = false;
        }

        if (glowEnabled && isOpen) {
            glowIntensity = Easing.lerp(glowIntensity, 1f, 0.15f);
        } else {
            glowIntensity = Easing.lerp(glowIntensity, 0f, 0.2f);
        }

        itemRevealOffset = Easing.easeOutBack(openProgress);
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float totalHeight = bounds.getHeight();

        Draw.pushMatrix();
        Draw.translate(x + width / 2f, y + height / 2f, 0);
        Draw.scale(hoverScale, hoverScale, 1f);
        Draw.translate(-(x + width / 2f), -(y + height / 2f), 0);

        renderTrigger(x, y);
        Draw.popMatrix();

        if (openProgress > 0.01f) {
            renderDropdown(x, y + height + 4f, width, partialTicks);
        }
    }

    private void renderTrigger(float x, float y) {
        int bgColor = getTriggerBackgroundColor();
        int bColor = getTriggerBorderColor();

        if (glowEnabled && glowIntensity > 0) {
            int glowCol = ((int)(glowIntensity * 0.3f * 255) << 24) | (glowColor & 0x00FFFFFF);
            Draw.drawRoundedRect(x - 3f, y - 3f, width + 6f, height + 6f,
                                borderRadius + 3f, glowCol);
        }

        Draw.drawRoundedRect(x, y, width, height, borderRadius, bgColor);
        Draw.drawRoundedRectOutline(x, y, width, height, borderRadius, borderWidth, bColor);

        String displayText = selectedIndex >= 0 ? selectedOption : placeholder;
        int textCol = selectedIndex >= 0
            ? (isDisabled ? disabledTextColor : textColor)
            : placeholderColor;

        if (selectedIndex >= 0 && useGradient && !isDisabled) {
            textCol = getGradientTextColor();
        }

        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        net.minecraft.client.gui.FontRenderer fr = mc.fontRendererObj;

        float textX = x + padding;
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f;

        String display = displayText;
        if (fr.getStringWidth(display) > width - padding * 2 - chevronSize - 8f) {
            while (fr.getStringWidth(display + "...") > width - padding * 2 - chevronSize - 8f && display.length() > 0) {
                display = display.substring(0, display.length() - 1);
            }
            display += "...";
        }

        Draw.drawString(display, textX, textY, textCol, 1f);

        float chevronX = x + width - padding - chevronSize;
        float chevronY = y + height / 2f;

        renderChevron(chevronX, chevronY);
    }

    private void renderChevron(float x, float y) {
        int chevronColor = isDisabled ? 0xFFAAAAAA : 0xFF666666;

        Draw.pushMatrix();
        Draw.translate(x + chevronSize / 2f, y, 0);
        Draw.rotate(0, 0, chevronRotation);
        Draw.translate(-(x + chevronSize / 2f), -y, 0);

        float size = chevronSize;
        Draw.drawLine(x, y - size / 3f, x + size / 2f, y, size * 0.6f, chevronColor);
        Draw.drawLine(x + size / 2f, y, x + size, y - size / 3f, size * 0.6f, chevronColor);

        Draw.popMatrix();
    }

    private void renderDropdown(float x, float y, float dropdownWidth, float partialTicks) {
        float maxDropdownHeight = itemHeight * maxVisibleItems;
        float actualHeight = Math.min(options.size() * itemHeight, maxDropdownHeight);

        if (showScrollbar) {
            renderScrollbar(x + dropdownWidth - scrollbarWidth - 2f, y + 2f, actualHeight - 4f);
        }

        Draw.pushMatrix();
        Draw.translate(0, y + actualHeight / 2f, 0);
        Draw.scale(1f, itemRevealOffset, 1f);
        Draw.translate(0, -(y + actualHeight / 2f), 0);

        int bgColor = isDisabled ? disabledColor : backgroundColor;
        Draw.drawRoundedRect(x, y, dropdownWidth, actualHeight, borderRadius, bgColor);
        Draw.drawRoundedRectOutline(x, y, dropdownWidth, actualHeight, borderRadius, borderWidth, borderColor);

        float searchY = y;
        if (showSearch && searchProgress > 0) {
            renderSearchBar(x + 4f, y + 4f, dropdownWidth - 8f);
            searchY = y + itemHeight;
        }

        float itemY = searchY + 4f;
        float visibleStart = (int)(scrollPosition / itemHeight);
        float visibleEnd = Math.min(options.size(), visibleStart + (int)maxVisibleItems);

        for (int i = visibleStart; i < visibleEnd; i++) {
            String option = options.get(i);
            boolean isSelected = i == selectedIndex;
            boolean itemHovered = isItemHovered(mouseX, mouseY, x, itemY, dropdownWidth);

            int itemBgColor;
            if (isDisabled) {
                itemBgColor = 0x00000000;
            } else if (isSelected) {
                itemBgColor = selectedColor;
            } else if (itemHovered) {
                itemBgColor = itemHoverColor;
            } else {
                itemBgColor = 0x00000000;
            }

            if (itemBgColor != 0x00000000) {
                float itemBgHeight = itemHeight - 4f;
                Draw.drawRoundedRect(x + 4f, itemY, dropdownWidth - 8f, itemBgHeight,
                                    borderRadius / 2, itemBgColor);
            }

            int itemTextCol;
            if (isDisabled) {
                itemTextCol = disabledTextColor;
            } else if (isSelected) {
                itemTextCol = selectedTextColor;
            } else {
                itemTextCol = itemTextColor;
            }

            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
            net.minecraft.client.gui.FontRenderer fr = mc.fontRendererObj;

            String displayOption = option;
            if (fr.getStringWidth(displayOption) > dropdownWidth - padding * 2 - 16f) {
                while (fr.getStringWidth(displayOption + "...") > dropdownWidth - padding * 2 - 16f
                       && displayOption.length() > 0) {
                    displayOption = displayOption.substring(0, displayOption.length() - 1);
                }
                displayOption += "...";
            }

            float textX = x + padding + 4f;
            float textY = itemY + itemHeight / 2f - fr.FONT_HEIGHT / 2f - 2f;

            if (isSelected && useGradient && !isDisabled) {
                Draw.drawString(displayOption, textX, textY, getGradientTextColor(), 1f);
            } else {
                Draw.drawString(displayOption, textX, textY, itemTextCol, 1f);
            }

            if (isSelected) {
                renderCheckmark(x + dropdownWidth - padding - 8f, itemY + itemHeight / 2f);
            }

            itemY += itemHeight;
        }

        Draw.popMatrix();
    }

    private void renderSearchBar(float x, float y, float searchWidth) {
        int searchBgColor = isDisabled ? 0xFFEEEEEE : 0xFFFFFFFF;
        float searchHeight = itemHeight - 8f;

        Draw.drawRoundedRect(x, y, searchWidth, searchHeight, borderRadius / 2, searchBgColor);
        Draw.drawRoundedRectOutline(x, y, searchWidth, searchHeight, borderRadius / 2,
                                   searchFocused ? 1.5f : 1f,
                                   searchFocused ? borderOpenColor : borderColor);

        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        net.minecraft.client.gui.FontRenderer fr = mc.fontRendererObj;

        float textX = x + 8f;
        float textY = y + searchHeight / 2f - fr.FONT_HEIGHT / 2f;

        if (searchQuery.isEmpty() && !searchFocused) {
            Draw.drawString("Search...", textX, textY, placeholderColor, 0.9f);
        } else {
            Draw.drawString(searchQuery, textX, textY, textColor, 1f);
        }
    }

    private void renderScrollbar(float x, float y, float height) {
        int trackColor = isDisabled ? 0xFFE0E0E0 : 0xFFE8E8E8;
        Draw.drawRoundedRect(x, y, scrollbarWidth, height, scrollbarWidth / 2, trackColor);

        float thumbY = y + scrollPosition / (options.size() * itemHeight - maxVisibleItems * itemHeight)
                      * (height - scrollThumbSize);
        thumbY = Math.max(y, Math.min(y + height - scrollThumbSize, thumbY));

        int thumbColor = isDisabled ? 0xFFCCCCCC : 0xFF9E9E9E;
        Draw.drawRoundedRect(x + 1f, thumbY, scrollbarWidth - 2f, scrollThumbSize,
                           scrollbarWidth / 2 - 1f, thumbColor);
    }

    private void renderCheckmark(float x, float y) {
        int checkColor = selectedTextColor;
        float size = 8f;

        float startX = x - size / 2f;
        float startY = y;
        float midX = x - size / 6f;
        float midY = y + size / 3f;
        float endX = x + size / 2f;
        float endY = y - size / 3f;

        Draw.drawLine(startX, startY, midX, midY, 2f, checkColor);
        Draw.drawLine(midX, midY, endX, endY, 2f, checkColor);
    }

    private boolean isItemHovered(int mouseX, int mouseY, float itemX, float itemY, float itemWidth) {
        return mouseX >= itemX + 4f && mouseX <= itemX + itemWidth - 4f
            && mouseY >= itemY && mouseY <= itemY + itemHeight;
    }

    private int getTriggerBackgroundColor() {
        if (isDisabled) return disabledColor;
        if (isOpen) return openColor;
        if (isHovered) return hoverColor;
        return backgroundColor;
    }

    private int getTriggerBorderColor() {
        if (isDisabled) return borderDisabledColor;
        if (isOpen) return borderOpenColor;
        if (isHovered) return borderHoverColor;
        return borderColor;
    }

    private int getGradientTextColor() {
        float progress = (float) (Math.sin(System.currentTimeMillis() / 500.0) * 0.5 + 0.5);

        int r1 = (gradientStartColor >> 16) & 0xFF;
        int g1 = (gradientStartColor >> 8) & 0xFF;
        int b1 = gradientStartColor & 0xFF;
        int r2 = (gradientEndColor >> 16) & 0xFF;
        int g2 = (gradientEndColor >> 8) & 0xFF;
        int b2 = gradientEndColor & 0xFF;

        int r = (int) (r1 + (r2 - r1) * progress);
        int g = (int) (g1 + (g2 - g1) * progress);
        int b = (int) (b1 + (b2 - b1) * progress);

        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        if (mouseY >= y && mouseY <= y + height) {
            if (isOpen) {
                close();
            } else {
                open();
            }
            return true;
        }

        if (isOpen && mouseY > y + height) {
            float dropdownY = y + height + 4f;
            float maxDropdownHeight = itemHeight * maxVisibleItems;
            float actualHeight = Math.min(options.size() * itemHeight, maxDropdownHeight);

            if (mouseY >= dropdownY && mouseY <= dropdownY + actualHeight) {
                float itemY = dropdownY + 4f;
                int clickIndex = (int) ((mouseY - itemY) / itemHeight);

                if (clickIndex >= 0 && clickIndex < options.size()) {
                    select(clickIndex);
                    return true;
                }
            }
        }

        close();
        return true;
    }

    private void open() {
        isOpen = true;
        updateDimensions();
    }

    private void close() {
        isOpen = false;
        searchQuery = "";
        updateDimensions();
    }

    private void select(int index) {
        if (index >= 0 && index < options.size()) {
            selectedIndex = index;
            selectedOption = options.get(index);
            onSelect.accept(this);
            close();
        }
    }

    public Dropdown setOptions(String... options) {
        this.options = new ArrayList<>(Arrays.asList(options));
        if (this.options.size() > 0 && selectedIndex < 0) {
            selectedIndex = 0;
            selectedOption = this.options.get(0);
        }
        updateDimensions();
        return this;
    }

    public Dropdown addOption(String option) {
        this.options.add(option);
        if (selectedIndex < 0) {
            selectedIndex = 0;
            selectedOption = option;
        }
        updateDimensions();
        return this;
    }

    public Dropdown removeOption(String option) {
        int index = options.indexOf(option);
        if (index >= 0) {
            options.remove(index);
            if (selectedIndex == index) {
                selectedIndex = options.size() > 0 ? 0 : -1;
                selectedOption = selectedIndex >= 0 ? options.get(selectedIndex) : "";
            } else if (selectedIndex > index) {
                selectedIndex--;
            }
        }
        updateDimensions();
        return this;
    }

    public Dropdown selectIndex(int index) {
        select(index);
        return this;
    }

    public Dropdown selectValue(String value) {
        int index = options.indexOf(value);
        if (index >= 0) {
            select(index);
        }
        return this;
    }

    public int getSelectedIndex() { return selectedIndex; }
    public String getSelectedOption() { return selectedOption; }
    public List<String> getOptions() { return new ArrayList<>(options); }
    public boolean isOpen() { return isOpen; }
    public boolean isDisabled() { return isDisabled; }

    public Dropdown setWidth(float width) {
        this.width = width;
        updateDimensions();
        return this;
    }

    public Dropdown setHeight(float height) {
        this.height = height;
        this.itemHeight = height - 4f;
        updateDimensions();
        return this;
    }

    public Dropdown setItemHeight(float itemHeight) {
        this.itemHeight = itemHeight;
        updateDimensions();
        return this;
    }

    public Dropdown setMaxVisibleItems(float max) {
        this.maxVisibleItems = max;
        updateDimensions();
        return this;
    }

    public Dropdown setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public Dropdown setBorder(float width, int color) {
        this.borderWidth = width;
        this.borderColor = color;
        return this;
    }

    public Dropdown setColors(int bg, int border) {
        this.backgroundColor = bg;
        this.borderColor = border;
        return this;
    }

    public Dropdown setSelectedColor(int color) {
        this.selectedColor = color;
        return this;
    }

    public Dropdown setTextColor(int color) {
        this.textColor = color;
        this.itemTextColor = color;
        return this;
    }

    public Dropdown setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
        return this;
    }

    public Dropdown setPlaceholderColor(int color) {
        this.placeholderColor = color;
        return this;
    }

    public Dropdown setUseGradient(boolean use) {
        this.useGradient = use;
        return this;
    }

    public Dropdown setGradientColors(int start, int end) {
        this.gradientStartColor = start;
        this.gradientEndColor = end;
        return this;
    }

    public Dropdown setGlowEnabled(boolean enabled) {
        this.glowEnabled = enabled;
        return this;
    }

    public Dropdown setGlowColor(int color) {
        this.glowColor = color;
        return this;
    }

    public Dropdown setShowSearch(boolean show) {
        this.showSearch = show;
        updateDimensions();
        return this;
    }

    public Dropdown setOnSelect(Consumer<Dropdown> onSelect) {
        this.onSelect = onSelect;
        return this;
    }

    public Dropdown setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public Dropdown setSelectedIndexSupplier(Supplier<Integer> supplier) {
        this.selectedIndexSupplier = supplier;
        return this;
    }

    @Override
    public String toString() {
        return "Dropdown{selected=" + selectedOption + ", options=" + options.size() +
               ", isOpen=" + isOpen + '}';
    }
}
