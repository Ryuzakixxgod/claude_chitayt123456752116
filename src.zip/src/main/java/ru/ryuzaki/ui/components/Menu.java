package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Menu extends UIComponent {

    public enum MenuAnchor {
        TOP_LEFT,
        TOP_RIGHT,
        BOTTOM_LEFT,
        BOTTOM_RIGHT,
        CENTER
    }

    public enum MenuAnimation {
        NONE,
        SLIDE,
        FADE,
        SLIDE_FADE
    }

    private List<MenuItem> items = new ArrayList<>();
    private List<MenuItem> visibleItems = new ArrayList<>();

    private float menuWidth = 150f;
    private float itemHeight = 28f;
    private float padding = 4f;
    private float itemSpacing = 0f;
    private float borderRadius = 6f;
    private float shadowOffset = 4f;
    private float shadowBlur = 8f;

    private float openProgress = 0f;
    private float closeProgress = 1f;
    private float animationDuration = 0.2f;
    private float currentAnimationTime = 0f;

    private boolean isOpen = false;
    private boolean isAnimating = false;
    private boolean hasFocus = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;

    private MenuAnchor anchor = MenuAnchor.TOP_LEFT;
    private MenuAnimation animation = MenuAnimation.SLIDE_FADE;
    private MenuDirection direction = MenuDirection.DOWN;

    private int backgroundColor = 0xFFFFFFFF;
    private int hoverColor = 0xFFE3F2FD;
    private int activeColor = 0xFFBBDEFB;
    private int disabledColor = 0xFFBDBDBD;
    private int separatorColor = 0xFFEEEEEE;
    private int textColor = 0xFF333333;
    private int headerColor = 0xFF757575;
    private int borderColor = 0xFFE0E0E0;
    private int shadowColor = 0x30000000;

    private int hoverBackgroundColor = 0xFFE3F2FD;
    private int selectedBackgroundColor = 0xFFBBDEFB;
    private int shortcutColor = 0xFF9E9E9E;

    private MenuItem hoveredItem = null;
    private MenuItem selectedItem = null;

    private boolean showIcons = true;
    private boolean showShortcuts = true;
    private boolean showSeparators = true;
    private boolean showHeader = false;
    private String headerText = "";

    private boolean scrollEnabled = false;
    private float scrollPosition = 0f;
    private float maxScroll = 0f;
    private float visibleItemsCount = 10f;

    private float hoverScale = 1f;
    private float glowIntensity = 0f;

    private Consumer<Menu> onOpen = menu -> {};
    private Consumer<Menu> onClose = menu -> {};
    private Consumer<MenuItem> onItemClick = item -> {};
    private Supplier<Boolean> disabledSupplier = () -> isDisabled;

    public Menu() {
        super();
        setPassEvents(true);
    }

    public Menu(float width) {
        this();
        this.menuWidth = width;
        setMinSize(width, itemHeight);
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateVisibleItems();
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        isDisabled = disabledSupplier.get();

        boolean newHovered = isMouseOver();
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        updateAnimation(partialTicks);

        hoveredItem = getItemAtPosition(mouseX, mouseY);

        for (MenuItem item : visibleItems) {
            item.update(mouseX, mouseY, partialTicks);
        }

        float targetScale = isHovered && !isDisabled ? 1.02f : 1f;
        hoverScale = Easing.lerp(hoverScale, targetScale, 0.1f);

        if (isOpen || isAnimating) {
            glowIntensity = Easing.lerp(glowIntensity, 0.3f, 0.15f);
        } else {
            glowIntensity = Easing.lerp(glowIntensity, 0f, 0.15f);
        }
    }

    private void updateAnimation(float partialTicks) {
        if (!isAnimating) return;

        currentAnimationTime += partialTicks / 60f;
        float t = Math.min(1f, currentAnimationTime / animationDuration);

        if (isOpen) {
            openProgress = Easing.outCubic(t);
            closeProgress = 1f - openProgress;
        } else {
            closeProgress = Easing.outCubic(t);
            openProgress = 1f - closeProgress;
        }

        if (t >= 1f) {
            isAnimating = false;
            if (!isOpen) {
                openProgress = 0f;
                closeProgress = 1f;
            } else {
                openProgress = 1f;
                closeProgress = 0f;
            }
        }
    }

    private void updateVisibleItems() {
        visibleItems.clear();
        for (MenuItem item : items) {
            if (item.isVisible()) {
                visibleItems.add(item);
            }
        }

        if (scrollEnabled) {
            float totalHeight = visibleItems.size() * (itemHeight + itemSpacing) + padding * 2;
            maxScroll = Math.max(0, totalHeight - visibleItemsCount * (itemHeight + itemSpacing));
        }
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        Draw.pushMatrix();

        if (glowIntensity > 0) {
            int glowCol = ((int)(glowIntensity * 0.3f * 255) << 24) | (shadowColor & 0x00FFFFFF);
            Draw.drawShadow(x, y + shadowOffset, width, height, shadowBlur, glowCol);
        }

        if (isOpen || closeProgress > 0) {
            renderMenu(x, y, width, height, partialTicks);
        }

        Draw.popMatrix();
    }

    private void renderMenu(float x, float y, float width, float height, float partialTicks) {
        float actualHeight = getMenuHeight();
        float animY = y;
        float animHeight = actualHeight;
        float animAlpha = 1f;

        switch (animation) {
            case SLIDE:
                animY = y - actualHeight * (1f - openProgress);
                animHeight = actualHeight * openProgress;
                break;
            case FADE:
                animAlpha = openProgress;
                break;
            case SLIDE_FADE:
                float slideAmount = actualHeight * (1f - openProgress);
                animY = y - slideAmount * 0.5f;
                animHeight = actualHeight * openProgress;
                animAlpha = openProgress;
                break;
            case NONE:
            default:
                break;
        }

        if (animHeight <= 0 || animAlpha <= 0) return;

        Draw.drawRoundedRect(x, animY, width, animHeight, borderRadius, backgroundColor);
        Draw.drawRoundedRectOutline(x, animY, width, animHeight, borderRadius, 1, borderColor);

        if (scrollEnabled) {
            Draw.enableScissor((int)x, (int)(animY + animHeight), (int)(x + width), (int)animY);
        }

        Draw.pushMatrix();

        float renderY = animY + padding - scrollPosition;

        if (showHeader && !headerText.isEmpty()) {
            renderHeader(x, renderY, width);
            renderY += itemHeight;
        }

        for (int i = 0; i < visibleItems.size(); i++) {
            MenuItem item = visibleItems.get(i);

            if (renderY + itemHeight < animY || renderY > animY + animHeight) {
                renderY += itemHeight + itemSpacing;
                continue;
            }

            boolean isItemHovered = item == hoveredItem;
            boolean isItemSelected = item == selectedItem;

            if (item.isSeparator()) {
                renderSeparator(x, renderY, width);
            } else {
                renderMenuItem(item, x, renderY, width, isItemHovered, isItemSelected);
            }

            renderY += itemHeight + itemSpacing;
        }

        Draw.popMatrix();

        if (scrollEnabled) {
            Draw.disableScissor();
            renderScrollbar(x, animY, width, animHeight);
        }
    }

    private void renderHeader(float x, float y, float width) {
        Draw.drawRect(x + padding, y, width - padding * 2, 1, separatorColor);

        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        float textY = y + itemHeight / 2f - fr.FONT_HEIGHT / 2f;
        Draw.drawString(headerText, x + padding, textY, headerColor, 0.8f);
    }

    private void renderMenuItem(MenuItem item, float x, float y, float width,
                               boolean isHovered, boolean isSelected) {
        float itemX = x + padding;
        float itemWidth = width - padding * 2;
        float itemY = y;
        float radius = Math.min(borderRadius / 2f, 4f);

        int bgColor;
        if (!item.isEnabled()) {
            bgColor = 0x00000000;
        } else if (isSelected) {
            bgColor = selectedBackgroundColor;
        } else if (isHovered) {
            bgColor = hoverBackgroundColor;
        } else {
            bgColor = 0x00000000;
        }

        if (bgColor != 0x00000000) {
            Draw.drawRoundedRect(itemX, itemY + 2, itemWidth, itemHeight - 4, radius, bgColor);
        }

        if (showIcons && item.getIcon() != null) {
            int iconSize = 16;
            float iconX = itemX + 4;
            float iconY = itemY + itemHeight / 2f - iconSize / 2f;
            Draw.drawTexture(item.getIcon(), iconX, iconY, iconSize, iconSize, 1f);
        }

        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        float textX = itemX + (showIcons ? 24 : 0);
        float textY = itemY + itemHeight / 2f - fr.FONT_HEIGHT / 2f;

        int textCol = !item.isEnabled() ? disabledColor :
                     (isSelected ? fillColor : textColor);

        Draw.drawString(item.getLabel(), textX, textY, textCol, 1f);

        if (showShortcuts && item.getShortcut() != null && !item.getShortcut().isEmpty()) {
            float shortcutX = x + width - padding - fr.getStringWidth(item.getShortcut()) - 4;
            Draw.drawString(item.getShortcut(), shortcutX, textY, shortcutColor, 0.7f);
        }

        if (item.hasSubmenu()) {
            float arrowX = x + width - padding - 8;
            float arrowY = itemY + itemHeight / 2f;
            Draw.drawArrowRight(arrowX, arrowY, 4, textCol);
        }
    }

    private void renderSeparator(float x, float y, float width) {
        float sepX = x + padding + (showIcons ? 20 : 0);
        float sepWidth = width - padding * 2 - (showIcons ? 20 : 0);
        Draw.drawRect(sepX, y + itemHeight / 2f, sepWidth, 1, separatorColor);
    }

    private void renderScrollbar(float x, float y, float width, float height) {
        if (maxScroll <= 0) return;

        float scrollbarWidth = 4f;
        float scrollbarX = x + width - scrollbarWidth - 2f;
        float scrollbarHeight = Math.max(20f, height * (visibleItemsCount / visibleItems.size()));
        float scrollbarY = y + 2f + (height - scrollbarHeight - 4f) * (scrollPosition / maxScroll);

        Draw.drawRoundedRect(scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight, 2, 0x40000000);
    }

    private float getMenuHeight() {
        float height = padding * 2;

        if (showHeader && !headerText.isEmpty()) {
            height += itemHeight;
        }

        int visibleCount = scrollEnabled ?
            Math.min((int) visibleItemsCount, visibleItems.size()) :
            visibleItems.size();

        height += visibleCount * (itemHeight + itemSpacing);

        return height;
    }

    private MenuItem getItemAtPosition(int mouseX, int mouseY) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();

        if (!isOpen) return null;

        float menuHeight = getMenuHeight();
        float actualY = y;

        switch (animation) {
            case SLIDE:
                actualY = y - menuHeight * (1f - openProgress);
                break;
            case SLIDE_FADE:
                actualY = y - menuHeight * (1f - openProgress) * 0.5f;
                break;
            default:
                break;
        }

        if (mouseX < x || mouseX > x + width ||
            mouseY < actualY || mouseY > actualY + menuHeight * openProgress) {
            return null;
        }

        float renderY = actualY + padding - scrollPosition;

        if (showHeader && !headerText.isEmpty()) {
            renderY += itemHeight;
        }

        for (MenuItem item : visibleItems) {
            if (item.isSeparator()) {
                renderY += itemHeight + itemSpacing;
                continue;
            }

            if (mouseY >= renderY && mouseY < renderY + itemHeight) {
                return item;
            }
            renderY += itemHeight + itemSpacing;
        }

        return null;
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        MenuItem item = getItemAtPosition(mouseX, mouseY);

        if (item != null && item.isEnabled() && !item.isSeparator()) {
            if (item.hasSubmenu()) {
                item.getSubmenu().open();
                return true;
            }

            selectedItem = item;
            onItemClick.accept(item);
            close();
            return true;
        }

        return false;
    }

    public Menu open() {
        if (isOpen) return this;

        isOpen = true;
        isAnimating = true;
        currentAnimationTime = 0f;
        onOpen.accept(this);

        return this;
    }

    public Menu close() {
        if (!isOpen) return this;

        isOpen = false;
        isAnimating = true;
        currentAnimationTime = 0f;
        hoveredItem = null;
        onClose.accept(this);

        return this;
    }

    public Menu toggle() {
        if (isOpen) {
            close();
        } else {
            open();
        }
        return this;
    }

    public Menu addItem(String label) {
        return addItem(label, null, null);
    }

    public Menu addItem(String label, String shortcut) {
        return addItem(label, shortcut, null);
    }

    public Menu addItem(String label, String shortcut, Consumer<MenuItem> onClick) {
        MenuItem item = new MenuItem(label, shortcut, onClick);
        items.add(item);
        updateVisibleItems();
        return this;
    }

    public Menu addSeparator() {
        MenuItem separator = new MenuItem();
        separator.setSeparator(true);
        items.add(separator);
        updateVisibleItems();
        return this;
    }

    public Menu addSubmenu(String label, Menu submenu) {
        MenuItem item = new MenuItem(label);
        item.setSubmenu(submenu);
        items.add(item);
        updateVisibleItems();
        return this;
    }

    public Menu removeItem(MenuItem item) {
        items.remove(item);
        visibleItems.remove(item);
        updateVisibleItems();
        return this;
    }

    public Menu removeItem(int index) {
        if (index >= 0 && index < items.size()) {
            MenuItem item = items.remove(index);
            visibleItems.remove(item);
            updateVisibleItems();
        }
        return this;
    }

    public Menu clearItems() {
        items.clear();
        visibleItems.clear();
        hoveredItem = null;
        selectedItem = null;
        return this;
    }

    public MenuItem getItem(int index) {
        return index >= 0 && index < items.size() ? items.get(index) : null;
    }

    public List<MenuItem> getItems() {
        return new ArrayList<>(items);
    }

    public int getItemCount() {
        return items.size();
    }

    public Menu setWidth(float width) {
        this.menuWidth = width;
        setMinSize(width, itemHeight);
        return this;
    }

    public Menu setItemHeight(float height) {
        this.itemHeight = height;
        return this;
    }

    public Menu setColors(int background, int hover, int active, int disabled, int text) {
        this.backgroundColor = background;
        this.hoverBackgroundColor = hover;
        this.selectedBackgroundColor = active;
        this.disabledColor = disabled;
        this.textColor = text;
        return this;
    }

    public Menu setBackgroundColor(int color) {
        this.backgroundColor = color;
        return this;
    }

    public Menu setHoverColor(int color) {
        this.hoverBackgroundColor = color;
        return this;
    }

    public Menu setSelectedColor(int color) {
        this.selectedBackgroundColor = color;
        return this;
    }

    public Menu setTextColor(int color) {
        this.textColor = color;
        return this;
    }

    public Menu setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public Menu setAnchor(MenuAnchor anchor) {
        this.anchor = anchor;
        return this;
    }

    public Menu setAnimation(MenuAnimation anim) {
        this.animation = anim;
        return this;
    }

    public Menu setAnimationDuration(float duration) {
        this.animationDuration = duration;
        return this;
    }

    public Menu setDirection(MenuDirection dir) {
        this.direction = dir;
        return this;
    }

    public Menu setShowIcons(boolean show) {
        this.showIcons = show;
        return this;
    }

    public Menu setShowShortcuts(boolean show) {
        this.showShortcuts = show;
        return this;
    }

    public Menu setShowSeparators(boolean show) {
        this.showSeparators = show;
        return this;
    }

    public Menu setShowHeader(boolean show, String text) {
        this.showHeader = show;
        this.headerText = text != null ? text : "";
        return this;
    }

    public Menu setScrollEnabled(boolean enabled) {
        this.scrollEnabled = enabled;
        return this;
    }

    public Menu setVisibleItemsCount(float count) {
        this.visibleItemsCount = count;
        return this;
    }

    public Menu setOnOpen(Consumer<Menu> onOpen) {
        this.onOpen = onOpen;
        return this;
    }

    public Menu setOnClose(Consumer<Menu> onClose) {
        this.onClose = onClose;
        return this;
    }

    public Menu setOnItemClick(Consumer<MenuItem> onClick) {
        this.onItemClick = onClick;
        return this;
    }

    public Menu setDisabled(boolean disabled) {
        this.isDisabled = disabled;
        return this;
    }

    public Menu setDisabledSupplier(Supplier<Boolean> supplier) {
        this.disabledSupplier = supplier;
        return this;
    }

    public boolean isOpen() { return isOpen; }
    public boolean isAnimating() { return isAnimating; }
    public boolean hasFocus() { return hasFocus; }
    public MenuItem getHoveredItem() { return hoveredItem; }
    public MenuItem getSelectedItem() { return selectedItem; }

    public enum MenuDirection {
        UP, DOWN, LEFT, RIGHT
    }

    public static class MenuItem {
        private String label;
        private String shortcut;
        private Consumer<MenuItem> onClick;
        private Menu submenu;
        private Object icon;
        private boolean enabled = true;
        private boolean visible = true;
        private boolean separator = false;

        public MenuItem() {
            this.separator = true;
        }

        public MenuItem(String label) {
            this.label = label;
        }

        public MenuItem(String label, String shortcut, Consumer<MenuItem> onClick) {
            this.label = label;
            this.shortcut = shortcut;
            this.onClick = onClick;
        }

        public void update(int mouseX, int mouseY, float partialTicks) {
        }

        public String getLabel() { return label; }
        public String getShortcut() { return shortcut; }
        public Object getIcon() { return icon; }
        public boolean isEnabled() { return enabled; }
        public boolean isVisible() { return visible; }
        public boolean isSeparator() { return separator; }
        public boolean hasSubmenu() { return submenu != null; }
        public Menu getSubmenu() { return submenu; }
        public Consumer<MenuItem> getOnClick() { return onClick; }

        public MenuItem setLabel(String label) {
            this.label = label;
            return this;
        }

        public MenuItem setShortcut(String shortcut) {
            this.shortcut = shortcut;
            return this;
        }

        public MenuItem setIcon(Object icon) {
            this.icon = icon;
            return this;
        }

        public MenuItem setEnabled(boolean enabled) {
            this.enabled = enabled;
            return this;
        }

        public MenuItem setVisible(boolean visible) {
            this.visible = visible;
            return this;
        }

        public MenuItem setSeparator(boolean separator) {
            this.separator = separator;
            return this;
        }

        public MenuItem setSubmenu(Menu submenu) {
            this.submenu = submenu;
            return this;
        }

        public MenuItem setOnClick(Consumer<MenuItem> onClick) {
            this.onClick = onClick;
            return this;
        }

        public void click() {
            if (enabled && onClick != null) {
                onClick.accept(this);
            }
        }
    }

    @Override
    public String toString() {
        return "Menu{items=" + items.size() + ", open=" + isOpen + ", animating=" + isAnimating + "}";
    }

    private static class Minecraft {
        public static net.minecraft.client.Minecraft getMinecraft() {
            return net.minecraft.client.Minecraft.getMinecraft();
        }
    }

    private static class FontRenderer {
        public static int getFontHeight() {
            return getMinecraft().fontRendererObj.FONT_HEIGHT;
        }

        public static float getStringWidth(String text) {
            return getMinecraft().fontRendererObj.getStringWidth(text);
        }
    }
}
