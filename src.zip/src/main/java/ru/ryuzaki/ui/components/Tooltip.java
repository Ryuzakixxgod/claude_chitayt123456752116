package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class Tooltip extends UIComponent {

    public enum TooltipPosition {
        TOP,
        BOTTOM,
        LEFT,
        RIGHT,
        FOLLOW
    }

    private List<String> lines = new ArrayList<>();
    private String title = "";
    private String description = "";

    private float padding = 6f;
    private float maxWidth = 200f;
    private float borderRadius = 4f;
    private float borderWidth = 1f;
    private float arrowSize = 6f;
    private float fadeDistance = 0f;

    private float showDelay = 0.5f;
    private float hideDelay = 0.1f;
    private float currentShowTime = 0f;
    private float currentHideTime = 0f;
    private float fadeProgress = 0f;

    private boolean isVisible = false;
    private boolean isAnimating = false;
    private boolean followMouse = false;
    private boolean showArrow = true;

    private TooltipPosition preferredPosition = TooltipPosition.TOP;
    private TooltipPosition actualPosition = TooltipPosition.TOP;

    private float offsetX = 10f;
    private float offsetY = 10f;
    private float pivotX = 0.5f;
    private float pivotY = 0.5f;

    private int backgroundColor = 0xF0000000;
    private int titleColor = 0xFFFFFFFF;
    private int textColor = 0xFFE0E0E0;
    private int borderColor = 0xFF424242;
    private int arrowColor = 0xF0000000;

    private int titleSize = 14;
    private int textSize = 12;
    private boolean wordWrap = true;
    private int maxLines = 10;

    private float calculatedWidth = 0f;
    private float calculatedHeight = 0f;

    private Supplier<String> textSupplier = () -> "";
    private Supplier<List<String>> linesSupplier = () -> new ArrayList<>();

    public Tooltip() {
        super();
        setPassEvents(false);
        setVisible(false);
    }

    public Tooltip(String text) {
        this();
        setText(text);
    }

    public Tooltip(String title, String description) {
        this();
        this.title = title;
        this.description = description;
        updateText();
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        updateFromSuppliers();

        if (followMouse) {
            updateFollowPosition(mouseX, mouseY);
        }

        if (isVisible) {
            currentHideTime = 0f;
            currentShowTime += partialTicks / 60f;
            float targetFade = currentShowTime >= showDelay ? 1f : currentShowTime / showDelay;
            fadeProgress = Easing.lerp(fadeProgress, targetFade, 0.2f);

            if (currentShowTime >= showDelay && !isAnimating) {
                isAnimating = true;
            }
        } else {
            currentShowTime = 0f;
            currentHideTime += partialTicks / 60f;
            float targetFade = currentHideTime >= hideDelay ? 0f : 1f - (currentHideTime / hideDelay);
            fadeProgress = Easing.lerp(fadeProgress, Math.max(0, targetFade), 0.2f);

            if (fadeProgress <= 0.01f) {
                isAnimating = false;
                setVisible(false);
            }
        }
    }

    private void updateFromSuppliers() {
        String supplierText = textSupplier.get();
        if (supplierText != null && !supplierText.isEmpty()) {
            setText(supplierText);
        }

        List<String> supplierLines = linesSupplier.get();
        if (supplierLines != null && !supplierLines.isEmpty()) {
            this.lines = new ArrayList<>(supplierLines);
        }
    }

    private void updateFollowPosition(int mouseX, int mouseY) {
        BoundingBox parentBounds = getParent() != null ? getParent().getBounds() : new BoundingBox(0, 0, 0, 0);

        float x = mouseX + offsetX;
        float y = mouseY + offsetY;

        float screenWidth = 1920f;
        float screenHeight = 1080f;

        if (x + calculatedWidth > screenWidth) {
            x = mouseX - calculatedWidth - offsetX;
        }
        if (y + calculatedHeight > screenHeight) {
            y = mouseY - calculatedHeight - offsetY;
        }

        actualPosition = preferredPosition;
        switch (actualPosition) {
            case TOP:
                y = mouseY - calculatedHeight - offsetY;
                break;
            case BOTTOM:
                y = mouseY + offsetY;
                break;
            case LEFT:
                x = mouseX - calculatedWidth - offsetX;
                break;
            case RIGHT:
                x = mouseX + offsetX;
                break;
        }

        setPosition(x, y);
    }

    @Override
    public void render(float partialTicks) {
        if (fadeProgress <= 0.01f) return;

        calculateSize();

        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        Draw.pushMatrix();
        Draw.setAlpha((int)(fadeProgress * 255));

        int bgColor = ((int)(fadeProgress * 0xF0) << 24) | (backgroundColor & 0x00FFFFFF);
        int borderCol = ((int)(fadeProgress * 0xFF) << 24) | (borderColor & 0x00FFFFFF);

        Draw.drawRoundedRect(x, y, width, height, borderRadius, bgColor);
        Draw.drawRoundedRectOutline(x, y, width, height, borderRadius, borderWidth, borderCol);

        float renderY = y + padding;
        float contentX = x + padding;
        float contentWidth = width - padding * 2;

        if (!title.isEmpty()) {
            renderTitle(contentX, renderY, contentWidth);
            renderY += titleSize + 4;
        }

        if (!description.isEmpty()) {
            renderDescription(contentX, renderY, contentWidth);
        }

        if (!lines.isEmpty()) {
            renderLines(contentX, renderY, contentWidth);
        }

        if (showArrow) {
            renderArrow(x, y, width, height);
        }

        Draw.setAlpha(255);
        Draw.popMatrix();
    }

    private void calculateSize() {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        float contentWidth = 0f;

        if (!title.isEmpty()) {
            float titleWidth = fr.getStringWidth(title);
            contentWidth = Math.max(contentWidth, titleWidth);
        }

        if (!description.isEmpty()) {
            if (wordWrap) {
                List<String> wrapped = wrapText(description, maxWidth - padding * 2);
                for (String line : wrapped) {
                    contentWidth = Math.max(contentWidth, fr.getStringWidth(line));
                }
            } else {
                contentWidth = Math.max(contentWidth, fr.getStringWidth(description));
            }
        }

        for (String line : lines) {
            contentWidth = Math.max(contentWidth, fr.getStringWidth(line));
        }

        calculatedWidth = Math.min(contentWidth + padding * 2, maxWidth);
        calculatedHeight = padding * 2;

        if (!title.isEmpty()) {
            calculatedHeight += titleSize + 4;
        }

        if (!description.isEmpty()) {
            if (wordWrap) {
                List<String> wrapped = wrapText(description, maxWidth - padding * 2);
                calculatedHeight += wrapped.size() * (textSize + 2);
            } else {
                calculatedHeight += textSize + 2;
            }
        }

        calculatedHeight += lines.size() * (textSize + 2);

        if (showArrow) {
            calculatedHeight += arrowSize;
        }

        setMinSize(calculatedWidth, calculatedHeight);
    }

    private void renderTitle(float x, float y, float maxWidth) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        int titleCol = ((int)(fadeProgress * 255) << 24) | (titleColor & 0x00FFFFFF);

        if (wordWrap && fr.getStringWidth(title) > maxWidth) {
            List<String> wrapped = wrapText(title, maxWidth);
            float lineY = y;
            for (String line : wrapped) {
                if (lineY > y + titleSize * 2) break;
                Draw.drawString(line, x, lineY, titleCol, 1f);
                lineY += titleSize + 2;
            }
        } else {
            Draw.drawString(title, x, y, titleCol, 1f);
        }
    }

    private void renderDescription(float x, float y, float maxWidth) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        int descCol = ((int)(fadeProgress * 255) << 24) | (textColor & 0x00FFFFFF);
        List<String> textLines = wordWrap ? wrapText(description, maxWidth) :
                                 List.of(description);

        float lineY = y;
        int linesRendered = 0;
        for (String line : textLines) {
            if (linesRendered >= maxLines) break;
            Draw.drawString(line, x, lineY, descCol, 1f);
            lineY += textSize + 2;
            linesRendered++;
        }
    }

    private void renderLines(float x, float startY, float maxWidth) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        int textCol = ((int)(fadeProgress * 255) << 24) | (textColor & 0x00FFFFFF);

        float lineY = startY;
        int linesRendered = 0;
        for (String line : lines) {
            if (linesRendered >= maxLines) break;

            if (wordWrap && fr.getStringWidth(line) > maxWidth) {
                List<String> wrapped = wrapText(line, maxWidth);
                for (String wrappedLine : wrapped) {
                    if (linesRendered >= maxLines) break;
                    Draw.drawString(wrappedLine, x, lineY, textCol, 1f);
                    lineY += textSize + 2;
                    linesRendered++;
                }
            } else {
                Draw.drawString(line, x, lineY, textCol, 1f);
                lineY += textSize + 2;
                linesRendered++;
            }
        }
    }

    private void renderArrow(float x, float y, float width, float height) {
        int arrowCol = ((int)(fadeProgress * 0xF0) << 24) | (backgroundColor & 0x00FFFFFF);

        float ax, ay1, ay2;

        switch (actualPosition) {
            case TOP:
                ax = x + width / 2f;
                ay1 = y;
                Draw.drawTriangleDown(ax, ay1, arrowSize, arrowCol);
                break;
            case BOTTOM:
                ax = x + width / 2f;
                ay1 = y + height;
                Draw.drawTriangleUp(ax, ay1, arrowSize, arrowCol);
                break;
            case LEFT:
                float ay = y + height / 2f;
                Draw.drawTriangleRight(x, ay, arrowSize, arrowCol);
                break;
            case RIGHT:
                float ry = y + height / 2f;
                Draw.drawTriangleLeft(x + width, ry, arrowSize, arrowCol);
                break;
        }
    }

    private List<String> wrapText(String text, float maxWidth) {
        List<String> result = new ArrayList<>();
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        String[] words = text.split(" ");
        StringBuilder currentLine = new StringBuilder();

        for (String word : words) {
            String testLine = currentLine.length() > 0 ? currentLine + " " + word : word;
            if (fr.getStringWidth(testLine) <= maxWidth) {
                currentLine = new StringBuilder(testLine);
            } else {
                if (currentLine.length() > 0) {
                    result.add(currentLine.toString());
                }
                currentLine = new StringBuilder(word);
            }
        }

        if (currentLine.length() > 0) {
            result.add(currentLine.toString());
        }

        return result;
    }

    public Tooltip show() {
        this.isVisible = true;
        setVisible(true);
        currentShowTime = 0f;
        fadeProgress = 0f;
        return this;
    }

    public Tooltip hide() {
        this.isVisible = false;
        currentHideTime = 0f;
        return this;
    }

    public Tooltip setText(String text) {
        this.description = text;
        this.lines.clear();
        updateText();
        return this;
    }

    public Tooltip setTitle(String title) {
        this.title = title;
        return this;
    }

    public Tooltip setDescription(String description) {
        this.description = description;
        return this;
    }

    public Tooltip setLines(List<String> lines) {
        this.lines = new ArrayList<>(lines);
        return this;
    }

    public Tooltip addLine(String line) {
        this.lines.add(line);
        return this;
    }

    private void updateText() {
        calculateSize();
    }

    public Tooltip setPosition(float x, float y) {
        setBounds(new BoundingBox(x, y, calculatedWidth, calculatedHeight));
        return this;
    }

    public Tooltip setOffset(float x, float y) {
        this.offsetX = x;
        this.offsetY = y;
        return this;
    }

    public Tooltip setPivot(float x, float y) {
        this.pivotX = x;
        this.pivotY = y;
        return this;
    }

    public Tooltip setPreferredPosition(TooltipPosition position) {
        this.preferredPosition = position;
        return this;
    }

    public Tooltip setMaxWidth(float width) {
        this.maxWidth = width;
        calculateSize();
        return this;
    }

    public Tooltip setPadding(float padding) {
        this.padding = padding;
        return this;
    }

    public Tooltip setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public Tooltip setColors(int background, int text, int border) {
        this.backgroundColor = background;
        this.textColor = text;
        this.borderColor = border;
        return this;
    }

    public Tooltip setBackgroundColor(int color) {
        this.backgroundColor = color;
        return this;
    }

    public Tooltip setTitleColor(int color) {
        this.titleColor = color;
        return this;
    }

    public Tooltip setTextColor(int color) {
        this.textColor = color;
        return this;
    }

    public Tooltip setTitleSize(int size) {
        this.titleSize = size;
        return this;
    }

    public Tooltip setTextSize(int size) {
        this.textSize = size;
        return this;
    }

    public Tooltip setShowDelay(float delay) {
        this.showDelay = delay;
        return this;
    }

    public Tooltip setHideDelay(float delay) {
        this.hideDelay = delay;
        return this;
    }

    public Tooltip setShowArrow(boolean show) {
        this.showArrow = show;
        return this;
    }

    public Tooltip setFollowMouse(boolean follow) {
        this.followMouse = follow;
        return this;
    }

    public Tooltip setWordWrap(boolean wrap) {
        this.wordWrap = wrap;
        return this;
    }

    public Tooltip setMaxLines(int maxLines) {
        this.maxLines = maxLines;
        return this;
    }

    public Tooltip setTextSupplier(Supplier<String> supplier) {
        this.textSupplier = supplier;
        return this;
    }

    public Tooltip setLinesSupplier(Supplier<List<String>> supplier) {
        this.linesSupplier = supplier;
        return this;
    }

    public boolean isVisible() { return isVisible; }
    public float getFadeProgress() { return fadeProgress; }
    public String getText() { return description; }
    public String getTitle() { return title; }
    public List<String> getLines() { return new ArrayList<>(lines); }

    @Override
    public String toString() {
        return "Tooltip{title='" + title + "', text='" + description +
               "', visible=" + isVisible + ", progress=" + fadeProgress + "}";
    }

    private static class Minecraft {
        public static net.minecraft.client.Minecraft getMinecraft() {
            return net.minecraft.client.Minecraft.getMinecraft();
        }
    }

    private static class FontRenderer {
        public static int getFontHeight() {
            return getMinecraft().fontRendererObj.FONT_HEIGHT;
        }

        public static float getStringWidth(String text) {
            return getMinecraft().fontRendererObj.getStringWidth(text);
        }
    }
}
