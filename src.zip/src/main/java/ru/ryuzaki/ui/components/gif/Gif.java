package ru.ryuzaki.ui.components.gif;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import ru.ryuzaki.RyuzakiClient;
import ru.ryuzaki.util.IMinecraft;

import java.awt.image.BufferedImage;
import java.util.HashMap;

public class Gif implements IMinecraft {
    private final Identifier gifIdentifier;
    private final NativeImage sharedImage;
    private final HashMap<Integer, NativeImage> frameCache = new HashMap<>();
    private int currentFrame = 0;
    private int frameCount = 0;
    private long lastFrameTime = 0;
    private int frameDelay = 50;
    private NativeImageBackedTexture dynamicTexture;
    private Identifier dynamicTextureId;
    private float alpha = 1.0f;
    public float x, y, width, height;

    public Gif(Identifier gifIdentifier, float x, float y, float width, float height) {
        this.gifIdentifier = gifIdentifier;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.sharedImage = loadGif(gifIdentifier);
    }

    private NativeImage loadGif(Identifier identifier) {
        try {
            var optResource = mc.getResourceManager().getResource(identifier);
            if (optResource.isEmpty()) return null;
            Resource resource = optResource.get();
            BufferedImage image = javax.imageio.ImageIO.read(resource.getInputStream());
            if (image == null) return null;
            this.frameCount = 1;
            this.frameDelay = 100;
            return nativeImageFromBuffered(image);
        } catch (Exception e) {
            System.err.println("[Ryuzaki] Gif load failed: " + e.getMessage());
            return null;
        }
    }

    private NativeImage nativeImageFromBuffered(BufferedImage buffered) {
        int w = buffered.getWidth();
        int h = buffered.getHeight();
        NativeImage nativeImg = new NativeImage(net.minecraft.client.texture.NativeImage.Format.RGBA, w, h, false);
        for (int row = 0; row < h; row++) {
            for (int col = 0; col < w; col++) {
                int argb = buffered.getRGB(col, row);
                nativeImg.setColorArgb(col, row, argb);
            }
        }
        return nativeImg;
    }

    public void update() {
        if (sharedImage == null || frameCount <= 1) return;
        long currentTime = System.currentTimeMillis();
        if (currentTime - lastFrameTime >= frameDelay) {
            currentFrame = (currentFrame + 1) % frameCount;
            lastFrameTime = currentTime;
        }
    }

    public void render(DrawContext context) {
        if (sharedImage == null) return;
        if (dynamicTexture == null) {
            dynamicTexture = new NativeImageBackedTexture(sharedImage);
            dynamicTextureId = RyuzakiClient.id("gif_" + gifIdentifier.getPath().hashCode());
            mc.getTextureManager().registerTexture(dynamicTextureId, dynamicTexture);
        }
        int alphaInt = (int)(this.alpha * 255) << 24;
        context.drawTexture(net.minecraft.client.render.RenderLayer::getGuiTextured, this.dynamicTextureId,
            (int)this.x, (int)this.y, (int)this.width, (int)this.height,
            0, 0, (int)this.width, (int)this.height, (int)this.width, (int)this.height);
    }

    public void setAlpha(float alpha) {
        this.alpha = alpha;
    }

    public void set(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void dispose() {
        if (dynamicTexture != null && dynamicTextureId != null) {
            mc.getTextureManager().destroyTexture(dynamicTextureId);
            dynamicTexture.close();
            dynamicTexture = null;
        }
        frameCache.clear();
    }
}
