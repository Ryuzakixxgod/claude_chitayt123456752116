package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Slider extends UIComponent {

    public enum Orientation {
        HORIZONTAL,
        VERTICAL
    }

    public enum SliderStyle {
        SIMPLE,
        ROUND,
        SQUARE,
        GLOW,
        GRADIENT
    }

    private float value = 0f;
    private float minValue = 0f;
    private float maxValue = 100f;
    private float step = 0f;

    private float trackWidth = 200f;
    private float trackHeight = 8f;
    private float thumbSize = 16f;
    private float thumbRadius = 8f;
    private float borderRadius = 4f;

    private float hoverProgress = 0f;
    private float dragProgress = 0f;
    private float animValue = 0f;

    private Orientation orientation = Orientation.HORIZONTAL;
    private SliderStyle style = SliderStyle.ROUND;

    private int trackColor = 0xFFE0E0E0;
    private int fillColor = 0xFF4CAF50;
    private int thumbColor = 0xFFFFFFFF;
    private int thumbBorderColor = 0xFFBDBDBD;
    private int thumbHoverColor = 0xFFF5F5F5;
    private int textColor = 0xFF333333;
    private int glowColor = 0x804CAF50;

    private int gradientStartColor = 0xFF4CAF50;
    private int gradientEndColor = 0xFF8BC34A;

    private boolean isDragging = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;
    private boolean hasFocus = false;

    private boolean showValue = true;
    private boolean showMinMax = false;
    private boolean showTicks = false;
    private boolean snapToTicks = false;
    private int tickCount = 5;
    private float tickSize = 4f;

    private boolean useGradient = false;
    private boolean useGlow = false;
    private float glowIntensity = 0f;

    private String prefix = "";
    private String suffix = "";
    private int decimalPlaces = 1;

    private List<Marker> markers = new ArrayList<>();
    private float markerSize = 6f;
    private int markerColor = 0xFF757575;

    private float clickOffset = 0f;

    private Consumer<Slider> onChange = slider -> {};
    private Consumer<Slider> onDragStart = slider -> {};
    private Consumer<Slider> onDragEnd = slider -> {};
    private Supplier<Float> valueSupplier = () -> value;
    private Supplier<Boolean> disabledSupplier = () -> isDisabled;

    public Slider() {
        super();
        setPassEvents(true);
    }

    public Slider(float min, float max) {
        this();
        this.minValue = min;
        this.maxValue = max;
        setMinSize(trackWidth, thumbSize);
    }

    public Slider(float min, float max, float defaultValue) {
        this(min, max);
        this.value = defaultValue;
        this.animValue = defaultValue;
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateFromSupplier();
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        updateFromSupplier();
        isDisabled = disabledSupplier.get();

        boolean newHovered = isMouseOver();
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        float targetHover = isHovered && !isDisabled ? 1f : 0f;
        hoverProgress = Easing.lerp(hoverProgress, targetHover, 0.15f);

        animValue = Easing.lerp(animValue, value, 0.2f);

        if (useGlow || style == SliderStyle.GLOW) {
            float targetGlow = isDragging ? 1f : (isHovered ? 0.5f : 0f);
            glowIntensity = Easing.lerp(glowIntensity, targetGlow, 0.15f);
        }
    }

    private void updateFromSupplier() {
        Float supplierValue = valueSupplier.get();
        if (supplierValue != null && !isDragging) {
            value = clamp(supplierValue);
        }
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        Draw.pushMatrix();

        if (useGlow && glowIntensity > 0) {
            renderGlow(x, y);
        }

        if (orientation == Orientation.HORIZONTAL) {
            renderHorizontal(x, y);
        } else {
            renderVertical(x, y);
        }

        Draw.popMatrix();
    }

    private void renderHorizontal(float x, float y) {
        float centerY = y + trackHeight / 2f;
        float trackY = centerY - trackHeight / 2f;
        float thumbY = centerY - thumbSize / 2f;

        float ratio = (animValue - minValue) / (maxValue - minValue);
        float fillWidth = ratio * trackWidth;
        float thumbX = x + fillWidth - thumbSize / 2f;

        if (style == SliderStyle.GLOW || style == SliderStyle.GRADIENT) {
            Draw.drawGradientRect(x, trackY, fillWidth, trackHeight, gradientStartColor, gradientEndColor);
            Draw.drawRect(x + fillWidth, trackY, trackWidth - fillWidth, trackHeight, trackColor);
        } else {
            Draw.drawRoundedRect(x, trackY, trackWidth, trackHeight, borderRadius, trackColor);
        }

        if (showTicks) {
            renderTicks(x, trackY, trackWidth, trackHeight);
        }

        renderMarkers(x, trackY, trackWidth);

        if (useGlow || style == SliderStyle.GLOW) {
            int glowCol = ((int)(glowIntensity * 0.4f * 255) << 24) | (fillColor & 0x00FFFFFF);
            Draw.drawRoundedRect(thumbX - 2f, thumbY - 2f, thumbSize + 4f, thumbSize + 4f,
                                thumbRadius + 2f, glowCol);
        }

        int currentThumbColor = isDisabled ? thumbBorderColor :
                               (isHovered || isDragging ? thumbHoverColor : thumbColor);
        int currentBorderColor = isDisabled ? 0xFFCCCCCC :
                                 (hasFocus ? fillColor : thumbBorderColor);

        switch (style) {
            case ROUND:
                Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                               thumbSize / 2f, currentBorderColor);
                Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                               thumbSize / 2f - 1f, currentThumbColor);
                break;
            case SQUARE:
                Draw.drawRect(thumbX, thumbY, thumbSize, thumbSize, currentBorderColor);
                Draw.drawRect(thumbX + 1, thumbY + 1, thumbSize - 2, thumbSize - 2, currentThumbColor);
                break;
            case GLOW:
            case GRADIENT:
            case SIMPLE:
            default:
                Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                               thumbSize / 2f, currentBorderColor);
                Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                               thumbSize / 2f - 1f, currentThumbColor);
                if (style == SliderStyle.GLOW) {
                    int innerGlow = ((int)(glowIntensity * 0.3f * 255) << 24) | (fillColor & 0x00FFFFFF);
                    Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                                   thumbSize / 2f - 2f, innerGlow);
                }
                break;
        }

        if (showValue) {
            renderValueText(x, y, thumbX);
        }
    }

    private void renderVertical(float x, float y) {
        float centerX = x + trackHeight / 2f;
        float trackX = centerX - trackHeight / 2f;
        float thumbX = centerX - thumbSize / 2f;

        float ratio = (animValue - minValue) / (maxValue - minValue);
        float fillHeight = ratio * trackWidth;
        float thumbY = y + trackWidth - fillHeight - thumbSize / 2f;

        Draw.drawRoundedRect(trackX, y, trackHeight, trackWidth, borderRadius, trackColor);

        float fillY = y + trackWidth - fillHeight;
        Draw.drawGradientRect(trackX, fillY, trackHeight, fillHeight, gradientStartColor, gradientEndColor);

        if (showTicks) {
            renderTicksVertical(x, trackX, trackWidth, trackHeight);
        }

        int currentThumbColor = isDisabled ? thumbBorderColor :
                               (isHovered || isDragging ? thumbHoverColor : thumbColor);
        int currentBorderColor = isDisabled ? 0xFFCCCCCC :
                                 (hasFocus ? fillColor : thumbBorderColor);

        Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                       thumbSize / 2f, currentBorderColor);
        Draw.drawCircle(thumbX + thumbSize / 2f, thumbY + thumbSize / 2f,
                       thumbSize / 2f - 1f, currentThumbColor);

        if (showValue) {
            renderValueTextVertical(x, y, thumbY);
        }
    }

    private void renderGlow(float x, float y) {
        int glowCol = ((int)(glowIntensity * 0.5f * 255) << 24) | (glowColor & 0x00FFFFFF);
        float ratio = (animValue - minValue) / (maxValue - minValue);
        float fillWidth = ratio * trackWidth;

        if (orientation == Orientation.HORIZONTAL) {
            Draw.drawRoundedRect(x - 4f, y - 4f, trackWidth + 8f, trackHeight + 8f,
                                borderRadius + 4f, glowCol);
        }
    }

    private void renderTicks(float x, float trackY, float trackWidth, float trackHeight) {
        float tickSpacing = trackWidth / (tickCount - 1);
        float tickY = trackY + trackHeight;

        for (int i = 0; i < tickCount; i++) {
            float tickX = x + i * tickSpacing - tickSize / 2f;
            Draw.drawRect(tickX, tickY, tickSize, tickSize, markerColor);
        }
    }

    private void renderTicksVertical(float x, float trackX, float trackWidth, float trackHeight) {
        float tickSpacing = trackWidth / (tickCount - 1);
        float tickX = trackX + trackHeight;

        for (int i = 0; i < tickCount; i++) {
            float tickY = x + i * tickSpacing - tickSize / 2f;
            Draw.drawRect(tickX, tickY, tickSize, tickSize, markerColor);
        }
    }

    private void renderMarkers(float x, float trackY, float trackWidth) {
        for (Marker marker : markers) {
            float ratio = (marker.value - minValue) / (maxValue - minValue);
            float markerX = x + ratio * trackWidth - markerSize / 2f;
            Draw.drawRect(markerX, trackY - markerSize - 2, markerSize, markerSize, marker.color);
        }
    }

    private void renderValueText(float sliderX, float y, float thumbX) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        String text = formatValue(value);
        float textWidth = fr.getStringWidth(text);
        float textHeight = fr.FONT_HEIGHT;

        float textX = thumbX + thumbSize / 2f - textWidth / 2f;
        float textY = y - textHeight - 4f;

        textX = Math.max(sliderX, Math.min(textX, sliderX + trackWidth - textWidth));

        if (thumbY < textY + textHeight + 4f) {
            textY = y + trackHeight + 4f;
        }

        Draw.drawRect(textX - 2, textY - 1, textWidth + 4, textHeight + 2, 0x40000000);
        Draw.drawString(text, textX, textY, isDisabled ? 0xFFAAAAAA : textColor, 1f);
    }

    private void renderValueTextVertical(float x, float sliderY, float thumbY) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        String text = formatValue(value);
        float textWidth = fr.getStringWidth(text);

        float textX = x + trackHeight + 4f;
        float textY = thumbY + thumbSize / 2f - fr.FONT_HEIGHT / 2f;

        Draw.drawRect(textX - 2, textY - 1, textWidth + 4, fr.FONT_HEIGHT + 2, 0x40000000);
        Draw.drawString(text, textX, textY, isDisabled ? 0xFFAAAAAA : textColor, 1f);
    }

    private String formatValue(float val) {
        StringBuilder sb = new StringBuilder();
        sb.append(prefix);
        if (decimalPlaces > 0) {
            sb.append(String.format("%." + decimalPlaces + "f", val));
        } else {
            sb.append((int) Math.round(val));
        }
        sb.append(suffix);
        return sb.toString();
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        BoundingBox bounds = getBounds();
        float thumbHitSize = thumbSize * 1.5f;

        if (orientation == Orientation.HORIZONTAL) {
            float centerY = bounds.getY() + trackHeight / 2f;
            float thumbX = bounds.getX() + getRatio() * trackWidth - thumbSize / 2f;

            if (isInBounds(mouseX, mouseY, thumbX - thumbHitSize / 2f, centerY - thumbHitSize / 2f,
                          thumbSize + thumbHitSize, thumbSize + thumbHitSize)) {
                isDragging = true;
                clickOffset = mouseX - (thumbX + thumbSize / 2f);
                onDragStart.accept(this);
                return true;
            }

            if (isInBounds(mouseX, mouseY, bounds.getX(), bounds.getY(), trackWidth, trackHeight + thumbSize)) {
                isDragging = true;
                setValueFromMouse(mouseX, bounds.getX());
                onDragStart.accept(this);
                return true;
            }
        } else {
            float centerX = bounds.getX() + trackHeight / 2f;
            float thumbY = bounds.getY() + trackWidth - getRatio() * trackWidth - thumbSize / 2f;

            if (isInBounds(mouseX, mouseY, centerX - thumbHitSize / 2f, thumbY - thumbHitSize / 2f,
                          thumbSize + thumbHitSize, thumbSize + thumbHitSize)) {
                isDragging = true;
                onDragStart.accept(this);
                return true;
            }
        }

        return false;
    }

    @Override
    public void onMouseDrag(int mouseX, int mouseY, int clickedMouseButton, long timeSinceClick) {
        if (!isDragging || isDisabled) return;

        BoundingBox bounds = getBounds();

        if (orientation == Orientation.HORIZONTAL) {
            setValueFromMouse(mouseX, bounds.getX());
        } else {
            setValueFromMouseVertical(mouseY, bounds.getY());
        }
    }

    @Override
    public boolean onMouseRelease(int mouseX, int mouseY, int mouseButton) {
        if (isDragging) {
            isDragging = false;
            onDragEnd.accept(this);
            return true;
        }
        return false;
    }

    private void setValueFromMouse(int mouseX, float trackStartX) {
        float ratio = (mouseX - clickOffset - trackStartX) / trackWidth;
        ratio = Math.max(0f, Math.min(1f, ratio));

        float newValue = minValue + ratio * (maxValue - minValue);

        if (step > 0 && snapToTicks) {
            newValue = Math.round(newValue / step) * step;
        }

        value = clamp(newValue);
        onChange.accept(this);
    }

    private void setValueFromMouseVertical(int mouseY, float trackStartY) {
        float ratio = 1f - (mouseY - trackStartY) / trackWidth;
        ratio = Math.max(0f, Math.min(1f, ratio));

        float newValue = minValue + ratio * (maxValue - minValue);

        if (step > 0 && snapToTicks) {
            newValue = Math.round(newValue / step) * step;
        }

        value = clamp(newValue);
        onChange.accept(this);
    }

    private boolean isInBounds(float px, float py, float bx, float by, float bw, float bh) {
        return px >= bx && px <= bx + bw && py >= by && py <= by + bh;
    }

    private float getRatio() {
        return (animValue - minValue) / (maxValue - minValue);
    }

    private float clamp(float val) {
        return Math.max(minValue, Math.min(maxValue, val));
    }

    public Slider setValue(float value) {
        this.value = clamp(value);
        return this;
    }

    public Slider setRange(float min, float max) {
        this.minValue = min;
        this.maxValue = max;
        this.value = clamp(this.value);
        return this;
    }

    public Slider setStep(float step) {
        this.step = step;
        return this;
    }

    public Slider setSnapToTicks(boolean snap) {
        this.snapToTicks = snap;
        return this;
    }

    public Slider setOrientation(Orientation orient) {
        this.orientation = orient;
        return this;
    }

    public Slider setStyle(SliderStyle style) {
        this.style = style;
        return this;
    }

    public Slider setTrackSize(float width, float height) {
        this.trackWidth = width;
        this.trackHeight = height;
        setMinSize(width, thumbSize);
        return this;
    }

    public Slider setThumbSize(float size) {
        this.thumbSize = size;
        this.thumbRadius = size / 2f;
        return this;
    }

    public Slider setColors(int track, int fill, int thumb, int thumbBorder) {
        this.trackColor = track;
        this.fillColor = fill;
        this.thumbColor = thumb;
        this.thumbBorderColor = thumbBorder;
        return this;
    }

    public Slider setFillColor(int color) {
        this.fillColor = color;
        return this;
    }

    public Slider setTrackColor(int color) {
        this.trackColor = color;
        return this;
    }

    public Slider setThumbColor(int color) {
        this.thumbColor = color;
        return this;
    }

    public Slider setThumbHoverColor(int color) {
        this.thumbHoverColor = color;
        return this;
    }

    public Slider setGradientColors(int start, int end) {
        this.gradientStartColor = start;
        this.gradientEndColor = end;
        this.useGradient = true;
        return this;
    }

    public Slider setGlowColor(int color) {
        this.glowColor = color;
        this.useGlow = true;
        return this;
    }

    public Slider setShowValue(boolean show) {
        this.showValue = show;
        return this;
    }

    public Slider setShowMinMax(boolean show) {
        this.showMinMax = show;
        return this;
    }

    public Slider setShowTicks(boolean show, int count) {
        this.showTicks = show;
        this.tickCount = count;
        return this;
    }

    public Slider setPrefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public Slider setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public Slider setDecimalPlaces(int places) {
        this.decimalPlaces = places;
        return this;
    }

    public Slider setDisabled(boolean disabled) {
        this.isDisabled = disabled;
        return this;
    }

    public Slider setValueSupplier(Supplier<Float> supplier) {
        this.valueSupplier = supplier;
        return this;
    }

    public Slider setDisabledSupplier(Supplier<Boolean> supplier) {
        this.disabledSupplier = supplier;
        return this;
    }

    public Slider setOnChange(Consumer<Slider> onChange) {
        this.onChange = onChange;
        return this;
    }

    public Slider setOnDragStart(Consumer<Slider> onStart) {
        this.onDragStart = onStart;
        return this;
    }

    public Slider setOnDragEnd(Consumer<Slider> onEnd) {
        this.onDragEnd = onEnd;
        return this;
    }

    public Slider addMarker(float markerValue, int color) {
        Marker marker = new Marker();
        marker.value = markerValue;
        marker.color = color;
        markers.add(marker);
        return this;
    }

    public Slider clearMarkers() {
        markers.clear();
        return this;
    }

    public float getValue() { return value; }
    public float getMinValue() { return minValue; }
    public float getMaxValue() { return maxValue; }
    public float getRatio() { return (value - minValue) / (maxValue - minValue); }
    public boolean isDragging() { return isDragging; }
    public boolean isHovered() { return isHovered; }
    public boolean isDisabled() { return isDisabled; }

    public static class Marker {
        public float value;
        public int color = 0xFF757575;
    }

    @Override
    public String toString() {
        return "Slider{value=" + value + ", min=" + minValue + ", max=" + maxValue +
               ", dragging=" + isDragging + "}";
    }

    private static class Minecraft {
        public static net.minecraft.client.Minecraft getMinecraft() {
            return net.minecraft.client.Minecraft.getMinecraft();
        }
    }

    private static class FontRenderer {
        public static int getFontHeight() {
            return getMinecraft().fontRendererObj.FONT_HEIGHT;
        }

        public static float getStringWidth(String text) {
            return getMinecraft().fontRendererObj.getStringWidth(text);
        }
    }
}
