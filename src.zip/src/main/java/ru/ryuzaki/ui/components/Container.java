package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class Container extends UIComponent {

    public enum LayoutType {
        VERTICAL,
        HORIZONTAL,
        GRID,
        STACK,
        ABSOLUTE
    }

    public enum Alignment {
        START,
        CENTER,
        END,
        STRETCH,
        SPACE_BETWEEN,
        SPACE_AROUND
    }

    private LayoutType layoutType = LayoutType.VERTICAL;
    private Alignment mainAxisAlignment = Alignment.START;
    private Alignment crossAxisAlignment = Alignment.START;

    private List<UIComponent> children = new ArrayList<>();
    private List<UIComponent> visibleChildren = new ArrayList<>();

    private float spacing = 8f;
    private float padding = 10f;
    private float gridColumns = 2f;
    private float gridGap = 8f;
    private float stackOverlap = 0f;
    private float itemWidth = -1f;
    private float itemHeight = -1f;

    private float contentWidth = 0f;
    private float contentHeight = 0f;

    private boolean scrollEnabled = false;
    private boolean scrollVertical = true;
    private boolean scrollHorizontal = false;
    private float scrollSpeed = 20f;
    private float scrollPosition = 0f;
    private float scrollVelocity = 0f;
    private float maxScroll = 0f;
    private float scrollbarWidth = 6f;
    private float scrollbarRadius = 3f;
    private boolean scrollbarVisible = false;
    private boolean isScrolling = false;

    private boolean isHovered = false;
    private boolean isDisabled = false;

    private boolean useGradient = false;
    private int gradientDirection = 1;
    private int gradientStartColor = 0xFF2196F3;
    private int gradientEndColor = 0xFF64B5F6;

    private boolean shadowEnabled = false;
    private float shadowIntensity = 0f;
    private float shadowOffset = 4f;
    private float shadowBlur = 8f;
    private int shadowColor = 0x40000000;

    private boolean glowEnabled = false;
    private float glowIntensity = 0f;
    private int glowColor = 0x402196F3;

    private int animationType = 0;
    private float animationDelay = 0f;
    private float animationDuration = 0.3f;
    private float[] itemDelays = new float[0];

    private boolean clipContent = true;
    private boolean showBorder = false;
    private float borderRadius = 8f;
    private int borderWidth = 1;
    private int borderColor = 0xFFBDBDBD;

    private float hoverScale = 1f;
    private float collapseProgress = 0f;
    private boolean isCollapsed = false;

    private Consumer<Container> onScroll = container -> {};
    private Consumer<List<UIComponent>> onLayoutChange = components -> {};

    public Container() {
        super();
        setPassEvents(true);
    }

    public Container(LayoutType layoutType) {
        this();
        this.layoutType = layoutType;
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);

        for (UIComponent child : children) {
            child.init(root);
        }

        calculateLayout();
        updateVisibleChildren();
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        boolean newHovered = isMouseOver();
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        for (UIComponent child : children) {
            if (child.isVisible()) {
                child.update(mouseX, mouseY, partialTicks);
            }
        }

        float targetScale = isHovered && !isDisabled ? 1.02f : 1f;
        hoverScale = Easing.lerp(hoverScale, targetScale, 0.1f);

        if (scrollEnabled) {
            updateScroll();
        }

        float targetCollapse = isCollapsed ? 1f : 0f;
        collapseProgress = Easing.lerp(collapseProgress, targetCollapse, 0.25f);

        if (shadowEnabled) {
            float targetShadow = isHovered ? 1f : 0.5f;
            shadowIntensity = Easing.lerp(shadowIntensity, targetShadow, 0.15f);
        }

        if (glowEnabled) {
            float targetGlow = isHovered ? 1f : 0f;
            glowIntensity = Easing.lerp(glowIntensity, targetGlow, 0.15f);
        }
    }

    private void updateScroll() {
        if (maxScroll > 0) {
            float friction = 0.92f;
            scrollVelocity *= friction;

            if (Math.abs(scrollVelocity) < 0.1f) {
                scrollVelocity = 0f;
            }

            scrollPosition += scrollVelocity;
            scrollPosition = Math.max(0, Math.min(maxScroll, scrollPosition));
        }

        scrollbarVisible = maxScroll > 0;
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        Draw.pushMatrix();

        if (glowEnabled && glowIntensity > 0) {
            int glowCol = ((int)(glowIntensity * 0.3f * 255) << 24) | (glowColor & 0x00FFFFFF);
            Draw.drawRoundedRect(x - 4f, y - 4f, width + 8f, height + 8f,
                                borderRadius + 4f, glowCol);
        }

        if (shadowEnabled && shadowIntensity > 0) {
            int shadowCol = ((int)(shadowIntensity * 0.25f * 255) << 24) | (shadowColor & 0x00FFFFFF);
            Draw.drawShadow(x, y + shadowOffset, width, height, shadowBlur, shadowCol);
        }

        renderBackground(x, y, width, height);

        if (showBorder) {
            Draw.drawRoundedRectOutline(x, y, width, height, borderRadius, borderWidth, borderColor);
        }

        if (clipContent) {
            Draw.enableScissor((int)x, (int)(y + height), (int)(x + width), (int)y);
        }

        float renderHeight = height * (1 - collapseProgress);
        if (collapseProgress < 1f) {
            Draw.pushMatrix();
            Draw.translate(0, -scrollPosition, 0);
            renderChildren(x, y, width, height);
            Draw.popMatrix();
        }

        if (clipContent) {
            Draw.disableScissor();
        }

        if (scrollEnabled && scrollbarVisible && collapseProgress < 1f) {
            renderScrollbar(x, y, width, height);
        }

        Draw.popMatrix();
    }

    private void renderBackground(float x, float y, float width, float height) {
        if (useGradient) {
            Draw.drawGradientRoundRect(x, y, width, height, borderRadius,
                                     gradientStartColor, gradientEndColor, gradientDirection);
        } else {
            Draw.drawRoundedRect(x, y, width, height, borderRadius, getBackgroundColor());
        }
    }

    private void renderChildren(float x, float y, float width, float height) {
        if (children.isEmpty()) return;

        float renderY = y + padding;

        switch (layoutType) {
            case VERTICAL:
                renderVertical(x, renderY, width, height);
                break;
            case HORIZONTAL:
                renderHorizontal(x, y + padding, width, height);
                break;
            case GRID:
                renderGrid(x, renderY, width, height);
                break;
            case STACK:
                renderStack(x, y + padding, width, height);
                break;
            case ABSOLUTE:
                renderAbsolute(x, y, width, height);
                break;
        }
    }

    private void renderVertical(float x, float y, float width, float height) {
        float currentY = y;
        float availableWidth = width - padding * 2;

        List<Float> sizes = calculateAxisSizes(children, availableWidth, true);
        float totalSize = calculateTotalSize(sizes);
        float totalSpacing = (children.size() - 1) * spacing;

        currentY = applyMainAxisAlignment(currentY, totalSize + totalSpacing, height - padding * 2, mainAxisAlignment);

        for (int i = 0; i < children.size(); i++) {
            UIComponent child = children.get(i);
            if (!child.isVisible()) continue;

            float childWidth = itemWidth > 0 ? itemWidth : sizes.get(i);
            float childHeight = itemHeight > 0 ? itemHeight : child.getMinHeight();

            float childX = x + padding;
            childX = applyCrossAxisAlignment(childX, childWidth, availableWidth, crossAxisAlignment);

            if (isInView(currentY, childHeight, height, scrollPosition)) {
                setChildBounds(child, childX, currentY, childWidth, childHeight);
            }

            currentY += childHeight + spacing;
        }
    }

    private void renderHorizontal(float x, float y, float width, float height) {
        float currentX = x + padding;
        float availableHeight = height - padding * 2;

        List<Float> sizes = calculateAxisSizes(children, width - padding * 2, false);
        float totalSize = calculateTotalSize(sizes);
        float totalSpacing = (children.size() - 1) * spacing;

        currentX = applyMainAxisAlignmentHorizontal(currentX, totalSize + totalSpacing, width - padding * 2, mainAxisAlignment);

        for (int i = 0; i < children.size(); i++) {
            UIComponent child = children.get(i);
            if (!child.isVisible()) continue;

            float childWidth = itemWidth > 0 ? itemWidth : child.getMinWidth();
            float childHeight = itemHeight > 0 ? itemHeight : sizes.get(i);

            float childY = y;
            childY = applyCrossAxisAlignment(childY, childHeight, availableHeight, crossAxisAlignment);

            if (isInViewHorizontal(currentX, childWidth, width)) {
                setChildBounds(child, currentX, childY, childWidth, childHeight);
            }

            currentX += childWidth + spacing;
        }
    }

    private void renderGrid(float x, float y, float width, float height) {
        float availableWidth = width - padding * 2;
        float cellWidth = (availableWidth - (gridColumns - 1) * gridGap) / gridColumns;
        float cellHeight = itemHeight > 0 ? itemHeight : 30f;

        int row = 0;
        int col = 0;

        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            float childX = x + padding + col * (cellWidth + gridGap);
            float childY = y + row * (cellHeight + gridGap);

            setChildBounds(child, childX, childY, cellWidth, cellHeight);

            col++;
            if (col >= gridColumns) {
                col = 0;
                row++;
            }
        }
    }

    private void renderStack(float x, float y, float width, float height) {
        float overlap = stackOverlap;

        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            float childWidth = itemWidth > 0 ? itemWidth : width - padding * 2;
            float childHeight = itemHeight > 0 ? itemHeight : child.getMinHeight();

            setChildBounds(child, x + padding, y, childWidth, childHeight);
            y -= overlap;
        }
    }

    private void renderAbsolute(float x, float y, float width, float height) {
        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            BoundingBox childBounds = child.getBounds();
            float childX = x + childBounds.getX();
            float childY = y + childBounds.getY();

            setChildBounds(child, childX, childY, childBounds.getWidth(), childBounds.getHeight());
        }
    }

    private void renderScrollbar(float x, float y, float width, float height) {
        float scrollbarX = x + width - scrollbarWidth - 2f;
        float scrollbarHeight = Math.max(20f, height * (height / (height + maxScroll)));
        float scrollbarY = y + 2f + (height - scrollbarHeight - 4f) * (scrollPosition / maxScroll);

        Draw.drawRoundedRect(scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight,
                            scrollbarRadius, 0x40000000);

        if (scrollbarVisible) {
            int hoverColor = 0x60000000;
            Draw.drawRoundedRect(scrollbarX, scrollbarY, scrollbarWidth, scrollbarHeight,
                                scrollbarRadius, hoverColor);
        }
    }

    private List<Float> calculateAxisSizes(List<UIComponent> comps, float availableSpace, boolean isVertical) {
        List<Float> sizes = new ArrayList<>();
        for (UIComponent comp : comps) {
            if (!comp.isVisible()) {
                sizes.add(0f);
            } else {
                sizes.add(isVertical ? comp.getMinWidth() : comp.getMinHeight());
            }
        }
        return sizes;
    }

    private float calculateTotalSize(List<Float> sizes) {
        float total = 0f;
        for (Float size : sizes) {
            total += size;
        }
        return total;
    }

    private float applyMainAxisAlignment(float current, float totalSize, float available, Alignment alignment) {
        switch (alignment) {
            case CENTER:
                return current + (available - totalSize) / 2f;
            case END:
                return current + available - totalSize;
            case SPACE_BETWEEN:
                return current;
            case SPACE_AROUND:
                return current + (available - totalSize) / 2f;
            default:
                return current;
        }
    }

    private float applyMainAxisAlignmentHorizontal(float current, float totalSize, float available, Alignment alignment) {
        switch (alignment) {
            case CENTER:
                return current + (available - totalSize) / 2f;
            case END:
                return current + available - totalSize;
            default:
                return current;
        }
    }

    private float applyCrossAxisAlignment(float current, float itemSize, float available, Alignment alignment) {
        switch (alignment) {
            case CENTER:
                return current + (available - itemSize) / 2f;
            case END:
                return current + available - itemSize;
            case STRETCH:
                return current;
            default:
                return current;
        }
    }

    private boolean isInView(float itemY, float itemHeight, float containerHeight, float scrollPos) {
        return itemY + itemHeight > scrollPos && itemY < scrollPos + containerHeight;
    }

    private boolean isInViewHorizontal(float itemX, float itemWidth, float containerWidth) {
        return itemX + itemWidth > 0 && itemX < containerWidth;
    }

    private void setChildBounds(UIComponent child, float x, float y, float width, float height) {
        child.setBounds(new BoundingBox(x, y, width, height));
    }

    private int getBackgroundColor() {
        return isDisabled ? 0xFFF5F5F5 : 0xFFFFFFFF;
    }

    private void calculateLayout() {
        contentWidth = padding * 2;
        contentHeight = padding * 2;

        if (children.isEmpty()) return;

        switch (layoutType) {
            case VERTICAL:
                calculateVerticalLayout();
                break;
            case HORIZONTAL:
                calculateHorizontalLayout();
                break;
            case GRID:
                calculateGridLayout();
                break;
            case STACK:
                calculateStackLayout();
                break;
            case ABSOLUTE:
                calculateAbsoluteLayout();
                break;
        }
    }

    private void calculateVerticalLayout() {
        float maxWidth = 0f;
        float totalHeight = 0f;

        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            float childWidth = itemWidth > 0 ? itemWidth : child.getMinWidth();
            float childHeight = itemHeight > 0 ? itemHeight : child.getMinHeight();

            maxWidth = Math.max(maxWidth, childWidth);
            totalHeight += childHeight + (totalHeight > 0 ? spacing : 0);
        }

        contentWidth += maxWidth;
        contentHeight += totalHeight - (children.isEmpty() ? 0 : spacing);

        if (scrollEnabled) {
            maxScroll = Math.max(0, contentHeight - getBounds().getHeight());
        }

        setMinSize(contentWidth, contentHeight);
    }

    private void calculateHorizontalLayout() {
        float totalWidth = 0f;
        float maxHeight = 0f;

        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            float childWidth = itemWidth > 0 ? itemWidth : child.getMinWidth();
            float childHeight = itemHeight > 0 ? itemHeight : child.getMinHeight();

            totalWidth += childWidth + (totalWidth > 0 ? spacing : 0);
            maxHeight = Math.max(maxHeight, childHeight);
        }

        contentWidth += totalWidth;
        contentHeight += maxHeight;

        setMinSize(contentWidth, contentHeight);
    }

    private void calculateGridLayout() {
        int rows = (int) Math.ceil((float) children.size() / gridColumns);
        float cellWidth = (getBounds().getWidth() - padding * 2 - (gridColumns - 1) * gridGap) / gridColumns;
        float cellHeight = itemHeight > 0 ? itemHeight : 30f;

        contentWidth = getBounds().getWidth();
        contentHeight = padding * 2 + rows * cellHeight + (rows - 1) * gridGap;

        setMinSize(contentWidth, contentHeight);
    }

    private void calculateStackLayout() {
        float maxWidth = 0f;
        float totalHeight = 0f;
        float overlap = stackOverlap;

        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            float childWidth = itemWidth > 0 ? itemWidth : child.getMinWidth();
            float childHeight = itemHeight > 0 ? itemHeight : child.getMinHeight();

            maxWidth = Math.max(maxWidth, childWidth);
            totalHeight += childHeight - overlap;
        }

        contentWidth += maxWidth;
        contentHeight += totalHeight + overlap;

        setMinSize(contentWidth, contentHeight);
    }

    private void calculateAbsoluteLayout() {
        float maxX = 0f;
        float maxY = 0f;

        for (UIComponent child : children) {
            if (!child.isVisible()) continue;

            BoundingBox bounds = child.getBounds();
            maxX = Math.max(maxX, bounds.getX() + bounds.getWidth());
            maxY = Math.max(maxY, bounds.getY() + bounds.getHeight());
        }

        contentWidth = maxX + padding;
        contentHeight = maxY + padding;

        setMinSize(contentWidth, contentHeight);
    }

    private void updateVisibleChildren() {
        visibleChildren.clear();
        for (UIComponent child : children) {
            if (child.isVisible()) {
                visibleChildren.add(child);
            }
        }
    }

    @Override
    public boolean onMouseWheel(int mouseX, int mouseY, int delta) {
        if (!scrollEnabled || isDisabled) return false;

        BoundingBox bounds = getBounds();
        if (mouseX < bounds.getX() || mouseX > bounds.getX() + bounds.getWidth()
            || mouseY < bounds.getY() || mouseY > bounds.getY() + bounds.getHeight()) {
            return false;
        }

        if (scrollVertical) {
            scrollVelocity = -delta * scrollSpeed * 0.1f;
            scrollPosition += scrollVelocity;
            scrollPosition = Math.max(0, Math.min(maxScroll, scrollPosition));
            onScroll.accept(this);
            return true;
        }

        return false;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        return propagateClickToChildren(mouseX, mouseY, mouseButton);
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        return propagateMouseDownToChildren(mouseX, mouseY, mouseButton);
    }

    @Override
    public void onMouseDrag(int mouseX, int mouseY, int clickedMouseButton, long timeSinceClick) {
        if (isDisabled) return;

        for (UIComponent child : children) {
            if (child.isVisible() && child.isMouseOver()) {
                child.onMouseDrag(mouseX, mouseY, clickedMouseButton, timeSinceClick);
            }
        }

        if (scrollEnabled && isScrolling) {
            scrollVelocity = mouseY * 0.5f;
        }
    }

    @Override
    public boolean onMouseRelease(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        isScrolling = false;
        return propagateMouseReleaseToChildren(mouseX, mouseY, mouseButton);
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (isDisabled) return false;
        return propagateKeyTypedToChildren(typedChar, keyCode);
    }

    private boolean propagateClickToChildren(int mouseX, int mouseY, int mouseButton) {
        for (UIComponent child : visibleChildren) {
            if (child.isVisible() && child.isMouseOver() && child.isClickable()) {
                return child.onClick(mouseX, mouseY, mouseButton);
            }
        }
        return false;
    }

    private boolean propagateMouseDownToChildren(int mouseX, int mouseY, int mouseButton) {
        for (UIComponent child : visibleChildren) {
            if (child.isVisible() && child.isMouseOver()) {
                return child.onMouseDown(mouseX, mouseY, mouseButton);
            }
        }
        return false;
    }

    private boolean propagateMouseReleaseToChildren(int mouseX, int mouseY, int mouseButton) {
        boolean handled = false;
        for (UIComponent child : visibleChildren) {
            if (child.isVisible()) {
                if (child.onMouseRelease(mouseX, mouseY, mouseButton)) {
                    handled = true;
                }
            }
        }
        return handled;
    }

    private boolean propagateKeyTypedToChildren(char typedChar, int keyCode) {
        for (UIComponent child : visibleChildren) {
            if (child.isVisible() && child.hasFocus()) {
                if (child.onKeyTyped(typedChar, keyCode)) {
                    return true;
                }
            }
        }
        return false;
    }

    public Container add(UIComponent component) {
        children.add(component);
        if (getRoot() != null) {
            component.init(getRoot());
        }
        calculateLayout();
        updateVisibleChildren();
        onLayoutChange.accept(children);
        return this;
    }

    public Container add(UIComponent... components) {
        for (UIComponent component : components) {
            add(component);
        }
        return this;
    }

    public Container remove(UIComponent component) {
        children.remove(component);
        calculateLayout();
        updateVisibleChildren();
        onLayoutChange.accept(children);
        return this;
    }

    public Container removeAll() {
        children.clear();
        visibleChildren.clear();
        calculateLayout();
        onLayoutChange.accept(children);
        return this;
    }

    public <T extends UIComponent> T getChild(int index) {
        return (T) children.get(index);
    }

    public List<UIComponent> getChildren() {
        return new ArrayList<>(children);
    }

    public int getChildCount() {
        return children.size();
    }

    public Container setLayoutType(LayoutType type) {
        this.layoutType = type;
        calculateLayout();
        return this;
    }

    public Container setSpacing(float spacing) {
        this.spacing = spacing;
        calculateLayout();
        return this;
    }

    public Container setPadding(float padding) {
        this.padding = padding;
        calculateLayout();
        return this;
    }

    public Container setMainAxisAlignment(Alignment alignment) {
        this.mainAxisAlignment = alignment;
        return this;
    }

    public Container setCrossAxisAlignment(Alignment alignment) {
        this.crossAxisAlignment = alignment;
        return this;
    }

    public Container setItemSize(float width, float height) {
        this.itemWidth = width;
        this.itemHeight = height;
        calculateLayout();
        return this;
    }

    public Container setScrollEnabled(boolean enabled) {
        this.scrollEnabled = enabled;
        return this;
    }

    public Container setScrollDirection(boolean vertical, boolean horizontal) {
        this.scrollVertical = vertical;
        this.scrollHorizontal = horizontal;
        return this;
    }

    public Container setScrollPosition(float position) {
        this.scrollPosition = Math.max(0, Math.min(maxScroll, position));
        return this;
    }

    public float getScrollPosition() {
        return scrollPosition;
    }

    public float getMaxScroll() {
        return maxScroll;
    }

    public Container setCollapsed(boolean collapsed) {
        this.isCollapsed = collapsed;
        return this;
    }

    public boolean isCollapsed() {
        return isCollapsed;
    }

    public Container setClipContent(boolean clip) {
        this.clipContent = clip;
        return this;
    }

    public Container setShowBorder(boolean show, float radius, int color) {
        this.showBorder = show;
        this.borderRadius = radius;
        this.borderColor = color;
        return this;
    }

    public Container setGradient(boolean use, int start, int end) {
        this.useGradient = use;
        this.gradientStartColor = start;
        this.gradientEndColor = end;
        return this;
    }

    public Container setShadow(boolean enabled, float intensity) {
        this.shadowEnabled = enabled;
        this.shadowIntensity = intensity;
        return this;
    }

    public Container setGlow(boolean enabled, int color) {
        this.glowEnabled = enabled;
        this.glowColor = color;
        return this;
    }

    public Container setGridColumns(float columns) {
        this.gridColumns = columns;
        calculateLayout();
        return this;
    }

    public Container setGridGap(float gap) {
        this.gridGap = gap;
        calculateLayout();
        return this;
    }

    public Container setStackOverlap(float overlap) {
        this.stackOverlap = overlap;
        calculateLayout();
        return this;
    }

    public Container setOnScroll(Consumer<Container> onScroll) {
        this.onScroll = onScroll;
        return this;
    }

    public Container setOnLayoutChange(Consumer<List<UIComponent>> onChange) {
        this.onLayoutChange = onChange;
        return this;
    }

    public Container setDisabled(boolean disabled) {
        this.isDisabled = disabled;
        return this;
    }

    @Override
    public String toString() {
        return "Container{layout=" + layoutType + ", children=" + children.size() +
               ", scroll=" + scrollEnabled + "}";
    }
}
