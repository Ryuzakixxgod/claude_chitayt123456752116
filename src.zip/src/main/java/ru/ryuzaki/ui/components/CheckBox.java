package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class CheckBox extends UIComponent {

    public enum State {
        UNCHECKED, CHECKED, INDETERMINATE
    }

    private State state = State.UNCHECKED;
    private State targetState = State.UNCHECKED;

    private boolean isHovered = false;
    private boolean isDisabled = false;
    private boolean isAnimating = false;

    private float boxSize = 20f;
    private float borderWidth = 2f;
    private float borderRadius = 4f;
    private float checkMarkWidth = 3f;

    private float animationProgress = 0f;
    private float hoverScale = 1f;
    private float checkScale = 0f;
    private float pulsePhase = 0f;
    private float pulseIntensity = 0f;

    private int uncheckedColor = 0xFFE0E0E0;
    private int checkedColor = 0xFF4CAF50;
    private int indeterminateColor = 0xFF2196F3;
    private int hoverColor = 0xFFE8E8E8;
    private int disabledColor = 0xFFBDBDBD;

    private int borderColor = 0xFF757575;
    private int borderHoverColor = 0xFF5B5B5B;
    private int borderDisabledColor = 0xFFAAAAAA;
    private int borderCheckedColor = 0xFF388E3C;
    private int borderIndeterminateColor = 0xFF1976D2;

    private int checkMarkColor = 0xFFFFFFFF;
    private int disabledCheckMarkColor = 0xFFCCCCCC;

    private boolean animated = true;
    private float animationSpeed = 0.15f;

    private boolean useGradient = false;
    private int gradientStartColor = 0xFF4CAF50;
    private int gradientEndColor = 0xFF8BC34A;

    private boolean glowEnabled = false;
    private float glowIntensity = 0f;
    private int glowColor = 0x804CAF50;

    private boolean showPulse = false;

    private String label = "";
    private int labelColor = 0xFF333333;
    private int disabledLabelColor = 0xFF888888;
    private float labelOffset = 28f;

    private String description = "";
    private int descriptionColor = 0xFF666666;
    private float descriptionOffset = 16f;

    private boolean useRadioStyle = false;
    private float radioOuterRadius = 0f;
    private float radioInnerRadius = 0f;
    private float radioInnerScale = 0f;

    private Consumer<CheckBox> onStateChange = cb -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;
    private Supplier<State> stateSupplier = () -> state;

    private List<CheckBox> linkedBoxes = new ArrayList<>();
    private String groupId = "";

    public CheckBox() {
        super();
        setClickable(true);
        setFocusable(true);
        updateDimensions();
    }

    public CheckBox(String label) {
        this();
        this.label = label;
    }

    public CheckBox(String label, boolean checked) {
        this(label);
        this.state = checked ? State.CHECKED : State.UNCHECKED;
        this.targetState = this.state;
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateDimensions();
    }

    private void updateDimensions() {
        float height = boxSize;
        if (!description.isEmpty()) {
            height += descriptionOffset;
        }
        setMinSize(boxSize + labelOffset + 100f, height);
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        state = stateSupplier.get();

        boolean newHovered = isMouseOver() && !isDisabled;
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        isDisabled = isDisabledSupplier.get();

        float targetScale = isHovered && !isDisabled ? 1.1f : 1f;
        hoverScale = Easing.lerp(hoverScale, targetScale, 0.15f);

        if (animated) {
            float targetProgress = 0f;
            switch (state) {
                case CHECKED:
                    targetProgress = 1f;
                    break;
                case INDETERMINATE:
                    targetProgress = 0.5f;
                    break;
                case UNCHECKED:
                default:
                    targetProgress = 0f;
                    break;
            }

            float prevProgress = animationProgress;
            animationProgress = Easing.lerp(animationProgress, targetProgress, animationSpeed);

            if (Math.abs(animationProgress - prevProgress) > 0.01f) {
                isAnimating = true;
            } else {
                isAnimating = false;
            }
        } else {
            switch (state) {
                case CHECKED:
                    animationProgress = 1f;
                    break;
                case INDETERMINATE:
                    animationProgress = 0.5f;
                    break;
                case UNCHECKED:
                default:
                    animationProgress = 0f;
                    break;
            }
            isAnimating = false;
        }

        checkScale = Easing.easeOutBack(animationProgress);

        float targetInnerScale = 0f;
        switch (state) {
            case CHECKED:
                targetInnerScale = 1f;
                break;
            case INDETERMINATE:
                targetInnerScale = 0.6f;
                break;
            case UNCHECKED:
            default:
                targetInnerScale = 0f;
                break;
        }
        radioInnerScale = Easing.lerp(radioInnerScale, targetInnerScale, 0.2f);

        if (glowEnabled && state != State.UNCHECKED) {
            glowIntensity = Easing.lerp(glowIntensity, 1f, 0.1f);
        } else {
            glowIntensity = Easing.lerp(glowIntensity, 0f, 0.15f);
        }

        if (showPulse) {
            pulsePhase += 0.05f;
            pulseIntensity = (float) Math.sin(pulsePhase) * 0.3f + 0.7f;
        }
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        float centerY = height / 2f;
        float boxX = x;
        float boxY = y + centerY - boxSize / 2f;

        if (!description.isEmpty()) {
            boxY = y + 4f;
        }

        Draw.pushMatrix();
        Draw.translate(boxX + boxSize / 2f, boxY + boxSize / 2f, 0);
        Draw.scale(hoverScale, hoverScale, 1f);
        Draw.translate(-(boxX + boxSize / 2f), -(boxY + boxSize / 2f), 0);

        if (glowEnabled && glowIntensity > 0) {
            renderGlow(boxX, boxY);
        }

        if (useRadioStyle) {
            renderRadio(boxX, boxY);
        } else {
            renderCheckbox(boxX, boxY);
        }

        Draw.popMatrix();

        renderLabel(x, y, width, height);
        renderDescription(x, y, width, height);
    }

    private void renderCheckbox(float x, float y) {
        int bgColor = getBackgroundColor();
        int bColor = getBorderColor();

        Draw.drawRoundedRect(x, y, boxSize, boxSize, borderRadius, bgColor);
        Draw.drawRoundedRectOutline(x, y, boxSize, boxSize, borderRadius, borderWidth, bColor);

        if (animationProgress > 0) {
            int fillColor = getFillColor();
            float padding = 4f;
            float checkSize = (boxSize - padding * 2) * checkScale;

            Draw.drawRoundedRect(x + padding, y + padding, checkSize, checkSize,
                               borderRadius - 1, fillColor);

            renderCheckMark(x, y, checkSize);
        }

        if (showPulse && pulseIntensity > 0) {
            int pulseColor = ((int)(pulseIntensity * 0.3f * 255) << 24) | 0x00FFFFFF;
            Draw.drawRoundedRect(x - 4f, y - 4f, boxSize + 8f, boxSize + 8f,
                               borderRadius + 4f, pulseColor);
        }
    }

    private void renderRadio(float x, float y) {
        float centerX = x + boxSize / 2f;
        float centerY = y + boxSize / 2f;
        float outerRadius = boxSize / 2f;
        float innerRadius = outerRadius * radioInnerScale;

        Draw.drawCircle(centerX, centerY, outerRadius, uncheckedColor);
        Draw.drawCircleOutline(centerX, centerY, outerRadius, borderWidth, borderColor);

        if (radioInnerScale > 0) {
            int innerColor = getFillColor();
            Draw.drawCircle(centerX, centerY, innerRadius, innerColor);
        }
    }

    private void renderCheckMark(float boxX, float boxY, float checkSize) {
        float centerX = boxX + boxSize / 2f;
        float centerY = boxY + boxSize / 2f;

        float markSize = checkSize * 0.6f;
        float shortArm = markSize * 0.35f;
        float longArm = markSize * 0.65f;

        float startX = centerX - longArm * 0.5f;
        float startY = centerY;

        float midX = centerX - shortArm * 0.3f;
        float midY = centerY + shortArm;

        float endX = centerX + longArm * 0.5f;
        float endY = centerY - shortArm;

        int checkColor = isDisabled ? disabledCheckMarkColor : checkMarkColor;

        Draw.drawLine(startX, startY, midX, midY, checkMarkWidth, checkColor);
        Draw.drawLine(midX, midY, endX, endY, checkMarkWidth, checkColor);
    }

    private void renderGlow(float x, float y) {
        int glowCol = ((int)(glowIntensity * 0.5f * 255) << 24) | (glowColor & 0x00FFFFFF);
        float expansion = 6f;
        float expandedRadius = borderRadius + expansion / 2f;

        Draw.drawRoundedRect(x - expansion / 2f, y - expansion / 2f,
                            boxSize + expansion, boxSize + expansion,
                            expandedRadius, glowCol);
    }

    private void renderLabel(float x, float y, float width, float height) {
        if (label.isEmpty()) return;

        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        net.minecraft.client.gui.FontRenderer fr = mc.fontRendererObj;

        float labelX = x + labelOffset;
        float labelY = y + height / 2f - fr.FONT_HEIGHT / 2f;

        if (!description.isEmpty()) {
            labelY = y + 6f;
        }

        int lColor = isDisabled ? disabledLabelColor : labelColor;
        Draw.drawString(label, labelX, labelY, lColor, 1f);
    }

    private void renderDescription(float x, float y, float width, float height) {
        if (description.isEmpty()) return;

        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
        net.minecraft.client.gui.FontRenderer fr = mc.fontRendererObj;

        float descX = x + labelOffset;
        float descY = y + height - fr.FONT_HEIGHT - 4f;

        int dColor = isDisabled ? 0xFF888888 : descriptionColor;
        Draw.drawString(description, descX, descY, dColor, 0.85f);
    }

    private int getBackgroundColor() {
        if (isDisabled) {
            return disabledColor;
        }
        switch (state) {
            case CHECKED:
                return checkedColor;
            case INDETERMINATE:
                return indeterminateColor;
            case UNCHECKED:
            default:
                return isHovered ? hoverColor : uncheckedColor;
        }
    }

    private int getFillColor() {
        if (isDisabled) {
            return 0xFF9E9E9E;
        }
        if (useGradient) {
            int r1 = (gradientStartColor >> 16) & 0xFF;
            int g1 = (gradientStartColor >> 8) & 0xFF;
            int b1 = gradientStartColor & 0xFF;
            int r2 = (gradientEndColor >> 16) & 0xFF;
            int g2 = (gradientEndColor >> 8) & 0xFF;
            int b2 = gradientEndColor & 0xFF;

            float t = (float) Math.sin(animationProgress * Math.PI);
            int r = (int) (r1 + (r2 - r1) * t);
            int g = (int) (g1 + (g2 - g1) * t);
            int b = (int) (b1 + (b2 - b1) * t);

            return 0xFF000000 | (r << 16) | (g << 8) | b;
        }
        switch (state) {
            case CHECKED:
                return checkedColor;
            case INDETERMINATE:
                return indeterminateColor;
            case UNCHECKED:
            default:
                return isHovered ? hoverColor : uncheckedColor;
        }
    }

    private int getBorderColor() {
        if (isDisabled) {
            return borderDisabledColor;
        }
        if (!isHovered && state != State.UNCHECKED) {
            switch (state) {
                case CHECKED:
                    return borderCheckedColor;
                case INDETERMINATE:
                    return borderIndeterminateColor;
                default:
                    break;
            }
        }
        return isHovered ? borderHoverColor : borderColor;
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        return true;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        if (!linkedBoxes.isEmpty()) {
            for (CheckBox linked : linkedBoxes) {
                if (linked != this) {
                    linked.setState(State.UNCHECKED);
                }
            }
        }

        State newState;
        switch (state) {
            case UNCHECKED:
                newState = State.CHECKED;
                break;
            case CHECKED:
                newState = State.UNCHECKED;
                break;
            case INDETERMINATE:
            default:
                newState = State.CHECKED;
                break;
        }

        setState(newState);
        onStateChange.accept(this);

        return true;
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (isDisabled) return false;

        if (keyCode == 0x1C || keyCode == 0x9C) {
            onClick(0, 0, 0);
            return true;
        }

        return super.onKeyTyped(typedChar, keyCode);
    }

    @Override
    public boolean isMouseOver() {
        return ru.ryuzaki.ui.base.GeometryUtils.pointInBounds(getBounds(),
                getLastMouseX(), getLastMouseY());
    }

    public CheckBox setState(State newState) {
        this.state = newState;
        this.targetState = newState;
        return this;
    }

    public State getState() { return state; }

    public boolean isChecked() { return state == State.CHECKED; }
    public boolean isIndeterminate() { return state == State.INDETERMINATE; }
    public boolean isUnchecked() { return state == State.UNCHECKED; }
    public boolean isHovered() { return isHovered; }
    public boolean isDisabled() { return isDisabled; }

    public CheckBox setLabel(String label) {
        this.label = label;
        return this;
    }

    public String getLabel() { return label; }

    public CheckBox setDescription(String description) {
        this.description = description;
        updateDimensions();
        return this;
    }

    public CheckBox setLabelColor(int color) {
        this.labelColor = color;
        return this;
    }

    public CheckBox setDisabledLabelColor(int color) {
        this.disabledLabelColor = color;
        return this;
    }

    public CheckBox setLabelOffset(float offset) {
        this.labelOffset = offset;
        return this;
    }

    public CheckBox setBoxSize(float size) {
        this.boxSize = size;
        updateDimensions();
        return this;
    }

    public CheckBox setBorderWidth(float width) {
        this.borderWidth = width;
        return this;
    }

    public CheckBox setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public CheckBox setColors(int unchecked, int checked) {
        this.uncheckedColor = unchecked;
        this.checkedColor = checked;
        return this;
    }

    public CheckBox setCheckedColor(int color) {
        this.checkedColor = color;
        return this;
    }

    public CheckBox setIndeterminateColor(int color) {
        this.indeterminateColor = color;
        return this;
    }

    public CheckBox setBorderColors(int normal, int checked, int indeterminate) {
        this.borderColor = normal;
        this.borderCheckedColor = checked;
        this.borderIndeterminateColor = indeterminate;
        return this;
    }

    public CheckBox setDisabledColor(int color) {
        this.disabledColor = color;
        return this;
    }

    public CheckBox setDisabledBorderColor(int color) {
        this.borderDisabledColor = color;
        return this;
    }

    public CheckBox setCheckMarkColor(int color) {
        this.checkMarkColor = color;
        return this;
    }

    public CheckBox setCheckMarkWidth(float width) {
        this.checkMarkWidth = width;
        return this;
    }

    public CheckBox setAnimated(boolean animated) {
        this.animated = animated;
        return this;
    }

    public CheckBox setAnimationSpeed(float speed) {
        this.animationSpeed = speed;
        return this;
    }

    public CheckBox setUseGradient(boolean use) {
        this.useGradient = use;
        return this;
    }

    public CheckBox setGradientColors(int start, int end) {
        this.gradientStartColor = start;
        this.gradientEndColor = end;
        return this;
    }

    public CheckBox setGlowEnabled(boolean enabled) {
        this.glowEnabled = enabled;
        return this;
    }

    public CheckBox setGlowColor(int color) {
        this.glowColor = color;
        return this;
    }

    public CheckBox setShowPulse(boolean show) {
        this.showPulse = show;
        return this;
    }

    public CheckBox setRadioStyle(boolean radio) {
        this.useRadioStyle = radio;
        return this;
    }

    public CheckBox setOnStateChange(Consumer<CheckBox> onChange) {
        this.onStateChange = onChange;
        return this;
    }

    public CheckBox setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public CheckBox setStateSupplier(Supplier<State> supplier) {
        this.stateSupplier = supplier;
        return this;
    }

    public CheckBox linkWith(CheckBox... boxes) {
        for (CheckBox box : boxes) {
            if (!linkedBoxes.contains(box)) {
                linkedBoxes.add(box);
            }
            if (!box.linkedBoxes.contains(this)) {
                box.linkedBoxes.add(this);
            }
        }
        return this;
    }

    public CheckBox setGroupId(String id) {
        this.groupId = id;
        return this;
    }

    public String getGroupId() { return groupId; }

    public CheckBox toggle() {
        setState(state == State.CHECKED ? State.UNCHECKED : State.CHECKED);
        onStateChange.accept(this);
        return this;
    }

    @Override
    public String toString() {
        return "CheckBox{label='" + label + "', state=" + state + ", disabled=" + isDisabled + '}';
    }
}
