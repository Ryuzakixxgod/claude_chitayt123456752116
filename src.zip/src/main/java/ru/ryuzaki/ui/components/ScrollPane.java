package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;
import ru.ryuzaki.ui.core.UIContainer;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class ScrollPane extends UIContainer {

    public enum ScrollBarStyle {
        THIN,
        NORMAL,
        THICK,
        ROUND,
        FLAT,
        GLOW
    }

    public enum ScrollBarVisibility {
        ALWAYS,
        AUTO,
        NEVER
    }

    private UIContainer content;
    private float scrollX = 0f;
    private float scrollY = 0f;
    private float targetScrollX = 0f;
    private float targetScrollY = 0f;

    private float contentWidth = 0f;
    private float contentHeight = 0f;
    private float scrollSpeed = 20f;
    private float scrollAcceleration = 0.1f;
    private float smoothScrollFactor = 0.15f;

    private float scrollbarWidth = 8f;
    private float scrollbarHeight = 40f;
    private float scrollbarRadius = 4f;
    private float scrollbarPadding = 2f;

    private boolean showHorizontalScrollbar = false;
    private boolean showVerticalScrollbar = true;
    private boolean smoothScrolling = true;
    private boolean invertScroll = false;
    private boolean scrollLockedX = false;
    private boolean scrollLockedY = false;

    private ScrollBarStyle horizontalScrollbarStyle = ScrollBarStyle.THIN;
    private ScrollBarStyle verticalScrollbarStyle = ScrollBarStyle.NORMAL;
    private ScrollBarVisibility horizontalScrollbarVisibility = ScrollBarVisibility.AUTO;
    private ScrollBarVisibility verticalScrollbarVisibility = ScrollBarVisibility.AUTO;

    private float horizontalScrollbarOpacity = 1f;
    private float verticalScrollbarOpacity = 1f;
    private float scrollbarHoverProgress = 0f;
    private float scrollbarDragProgress = 0f;

    private int scrollbarTrackColor = 0x20000000;
    private int scrollbarColor = 0x80000000;
    private int scrollbarHoverColor = 0xA0000000;
    private int scrollbarDragColor = 0xC0000000;
    private int glowColor = 0x404CAF50;

    private boolean isDraggingHorizontal = false;
    private boolean isDraggingVertical = false;
    private boolean isHoveringHorizontal = false;
    private boolean isHoveringVertical = false;

    private float horizontalThumbX = 0f;
    private float verticalThumbY = 0f;
    private float dragStartX = 0f;
    private float dragStartY = 0f;
    private float scrollStartValue = 0f;

    private float bounceBack = 0f;
    private float maxBounce = 50f;
    private boolean enableBounce = true;

    private boolean showScrollIndicators = true;
    private float indicatorFade = 0f;
    private float lastScrollTime = 0f;

    private Consumer<ScrollPane> onScroll = pane -> {};
    private Supplier<Float> scrollYSupplier = () -> scrollY;
    private Supplier<Float> scrollXSupplier = () -> scrollX;

    private boolean isMouseWheelEnabled = true;
    private float mouseWheelMultiplier = 3f;
    private boolean shiftScrollsHorizontal = false;

    public ScrollPane() {
        super();
        setPassEvents(true);
        initContent();
    }

    public ScrollPane(float width, float height) {
        this();
        setSize(width, height);
    }

    private void initContent() {
        content = new UIContainer() {
            @Override
            public void update(int mouseX, int mouseY, float partialTicks) {
                updateChildren(mouseX, mouseY, partialTicks);
            }
        };
        content.setPassEvents(true);
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        if (content != null) {
            content.init(root);
        }
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        updateScrollbarHover(mouseX, mouseY);
        updateDragging(mouseX, mouseY, partialTicks);

        if (smoothScrolling) {
            scrollX = Easing.lerp(scrollX, targetScrollX, smoothScrollFactor);
            scrollY = Easing.lerp(scrollY, targetScrollY, smoothScrollFactor);
        } else {
            scrollX = targetScrollX;
            scrollY = targetScrollY;
        }

        clampScroll();
        updateBounce(partialTicks);
        updateIndicators(partialTicks);

        float hoverTarget = (isHoveringHorizontal || isHoveringVertical ||
                           isDraggingHorizontal || isDraggingVertical) ? 1f : 0f;
        scrollbarHoverProgress = Easing.lerp(scrollbarHoverProgress, hoverTarget, 0.15f);

        lastScrollTime += partialTicks / 60f;
    }

    private void updateScrollbarHover(int mouseX, int mouseY) {
        BoundingBox bounds = getBounds();
        float viewWidth = bounds.getWidth();
        float viewHeight = bounds.getHeight();

        if (showHorizontalScrollbar) {
            float hTrackY = bounds.getY() + viewHeight - scrollbarWidth - scrollbarPadding;
            isHoveringHorizontal = isInBounds(mouseX, mouseY,
                bounds.getX() + scrollbarPadding,
                hTrackY,
                viewWidth - scrollbarPadding * 2,
                scrollbarWidth);
        }

        if (showVerticalScrollbar) {
            float vTrackX = bounds.getX() + viewWidth - scrollbarWidth - scrollbarPadding;
            isHoveringVertical = isInBounds(mouseX, mouseY,
                vTrackX,
                bounds.getY() + scrollbarPadding,
                scrollbarWidth,
                viewHeight - scrollbarPadding * 2);
        }
    }

    private void updateDragging(int mouseX, int mouseY, float partialTicks) {
        if (isDraggingHorizontal) {
            BoundingBox bounds = getBounds();
            float viewWidth = bounds.getWidth();
            float trackWidth = viewWidth - scrollbarPadding * 2;
            float thumbWidth = getHorizontalThumbWidth();
            float maxThumbX = trackWidth - thumbWidth;

            float thumbX = horizontalThumbX;
            float relativeX = mouseX - dragStartX;
            float newThumbX = scrollStartValue + relativeX;

            float ratio = Math.max(0, Math.min(1, newThumbX / maxThumbX));
            setScrollX(ratio * getMaxScrollX());
            targetScrollX = scrollX;
        }

        if (isDraggingVertical) {
            BoundingBox bounds = getBounds();
            float viewHeight = bounds.getHeight();
            float trackHeight = viewHeight - scrollbarPadding * 2;
            float thumbHeight = getVerticalThumbHeight();
            float maxThumbY = trackHeight - thumbHeight;

            float relativeY = mouseY - dragStartY;
            float newThumbY = scrollStartValue + relativeY;

            float ratio = Math.max(0, Math.min(1, newThumbY / maxThumbY));
            setScrollY(ratio * getMaxScrollY());
            targetScrollY = scrollY;
        }
    }

    private void updateBounce(float partialTicks) {
        if (!enableBounce) return;

        float minScrollY = getMinScrollY();
        float maxScrollY = getMaxScrollY();
        float minScrollX = getMinScrollX();
        float maxScrollX = getMaxScrollX();

        if (scrollY < minScrollY) {
            bounceBack = scrollY - minScrollY;
        } else if (scrollY > maxScrollY) {
            bounceBack = scrollY - maxScrollY;
        } else {
            bounceBack *= 0.9f;
        }

        if (Math.abs(bounceBack) < 0.5f) {
            bounceBack = 0f;
        }
    }

    private void updateIndicators(float partialTicks) {
        float timeSinceScroll = lastScrollTime;

        if (timeSinceScroll > 2f) {
            indicatorFade = Easing.lerp(indicatorFade, 0f, 0.1f);
        } else {
            indicatorFade = Easing.lerp(indicatorFade, 1f, 0.2f);
        }
    }

    private void clampScroll() {
        float minScrollX = getMinScrollX();
        float maxScrollX = getMaxScrollX();
        float minScrollY = getMinScrollY();
        float maxScrollY = getMaxScrollY();

        if (!scrollLockedX) {
            scrollX = Math.max(minScrollX, Math.min(maxScrollX, scrollX));
            targetScrollX = Math.max(minScrollX, Math.min(maxScrollX, targetScrollX));
        }

        if (!scrollLockedY) {
            scrollY = Math.max(minScrollY, Math.min(maxScrollY, scrollY));
            targetScrollY = Math.max(minScrollY, Math.min(maxScrollY, targetScrollY));
        }
    }

    private float getMinScrollX() {
        return 0f;
    }

    private float getMinScrollY() {
        return 0f;
    }

    private float getMaxScrollX() {
        return Math.max(0, contentWidth - getBounds().getWidth());
    }

    private float getMaxScrollY() {
        return Math.max(0, contentHeight - getBounds().getHeight());
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        Draw.pushMatrix();

        Draw.enableScissor((int)x, (int)(y + height), (int)(x + width), (int)y);

        Draw.pushMatrix();
        Draw.translate(-scrollX, -scrollY + bounceBack);

        if (content != null) {
            content.render(partialTicks);
        }

        Draw.popMatrix();
        Draw.disableScissor();

        if (showScrollIndicators && indicatorFade > 0.01f) {
            renderScrollIndicators(x, y, width, height);
        }

        if (showHorizontalScrollbar &&
            (horizontalScrollbarVisibility == ScrollBarVisibility.ALWAYS ||
             (horizontalScrollbarVisibility == ScrollBarVisibility.AUTO && getMaxScrollX() > 0))) {
            renderHorizontalScrollbar(x, y, width, height);
        }

        if (showVerticalScrollbar &&
            (verticalScrollbarVisibility == ScrollBarVisibility.ALWAYS ||
             (verticalScrollbarVisibility == ScrollBarVisibility.AUTO && getMaxScrollY() > 0))) {
            renderVerticalScrollbar(x, y, width, height);
        }

        Draw.popMatrix();
    }

    private void renderHorizontalScrollbar(float x, float y, float width, float height) {
        float trackY = y + height - scrollbarWidth - scrollbarPadding;
        float trackWidth = width - scrollbarPadding * 2;
        float trackHeight = scrollbarWidth;

        int trackCol = ((int)(scrollbarHoverProgress * 0.3f * 255) << 24) |
                       (scrollbarTrackColor & 0x00FFFFFF);

        if (horizontalScrollbarStyle == ScrollBarStyle.THIN) {
            Draw.drawRoundedRect(x + scrollbarPadding, trackY + trackHeight / 2f - 1,
                               trackWidth, 2, 1, trackCol);
        } else {
            Draw.drawRoundedRect(x + scrollbarPadding, trackY, trackWidth, trackHeight,
                               scrollbarRadius, trackCol);
        }

        float thumbWidth = getHorizontalThumbWidth();
        float thumbX = x + scrollbarPadding + (getScrollX() / getMaxScrollX()) *
                      (trackWidth - thumbWidth) * (getMaxScrollX() > 0 ? 1 : 0);

        int thumbCol = getThumbColor();
        float radius = horizontalScrollbarStyle == ScrollBarStyle.ROUND ?
                      thumbWidth / 2f : scrollbarRadius;

        switch (horizontalScrollbarStyle) {
            case GLOW:
                int glowCol = ((int)(scrollbarHoverProgress * 0.3f * 255) << 24) |
                             (glowColor & 0x00FFFFFF);
                Draw.drawRoundedRect(thumbX - 2, trackY - 2, thumbWidth + 4, trackHeight + 4,
                                   radius + 2, glowCol);
                Draw.drawRoundedRect(thumbX, trackY, thumbWidth, trackHeight, radius, thumbCol);
                break;
            case FLAT:
                Draw.drawRect(thumbX, trackY + 2, thumbWidth, trackHeight - 4, thumbCol);
                break;
            default:
                Draw.drawRoundedRect(thumbX, trackY, thumbWidth, trackHeight, radius, thumbCol);
                break;
        }
    }

    private void renderVerticalScrollbar(float x, float y, float width, float height) {
        float trackX = x + width - scrollbarWidth - scrollbarPadding;
        float trackHeight = height - scrollbarPadding * 2;
        float trackWidth = scrollbarWidth;

        int trackCol = ((int)(scrollbarHoverProgress * 0.3f * 255) << 24) |
                       (scrollbarTrackColor & 0x00FFFFFF);

        if (verticalScrollbarStyle == ScrollBarStyle.THIN) {
            Draw.drawRoundedRect(trackX + trackWidth / 2f - 1, y + scrollbarPadding,
                               2, trackHeight, 1, trackCol);
        } else {
            Draw.drawRoundedRect(trackX, y + scrollbarPadding, trackWidth, trackHeight,
                               scrollbarRadius, trackCol);
        }

        float thumbHeight = getVerticalThumbHeight();
        float thumbY = y + scrollbarPadding + (getScrollY() / getMaxScrollY()) *
                      (trackHeight - thumbHeight) * (getMaxScrollY() > 0 ? 1 : 0);

        int thumbCol = getThumbColor();
        float radius = verticalScrollbarStyle == ScrollBarStyle.ROUND ?
                      thumbHeight / 2f : scrollbarRadius;

        switch (verticalScrollbarStyle) {
            case GLOW:
                int glowCol = ((int)(scrollbarHoverProgress * 0.3f * 255) << 24) |
                             (glowColor & 0x00FFFFFF);
                Draw.drawRoundedRect(trackX - 2, thumbY - 2, trackWidth + 4, thumbHeight + 4,
                                   radius + 2, glowCol);
                Draw.drawRoundedRect(trackX, thumbY, trackWidth, thumbHeight, radius, thumbCol);
                break;
            case FLAT:
                Draw.drawRect(trackX + 2, thumbY, trackWidth - 4, thumbHeight, thumbCol);
                break;
            default:
                Draw.drawRoundedRect(trackX, thumbY, trackWidth, thumbHeight, radius, thumbCol);
                break;
        }
    }

    private int getThumbColor() {
        float intensity = scrollbarHoverProgress;
        if (isDraggingHorizontal || isDraggingVertical) {
            return scrollbarDragColor;
        } else if (isHoveringHorizontal || isHoveringVertical) {
            return scrollbarHoverColor;
        }
        return scrollbarColor;
    }

    private void renderScrollIndicators(float x, float y, float width, float height) {
        int alpha = (int)(indicatorFade * 100);

        if (scrollX > 0) {
            int leftColor = (alpha << 24) | 0x333333;
            Draw.drawGradientRect(x, y + height / 2f - 20, 20, 40, leftColor, 0x00000000);
        }

        if (scrollX < getMaxScrollX()) {
            int rightColor = (alpha << 24) | 0x333333;
            Draw.drawGradientRect(x + width - 20, y + height / 2f - 20, 20, 40, 0x00000000, rightColor);
        }

        if (scrollY > 0) {
            int topColor = (alpha << 24) | 0x333333;
            Draw.drawGradientRect(x + width / 2f - 20, y, 40, 20, topColor, 0x00000000);
        }

        if (scrollY < getMaxScrollY()) {
            int bottomColor = (alpha << 24) | 0x333333;
            Draw.drawGradientRect(x + width / 2f - 20, y + height - 20, 40, 20, 0x00000000, bottomColor);
        }
    }

    private float getHorizontalThumbWidth() {
        float viewWidth = getBounds().getWidth();
        float ratio = viewWidth / contentWidth;
        return Math.max(20f, scrollbarWidth * 2 * ratio);
    }

    private float getVerticalThumbHeight() {
        float viewHeight = getBounds().getHeight();
        float ratio = viewHeight / contentHeight;
        return Math.max(20f, scrollbarHeight * ratio);
    }

    @Override
    public boolean onMouseScroll(int mouseX, int mouseY, int scrollAmount) {
        if (!isMouseWheelEnabled) return false;

        if (!isMouseOver()) return false;

        float multiplier = invertScroll ? -1 : 1;
        float scrollDelta = scrollAmount * scrollSpeed * mouseWheelMultiplier * multiplier * -1;

        if (shiftScrollsHorizontal && isShiftKeyDown()) {
            setScrollX(getScrollX() + scrollDelta);
        } else {
            setScrollY(getScrollY() + scrollDelta);
        }

        targetScrollX = scrollX;
        targetScrollY = scrollY;
        lastScrollTime = 0f;

        onScroll.accept(this);
        return true;
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        BoundingBox bounds = getBounds();

        if (showVerticalScrollbar) {
            float vTrackX = bounds.getX() + bounds.getWidth() - scrollbarWidth - scrollbarPadding;
            float vTrackY = bounds.getY() + scrollbarPadding;
            float trackHeight = bounds.getHeight() - scrollbarPadding * 2;
            float thumbHeight = getVerticalThumbHeight();
            float thumbY = vTrackY + (getScrollY() / getMaxScrollY()) * (trackHeight - thumbHeight);

            if (isInBounds(mouseX, mouseY, vTrackX, thumbY, scrollbarWidth, thumbHeight)) {
                isDraggingVertical = true;
                dragStartY = mouseY;
                scrollStartValue = thumbY - vTrackY;
                return true;
            }
        }

        if (showHorizontalScrollbar) {
            float hTrackY = bounds.getY() + bounds.getHeight() - scrollbarWidth - scrollbarPadding;
            float hTrackX = bounds.getX() + scrollbarPadding;
            float trackWidth = bounds.getWidth() - scrollbarPadding * 2;
            float thumbWidth = getHorizontalThumbWidth();
            float thumbX = hTrackX + (getScrollX() / getMaxScrollX()) * (trackWidth - thumbWidth);

            if (isInBounds(mouseX, mouseY, thumbX, hTrackY, thumbWidth, scrollbarWidth)) {
                isDraggingHorizontal = true;
                dragStartX = mouseX;
                scrollStartValue = thumbX - hTrackX;
                return true;
            }
        }

        return false;
    }

    @Override
    public boolean onMouseRelease(int mouseX, int mouseY, int mouseButton) {
        if (isDraggingHorizontal) {
            isDraggingHorizontal = false;
            return true;
        }
        if (isDraggingVertical) {
            isDraggingVertical = false;
            return true;
        }
        return false;
    }

    private boolean isInBounds(float px, float py, float bx, float by, float bw, float bh) {
        return px >= bx && px <= bx + bw && py >= by && py <= by + bh;
    }

    public ScrollPane setScrollX(float value) {
        this.scrollX = Math.max(getMinScrollX(), Math.min(getMaxScrollX(), value));
        this.targetScrollX = scrollX;
        return this;
    }

    public ScrollPane setScrollY(float value) {
        this.scrollY = Math.max(getMinScrollY(), Math.min(getMaxScrollY(), value));
        this.targetScrollY = scrollY;
        return this;
    }

    public ScrollPane scrollToTop() {
        setScrollY(0);
        return this;
    }

    public ScrollPane scrollToBottom() {
        setScrollY(getMaxScrollY());
        return this;
    }

    public ScrollPane scrollBy(float deltaX, float deltaY) {
        setScrollX(getScrollX() + deltaX);
        setScrollY(getScrollY() + deltaY);
        return this;
    }

    public ScrollPane setContentSize(float width, float height) {
        this.contentWidth = width;
        this.contentHeight = height;
        if (content != null) {
            content.setMinSize(width, height);
        }
        return this;
    }

    public ScrollPane setContent(UIContainer content) {
        this.content = content;
        return this;
    }

    public UIContainer getContent() {
        return content;
    }

    public float getScrollX() { return scrollX; }
    public float getScrollY() { return scrollY; }
    public float getContentWidth() { return contentWidth; }
    public float getContentHeight() { return contentHeight; }

    public ScrollPane setScrollSpeed(float speed) {
        this.scrollSpeed = speed;
        return this;
    }

    public ScrollPane setSmoothScrolling(boolean smooth) {
        this.smoothScrolling = smooth;
        return this;
    }

    public ScrollPane setSmoothScrollFactor(float factor) {
        this.smoothScrollFactor = factor;
        return this;
    }

    public ScrollPane setShowHorizontalScrollbar(boolean show) {
        this.showHorizontalScrollbar = show;
        return this;
    }

    public ScrollPane setShowVerticalScrollbar(boolean show) {
        this.showVerticalScrollbar = show;
        return this;
    }

    public ScrollPane setScrollBarStyle(ScrollBarStyle style) {
        this.verticalScrollbarStyle = style;
        this.horizontalScrollbarStyle = style;
        return this;
    }

    public ScrollPane setScrollBarVisibility(ScrollBarVisibility visibility) {
        this.verticalScrollbarVisibility = visibility;
        this.horizontalScrollbarVisibility = visibility;
        return this;
    }

    public ScrollPane setScrollBarWidth(float width) {
        this.scrollbarWidth = width;
        return this;
    }

    public ScrollPane setColors(int track, int thumb) {
        this.scrollbarTrackColor = track;
        this.scrollbarColor = thumb;
        return this;
    }

    public ScrollPane setScrollBarColors(int track, int thumb, int hover, int drag) {
        this.scrollbarTrackColor = track;
        this.scrollbarColor = thumb;
        this.scrollbarHoverColor = hover;
        this.scrollbarDragColor = drag;
        return this;
    }

    public ScrollPane setMouseWheelEnabled(boolean enabled) {
        this.isMouseWheelEnabled = enabled;
        return this;
    }

    public ScrollPane setMouseWheelMultiplier(float multiplier) {
        this.mouseWheelMultiplier = multiplier;
        return this;
    }

    public ScrollPane setShiftScrollsHorizontal(boolean shift) {
        this.shiftScrollsHorizontal = shift;
        return this;
    }

    public ScrollPane setEnableBounce(boolean enable) {
        this.enableBounce = enable;
        return this;
    }

    public ScrollPane setScrollLockedX(boolean locked) {
        this.scrollLockedX = locked;
        return this;
    }

    public ScrollPane setScrollLockedY(boolean locked) {
        this.scrollLockedY = locked;
        return this;
    }

    public ScrollPane setOnScroll(Consumer<ScrollPane> onScroll) {
        this.onScroll = onScroll;
        return this;
    }

    public ScrollPane setScrollYSupplier(Supplier<Float> supplier) {
        this.scrollYSupplier = supplier;
        return this;
    }

    public ScrollPane setScrollXSupplier(Supplier<Float> supplier) {
        this.scrollXSupplier = supplier;
        return this;
    }

    private boolean isShiftKeyDown() {
        return false;
    }

    @Override
    public String toString() {
        return "ScrollPane{scrollX=" + scrollX + ", scrollY=" + scrollY +
               ", contentSize=" + contentWidth + "x" + contentHeight + "}";
    }
}
