package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.ColorScience;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class ColorPicker extends UIComponent {

    public enum Mode {
        RGB, HSV, HSL, HEX
    }

    private Mode mode = Mode.HSL;

    private float hue = 0f;
    private float saturation = 1f;
    private float lightness = 0.5f;

    private float red = 1f;
    private float green = 0f;
    private float blue = 0f;

    private float previewAlpha = 1f;

    private boolean isOpen = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;

    private boolean hueDragging = false;
    private boolean satLightDragging = false;
    private boolean alphaDragging = false;
    private boolean hexDragging = false;

    private float previewWidth = 60f;
    private float previewHeight = 40f;
    private float sliderHeight = 20f;
    private float hueBarHeight = 16f;
    private float alphaBarHeight = 16f;
    private float satLightAreaSize = 180f;
    private float inputWidth = 50f;
    private float inputHeight = 24f;
    private float borderRadius = 4f;
    private float padding = 8f;

    private float previewScale = 1f;
    private float animationProgress = 0f;
    private float hoverScale = 1f;

    private int currentColor = 0xFFFF0000;
    private int previousColor = 0xFFFFFFFF;

    private boolean showAlpha = true;
    private boolean showPreviousColor = true;
    private boolean useGradientPreview = false;

    private String hexValue = "#FF0000";

    private boolean glowEnabled = false;
    private float glowIntensity = 0f;
    private int glowColor = 0x80FF0000;

    private boolean animated = true;
    private boolean showModeSelector = true;
    private boolean showColorPresets = false;

    private List<Integer> presetColors = new ArrayList<>();
    private int presetHoverIndex = -1;
    private float presetSize = 20f;
    private float presetGap = 4f;

    private Consumer<ColorPicker> onColorChange = picker -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;
    private Supplier<Integer> colorSupplier = () -> currentColor;

    public ColorPicker() {
        super();
        setClickable(true);
        initPresets();
        updateDimensions();
    }

    public ColorPicker(int initialColor) {
        this();
        setColor(initialColor);
    }

    private void initPresets() {
        presetColors.add(0xFFFF0000);
        presetColors.add(0xFFFF7F00);
        presetColors.add(0xFFFFFF00);
        presetColors.add(0xFF00FF00);
        presetColors.add(0xFF00FFFF);
        presetColors.add(0xFF0000FF);
        presetColors.add(0xFFFF00FF);
        presetColors.add(0xFFFFFFFF);
        presetColors.add(0xFF000000);
        presetColors.add(0xFF808080);
        presetColors.add(0xFFC0C0C0);
        presetColors.add(0xFF404040);
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateDimensions();
    }

    private void updateDimensions() {
        float width = previewWidth + padding * 3 + satLightAreaSize;
        float height = padding * 2 + previewHeight + padding + hueBarHeight + padding;

        if (showAlpha) {
            height += padding + alphaBarHeight;
        }

        if (showModeSelector) {
            height += padding + inputHeight + padding * 0.5f;
        }

        if (showColorPresets && !presetColors.isEmpty()) {
            int cols = 6;
            int rows = (int) Math.ceil((float) presetColors.size() / cols);
            height += padding + rows * presetSize + (rows - 1) * presetGap;
        }

        if (isOpen) {
            setMinSize(width, height);
        } else {
            setMinSize(previewWidth + 20f, previewHeight + 4f);
        }
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        int newColor = colorSupplier.get();
        if (newColor != currentColor) {
            setColorDirect(newColor);
        }

        isDisabled = isDisabledSupplier.get();

        boolean newHovered = isMouseOver() && !isDisabled;
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        float targetScale = isHovered && !isDisabled ? 1.05f : 1f;
        hoverScale = Easing.lerp(hoverScale, targetScale, 0.15f);

        float targetProgress = isOpen ? 1f : 0f;
        animationProgress = Easing.lerp(animationProgress, targetProgress, 0.25f);

        if (glowEnabled) {
            glowIntensity = Easing.lerp(glowIntensity, isOpen ? 1f : 0f, 0.15f);
        }

        previewScale = Easing.easeOutBack(animationProgress);
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        Draw.pushMatrix();
        Draw.translate(x + bounds.getWidth() / 2f, y + bounds.getHeight() / 2f, 0);
        Draw.scale(hoverScale, hoverScale, 1f);
        Draw.translate(-(x + bounds.getWidth() / 2f), -(y + bounds.getHeight() / 2f), 0);

        if (glowEnabled && glowIntensity > 0) {
            int glowCol = ((int)(glowIntensity * 0.4f * 255) << 24) | (glowColor & 0x00FFFFFF);
            Draw.drawRoundedRect(x - 4f, y - 4f, previewWidth + 8f, previewHeight + 8f,
                                borderRadius + 4f, glowCol);
        }

        renderPreviewTrigger(x, y);
        Draw.popMatrix();

        if (animationProgress > 0.01f) {
            renderFullPicker(x, y + previewHeight + 6f, partialTicks);
        }
    }

    private void renderPreviewTrigger(float x, float y) {
        if (showPreviousColor && previousColor != currentColor) {
            float checkSize = 8f;
            for (int i = 0; i < previewWidth / checkSize; i++) {
                for (int j = 0; j < previewHeight / checkSize; j++) {
                    boolean isLight = (i + j) % 2 == 0;
                    int bgColor = isLight ? 0xFFFFFFFF : 0xFFE0E0E0;
                    Draw.drawRect(x + i * checkSize, y + j * checkSize, checkSize, checkSize, bgColor);
                }
            }
        }

        Draw.drawRoundedRect(x, y, previewWidth, previewHeight, borderRadius, currentColor);
        Draw.drawRoundedRectOutline(x, y, previewWidth, previewHeight, borderRadius, 1.5f,
                                   isDisabled ? 0xFFCCCCCC : 0xFF888888);

        if (isOpen) {
            Draw.drawTriangle(x + previewWidth / 2f, y + previewHeight + 4f,
                            x + previewWidth / 2f - 5f, y + previewHeight + 10f,
                            x + previewWidth / 2f + 5f, y + previewHeight + 10f,
                            isDisabled ? 0xFFCCCCCC : 0xFF888888);
        } else {
            Draw.drawTriangle(x + previewWidth / 2f, y + previewHeight + 6f,
                            x + previewWidth / 2f - 4f, y + previewHeight,
                            x + previewWidth / 2f + 4f, y + previewHeight,
                            isDisabled ? 0xFFCCCCCC : 0xFF888888);
        }
    }

    private void renderFullPicker(float x, float y, float partialTicks) {
        float width = previewWidth + padding * 2 + satLightAreaSize;
        float height = 0;

        float satLightY = y;
        height += satLightAreaSize;

        float hueY = satLightY + satLightAreaSize + padding;
        height += hueBarHeight;

        float alphaY = hueY + hueBarHeight + padding;
        if (showAlpha) {
            height += alphaBarHeight;
        } else {
            alphaY = hueY;
        }

        float modeY = alphaY + (showAlpha ? alphaBarHeight : 0) + padding;
        if (showModeSelector) {
            height += inputHeight + padding * 0.5f;
        }

        float presetY = modeY + (showModeSelector ? inputHeight + padding * 0.5f : 0);
        if (showColorPresets && !presetColors.isEmpty()) {
            int cols = 6;
            int rows = (int) Math.ceil((float) presetColors.size() / cols);
            height += padding + rows * presetSize + (rows - 1) * presetGap;
        }

        Draw.pushMatrix();
        Draw.scale(1f, animationProgress, 1f);
        Draw.translate(0, -height * (1 - animationProgress), 0);
        Draw.popMatrix();

        renderSaturationLightnessArea(x, satLightY);
        renderHueBar(x, hueY);

        if (showAlpha) {
            renderAlphaBar(x, alphaY);
        }

        if (showModeSelector) {
            renderModeSelector(x, modeY);
        }

        if (showColorPresets && !presetColors.isEmpty()) {
            renderPresets(x, presetY);
        }
    }

    private void renderSaturationLightnessArea(float x, float y) {
        int bgWhite = 0xFFFFFFFF;
        Draw.drawRect(x, y, satLightAreaSize, satLightAreaSize, bgWhite);

        float hueColor = ColorScience.hslToRgb(hue, 1f, 0.5f);
        Draw.drawRect(x, y, satLightAreaSize, satLightAreaSize, hueColor);

        float whiteToTransparent = 0x00FFFFFF;
        Draw.drawRect(x, y, satLightAreaSize * (1 - saturation), satLightAreaSize, whiteToTransparent);

        float transparentToBlack = 0xFF000000 | ((int)(255 * (1 - lightness)) << 24);
        Draw.drawRect(x, y + satLightAreaSize * lightness, satLightAreaSize, satLightAreaSize * (1 - lightness), transparentToBlack);

        float pickerX = x + saturation * satLightAreaSize;
        float pickerY = y + (1 - lightness) * satLightAreaSize;

        Draw.drawCircle(pickerX, pickerY, 6f, 0xFFFFFFFF);
        Draw.drawCircleOutline(pickerX, pickerY, 6f, 1.5f, 0xFF000000);
        Draw.drawCircleOutline(pickerX, pickerY, 4f, 1f, 0xFFFFFFFF);
    }

    private void renderHueBar(float x, float y) {
        float barWidth = satLightAreaSize;
        int segments = 12;

        for (int i = 0; i < segments; i++) {
            float t1 = (float) i / segments;
            float t2 = (float) (i + 1) / segments;

            int color1 = ColorScience.hslToRgb(t1, 1f, 0.5f);
            int color2 = ColorScience.hslToRgb(t2, 1f, 0.5f);

            float segWidth = barWidth / segments;
            Draw.drawGradientRect(x + i * segWidth, y, segWidth + 1, hueBarHeight, color1, color2, true);
        }

        float hueHandleX = x + hue * barWidth;
        Draw.drawRoundedRect(hueHandleX - 4f, y - 2f, 8f, hueBarHeight + 4f, 3f, 0xFFFFFFFF);
        Draw.drawRoundedRectOutline(hueHandleX - 4f, y - 2f, 8f, hueBarHeight + 4f, 3f, 1f, 0xFF000000);
    }

    private void renderAlphaBar(float x, float y) {
        float barWidth = satLightAreaSize;

        float checkSize = 8f;
        for (int i = 0; i < barWidth / checkSize; i++) {
            for (int j = 0; j < alphaBarHeight / checkSize; j++) {
                boolean isLight = (i + j) % 2 == 0;
                int bgColor = isLight ? 0xFFFFFFFF : 0xFFE0E0E0;
                Draw.drawRect(x + i * checkSize, y + j * checkSize, checkSize, checkSize, bgColor);
            }
        }

        int opaqueColor = currentColor | 0xFF000000;
        int transparentColor = currentColor & 0x00FFFFFF;
        Draw.drawGradientRect(x, y, barWidth, alphaBarHeight, opaqueColor, transparentColor, true);

        float alphaHandleX = x + previewAlpha * barWidth;
        Draw.drawRoundedRect(alphaHandleX - 4f, y - 2f, 8f, alphaBarHeight + 4f, 3f, 0xFFFFFFFF);
        Draw.drawRoundedRectOutline(alphaHandleX - 4f, y - 2f, 8f, alphaBarHeight + 4f, 3f, 1f, 0xFF000000);
    }

    private void renderModeSelector(float x, float y) {
        float totalWidth = satLightAreaSize;
        float buttonWidth = totalWidth / 4f;

        String[] modes = {"RGB", "HSV", "HSL", "HEX"};

        for (int i = 0; i < modes.length; i++) {
            Mode m = Mode.valueOf(modes[i]);
            boolean isSelected = mode == m;

            int bgColor = isSelected ? currentColor : 0xFFF5F5F5;
            int textColor = isSelected ? 0xFFFFFFFF : 0xFF333333;

            Draw.drawRoundedRect(x + i * buttonWidth, y, buttonWidth - 2f, inputHeight,
                                borderRadius, bgColor);

            net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getMinecraft();
            net.minecraft.client.gui.FontRenderer fr = mc.fontRendererObj;

            String label = modes[i];
            float textWidth = fr.getStringWidth(label);
            float textX = x + i * buttonWidth + (buttonWidth - 2f) / 2f - textWidth / 2f;
            float textY = y + inputHeight / 2f - fr.FONT_HEIGHT / 2f;

            Draw.drawString(label, textX, textY, textColor, 1f);
        }
    }

    private void renderPresets(float x, float y) {
        int cols = 6;
        float totalWidth = satLightAreaSize;
        float rowWidth = (presetSize + presetGap) * cols - presetGap;

        for (int i = 0; i < presetColors.size(); i++) {
            int col = i % cols;
            int row = i / cols;

            float px = x + col * (presetSize + presetGap);
            float py = y + row * (presetSize + presetGap);

            int presetColor = presetColors.get(i);
            boolean isHovered = presetHoverIndex == i;

            if (isHovered) {
                Draw.drawRoundedRect(px - 2f, py - 2f, presetSize + 4f, presetSize + 4f,
                                    borderRadius + 2f, 0xFF2196F3);
            }

            Draw.drawRoundedRect(px, py, presetSize, presetSize, borderRadius, presetColor);
        }
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        if (!isOpen) {
            isOpen = true;
            updateDimensions();
            return true;
        }

        float satLightY = y + previewHeight + 6f;
        if (isInArea(mouseX, mouseY, x, satLightY, satLightAreaSize, satLightAreaSize)) {
            satLightDragging = true;
            updateSatLightFromMouse(mouseX, mouseY, x, satLightY);
            return true;
        }

        float hueY = satLightY + satLightAreaSize + padding;
        if (isInArea(mouseX, mouseY, x, hueY, satLightAreaSize, hueBarHeight)) {
            hueDragging = true;
            updateHueFromMouse(mouseX, x, satLightAreaSize);
            return true;
        }

        float alphaY = hueY + hueBarHeight + padding;
        if (showAlpha && isInArea(mouseX, mouseY, x, alphaY, satLightAreaSize, alphaBarHeight)) {
            alphaDragging = true;
            updateAlphaFromMouse(mouseX, x, satLightAreaSize);
            return true;
        }

        return true;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        if (!isOpen) {
            isOpen = true;
            updateDimensions();
            return true;
        }

        float satLightY = y + previewHeight + 6f;
        if (isInArea(mouseX, mouseY, x, satLightY, satLightAreaSize, satLightAreaSize)) {
            updateSatLightFromMouse(mouseX, mouseY, x, satLightY);
            notifyColorChange();
            return true;
        }

        float hueY = satLightY + satLightAreaSize + padding;
        if (isInArea(mouseX, mouseY, x, hueY, satLightAreaSize, hueBarHeight)) {
            updateHueFromMouse(mouseX, x, satLightAreaSize);
            notifyColorChange();
            return true;
        }

        float alphaY = hueY + hueBarHeight + padding;
        if (showAlpha && isInArea(mouseX, mouseY, x, alphaY, satLightAreaSize, alphaBarHeight)) {
            updateAlphaFromMouse(mouseX, x, satLightAreaSize);
            notifyColorChange();
            return true;
        }

        float modeY = alphaY + (showAlpha ? alphaBarHeight : 0) + padding;
        if (showModeSelector) {
            float buttonWidth = satLightAreaSize / 4f;
            for (int i = 0; i < 4; i++) {
                if (isInArea(mouseX, mouseY, x + i * buttonWidth, modeY, buttonWidth, inputHeight)) {
                    mode = Mode.values()[i];
                    return true;
                }
            }
        }

        float presetY = modeY + (showModeSelector ? inputHeight + padding * 0.5f : 0);
        if (showColorPresets && !presetColors.isEmpty()) {
            int cols = 6;
            for (int i = 0; i < presetColors.size(); i++) {
                int col = i % cols;
                int row = i / cols;
                float px = x + col * (presetSize + presetGap);
                float py = presetY + row * (presetSize + presetGap);

                if (isInArea(mouseX, mouseY, px, py, presetSize, presetSize)) {
                    setColor(presetColors.get(i));
                    onColorChange.accept(this);
                    return true;
                }
            }
        }

        isOpen = false;
        updateDimensions();
        return true;
    }

    @Override
    public void onMouseDrag(int mouseX, int mouseY, int clickedMouseButton, long timeSinceClick) {
        if (isDisabled) return;

        if (satLightDragging) {
            BoundingBox bounds = getBounds();
            float x = bounds.getX();
            float satLightY = bounds.getY() + previewHeight + 6f;
            updateSatLightFromMouse(mouseX, mouseY, x, satLightY);
        } else if (hueDragging) {
            BoundingBox bounds = getBounds();
            float x = bounds.getX();
            updateHueFromMouse(mouseX, x, satLightAreaSize);
        } else if (alphaDragging) {
            BoundingBox bounds = getBounds();
            float x = bounds.getX();
            float satLightY = bounds.getY() + previewHeight + 6f;
            float hueY = satLightY + satLightAreaSize + padding;
            updateAlphaFromMouse(mouseX, x, satLightAreaSize);
        }
    }

    @Override
    public boolean onMouseRelease(int mouseX, int mouseY, int mouseButton) {
        boolean wasDragging = satLightDragging || hueDragging || alphaDragging;
        satLightDragging = false;
        hueDragging = false;
        alphaDragging = false;

        if (wasDragging) {
            notifyColorChange();
        }

        return true;
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (isDisabled) return false;

        if (keyCode == 0x1) {
            isOpen = !isOpen;
            updateDimensions();
            return true;
        }

        return super.onKeyTyped(typedChar, keyCode);
    }

    private boolean isInArea(float mouseX, float mouseY, float areaX, float areaY, float areaW, float areaH) {
        return mouseX >= areaX && mouseX <= areaX + areaW
            && mouseY >= areaY && mouseY <= areaY + areaH;
    }

    private void updateSatLightFromMouse(float mouseX, float mouseY, float areaX, float areaY) {
        saturation = Math.max(0f, Math.min(1f, (mouseX - areaX) / satLightAreaSize));
        lightness = Math.max(0f, Math.min(1f, 1f - (mouseY - areaY) / satLightAreaSize));

        updateRGBFromHSL();
        updateHexFromRGB();
    }

    private void updateHueFromMouse(float mouseX, float areaX, float barWidth) {
        hue = Math.max(0f, Math.min(1f, (mouseX - areaX) / barWidth));

        updateRGBFromHSL();
        updateHexFromRGB();
    }

    private void updateAlphaFromMouse(float mouseX, float areaX, float barWidth) {
        previewAlpha = Math.max(0f, Math.min(1f, (mouseX - areaX) / barWidth));

        int alpha = (int)(previewAlpha * 255);
        currentColor = (currentColor & 0x00FFFFFF) | (alpha << 24);
    }

    private void updateRGBFromHSL() {
        int rgb = ColorScience.hslToRgb(hue, saturation, lightness);
        red = ((rgb >> 16) & 0xFF) / 255f;
        green = ((rgb >> 8) & 0xFF) / 255f;
        blue = (rgb & 0xFF) / 255f;
        currentColor = rgb | ((int)(previewAlpha * 255) << 24);
    }

    private void updateHexFromRGB() {
        int r = (int)(red * 255);
        int g = (int)(green * 255);
        int b = (int)(blue * 255);
        hexValue = String.format("#%02X%02X%02X", r, g, b);
    }

    private void setColorDirect(int color) {
        currentColor = color;
        previousColor = color;

        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;

        red = r / 255f;
        green = g / 255f;
        blue = b / 255f;

        previewAlpha = ((color >> 24) & 0xFF) / 255f;

        float[] hsl = ColorScience.rgbToHsl(red, green, blue);
        hue = hsl[0];
        saturation = hsl[1];
        lightness = hsl[2];

        updateHexFromRGB();
    }

    private void notifyColorChange() {
        onColorChange.accept(this);
    }

    public ColorPicker setColor(int color) {
        previousColor = currentColor;
        setColorDirect(color);
        onColorChange.accept(this);
        return this;
    }

    public int getColor() {
        int alpha = (int)(previewAlpha * 255);
        return (alpha << 24) | (currentColor & 0x00FFFFFF);
    }

    public int getColorWithoutAlpha() {
        return currentColor & 0x00FFFFFF;
    }

    public ColorPicker setMode(Mode mode) {
        this.mode = mode;
        return this;
    }

    public Mode getMode() { return mode; }
    public float getHue() { return hue; }
    public float getSaturation() { return saturation; }
    public float getLightness() { return lightness; }
    public float getRed() { return red; }
    public float getGreen() { return green; }
    public float getBlue() { return blue; }
    public float getAlpha() { return previewAlpha; }
    public String getHex() { return hexValue; }
    public boolean isOpen() { return isOpen; }
    public boolean isDisabled() { return isDisabled; }

    public ColorPicker setShowAlpha(boolean show) {
        this.showAlpha = show;
        updateDimensions();
        return this;
    }

    public ColorPicker setShowPreviousColor(boolean show) {
        this.showPreviousColor = show;
        return this;
    }

    public ColorPicker setShowModeSelector(boolean show) {
        this.showModeSelector = show;
        updateDimensions();
        return this;
    }

    public ColorPicker setShowPresets(boolean show) {
        this.showColorPresets = show;
        updateDimensions();
        return this;
    }

    public ColorPicker addPreset(int color) {
        this.presetColors.add(color);
        updateDimensions();
        return this;
    }

    public ColorPicker setPresets(List<Integer> colors) {
        this.presetColors = new ArrayList<>(colors);
        updateDimensions();
        return this;
    }

    public ColorPicker setUseGradientPreview(boolean use) {
        this.useGradientPreview = use;
        return this;
    }

    public ColorPicker setGlowEnabled(boolean enabled) {
        this.glowEnabled = enabled;
        return this;
    }

    public ColorPicker setGlowColor(int color) {
        this.glowColor = color;
        return this;
    }

    public ColorPicker setAnimated(boolean animated) {
        this.animated = animated;
        return this;
    }

    public ColorPicker setPreviewSize(float width, float height) {
        this.previewWidth = width;
        this.previewHeight = height;
        updateDimensions();
        return this;
    }

    public ColorPicker setSatLightAreaSize(float size) {
        this.satLightAreaSize = size;
        updateDimensions();
        return this;
    }

    public ColorPicker setOnColorChange(Consumer<ColorPicker> onChange) {
        this.onColorChange = onChange;
        return this;
    }

    public ColorPicker setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public ColorPicker setColorSupplier(Supplier<Integer> supplier) {
        this.colorSupplier = supplier;
        return this;
    }

    @Override
    public String toString() {
        return "ColorPicker{hex=" + hexValue + ", rgb=(" + (int)(red*255) + "," +
               (int)(green*255) + "," + (int)(blue*255) + ")}";
    }
}
