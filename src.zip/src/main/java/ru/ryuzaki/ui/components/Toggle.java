package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class Toggle extends UIComponent {

    private boolean isOn = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;

    private float animationProgress = 0f;
    private float thumbScale = 1f;
    private float hoverGlow = 0f;

    private float trackWidth = 44f;
    private float trackHeight = 24f;
    private float thumbSize = 18f;
    private float thumbPadding = 3f;

    private int trackOffColor = 0xFFE0E0E0;
    private int trackOnColor = 0xFF4CAF50;
    private int trackHoverOffColor = 0xFFCACACA;
    private int trackHoverOnColor = 0xFF66BB6A;

    private int thumbOffColor = 0xFFFFFFFF;
    private int thumbOnColor = 0xFFFFFFFF;
    private int thumbDisabledColor = 0xFFBDBDBD;

    private int borderColor = 0x00000000;
    private float borderWidth = 0f;
    private float borderRadius = 12f;

    private float trackShadowRadius = 4f;
    private float thumbShadowRadius = 4f;
    private int shadowColor = 0x40000000;

    private boolean showLabel = false;
    private String labelText = "";
    private String labelOn = "ON";
    private String labelOff = "OFF";
    private float labelPadding = 8f;

    private boolean animatedTrack = false;
    private float gradientOffset = 0f;

    private Consumer<Toggle> onToggle = t -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;

    private float[] rippleEffects = new float[0];

    public Toggle() {
        super();
        setClickable(true);
        setFocusable(true);
        animationProgress = isOn ? 1f : 0f;
        updateDimensions();
    }

    public Toggle(boolean initialState) {
        this();
        this.isOn = initialState;
        animationProgress = initialState ? 1f : 0f;
    }

    public Toggle(boolean initialState, Consumer<Toggle> onToggle) {
        this(initialState);
        this.onToggle = onToggle;
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateDimensions();
    }

    private void updateDimensions() {
        float totalWidth = trackWidth;
        if (showLabel) {
            totalWidth += labelPadding + trackWidth;
        }
        setMinSize(totalWidth, Math.max(trackHeight, thumbSize + thumbPadding * 2));
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        boolean newHovered = isMouseOver() && !isDisabled;
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        float targetProgress = isOn ? 1f : 0f;
        animationProgress = Easing.lerp(animationProgress, targetProgress, 0.2f);

        float targetThumbScale = isHovered && !isDisabled ? 1.1f : 1f;
        thumbScale = Easing.lerp(thumbScale, targetThumbScale, 0.15f);

        hoverGlow = Easing.lerp(hoverGlow, isHovered && !isDisabled ? 1f : 0f, 0.15f);

        if (animatedTrack) {
            gradientOffset += 0.02f;
            if (gradientOffset > 1f) gradientOffset -= 1f;
        }

        isDisabled = isDisabledSupplier.get();
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        float renderX = showLabel ? x + (isOn ? labelPadding + trackWidth : 0) : x;

        renderTrackShadow(renderX, y);
        renderTrack(renderX, y);
        renderThumb(renderX, y);
        renderGlow(renderX, y);

        if (showLabel) {
            renderLabels(x, y, bounds.getWidth());
        }
    }

    private void renderTrackShadow(float x, float y) {
        float shadowAlpha = 0.3f * (isDisabled ? 0.5f : 1f);
        int shadowCol = ((int)(shadowAlpha * 255) << 24) | (shadowColor & 0x00FFFFFF);
        Draw.drawRoundedRect(x - trackShadowRadius, y - trackShadowRadius,
                            trackWidth + trackShadowRadius * 2, trackHeight + trackShadowRadius * 2,
                            borderRadius + trackShadowRadius, shadowCol);
    }

    private void renderTrack(float x, float y) {
        int trackColor;
        if (isDisabled) {
            trackColor = trackOffColor;
        } else if (isOn) {
            trackColor = isHovered ? trackHoverOnColor : trackOnColor;
        } else {
            trackColor = isHovered ? trackHoverOffColor : trackOffColor;
        }

        if (animatedTrack && isOn) {
            renderAnimatedTrack(x, y, trackColor);
        } else {
            Draw.drawRoundedRect(x, y, trackWidth, trackHeight, borderRadius, trackColor);
        }

        if (borderWidth > 0) {
            Draw.drawRoundedRectOutline(x, y, trackWidth, trackHeight, borderRadius, borderWidth, borderColor);
        }
    }

    private void renderAnimatedTrack(float x, float y, int baseColor) {
        int r = (baseColor >> 16) & 0xFF;
        int g = (baseColor >> 8) & 0xFF;
        int b = baseColor & 0xFF;

        float segments = 8f;
        float segmentWidth = trackWidth / segments;

        for (int i = 0; i < segments; i++) {
            float offset = (gradientOffset + i / segments) % 1f;
            float alpha = 0.7f + 0.3f * (float)Math.sin(offset * Math.PI * 2);
            int segColor = (int)(alpha * 255) << 24 | (r << 16) | (g << 8) | b;
            float segX = x + i * segmentWidth;
            Draw.drawRoundedRect(segX, y, segmentWidth, trackHeight, borderRadius, segColor);
        }
    }

    private void renderThumb(float x, float y) {
        float thumbTravel = trackWidth - thumbSize - thumbPadding * 2;
        float thumbX = x + thumbPadding + animationProgress * thumbTravel;
        float thumbY = y + (trackHeight - thumbSize) / 2f;

        float thumbCenterX = thumbX + thumbSize / 2f;
        float thumbCenterY = thumbY + thumbSize / 2f;

        Draw.pushMatrix();
        Draw.translate(thumbCenterX, thumbCenterY, 0);
        Draw.scale(thumbScale, thumbScale, 1f);
        Draw.translate(-thumbCenterX, -thumbCenterY, 0);

        renderThumbShadow(thumbX, thumbY);

        int thumbColor = isDisabled ? thumbDisabledColor : (isOn ? thumbOnColor : thumbOffColor);
        float thumbRadius = thumbSize / 2f;
        Draw.drawCircle(thumbCenterX, thumbCenterY, thumbRadius, thumbColor);

        if (!isDisabled) {
            renderThumbHighlight(thumbX, thumbY);
        }

        Draw.popMatrix();
    }

    private void renderThumbShadow(float x, float y) {
        float shadowAlpha = 0.4f * thumbScale;
        int shadowCol = ((int)(shadowAlpha * 255) << 24) | 0x000000;
        float thumbCenterX = x + thumbSize / 2f;
        float thumbCenterY = y + thumbSize / 2f;
        Draw.drawCircle(thumbCenterX, thumbCenterY + 1f, thumbSize / 2f + thumbShadowRadius, shadowCol);
    }

    private void renderThumbHighlight(float x, float y) {
        float highlightRadius = thumbSize * 0.15f;
        float highlightX = x + thumbSize * 0.35f;
        float highlightY = y + thumbSize * 0.35f;
        Draw.drawCircle(highlightX, highlightY, highlightRadius, 0x30FFFFFF);
    }

    private void renderGlow(float x, float y) {
        if (hoverGlow <= 0) return;

        float glowIntensity = hoverGlow * 0.3f;
        int glowColor = (int)(glowIntensity * 255) << 24 | 0x00FFFFFF;

        float glowExpansion = 4f;
        Draw.drawRoundedRect(x - glowExpansion, y - glowExpansion,
                            trackWidth + glowExpansion * 2, trackHeight + glowExpansion * 2,
                            borderRadius + glowExpansion, glowColor);
    }

    private void renderLabels(float x, float y, float totalWidth) {
        float labelY = y + trackHeight / 2f - 4f;

        if (!isOn) {
            int offColor = isDisabled ? 0xFF888888 : 0xFF666666;
            Draw.drawString(labelOff, x + labelPadding / 2f, labelY, offColor, 1f);
        }

        if (isOn) {
            int onColor = isDisabled ? 0xFF888888 : 0xFFFFFFFF;
            float labelX = x + trackWidth + labelPadding + labelPadding / 2f;
            Draw.drawString(labelOn, labelX, labelY, onColor, 1f);
        }
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        return true;
    }

    @Override
    public boolean onMouseUp(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        if (isMouseOver()) {
            toggle();
        }
        return true;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        toggle();
        return true;
    }

    private void toggle() {
        isOn = !isOn;
        thumbScale = isOn ? 0.85f : 1.1f;
        onToggle.accept(this);
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (isDisabled) return false;

        if (keyCode == 0x1F || keyCode == 0x2E || keyCode == 32) {
            toggle();
            return true;
        }
        return super.onKeyTyped(typedChar, keyCode);
    }

    @Override
    public boolean isMouseOver() {
        return ru.ryuzaki.ui.base.GeometryUtils.pointInBounds(getBounds(), getLastMouseX(), getLastMouseY());
    }

    public Toggle setOn(boolean on) {
        this.isOn = on;
        return this;
    }

    public boolean isOn() { return isOn; }
    public boolean isOff() { return !isOn; }
    public boolean isHovered() { return isHovered; }
    public boolean isDisabled() { return isDisabled; }

    public Toggle setOnToggle(Consumer<Toggle> onToggle) {
        this.onToggle = onToggle;
        return this;
    }

    public Toggle setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public Toggle setTrackSize(float width, float height) {
        this.trackWidth = width;
        this.trackHeight = height;
        this.thumbSize = height - 6f;
        updateDimensions();
        invalidate();
        return this;
    }

    public Toggle setTrackColors(int offColor, int onColor) {
        this.trackOffColor = offColor;
        this.trackOnColor = onColor;
        return this;
    }

    public Toggle setTrackHoverColors(int offColor, int onColor) {
        this.trackHoverOffColor = offColor;
        this.trackHoverOnColor = onColor;
        return this;
    }

    public Toggle setThumbColor(int offColor, int onColor) {
        this.thumbOffColor = offColor;
        this.thumbOnColor = onColor;
        return this;
    }

    public Toggle setDisabledThumbColor(int color) {
        this.thumbDisabledColor = color;
        return this;
    }

    public Toggle setBorder(float width, int color) {
        this.borderWidth = width;
        this.borderColor = color;
        return this;
    }

    public Toggle setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public Toggle setShowLabel(boolean show) {
        this.showLabel = show;
        updateDimensions();
        invalidate();
        return this;
    }

    public Toggle setLabelText(String onText, String offText) {
        this.labelOn = onText;
        this.labelOff = offText;
        return this;
    }

    public Toggle setLabelPadding(float padding) {
        this.labelPadding = padding;
        updateDimensions();
        invalidate();
        return this;
    }

    public Toggle setAnimatedTrack(boolean animated) {
        this.animatedTrack = animated;
        return this;
    }

    @Override
    public String toString() {
        return "Toggle{isOn=" + isOn + ", isHovered=" + isHovered + ", isDisabled=" + isDisabled + '}';
    }
}
