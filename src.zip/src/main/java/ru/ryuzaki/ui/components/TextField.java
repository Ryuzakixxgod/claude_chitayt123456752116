package ru.ryuzaki.ui.components;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.base.GeometryUtils;
import ru.ryuzaki.ui.core.UIComponent;
import ru.ryuzaki.ui.core.UIRoot;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class TextField extends UIComponent {

    private StringBuilder displayText = new StringBuilder();
    private String rawText = "";
    private String hintText = "";
    private String placeholder = "";
    private String prefix = "";
    private String suffix = "";

    private boolean isFocused = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;
    private boolean isReadOnly = false;
    private boolean isPassword = false;
    private boolean isMultiline = false;
    private boolean isNumeric = false;
    private boolean isAlphanumeric = false;

    private int cursorPosition = 0;
    private int selectionStart = -1;
    private int selectionEnd = -1;
    private float cursorBlink = 0f;
    private boolean cursorVisible = true;

    private int maxLength = 255;
    private int minLength = 0;

    private float normalBrightness = 1.0f;
    private float focusBrightness = 1.0f;
    private float currentBrightness = 1.0f;

    private int backgroundColor = 0xFF1E1E1E;
    private int backgroundFocusedColor = 0xFF2D2D2D;
    private int backgroundHoverColor = 0xFF252525;
    private int backgroundDisabledColor = 0xFF1A1A1A;

    private int textColor = 0xFFFFFFFF;
    private int hintColor = 0xFF888888;
    private int placeholderColor = 0xFF666666;
    private int disabledTextColor = 0xFF555555;
    private int prefixColor = 0xFF888888;
    private int suffixColor = 0xFF888888;

    private int borderColor = 0xFF3D3D3D;
    private int borderFocusedColor = 0xFF5B9CF6;
    private int borderHoverColor = 0xFF4A4A4A;
    private int borderDisabledColor = 0xFF2D2D2D;

    private float borderWidth = 1.5f;
    private float borderRadius = 6f;

    private int selectionColor = 0x805B9CF6;
    private int cursorColor = 0xFFFFFFFF;

    private float textXOffset = 0f;
    private float labelFloatOffset = 0f;
    private boolean labelFloated = false;
    private float labelScale = 1f;

    private float shakeOffset = 0f;
    private boolean isShaking = false;
    private long shakeStartTime = 0;

    private float glowIntensity = 0f;
    private int glowColor = 0x805B9CF6;

    private float caretWidth = 2f;
    private float caretOffset = 1f;

    private List<String> history = new ArrayList<>();
    private int historyIndex = -1;
    private int maxHistorySize = 50;

    private Predicate<String> validator = text -> true;
    private Function<String, String> formatter = text -> text;
    private Consumer<TextField> onTextChange = tf -> {};
    private Consumer<TextField> onEnter = tf -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;

    private boolean enforceUppercase = false;
    private boolean enforceLowercase = false;
    private boolean autoTrim = true;

    private float errorShakeIntensity = 4f;
    private long errorShakeDuration = 300;
    private String errorMessage = "";
    private int errorColor = 0xFFEF5350;

    private boolean animatedBorder = false;
    private float borderAnimationOffset = 0f;

    private float progress = 0f;
    private boolean showProgress = false;
    private int progressColor = 0xFF4CAF50;

    private boolean showCharacterCount = false;
    private int characterCountThreshold = -1;

    private float iconSize = 16f;
    private String leftIcon = "";
    private String rightIcon = "";
    private int iconColor = 0xFF888888;
    private int iconFocusedColor = 0xFF5B9CF6;
    private float iconPadding = 8f;

    public TextField() {
        super();
        setFocusable(true);
        setClickable(true);
        cursorBlink = 0.5f;
    }

    public TextField(String hint) {
        this();
        this.hintText = hint;
        this.placeholder = hint;
    }

    @Override
    public void init(UIRoot root) {
        super.init(root);
        updateDimensions();
    }

    private void updateDimensions() {
        float height = isMultiline ? 80f : 36f;
        setMinSize(150f, height);
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        boolean newHovered = isMouseOver();
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        isDisabled = isDisabledSupplier.get();

        float targetBrightness = isDisabled ? 1f : (isFocused ? focusBrightness : normalBrightness);
        currentBrightness = Easing.lerp(currentBrightness, targetBrightness, 0.15f);

        cursorBlink += isFocused ? 0.05f : 0f;
        if (cursorBlink >= 1f) {
            cursorBlink = 0f;
            cursorVisible = !cursorVisible;
        }

        updateLabelAnimation();
        updateShake();
        updateGlow();

        if (animatedBorder && isFocused) {
            borderAnimationOffset += 0.02f;
        }
    }

    private void updateLabelAnimation() {
        boolean shouldFloat = isFocused || !displayText.toString().isEmpty();
        if (shouldFloat != labelFloated) {
            labelFloated = shouldFloat;
            labelScale = shouldFloat ? 0.85f : 1f;
        }
        labelFloatOffset = Easing.lerp(labelFloatOffset, labelFloated ? -8f : 0f, 0.2f);
        labelScale = Easing.lerp(labelScale, labelFloated ? 0.85f : 1f, 0.2f);
    }

    private void updateShake() {
        if (!isShaking) {
            shakeOffset = Easing.lerp(shakeOffset, 0f, 0.3f);
            return;
        }

        long elapsed = System.currentTimeMillis() - shakeStartTime;
        if (elapsed > errorShakeDuration) {
            isShaking = false;
            shakeOffset = 0f;
            return;
        }

        float progress = elapsed / (float) errorShakeDuration;
        float intensity = errorShakeIntensity * (1f - progress);
        shakeOffset = (float) (Math.sin(elapsed * 0.05) * intensity);
    }

    private void updateGlow() {
        float targetGlow = isFocused ? 1f : (isHovered ? 0.5f : 0f);
        glowIntensity = Easing.lerp(glowIntensity, targetGlow, 0.15f);
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        Draw.pushMatrix();
        if (shakeOffset != 0) {
            Draw.translate(shakeOffset, 0, 0);
        }

        renderBackground(x, y, width, height);
        renderBorder(x, y, width, height);
        renderGlow(x, y, width, height);
        renderProgress(x, y, width, height);
        renderContent(x, y, width, height);
        renderPrefix(x, y, width, height);
        renderSuffix(x, y, width, height);
        renderSelection(x, y, width, height);
        renderText(x, y, width, height);
        renderCursor(x, y, width, height);
        renderLabel(x, y, width, height);
        renderIcons(x, y, width, height);
        renderCharacterCount(x, y, width, height);
        renderError(x, y, width, height);

        Draw.popMatrix();
    }

    private void renderBackground(float x, float y, float width, float height) {
        int bgColor;
        if (isDisabled) {
            bgColor = backgroundDisabledColor;
        } else if (isFocused) {
            bgColor = backgroundFocusedColor;
        } else if (isHovered) {
            bgColor = backgroundHoverColor;
        } else {
            bgColor = backgroundColor;
        }

        Draw.drawRoundedRect(x, y, width, height, borderRadius, bgColor);
    }

    private void renderBorder(float x, float y, float width, float height) {
        int bColor;
        if (isDisabled) {
            bColor = borderDisabledColor;
        } else if (isFocused) {
            bColor = animatedBorder ? blendBorderColor() : borderFocusedColor;
        } else if (isHovered) {
            bColor = borderHoverColor;
        } else {
            bColor = borderColor;
        }

        if (animatedBorder && isFocused) {
            Draw.drawAnimatedRoundedRectOutline(x, y, width, height, borderRadius,
                                                borderWidth, bColor, borderAnimationOffset);
        } else {
            Draw.drawRoundedRectOutline(x, y, width, height, borderRadius, borderWidth, bColor);
        }
    }

    private int blendBorderColor() {
        float t = (float) (Math.sin(borderAnimationOffset * Math.PI * 2) + 1) / 2f;
        return Easing.lerpColor(borderColor, borderFocusedColor, t);
    }

    private void renderGlow(float x, float y, float width, float height) {
        if (glowIntensity <= 0) return;

        int glowCol = (int)(glowIntensity * 0.4f * 255) << 24 | (glowColor & 0x00FFFFFF);
        float expansion = 4f;
        Draw.drawRoundedRect(x - expansion, y - expansion, width + expansion * 2,
                            height + expansion * 2, borderRadius + expansion, glowCol);
    }

    private void renderProgress(float x, float y, float width, float height) {
        if (!showProgress || progress <= 0) return;

        float progressWidth = width * progress;
        Draw.drawRoundedRect(x, y + height - 3f, progressWidth, 3f, 1.5f, progressColor);
    }

    private void renderContent(float x, float y, float width, float height) {
        float textStartX = x + caretOffset + getIconSpace();
        float textEndX = x + width - caretOffset - getIconSpace();
        float availableWidth = textEndX - textStartX;

        updateTextOffset(availableWidth);
    }

    private float getIconSpace() {
        float space = 0;
        if (!leftIcon.isEmpty()) space += iconSize + iconPadding * 2;
        if (!rightIcon.isEmpty()) space += iconSize + iconPadding * 2;
        return space;
    }

    private void updateTextOffset(float availableWidth) {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        String visibleText = getVisibleText();
        float textWidth = fr.getStringWidth(visibleText);

        if (textWidth > availableWidth) {
            float maxOffset = textWidth - availableWidth;
            textXOffset = Easing.lerp(textXOffset, -maxOffset, 0.1f);
        } else {
            textXOffset = Easing.lerp(textXOffset, 0f, 0.1f);
        }
    }

    private String getVisibleText() {
        if (isPassword) {
            return rawText.replaceAll(".", "•");
        }
        return displayText.toString();
    }

    private void renderPrefix(float x, float y, float width, float height) {
        if (prefix.isEmpty()) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float prefixY = y + height / 2f - fr.FONT_HEIGHT / 2f;
        float prefixX = x + caretOffset + iconPadding + getIconSpace();

        Draw.drawString(prefix, prefixX, prefixY, prefixColor, 1f);
    }

    private void renderSuffix(float x, float y, float width, float height) {
        if (suffix.isEmpty()) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float suffixY = y + height / 2f - fr.FONT_HEIGHT / 2f;
        float suffixX = x + width - caretOffset - iconPadding - fr.getStringWidth(suffix) - getIconSpace();

        Draw.drawString(suffix, suffixX, suffixY, suffixColor, 1f);
    }

    private void renderSelection(float x, float y, float width, float height) {
        if (selectionStart < 0 || selectionEnd < 0 || selectionStart == selectionEnd) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float textStartX = x + caretOffset + getIconSpace() + textXOffset;
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f;

        int selStart = Math.min(selectionStart, selectionEnd);
        int selEnd = Math.max(selectionStart, selectionEnd);

        String beforeSelection = rawText.substring(0, selStart);
        String selectedText = rawText.substring(selStart, selEnd);

        float selectionX = textStartX + fr.getStringWidth(beforeSelection);
        float selectionWidth = fr.getStringWidth(selectedText);

        Draw.drawRect(selectionX, textY - 1, selectionWidth, fr.FONT_HEIGHT + 2, selectionColor);
    }

    private void renderText(float x, float y, float width, float height) {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f;
        float textX = x + caretOffset + getIconSpace() + textXOffset;

        String textToRender = displayText.toString();
        if (isPassword) {
            textToRender = textToRender.replaceAll(".", "•");
        }

        int textCol;
        if (isDisabled) {
            textCol = disabledTextColor;
        } else if (!isFocused && textToRender.isEmpty()) {
            textCol = hintColor;
            textToRender = hintText;
        } else {
            textCol = textColor;
        }

        if (!textToRender.isEmpty()) {
            Draw.drawString(textToRender, textX, textY, textCol, 1f);
        }
    }

    private void renderCursor(float x, float y, float width, float height) {
        if (!isFocused || !cursorVisible || isDisabled) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float textStartX = x + caretOffset + getIconSpace() + textXOffset;

        String textBeforeCursor;
        if (isPassword) {
            textBeforeCursor = rawText.substring(0, Math.min(cursorPosition, rawText.length())).replaceAll(".", "•");
        } else {
            textBeforeCursor = rawText.substring(0, Math.min(cursorPosition, rawText.length()));
        }

        float cursorX = textStartX + fr.getStringWidth(textBeforeCursor);
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f;

        Draw.drawRect(cursorX, textY - caretOffset, caretWidth, fr.FONT_HEIGHT + caretOffset * 2, cursorColor);
    }

    private void renderLabel(float x, float y, float width, float height) {
        if (!labelFloated && hintText.isEmpty()) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float labelX = x + caretOffset;
        float labelY = y + height / 2f + labelFloatOffset;

        int labelCol = labelFloated ? hintColor : placeholderColor;

        String labelTextToRender = labelFloated ? this.hintText : placeholder;
        if (labelTextToRender.isEmpty()) return;

        float centerX = x + width / 2f;
        Draw.pushMatrix();
        Draw.translate(centerX, labelY + fr.FONT_HEIGHT / 2f, 0);
        Draw.scale(labelScale, labelScale, 1f);
        Draw.translate(-centerX, -labelY - fr.FONT_HEIGHT / 2f, 0);

        Draw.drawString(labelTextToRender, centerX - fr.getStringWidth(labelTextToRender) / 2f,
                       labelY, labelCol, 1f);

        Draw.popMatrix();
    }

    private void renderIcons(float x, float y, float width, float height) {
        if (!leftIcon.isEmpty()) {
            float iconX = x + iconPadding;
            float iconY = y + height / 2f - iconSize / 2f;
            int iconCol = isFocused ? iconFocusedColor : iconColor;
            Draw.drawCenteredString(leftIcon, iconX + iconSize / 2f, iconY + iconSize / 2f - 9f, iconCol, 1f);
        }

        if (!rightIcon.isEmpty()) {
            float iconX = x + width - iconPadding - iconSize;
            float iconY = y + height / 2f - iconSize / 2f;
            int iconCol = isFocused ? iconFocusedColor : iconColor;
            Draw.drawCenteredString(rightIcon, iconX + iconSize / 2f, iconY + iconSize / 2f - 9f, iconCol, 1f);
        }
    }

    private void renderCharacterCount(float x, float y, float width, float height) {
        if (!showCharacterCount) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        String countText = rawText.length() + "/" + maxLength;
        float countX = x + width - caretOffset - fr.getStringWidth(countText);
        float countY = y + height - fr.FONT_HEIGHT - 2f;

        int countColor = characterCountThreshold > 0 && rawText.length() >= characterCountThreshold
                        ? errorColor : hintColor;
        Draw.drawString(countText, countX, countY, countColor, 0.8f);
    }

    private void renderError(float x, float y, float width, float height) {
        if (errorMessage.isEmpty()) return;

        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float errorY = y + height + 4f;
        Draw.drawString(errorMessage, x + caretOffset, errorY, errorColor, 0.9f);
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled || isReadOnly) return false;

        requestFocus();

        int clickedPos = getPositionAt(mouseX);
        setCursorPosition(clickedPos);

        if (Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT)) {
            if (selectionStart < 0) selectionStart = cursorPosition;
            selectionEnd = cursorPosition;
        } else {
            selectionStart = -1;
            selectionEnd = -1;
        }

        return true;
    }

    @Override
    public boolean onMouseDrag(int mouseX, int mouseY, int mouseButton, long timeSinceClick) {
        if (isDisabled || isReadOnly || !isFocused) return false;

        int newPos = getPositionAt(mouseX);
        if (newPos != cursorPosition) {
            if (selectionStart < 0) selectionStart = cursorPosition;
            selectionEnd = newPos;
            cursorPosition = newPos;
        }
        return true;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled || isReadOnly) return false;

        requestFocus();
        setCursorPosition(getPositionAt(mouseX));
        selectionStart = -1;
        selectionEnd = -1;

        return true;
    }

    private int getPositionAt(float mouseX) {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float textStartX = getBounds().getX() + caretOffset + getIconSpace() + textXOffset;
        String text = getVisibleText();

        int pos = 0;
        for (int i = 0; i < text.length(); i++) {
            float charWidth = fr.getStringWidth(String.valueOf(text.charAt(i)));
            if (mouseX < textStartX + charWidth / 2f) {
                break;
            }
            pos = i + 1;
            textStartX += charWidth;
        }

        return Math.min(pos, rawText.length());
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (!isFocused) return false;
        if (isDisabled || isReadOnly) return false;

        if (keyCode == Keyboard.KEY_ESCAPE) {
            releaseFocus();
            return true;
        }

        if (keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_NUMPADENTER) {
            if (isMultiline || !isMultiline) {
                addToHistory(rawText.toString());
                onEnter.accept(this);
            }
            if (!isMultiline) {
                releaseFocus();
            }
            return true;
        }

        if (keyCode == Keyboard.KEY_BACK) {
            handleBackspace();
            return true;
        }

        if (keyCode == Keyboard.KEY_DELETE) {
            handleDelete();
            return true;
        }

        if (keyCode == Keyboard.KEY_LEFT) {
            moveCursor(-1, Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT));
            return true;
        }

        if (keyCode == Keyboard.KEY_RIGHT) {
            moveCursor(1, Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT));
            return true;
        }

        if (keyCode == Keyboard.KEY_HOME) {
            moveCursorToStart(Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT));
            return true;
        }

        if (keyCode == Keyboard.KEY_END) {
            moveCursorToEnd(Keyboard.isKeyDown(Keyboard.KEY_LSHIFT) || Keyboard.isKeyDown(Keyboard.KEY_RSHIFT));
            return true;
        }

        if (keyCode == Keyboard.KEY_UP) {
            historyNavigate(-1);
            return true;
        }

        if (keyCode == Keyboard.KEY_DOWN) {
            historyNavigate(1);
            return true;
        }

        if (keyCode == Keyboard.KEY_A && Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
            selectAll();
            return true;
        }

        if (keyCode == Keyboard.KEY_C && Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
            copyToClipboard();
            return true;
        }

        if (keyCode == Keyboard.KEY_V && Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
            pasteFromClipboard();
            return true;
        }

        if (keyCode == Keyboard.KEY_X && Keyboard.isKeyDown(Keyboard.KEY_LCONTROL)) {
            cutToClipboard();
            return true;
        }

        return handleCharacterInput(typedChar);
    }

    private boolean handleCharacterInput(char typedChar) {
        if (Character.isISOControl(typedChar)) return false;

        if (isNumeric && !Character.isDigit(typedChar) && typedChar != '-') return false;
        if (isAlphanumeric && !Character.isLetterOrDigit(typedChar)) return false;

        if (selectionStart >= 0 && selectionEnd >= 0) {
            deleteSelection();
        }

        if (rawText.length() >= maxLength) return false;

        char processedChar = typedChar;
        if (enforceUppercase) processedChar = Character.toUpperCase(typedChar);
        if (enforceLowercase) processedChar = Character.toLowerCase(typedChar);

        String newText = rawText.substring(0, cursorPosition) + processedChar + rawText.substring(cursorPosition);
        newText = formatter.apply(newText);

        if (!validator.test(newText)) {
            triggerError();
            return true;
        }

        rawText = newText;
        displayText = new StringBuilder(rawText);
        cursorPosition++;
        textChanged();
        return true;
    }

    private void handleBackspace() {
        if (selectionStart >= 0 && selectionEnd >= 0) {
            deleteSelection();
            return;
        }

        if (cursorPosition > 0) {
            rawText = rawText.substring(0, cursorPosition - 1) + rawText.substring(cursorPosition);
            displayText = new StringBuilder(rawText);
            cursorPosition--;
            textChanged();
        }
    }

    private void handleDelete() {
        if (selectionStart >= 0 && selectionEnd >= 0) {
            deleteSelection();
            return;
        }

        if (cursorPosition < rawText.length()) {
            rawText = rawText.substring(0, cursorPosition) + rawText.substring(cursorPosition + 1);
            displayText = new StringBuilder(rawText);
            textChanged();
        }
    }

    private void deleteSelection() {
        if (selectionStart < 0 || selectionEnd < 0 || selectionStart == selectionEnd) return;

        int start = Math.min(selectionStart, selectionEnd);
        int end = Math.max(selectionStart, selectionEnd);

        rawText = rawText.substring(0, start) + rawText.substring(end);
        displayText = new StringBuilder(rawText);
        cursorPosition = start;
        selectionStart = -1;
        selectionEnd = -1;
        textChanged();
    }

    private void moveCursor(int direction, boolean withSelection) {
        int newPos = cursorPosition + direction;
        newPos = Math.max(0, Math.min(newPos, rawText.length()));

        if (withSelection) {
            if (selectionStart < 0) selectionStart = cursorPosition;
            selectionEnd = newPos;
        } else {
            selectionStart = -1;
            selectionEnd = -1;
        }

        cursorPosition = newPos;
    }

    private void moveCursorToStart(boolean withSelection) {
        if (withSelection) {
            if (selectionStart < 0) selectionStart = cursorPosition;
            selectionEnd = 0;
        } else {
            selectionStart = -1;
            selectionEnd = -1;
        }
        cursorPosition = 0;
    }

    private void moveCursorToEnd(boolean withSelection) {
        if (withSelection) {
            if (selectionStart < 0) selectionStart = cursorPosition;
            selectionEnd = rawText.length();
        } else {
            selectionStart = -1;
            selectionEnd = -1;
        }
        cursorPosition = rawText.length();
    }

    private void selectAll() {
        selectionStart = 0;
        selectionEnd = rawText.length();
        cursorPosition = rawText.length();
    }

    private void copyToClipboard() {
        if (selectionStart < 0 || selectionEnd < 0) return;

        int start = Math.min(selectionStart, selectionEnd);
        int end = Math.max(selectionStart, selectionEnd);

        String selected = rawText.substring(start, end);
    }

    private void pasteFromClipboard() {
        String clipboard = "";
        if (selectionStart >= 0 && selectionEnd >= 0) {
            deleteSelection();
        }

        String newText = rawText.substring(0, cursorPosition) + clipboard + rawText.substring(cursorPosition);
        if (autoTrim) {
            newText = newText.trim();
        }

        if (newText.length() > maxLength) {
            newText = newText.substring(0, maxLength);
        }

        newText = formatter.apply(newText);

        if (!validator.test(newText)) {
            triggerError();
            return;
        }

        rawText = newText;
        displayText = new StringBuilder(rawText);
        cursorPosition += clipboard.length();
        textChanged();
    }

    private void cutToClipboard() {
        copyToClipboard();
        deleteSelection();
    }

    private void historyNavigate(int direction) {
        if (history.isEmpty()) return;

        if (direction < 0) {
            if (historyIndex < history.size() - 1) {
                historyIndex++;
            }
        } else {
            if (historyIndex > 0) {
                historyIndex--;
            } else {
                historyIndex = -1;
                rawText = "";
                displayText = new StringBuilder();
                cursorPosition = 0;
                return;
            }
        }

        if (historyIndex >= 0 && historyIndex < history.size()) {
            rawText = history.get(history.size() - 1 - historyIndex);
            displayText = new StringBuilder(rawText);
            cursorPosition = rawText.length();
            textChanged();
        }
    }

    private void addToHistory(String text) {
        if (text.isEmpty()) return;
        if (!history.isEmpty() && history.get(history.size() - 1).equals(text)) return;

        history.add(text);
        if (history.size() > maxHistorySize) {
            history.remove(0);
        }
        historyIndex = -1;
    }

    private void textChanged() {
        onTextChange.accept(this);
    }

    private void triggerError() {
        isShaking = true;
        shakeStartTime = System.currentTimeMillis();
    }

    public void setCursorPosition(int pos) {
        this.cursorPosition = Math.max(0, Math.min(pos, rawText.length()));
    }

    public int getCursorPosition() { return cursorPosition; }

    public void setText(String text) {
        if (autoTrim) text = text.trim();
        if (text.length() > maxLength) text = text.substring(0, maxLength);
        this.rawText = text;
        this.displayText = new StringBuilder(text);
        this.cursorPosition = text.length();
        textChanged();
    }

    public String getText() { return rawText; }
    public String getDisplayText() { return displayText.toString(); }

    public void clear() {
        setText("");
        selectionStart = -1;
        selectionEnd = -1;
    }

    public boolean isFocused() { return isFocused; }
    public boolean isHovered() { return isHovered; }
    public boolean isDisabled() { return isDisabled; }
    public boolean isReadOnly() { return isReadOnly; }

    public TextField setHintText(String hint) {
        this.hintText = hint;
        this.placeholder = hint;
        return this;
    }

    public TextField setPrefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public TextField setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public TextField setMaxLength(int max) {
        this.maxLength = max;
        return this;
    }

    public TextField setMinLength(int min) {
        this.minLength = min;
        return this;
    }

    public TextField setValidator(Predicate<String> validator) {
        this.validator = validator;
        return this;
    }

    public TextField setFormatter(Function<String, String> formatter) {
        this.formatter = formatter;
        return this;
    }

    public TextField setOnTextChange(Consumer<TextField> onChange) {
        this.onTextChange = onChange;
        return this;
    }

    public TextField setOnEnter(Consumer<TextField> onEnter) {
        this.onEnter = onEnter;
        return this;
    }

    public TextField setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public TextField setReadOnly(boolean readOnly) {
        this.isReadOnly = readOnly;
        return this;
    }

    public TextField setPassword(boolean password) {
        this.isPassword = password;
        return this;
    }

    public TextField setMultiline(boolean multiline) {
        this.isMultiline = multiline;
        updateDimensions();
        return this;
    }

    public TextField setNumeric(boolean numeric) {
        this.isNumeric = numeric;
        return this;
    }

    public TextField setAlphanumeric(boolean alphanumeric) {
        this.isAlphanumeric = alphanumeric;
        return this;
    }

    public TextField setEnforceUppercase(boolean enforce) {
        this.enforceUppercase = enforce;
        if (enforce) this.enforceLowercase = false;
        return this;
    }

    public TextField setEnforceLowercase(boolean enforce) {
        this.enforceLowercase = enforce;
        if (enforce) this.enforceUppercase = false;
        return this;
    }

    public TextField setAutoTrim(boolean trim) {
        this.autoTrim = trim;
        return this;
    }

    public TextField setBackgroundColor(int color) {
        this.backgroundColor = color;
        return this;
    }

    public TextField setTextColor(int color) {
        this.textColor = color;
        return this;
    }

    public TextField setHintColor(int color) {
        this.hintColor = color;
        return this;
    }

    public TextField setBorderColors(int normal, int focused, int hover) {
        this.borderColor = normal;
        this.borderFocusedColor = focused;
        this.borderHoverColor = hover;
        return this;
    }

    public TextField setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public TextField setAnimatedBorder(boolean animated) {
        this.animatedBorder = animated;
        return this;
    }

    public TextField setSelectionColor(int color) {
        this.selectionColor = color;
        return this;
    }

    public TextField setErrorMessage(String message) {
        this.errorMessage = message;
        return this;
    }

    public TextField setErrorColor(int color) {
        this.errorColor = color;
        return this;
    }

    public TextField setProgress(float progress) {
        this.progress = Math.max(0, Math.min(1, progress));
        this.showProgress = true;
        return this;
    }

    public TextField setProgressColor(int color) {
        this.progressColor = color;
        return this;
    }

    public TextField setShowCharacterCount(boolean show, int threshold) {
        this.showCharacterCount = show;
        this.characterCountThreshold = threshold;
        return this;
    }

    public TextField setLeftIcon(String icon) {
        this.leftIcon = icon;
        return this;
    }

    public TextField setRightIcon(String icon) {
        this.rightIcon = icon;
        return this;
    }

    public TextField setIconColor(int color) {
        this.iconColor = color;
        return this;
    }

    public TextField setIconFocusedColor(int color) {
        this.iconFocusedColor = color;
        return this;
    }

    public TextField setIconSize(float size) {
        this.iconSize = size;
        return this;
    }

    public TextField setIconPadding(float padding) {
        this.iconPadding = padding;
        return this;
    }

    @Override
    public String toString() {
        return "TextField{text='" + rawText + '\'' + ", focused=" + isFocused +
               ", hovered=" + isHovered + ", disabled=" + isDisabled + '}';
    }
}
