package ru.ryuzaki.ui.components;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import org.lwjgl.input.Keyboard;
import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.base.GeometryUtils;
import ru.ryuzaki.ui.core.UIComponent;
import ru.ryuzaki.ui.core.UIRoot;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class Button extends UIComponent {

    private String text = "";
    private String icon = "";
    private ButtonStyle style = ButtonStyle.SOLID;
    private ButtonSize size = ButtonSize.MEDIUM;

    private float normalBrightness = 1.0f;
    private float hoverBrightness = 1.0f;
    private float pressBrightness = 0.85f;
    private float currentBrightness = 1.0f;

    private int normalTextColor = 0xFFFFFFFF;
    private int hoverTextColor = 0xFFFFFFFF;
    private int disabledTextColor = 0xFF888888;

    private boolean isHovered = false;
    private boolean isPressed = false;
    private boolean isDisabled = false;
    private boolean isToggle = false;
    private boolean isToggled = false;

    private Consumer<Button> onClick = btn -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;

    private float rippleProgress = 0f;
    private float rippleX = 0f;
    private float rippleY = 0f;
    private float rippleRadius = 0f;
    private boolean rippleActive = false;

    private float bounceScale = 1f;
    private long lastClickTime = 0;

    private int backgroundColor = 0xFF3B82F6;
    private int hoverBackgroundColor = 0xFF60A5FA;
    private int pressedBackgroundColor = 0xFF2563EB;
    private int disabledBackgroundColor = 0xFF4B5563;

    private int borderColor = 0x00000000;
    private int hoverBorderColor = 0x00000000;
    private float borderWidth = 0f;
    private float borderRadius = 6f;

    private int iconColor = 0xFFFFFFFF;
    private int iconHoverColor = 0xFFFFFFFF;
    private float iconSize = 16f;
    private float iconPadding = 6f;

    private float textShadowOffset = 1f;
    private boolean textShadow = false;

    private float progress = 0f;
    private boolean showProgress = false;
    private int progressColor = 0xFFFFFFFF;

    private boolean animatedBackground = false;
    private float gradientAngle = 0f;

    public enum ButtonStyle {
        SOLID, OUTLINE, GHOST, GLASS, GRADIENT, ICON_ONLY, SPLIT
    }

    public enum ButtonSize {
        SMALL(28f, 12f, 8f, 8f),
        MEDIUM(36f, 14f, 10f, 10f),
        LARGE(44f, 16f, 12f, 12f),
        EXTRA_LARGE(52f, 18f, 14f, 14f);

        private final float height;
        private final float paddingH;
        private final float paddingV;
        private final float fontSize;

        ButtonSize(float height, float paddingH, float paddingV, float fontSize) {
            this.height = height;
            this.paddingH = paddingH;
            this.paddingV = paddingV;
            this.fontSize = fontSize;
        }

        public float getHeight() { return height; }
        public float getPaddingH() { return paddingH; }
        public float getPaddingV() { return paddingV; }
        public float getFontSize() { return fontSize; }
    }

    public Button() {
        super();
        setFocusable(true);
        setClickable(true);
    }

    public Button(String text) {
        this();
        this.text = text;
    }

    public Button(String text, Consumer<Button> onClick) {
        this(text);
        this.onClick = onClick;
    }

    @Override
    public void init(UIRoot root) {
        super.init(root);
        updateDimensions();
    }

    private void updateDimensions() {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float textWidth = fr.getStringWidth(text);
        float iconSpace = icon.isEmpty() ? 0 : iconSize + iconPadding;

        switch (size) {
            case SMALL:
                setMinSize(40f, 28f);
                break;
            case MEDIUM:
                setMinSize(Math.max(60f, textWidth + iconSpace + size.getPaddingH() * 2 + 16f), 36f);
                break;
            case LARGE:
                setMinSize(Math.max(80f, textWidth + iconSpace + size.getPaddingH() * 2 + 24f), 44f);
                break;
            case EXTRA_LARGE:
                setMinSize(Math.max(100f, textWidth + iconSpace + size.getPaddingH() * 2 + 32f), 52f);
                break;
        }
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        boolean newHovered = isMouseOver() && !isDisabled;
        if (newHovered != isHovered) {
            isHovered = newHovered;
            animateHoverTransition();
        }

        boolean wasPressed = isPressed;
        if (isDisabled) {
            isPressed = false;
        } else if (isPressed && !isMouseOver()) {
            isPressed = false;
        }

        float targetBrightness = isDisabled ? 1f : (isPressed ? pressBrightness : (isHovered ? hoverBrightness : normalBrightness));
        currentBrightness = Easing.lerp(currentBrightness, targetBrightness, 0.15f);

        if (rippleActive) {
            rippleProgress += 0.08f;
            if (rippleProgress >= 1f) {
                rippleActive = false;
                rippleProgress = 0f;
            }
        }

        if (showProgress) {
            float targetProgress = isDisabled ? 0f : progress;
            progress = Easing.lerp(progress, targetProgress, 0.1f);
        }

        if (isHovered && !isPressed) {
            bounceScale = Easing.lerp(bounceScale, 1.02f, 0.1f);
        } else {
            bounceScale = Easing.lerp(bounceScale, 1f, 0.15f);
        }

        gradientAngle += animatedBackground ? 0.5f : 0f;
    }

    private void animateHoverTransition() {
        if (isHovered && !isDisabled) {
            bounceScale = 1.05f;
        }
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        float centerX = x + width / 2f;
        float centerY = y + height / 2f;

        Draw.pushMatrix();
        Draw.translate(centerX, centerY, 0);
        Draw.scale(bounceScale, bounceScale, 1f);
        Draw.translate(-centerX, -centerY, 0);

        renderBackground(x, y, width, height);
        renderBorder(x, y, width, height);
        renderRipple(x, y, width, height);
        renderProgress(x, y, width, height);
        renderContent(x, y, width, height);

        Draw.popMatrix();
    }

    private void renderBackground(float x, float y, float width, float height) {
        int bgColor;
        switch (style) {
            case OUTLINE:
            case GHOST:
                bgColor = (isHovered || isPressed) ? 0x1A000000 : 0x00000000;
                break;
            case GLASS:
                bgColor = getGlassBackground();
                break;
            case GRADIENT:
                renderGradientBackground(x, y, width, height);
                return;
            default:
                bgColor = isDisabled ? disabledBackgroundColor :
                         (isPressed ? pressedBackgroundColor :
                         (isHovered ? hoverBackgroundColor : backgroundColor));
        }

        if (style == ButtonStyle.GLASS) {
            Draw.drawRoundedRect(x, y, width, height, borderRadius, bgColor);
        } else if (borderRadius > 0) {
            Draw.drawRoundedRect(x, y, width, height, borderRadius, bgColor);
        } else {
            Draw.drawRect(x, y, width, height, bgColor);
        }
    }

    private int getGlassBackground() {
        int base = isDisabled ? 0x40000000 :
                  (isPressed ? 0x60000000 :
                  (isHovered ? 0x50000000 : 0x30000000));
        return base;
    }

    private void renderGradientBackground(float x, float y, float width, float height) {
        int[] colors;
        if (isDisabled) {
            colors = new int[]{disabledBackgroundColor, disabledBackgroundColor};
        } else if (isPressed) {
            colors = new int[]{pressedBackgroundColor, pressedBackgroundColor};
        } else if (isHovered) {
            colors = new int[]{hoverBackgroundColor, backgroundColor};
        } else {
            colors = new int[]{backgroundColor, hoverBackgroundColor};
        }

        Draw.drawGradientRoundedRect(x, y, width, height, borderRadius, colors[0], colors[1], gradientAngle);
    }

    private void renderBorder(float x, float y, float width, float height) {
        if (borderWidth <= 0) return;

        int bColor = isHovered ? hoverBorderColor : borderColor;
        Draw.drawRoundedRectOutline(x, y, width, height, borderRadius, borderWidth, bColor);
    }

    private void renderRipple(float x, float y, float width, float height) {
        if (!rippleActive) return;

        float rippleAlpha = (1f - rippleProgress) * 0.3f;
        int rippleColor = (int)(rippleAlpha * 255) << 24 | 0xFFFFFF;
        float currentRadius = rippleRadius * rippleProgress;
        Draw.drawCircle(rippleX, rippleY, currentRadius, rippleColor);
    }

    private void renderProgress(float x, float y, float width, float height) {
        if (!showProgress || progress <= 0) return;

        float progressWidth = width * progress;
        Draw.drawRoundedRect(x, y, progressWidth, height, borderRadius, progressColor);
    }

    private void renderContent(float x, float y, float width, float height) {
        if (style == ButtonStyle.ICON_ONLY) {
            renderIcon(x, y, width, height);
        } else {
            boolean hasIcon = !icon.isEmpty();
            if (hasIcon) {
                float iconX = x + width / 2f - (getTextWidth() + iconSize + iconPadding) / 2f;
                renderIcon(iconX, y, width, height);
            }
            renderText(x, y, width, height, hasIcon);
        }
    }

    private void renderIcon(float x, float y, float width, float height) {
        int iconCol = isHovered ? iconHoverColor : iconColor;
        float iconX = x + width / 2f - iconSize / 2f;
        float iconY = y + height / 2f - iconSize / 2f;
        Draw.drawCenteredString(icon, iconX + iconSize / 2f, iconY + iconSize / 2f - 9f, iconCol, 1f);
    }

    private void renderText(float x, float y, float width, float height, boolean hasIcon) {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f + 1f;

        int textCol;
        if (isDisabled) {
            textCol = disabledTextColor;
        } else if (isHovered) {
            textCol = hoverTextColor;
        } else {
            textCol = normalTextColor;
        }

        float textX;
        if (hasIcon) {
            float totalWidth = getTextWidth();
            textX = x + width / 2f - totalWidth / 2f + iconSize + iconPadding;
        } else {
            textX = x + width / 2f - fr.getStringWidth(text) * 0.5f;
        }

        if (textShadow) {
            Draw.drawString(text, textX + textShadowOffset, textY + textShadowOffset, 0x88000000, 1f);
        }
        Draw.drawString(text, textX, textY, textCol, 1f);
    }

    private float getTextWidth() {
        FontRenderer fr = Minecraft.getMinecraft().fontRendererObj;
        float iconSpace = icon.isEmpty() ? 0 : iconSize + iconPadding;
        return fr.getStringWidth(text) + iconSpace;
    }

    @Override
    public boolean onMouseDown(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        isPressed = true;
        bounceScale = 0.95f;

        rippleX = mouseX;
        rippleY = mouseY;
        rippleRadius = Math.max(getBounds().getWidth(), getBounds().getHeight()) * 1.5f;
        rippleProgress = 0f;
        rippleActive = true;

        return true;
    }

    @Override
    public boolean onMouseUp(int mouseX, int mouseY, int mouseButton) {
        if (isPressed && !isDisabled) {
            if (isMouseOver()) {
                handleClick();
            }
        }
        isPressed = false;
        return true;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;
        handleClick();
        return true;
    }

    private void handleClick() {
        if (System.currentTimeMillis() - lastClickTime < 300) {
            bounceScale = 0.9f;
        }
        lastClickTime = System.currentTimeMillis();

        if (isToggle) {
            isToggled = !isToggled;
        }

        onClick.accept(this);
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (isDisabled) return false;

        if (keyCode == Keyboard.KEY_RETURN || keyCode == Keyboard.KEY_SPACE) {
            handleClick();
            return true;
        }
        return super.onKeyTyped(typedChar, keyCode);
    }

    @Override
    public boolean isMouseOver() {
        return GeometryUtils.pointInBounds(getBounds(), getLastMouseX(), getLastMouseY());
    }

    public Button setText(String text) {
        this.text = text;
        updateDimensions();
        invalidate();
        return this;
    }

    public String getText() { return text; }

    public Button setIcon(String icon) {
        this.icon = icon;
        updateDimensions();
        invalidate();
        return this;
    }

    public String getIcon() { return icon; }

    public Button setStyle(ButtonStyle style) {
        this.style = style;
        invalidate();
        return this;
    }

    public ButtonStyle getStyle() { return style; }

    public Button setSize(ButtonSize size) {
        this.size = size;
        updateDimensions();
        invalidate();
        return this;
    }

    public ButtonSize getSize() { return size; }

    public Button setOnClick(Consumer<Button> onClick) {
        this.onClick = onClick;
        return this;
    }

    public Button setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public Button setDisabled(boolean disabled) {
        this.isDisabled = disabled;
        return this;
    }

    public boolean isDisabled() { return isDisabled; }
    public boolean isHovered() { return isHovered; }
    public boolean isPressed() { return isPressed; }
    public boolean isToggled() { return isToggled; }

    public Button setToggle(boolean toggle) {
        this.isToggle = toggle;
        return this;
    }

    public Button setToggleState(boolean toggled) {
        this.isToggled = toggled;
        return this;
    }

    public Button setBackgroundColor(int color) {
        this.backgroundColor = color;
        return this;
    }

    public Button setHoverBackgroundColor(int color) {
        this.hoverBackgroundColor = color;
        return this;
    }

    public Button setPressedBackgroundColor(int color) {
        this.pressedBackgroundColor = color;
        return this;
    }

    public Button setTextColor(int color) {
        this.normalTextColor = color;
        return this;
    }

    public Button setHoverTextColor(int color) {
        this.hoverTextColor = color;
        return this;
    }

    public Button setDisabledTextColor(int color) {
        this.disabledTextColor = color;
        return this;
    }

    public Button setBorderColor(int color) {
        this.borderColor = color;
        return this;
    }

    public Button setBorderWidth(float width) {
        this.borderWidth = width;
        return this;
    }

    public Button setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public Button setIconSize(float size) {
        this.iconSize = size;
        updateDimensions();
        return this;
    }

    public Button setIconColor(int color) {
        this.iconColor = color;
        return this;
    }

    public Button setProgress(float progress) {
        this.progress = progress;
        this.showProgress = true;
        return this;
    }

    public Button setProgressColor(int color) {
        this.progressColor = color;
        return this;
    }

    public Button setTextShadow(boolean shadow) {
        this.textShadow = shadow;
        return this;
    }

    public Button setAnimatedBackground(boolean animated) {
        this.animatedBackground = animated;
        return this;
    }

    @Override
    public String toString() {
        return "Button{" + "text='" + text + '\'' + ", style=" + style + ", size=" + size +
               ", isHovered=" + isHovered + ", isPressed=" + isPressed + ", isDisabled=" + isDisabled + '}';
    }
}
