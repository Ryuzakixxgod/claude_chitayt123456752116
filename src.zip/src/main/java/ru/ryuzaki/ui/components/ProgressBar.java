package ru.ryuzaki.ui.components;

import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class ProgressBar extends UIComponent {

    public enum ProgressOrientation {
        LEFT_TO_RIGHT,
        RIGHT_TO_LEFT,
        TOP_TO_BOTTOM,
        BOTTOM_TO_TOP
    }

    public enum ProgressStyle {
        LINEAR,
        ROUND,
        CHUNKED,
        GLOWING,
        STRIPED,
        PULSING
    }

    private float progress = 0f;
    private float targetProgress = 0f;
    private float animatedProgress = 0f;
    private float minValue = 0f;
    private float maxValue = 100f;

    private float barWidth = 200f;
    private float barHeight = 20f;
    private float borderRadius = 6f;
    private float chunkSize = 10f;
    private float chunkSpacing = 4f;
    private float stripeWidth = 8f;
    private float stripeAngle = 45f;

    private float animationDuration = 0.5f;
    private float currentAnimationTime = 0f;
    private boolean isAnimating = false;
    private float pulsePhase = 0f;
    private float stripeOffset = 0f;

    private ProgressOrientation orientation = ProgressOrientation.LEFT_TO_RIGHT;
    private ProgressStyle style = ProgressStyle.ROUND;

    private int backgroundColor = 0xFF2A2A2A;
    private int barColor = 0xFF4CAF50;
    private int borderColor = 0xFF1A1A1A;
    private int glowColor = 0x804CAF50;
    private int textColor = 0xFFFFFFFF;
    private int percentColor = 0xFFFFFFFF;

    private boolean showText = true;
    private boolean showPercent = true;
    private boolean showBorder = true;
    private boolean showGlow = false;
    private boolean animate = true;

    private String prefix = "";
    private String suffix = "";
    private String customText = "";

    private float textPadding = 8f;
    private float textShadowStrength = 0f;
    private float glowIntensity = 0f;

    private Consumer<ProgressBar> onComplete = bar -> {};
    private Runnable onProgressChange = () -> {};
    private Supplier<Float> progressSupplier = () -> progress;

    private boolean isIndeterminate = false;
    private float indeterminatePosition = 0f;
    private float indeterminateWidth = 0.3f;

    private float shimmerPosition = 0f;
    private boolean showShimmer = false;
    private int shimmerColor = 0x40FFFFFF;

    public ProgressBar() {
        super();
        setMinSize(barWidth, barHeight);
    }

    public ProgressBar(float width, float height) {
        this();
        this.barWidth = width;
        this.barHeight = height;
        setMinSize(width, height);
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        updateAnimatedProgress();
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        progress = progressSupplier.get();

        updateAnimation(partialTicks);

        if (showGlow || style == ProgressStyle.GLOWING) {
            float targetGlow = showGlow ? 1f : (isMouseOver() ? 0.5f : 0f);
            glowIntensity = Easing.lerp(glowIntensity, targetGlow, 0.1f);
        }

        if (isIndeterminate) {
            updateIndeterminate(partialTicks);
        }

        if (style == ProgressStyle.STRIPED) {
            stripeOffset += partialTicks * 0.05f;
            if (stripeOffset > stripeWidth * 2) {
                stripeOffset = 0f;
            }
        }

        if (style == ProgressStyle.PULSING) {
            pulsePhase += partialTicks * 0.1f;
        }

        if (showShimmer) {
            shimmerPosition += partialTicks * 0.03f;
            if (shimmerPosition > 1.5f) {
                shimmerPosition = -0.5f;
            }
        }
    }

    private void updateAnimation(float partialTicks) {
        if (!isAnimating) return;

        currentAnimationTime += partialTicks / 60f;
        float t = Math.min(1f, currentAnimationTime / animationDuration);

        animatedProgress = Easing.outCubic(progress + (targetProgress - progress) * t);

        if (t >= 1f) {
            isAnimating = false;
            animatedProgress = targetProgress;
            if (targetProgress == maxValue) {
                onComplete.accept(this);
            }
            onProgressChange.run();
        }
    }

    private void updateIndeterminate(float partialTicks) {
        indeterminatePosition += partialTicks * 0.02f;
        if (indeterminatePosition > 1f + indeterminateWidth) {
            indeterminatePosition = -indeterminateWidth;
        }
    }

    private void updateAnimatedProgress() {
        float range = maxValue - minValue;
        float normalizedProgress = (progress - minValue) / range;
        animatedProgress = Easing.clamp(normalizedProgress, 0f, 1f);
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();
        float width = bounds.getWidth();
        float height = bounds.getHeight();

        Draw.pushMatrix();

        if (showBorder) {
            Draw.drawRoundedRect(x - 1, y - 1, width + 2, height + 2, borderRadius + 1, borderColor);
        }

        Draw.drawRoundedRect(x, y, width, height, borderRadius, backgroundColor);

        renderBar(x, y, width, height, partialTicks);

        if (showShimmer && animatedProgress > 0) {
            renderShimmer(x, y, width, height);
        }

        if (showText) {
            renderText(x, y, width, height);
        }

        if (glowIntensity > 0.01f && (showGlow || style == ProgressStyle.GLOWING)) {
            renderGlow(x, y, width, height);
        }

        Draw.popMatrix();
    }

    private void renderBar(float x, float y, float width, float height, float partialTicks) {
        float barX = x;
        float barY = y;
        float barW = width;
        float barH = height;

        float normalizedProgress = Easing.clamp(animatedProgress, 0f, 1f);

        switch (orientation) {
            case RIGHT_TO_LEFT:
                barX = x + width * (1f - normalizedProgress);
                barW = width * normalizedProgress;
                break;
            case TOP_TO_BOTTOM:
                barY = y + height * (1f - normalizedProgress);
                barH = height * normalizedProgress;
                break;
            case BOTTOM_TO_TOP:
                barH = height * normalizedProgress;
                break;
            case LEFT_TO_RIGHT:
            default:
                barW = width * normalizedProgress;
                break;
        }

        int finalBarColor = barColor;
        if (style == ProgressStyle.PULSING) {
            float pulse = (float) (Math.sin(pulsePhase) * 0.5 + 0.5);
            int r = (barColor >> 16) & 0xFF;
            int g = (barColor >> 8) & 0xFF;
            int b = barColor & 0xFF;
            int intensity = (int) (40 * pulse);
            finalBarColor = (0xFF << 24) | Math.min(255, r + intensity) << 16 |
                           Math.min(255, g + intensity) << 8 | Math.min(255, b + intensity);
        }

        switch (style) {
            case CHUNKED:
                renderChunkedBar(barX, barY, barW, barH, normalizedProgress);
                break;
            case STRIPED:
                renderStripedBar(barX, barY, barW, barH, normalizedProgress);
                break;
            case ROUND:
                float innerRadius = borderRadius - 2;
                Draw.drawRoundedRect(barX + 2, barY + 2, barW - 4, barH - 4, innerRadius, finalBarColor);
                break;
            case GLOWING:
                renderGlowingBar(barX, barY, barW, barH, normalizedProgress, partialTicks);
                break;
            case LINEAR:
            case PULSING:
            default:
                if (isIndeterminate) {
                    renderIndeterminateBar(x, y, width, height, partialTicks);
                } else {
                    Draw.drawRoundedRect(barX, barY, barW, barH, borderRadius, finalBarColor);
                }
                break;
        }
    }

    private void renderChunkedBar(float x, float y, float width, float height, float progress) {
        float chunk = chunkSize;
        float spacing = chunkSpacing;

        int cols = (int) ((width + spacing) / (chunk + spacing));
        float actualChunkSize = (width - spacing * (cols - 1)) / cols;

        for (int i = 0; i < cols; i++) {
            float chunkX = x + i * (actualChunkSize + spacing);
            float threshold = (float) i / cols;

            if (threshold < progress) {
                float fillRatio = Math.min(1f, (progress - threshold) * cols);
                int alpha = (int) (fillRatio * 255);
                int color = (alpha << 24) | (barColor & 0x00FFFFFF);
                Draw.drawRoundedRect(chunkX, y + 2, actualChunkSize, height - 4, 2, color);
            }
        }
    }

    private void renderStripedBar(float x, float y, float width, float height, float progress) {
        Draw.saveState();
        Draw.startClip((int) x, (int) y, (int) (x + width * progress), (int) height);

        int stripeCount = (int) (width / stripeWidth) + 4;
        float stripeH = (float) Math.tan(Math.toRadians(stripeAngle)) * height;

        for (int i = -2; i < stripeCount; i++) {
            float sx = x + i * stripeWidth - stripeOffset;
            Draw.drawTriangleStrip(sx, y, sx + stripeH, y, sx + stripeH, y + height, sx, y + height, barColor);
        }

        Draw.restoreState();
    }

    private void renderGlowingBar(float x, float y, float width, float height, float progress, float partialTicks) {
        float glowY = y;
        float glowH = height;
        float glowX = x;
        float glowW = width * progress;

        int glowCol = ((int)(glowIntensity * 0.5f * 255) << 24) | (glowColor & 0x00FFFFFF);
        Draw.drawRoundedRect(glowX - 4, glowY - 4, glowW + 8, glowH + 8, borderRadius + 2, glowCol);

        int barCol = ((int)((1f - glowIntensity * 0.3f) * 255) << 24) | (barColor & 0x00FFFFFF);
        Draw.drawRoundedRect(glowX, glowY, glowW, glowH, borderRadius, barCol);

        float innerGlow = glowY + glowH / 2f;
        int highlightCol = ((int)(0.2f * 255) << 24) | 0x00FFFFFF;
        Draw.drawGradientRect(glowX, glowY, glowW, glowH / 3f, highlightCol, 0x00000000);
    }

    private void renderIndeterminateBar(float x, float y, float width, float height, float partialTicks) {
        float indWidth = width * indeterminateWidth;
        float indX = x + width * indeterminatePosition - indWidth;

        Draw.saveState();
        Draw.startClip((int) x, (int) y, (int) width, (int) height);

        int indCol = ((int) (0.7f * 255) << 24) | (barColor & 0x00FFFFFF);
        Draw.drawRoundedRect(indX, y, indWidth, height, borderRadius, indCol);

        Draw.restoreState();
    }

    private void renderShimmer(float x, float y, float width, float height) {
        float shimmerX = x + width * shimmerPosition;
        float shimmerWidth = width * 0.3f;

        int shimCol = ((int) (0.3f * 255) << 24) | (shimmerColor & 0x00FFFFFF);
        Draw.drawGradientRect(shimmerX, y, shimmerWidth, height, 0x00000000, shimCol);
        Draw.drawGradientRect(shimmerX + shimmerWidth, y, shimmerWidth, height, shimCol, 0x00000000);
    }

    private void renderGlow(float x, float y, float width, float height) {
        int glowCol = ((int) (glowIntensity * 0.4f * 255) << 24) | (glowColor & 0x00FFFFFF);
        Draw.drawRoundedRect(x - 4, y - 4, width + 8, height + 8, borderRadius + 4, glowCol);
    }

    private void renderText(float x, float y, float width, float height) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        String displayText = getDisplayText();
        float textWidth = fr.getStringWidth(displayText);

        float textX = x + width / 2f - textWidth / 2f;
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f;

        if (textShadowStrength > 0) {
            Draw.drawStringWithShadow(displayText, textX, textY, textColor, textShadowStrength);
        } else {
            Draw.drawString(displayText, textX, textY, textColor, 1f);
        }
    }

    private String getDisplayText() {
        if (!customText.isEmpty()) {
            return customText;
        }

        StringBuilder sb = new StringBuilder();
        if (!prefix.isEmpty()) {
            sb.append(prefix);
        }

        if (showPercent) {
            int percent = (int) (animatedProgress * 100);
            sb.append(percent).append("%");
        }

        if (!suffix.isEmpty()) {
            sb.append(suffix);
        }

        return sb.toString();
    }

    public ProgressBar setProgress(float value) {
        this.targetProgress = value;
        if (animate) {
            isAnimating = true;
            currentAnimationTime = 0f;
        } else {
            animatedProgress = Easing.clamp(value, minValue, maxValue);
            isAnimating = false;
        }
        return this;
    }

    public ProgressBar setProgressInstant(float value) {
        boolean wasAnimate = animate;
        animate = false;
        setProgress(value);
        animate = wasAnimate;
        return this;
    }

    public ProgressBar setProgressAnimated(float value, float duration) {
        this.targetProgress = value;
        this.animationDuration = duration;
        isAnimating = true;
        currentAnimationTime = 0f;
        return this;
    }

    public ProgressBar setRange(float min, float max) {
        this.minValue = min;
        this.maxValue = max;
        return this;
    }

    public ProgressBar setText(String text) {
        this.customText = text;
        return this;
    }

    public ProgressBar setPrefix(String prefix) {
        this.prefix = prefix;
        return this;
    }

    public ProgressBar setSuffix(String suffix) {
        this.suffix = suffix;
        return this;
    }

    public ProgressBar setOrientation(ProgressOrientation orientation) {
        this.orientation = orientation;
        return this;
    }

    public ProgressBar setStyle(ProgressStyle style) {
        this.style = style;
        return this;
    }

    public ProgressBar setBarColor(int color) {
        this.barColor = color;
        return this;
    }

    public ProgressBar setBackgroundColor(int color) {
        this.backgroundColor = color;
        return this;
    }

    public ProgressBar setBorderColor(int color) {
        this.borderColor = color;
        return this;
    }

    public ProgressBar setGlowColor(int color) {
        this.glowColor = color;
        return this;
    }

    public ProgressBar setTextColor(int color) {
        this.textColor = color;
        return this;
    }

    public ProgressBar setSize(float width, float height) {
        this.barWidth = width;
        this.barHeight = height;
        setMinSize(width, height);
        return this;
    }

    public ProgressBar setShowText(boolean show) {
        this.showText = show;
        return this;
    }

    public ProgressBar setShowPercent(boolean show) {
        this.showPercent = show;
        return this;
    }

    public ProgressBar setShowBorder(boolean show) {
        this.showBorder = show;
        return this;
    }

    public ProgressBar setShowGlow(boolean show) {
        this.showGlow = show;
        return this;
    }

    public ProgressBar setAnimate(boolean animate) {
        this.animate = animate;
        return this;
    }

    public ProgressBar setAnimationDuration(float duration) {
        this.animationDuration = duration;
        return this;
    }

    public ProgressBar setShowShimmer(boolean show) {
        this.showShimmer = show;
        return this;
    }

    public ProgressBar setShimmerColor(int color) {
        this.shimmerColor = color;
        return this;
    }

    public ProgressBar setIsIndeterminate(boolean indeterminate) {
        this.isIndeterminate = indeterminate;
        return this;
    }

    public ProgressBar setOnComplete(Consumer<ProgressBar> onComplete) {
        this.onComplete = onComplete;
        return this;
    }

    public ProgressBar setOnProgressChange(Runnable onChange) {
        this.onProgressChange = onChange;
        return this;
    }

    public ProgressBar setProgressSupplier(Supplier<Float> supplier) {
        this.progressSupplier = supplier;
        return this;
    }

    public float getProgress() { return progress; }
    public float getAnimatedProgress() { return animatedProgress; }
    public float getMinValue() { return minValue; }
    public float getMaxValue() { return maxValue; }
    public boolean isAnimating() { return isAnimating; }
    public boolean isIndeterminate() { return isIndeterminate; }

    @Override
    public String toString() {
        return "ProgressBar{progress=" + animatedProgress + ", style=" + style + "}";
    }

    private static class Minecraft {
        public static net.minecraft.client.Minecraft getMinecraft() {
            return net.minecraft.client.Minecraft.getMinecraft();
        }
    }

    private static class FontRenderer {
        public static int getFontHeight() {
            return getMinecraft().fontRendererObj.FONT_HEIGHT;
        }

        public static float getStringWidth(String text) {
            return getMinecraft().fontRendererObj.getStringWidth(text);
        }
    }
}
