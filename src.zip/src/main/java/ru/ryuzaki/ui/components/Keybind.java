package ru.ryuzaki.ui.components;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;
import ru.ryuzaki.ui.base.BoundingBox;
import ru.ryuzaki.ui.base.Draw;
import ru.ryuzaki.ui.base.Easing;
import ru.ryuzaki.ui.core.UIComponent;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Keybind extends UIComponent {

    private KeyBinding keyBinding;

    private int keyCode = -1;
    private String keyName = "None";
    private String displayName = "";

    private boolean isListening = false;
    private boolean isHovered = false;
    private boolean isDisabled = false;
    private boolean isConflict = false;

    private float width = 180f;
    private float height = 28f;
    private float borderRadius = 4f;
    private float borderWidth = 1.5f;
    private float padding = 10f;
    private float keyHeight = 18f;

    private float hoverScale = 1f;
    private float listeningPulse = 0f;
    private float conflictShake = 0f;
    private float revealProgress = 0f;

    private int backgroundColor = 0xFFF0F0F0;
    private int hoverColor = 0xFFE8E8E8;
    private int activeColor = 0xFFE0E0E0;
    private int listeningColor = 0xFFBBDEFB;
    private int disabledColor = 0xFFFAFAFA;
    private int conflictColor = 0xFFFFCDD2;

    private int borderColor = 0xFFBDBDBD;
    private int borderHoverColor = 0xFF9E9E9E;
    private int borderActiveColor = 0xFF757575;
    private int borderListeningColor = 0xFF2196F3;
    private int borderDisabledColor = 0xFFDDDDDD;
    private int borderConflictColor = 0xFFF44336;

    private int textColor = 0xFF333333;
    private int listeningTextColor = 0xFF1976D2;
    private int disabledTextColor = 0xFFAAAAAA;
    private int conflictTextColor = 0xFFD32F2F;
    private int keyTextColor = 0xFFFFFFFF;

    private int keyBackgroundColor = 0xFF424242;
    private int keyHoverColor = 0xFF616161;
    private int keyActiveColor = 0xFF212121;

    private boolean useGradient = false;
    private int gradientStartColor = 0xFF4CAF50;
    private int gradientEndColor = 0xFF8BC34A;

    private boolean glowEnabled = false;
    private float glowIntensity = 0f;
    private int glowColor = 0x804CAF50;

    private boolean showConflictWarning = true;
    private boolean showKeyCode = false;
    private String conflictMessage = "Already in use!";

    private List<Integer> conflictingKeys = new ArrayList<>();

    private Consumer<Keybind> onBind = keybind -> {};
    private Supplier<Boolean> isDisabledSupplier = () -> false;
    private Supplier<Integer> keyCodeSupplier = () -> keyCode;

    public Keybind() {
        super();
        setClickable(true);
        updateDimensions();
    }

    public Keybind(String displayName, int keyCode) {
        this();
        this.displayName = displayName;
        this.keyCode = keyCode;
        this.keyName = getKeyName(keyCode);
        updateDimensions();
    }

    public Keybind(String displayName, KeyBinding keyBinding) {
        this(displayName, keyBinding.getKeyCode());
        this.keyBinding = keyBinding;
    }

    @Override
    public void init(ru.ryuzaki.ui.core.UIRoot root) {
        super.init(root);
        keyCode = keyCodeSupplier.get();
        keyName = getKeyName(keyCode);
        updateDimensions();
    }

    private void updateDimensions() {
        setMinSize(width, height);
    }

    @Override
    public void update(int mouseX, int mouseY, float partialTicks) {
        super.update(mouseX, mouseY, partialTicks);

        keyCode = keyCodeSupplier.get();
        keyName = getKeyName(keyCode);

        if (keyBinding != null && keyBinding.getKeyCode() != keyCode) {
            keyCode = keyBinding.getKeyCode();
            keyName = getKeyName(keyCode);
        }

        isDisabled = isDisabledSupplier.get();

        boolean newHovered = isMouseOver() && !isDisabled;
        if (newHovered != isHovered) {
            isHovered = newHovered;
        }

        float targetScale = isHovered && !isDisabled && !isListening ? 1.02f : 1f;
        hoverScale = Easing.lerp(hoverScale, targetScale, 0.15f);

        if (isListening) {
            listeningPulse = (float) (Math.sin(System.currentTimeMillis() / 200.0) * 0.5 + 0.5);
        } else {
            listeningPulse = Easing.lerp(listeningPulse, 0f, 0.2f);
        }

        if (isConflict && isHovered) {
            conflictShake = (float) Math.sin(System.currentTimeMillis() / 50.0) * 2f;
        } else {
            conflictShake = Easing.lerp(conflictShake, 0f, 0.3f);
        }

        if (glowEnabled) {
            float targetGlow = (isListening || (isHovered && !isDisabled)) ? 1f : 0f;
            glowIntensity = Easing.lerp(glowIntensity, targetGlow, 0.15f);
        }
    }

    @Override
    public void render(float partialTicks) {
        BoundingBox bounds = getBounds();
        float x = bounds.getX();
        float y = bounds.getY();

        float renderX = x + conflictShake;

        Draw.pushMatrix();
        Draw.translate(x + width / 2f, y + height / 2f, 0);
        Draw.scale(hoverScale, hoverScale, 1f);
        Draw.translate(-(x + width / 2f), -(y + height / 2f), 0);

        if (glowEnabled && glowIntensity > 0) {
            int glowCol = ((int)(glowIntensity * 0.35f * 255) << 24) | (glowColor & 0x00FFFFFF);
            Draw.drawRoundedRect(x - 3f, y - 3f, width + 6f, height + 6f,
                                borderRadius + 3f, glowCol);
        }

        if (isConflict && showConflictWarning) {
            int conflictBg = ((int)(0.2f * 255) << 24) | (conflictColor & 0x00FFFFFF);
            Draw.drawRoundedRect(x - 2f, y - 2f, width + 4f, height + 4f,
                                borderRadius + 2f, conflictBg);
        }

        renderBackground(renderX, y);
        renderDisplayName(renderX, y);

        if (isListening) {
            renderListeningState(renderX, y);
        } else {
            renderKey(renderX, y);
        }

        Draw.popMatrix();

        if (isConflict && showConflictWarning) {
            renderConflictWarning(renderX, y);
        }
    }

    private void renderBackground(float x, float y) {
        int bgColor = getBackgroundColor();
        int bColor = getBorderColor();

        Draw.drawRoundedRect(x, y, width, height, borderRadius, bgColor);
        Draw.drawRoundedRectOutline(x, y, width, height, borderRadius, borderWidth, bColor);
    }

    private void renderDisplayName(float x, float y) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        int textCol = getTextColor();
        if (useGradient && !isDisabled) {
            textCol = getGradientTextColor();
        }

        String name = displayName.isEmpty() ? "Key" : displayName;
        float textX = x + padding;
        float textY = y + height / 2f - fr.FONT_HEIGHT / 2f;

        Draw.drawString(name, textX, textY, textCol, 1f);
    }

    private void renderKey(float x, float y) {
        String keyDisplay = keyName;
        if (showKeyCode && keyCode >= 0) {
            keyDisplay = "[" + keyCode + "]";
        }

        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        float keyWidth = Math.max(fr.getStringWidth(keyDisplay) + 16f, 32f);
        float keyX = x + width - keyWidth - padding;
        float keyY = y + (height - keyHeight) / 2f;

        int keyBgColor;
        int keyTextColor;

        if (isDisabled) {
            keyBgColor = 0xFFCCCCCC;
            keyTextColor = 0xFF888888;
        } else if (isHovered) {
            keyBgColor = keyHoverColor;
            keyTextColor = keyTextColor;
        } else {
            keyBgColor = keyBackgroundColor;
            keyTextColor = keyTextColor;
        }

        if (useGradient && !isDisabled) {
            keyBgColor = getGradientKeyColor();
        }

        float kRadius = Math.min(keyHeight / 2f, 4f);
        Draw.drawRoundedRect(keyX, keyY, keyWidth, keyHeight, kRadius, keyBgColor);

        float textWidth = fr.getStringWidth(keyDisplay);
        float textX = keyX + keyWidth / 2f - textWidth / 2f;
        float textY = keyY + keyHeight / 2f - fr.FONT_HEIGHT / 2f;

        Draw.drawString(keyDisplay, textX, textY, keyTextColor, 1f);
    }

    private void renderListeningState(float x, float y) {
        float listeningWidth = 100f;
        float keyX = x + width - listeningWidth - padding;
        float keyY = y + (height - keyHeight) / 2f;

        float pulseIntensity = 0.1f + listeningPulse * 0.15f;
        int pulseColor = ((int)(pulseIntensity * 255) << 24) | (listeningColor & 0x00FFFFFF);

        Draw.drawRoundedRect(keyX - 2f, keyY - 2f, listeningWidth + 4f, keyHeight + 4f,
                            borderRadius + 2f, pulseColor);

        int keyBgColor = 0xFF2196F3;
        float kRadius = Math.min(keyHeight / 2f, 4f);
        Draw.drawRoundedRect(keyX, keyY, listeningWidth, keyHeight, kRadius, keyBgColor);
        Draw.drawRoundedRectOutline(keyX, keyY, listeningWidth, keyHeight, kRadius, 2f, 0xFF1565C0);

        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        String waitingText = "Press key...";
        float textWidth = fr.getStringWidth(waitingText);
        float textX = keyX + listeningWidth / 2f - textWidth / 2f;
        float textY = keyY + keyHeight / 2f - fr.FONT_HEIGHT / 2f;

        int textAlpha = (int)(150 + listeningPulse * 105);
        int textCol = 0xFF000000 | (textAlpha << 24) | (0xFFFFFF & listeningTextColor);

        Draw.drawString(waitingText, textX, textY, textCol, 1f);
    }

    private void renderConflictWarning(float x, float y) {
        Minecraft mc = Minecraft.getMinecraft();
        FontRenderer fr = mc.fontRendererObj;

        String warning = EnumChatFormatting.RED + conflictMessage;
        float textWidth = fr.getStringWidth(warning);
        float textX = x + width / 2f - textWidth / 2f;
        float textY = y - fr.FONT_HEIGHT - 4f;

        if (textY >= 0) {
            int bgColor = 0xCC000000;
            float bgWidth = textWidth + 8f;
            float bgHeight = fr.FONT_HEIGHT + 4f;
            Draw.drawRoundedRect(textX - 4f, textY - 2f, bgWidth, bgHeight, 4f, bgColor);

            Draw.drawString(warning, textX, textY, 0xFFFF5252, 1f);
        }
    }

    private int getBackgroundColor() {
        if (isDisabled) return disabledColor;
        if (isConflict) return conflictColor;
        if (isListening) return listeningColor;
        if (isHovered) return hoverColor;
        return backgroundColor;
    }

    private int getBorderColor() {
        if (isDisabled) return borderDisabledColor;
        if (isConflict) return borderConflictColor;
        if (isListening) return borderListeningColor;
        if (isHovered) return borderActiveColor;
        return borderColor;
    }

    private int getTextColor() {
        if (isDisabled) return disabledTextColor;
        if (isConflict) return conflictTextColor;
        if (isListening) return listeningTextColor;
        return textColor;
    }

    private int getGradientTextColor() {
        float progress = (float) (Math.sin(System.currentTimeMillis() / 500.0) * 0.5 + 0.5);

        int r1 = (gradientStartColor >> 16) & 0xFF;
        int g1 = (gradientStartColor >> 8) & 0xFF;
        int b1 = gradientStartColor & 0xFF;
        int r2 = (gradientEndColor >> 16) & 0xFF;
        int g2 = (gradientEndColor >> 8) & 0xFF;
        int b2 = gradientEndColor & 0xFF;

        int r = (int) (r1 + (r2 - r1) * progress);
        int g = (int) (g1 + (g2 - g1) * progress);
        int b = (int) (b1 + (b2 - b1) * progress);

        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private int getGradientKeyColor() {
        float progress = (float) (Math.sin(System.currentTimeMillis() / 400.0) * 0.5 + 0.5);

        int r1 = (gradientStartColor >> 16) & 0xFF;
        int g1 = (gradientStartColor >> 8) & 0xFF;
        int b1 = gradientStartColor & 0xFF;
        int r2 = (gradientEndColor >> 16) & 0xFF;
        int g2 = (gradientEndColor >> 8) & 0xFF;
        int b2 = gradientEndColor & 0xFF;

        int r = (int) (r1 + (r2 - r1) * progress);
        int g = (int) (g1 + (g2 - g1) * progress);
        int b = (int) (b1 + (b2 - b1) * progress);

        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    public boolean onClick(int mouseX, int mouseY, int mouseButton) {
        if (isDisabled) return false;

        if (!isListening) {
            isListening = true;
            checkConflicts();
            return true;
        }

        return true;
    }

    @Override
    public boolean onKeyTyped(char typedChar, int keyCode) {
        if (!isListening || isDisabled) return false;

        if (keyCode == Keyboard.KEY_ESCAPE) {
            isListening = false;
            return true;
        }

        if (keyCode == Keyboard.KEY_BACK || keyCode == Keyboard.KEY_DELETE) {
            setKey(-1);
            isListening = false;
            onBind.accept(this);
            return true;
        }

        if (!isModifierKey(keyCode) || isConflict) {
            setKey(keyCode);
            isListening = false;
            onBind.accept(this);
            return true;
        }

        return true;
    }

    @Override
    public void onLostFocus() {
        if (isListening) {
            isListening = false;
        }
    }

    private void setKey(int keyCode) {
        this.keyCode = keyCode;
        this.keyName = getKeyName(keyCode);

        if (keyBinding != null) {
            keyBinding.setKeyCode(keyCode);
        }

        checkConflicts();
    }

    private void checkConflicts() {
        isConflict = false;
        conflictingKeys.clear();

        if (keyCode < 0) {
            return;
        }

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.gameSettings.keyBindings != null) {
            for (KeyBinding kb : mc.gameSettings.keyBindings) {
                if (kb != keyBinding && kb.getKeyCode() == keyCode) {
                    isConflict = true;
                    conflictingKeys.add(keyCode);
                    break;
                }
            }
        }
    }

    private String getKeyName(int keyCode) {
        if (keyCode < 0) {
            return "None";
        }

        if (keyCode < 256) {
            String name = Keyboard.getKeyName(keyCode);
            if (!name.isEmpty()) {
                if (name.equals("SPACE")) return "Space";
                if (name.equals("CONTROL")) return "Ctrl";
                if (name.equals("SHIFT")) return "Shift";
                if (name.equals("TAB")) return "Tab";
                if (name.equals("CAPITAL")) return "Caps";
                if (name.equals("RETURN")) return "Enter";
                if (name.equals("BACK")) return "Back";
                if (name.equals("UP")) return "↑";
                if (name.equals("DOWN")) return "↓";
                if (name.equals("LEFT")) return "←";
                if (name.equals("RIGHT")) return "→";

                if (name.length() == 1) {
                    return name.toUpperCase();
                }
                return name;
            }
        }

        if (keyCode >= 96 && keyCode <= 105) {
            return "Num " + (keyCode - 96);
        }

        return "Key " + keyCode;
    }

    private boolean isModifierKey(int keyCode) {
        return keyCode == Keyboard.KEY_LCONTROL || keyCode == Keyboard.KEY_RCONTROL
            || keyCode == Keyboard.KEY_LSHIFT || keyCode == Keyboard.KEY_RSHIFT
            || keyCode == Keyboard.KEY_LMENU || keyCode == Keyboard.KEY_RMENU;
    }

    public Keybind setKeyBinding(KeyBinding keyBinding) {
        this.keyBinding = keyBinding;
        if (keyBinding != null) {
            this.keyCode = keyBinding.getKeyCode();
            this.keyName = getKeyName(this.keyCode);
            checkConflicts();
        }
        return this;
    }

    public Keybind setKeyCode(int keyCode) {
        this.keyCode = keyCode;
        this.keyName = getKeyName(keyCode);
        if (keyBinding != null) {
            keyBinding.setKeyCode(keyCode);
        }
        checkConflicts();
        return this;
    }

    public Keybind setDisplayName(String name) {
        this.displayName = name;
        return this;
    }

    public int getKeyCode() { return keyCode; }
    public String getKeyName() { return keyName; }
    public boolean isListening() { return isListening; }
    public boolean isDisabled() { return isDisabled; }
    public boolean isConflict() { return isConflict; }
    public KeyBinding getKeyBinding() { return keyBinding; }

    public Keybind setWidth(float width) {
        this.width = width;
        updateDimensions();
        return this;
    }

    public Keybind setHeight(float height) {
        this.height = height;
        this.keyHeight = height - 10f;
        updateDimensions();
        return this;
    }

    public Keybind setBorderRadius(float radius) {
        this.borderRadius = radius;
        return this;
    }

    public Keybind setBorder(float width, int color) {
        this.borderWidth = width;
        this.borderColor = color;
        return this;
    }

    public Keybind setColors(int bg, int border) {
        this.backgroundColor = bg;
        this.borderColor = border;
        return this;
    }

    public Keybind setTextColor(int color) {
        this.textColor = color;
        return this;
    }

    public Keybind setKeyColors(int bg, int hover) {
        this.keyBackgroundColor = bg;
        this.keyHoverColor = hover;
        return this;
    }

    public Keybind setUseGradient(boolean use) {
        this.useGradient = use;
        return this;
    }

    public Keybind setGradientColors(int start, int end) {
        this.gradientStartColor = start;
        this.gradientEndColor = end;
        return this;
    }

    public Keybind setGlowEnabled(boolean enabled) {
        this.glowEnabled = enabled;
        return this;
    }

    public Keybind setGlowColor(int color) {
        this.glowColor = color;
        return this;
    }

    public Keybind setShowConflictWarning(boolean show) {
        this.showConflictWarning = show;
        return this;
    }

    public Keybind setConflictMessage(String message) {
        this.conflictMessage = message;
        return this;
    }

    public Keybind setShowKeyCode(boolean show) {
        this.showKeyCode = show;
        return this;
    }

    public Keybind setOnBind(Consumer<Keybind> onBind) {
        this.onBind = onBind;
        return this;
    }

    public Keybind setDisabledSupplier(Supplier<Boolean> supplier) {
        this.isDisabledSupplier = supplier;
        return this;
    }

    public Keybind setKeyCodeSupplier(Supplier<Integer> supplier) {
        this.keyCodeSupplier = supplier;
        return this;
    }

    @Override
    public String toString() {
        return "Keybind{name=" + displayName + ", key=" + keyName + ", code=" + keyCode +
               ", listening=" + isListening + ", conflict=" + isConflict + "}";
    }
}
