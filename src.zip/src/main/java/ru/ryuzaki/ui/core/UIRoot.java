package ru.ryuzaki.ui.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.ui.base.*;
import ru.ryuzaki.ui.events.*;
import ru.ryuzaki.ui.render.*;

import java.util.*;

/**
 * UIRoot — root container for the entire UI hierarchy.
 *
 * Responsibilities:
 * - Manages top-level input routing (mouse, keyboard)
 * - Maintains focus chain for keyboard navigation
 * - Handles drag operations across component boundaries
 * - Provides screen-space coordinate transformations
 * - Coordinates with RenderGraph for multi-pass rendering
 * - Manages tooltip display
 * - Provides screen resize handling
 * - Event bubbling from children to root
 *
 * Architecture:
 * ┌─────────────────────────────────────────────────────────┐
 * │                      UIRoot                            │
 * │  ┌─────────────────────────────────────────────────┐  │
 * │  │              UIComponent Tree                    │  │
 * │  │  ┌──────────┐  ┌──────────┐  ┌──────────┐      │  │
 * │  │  │ Window1  │  │ Window2  │  │  Modal   │      │  │
 * │  │  │ ┌──────┐ │  │ ┌──────┐ │  │ ┌──────┐ │      │  │
 * │  │  │ │Button│ │  │ │Slider│ │  │ │Label │ │      │  │
 * │  │  │ └──────┘ │  │ └──────┘ │  │ └──────┘ │      │  │
 * │  │  └──────────┘  └──────────┘  └──────────┘      │  │
 * │  └─────────────────────────────────────────────────┘  │
 * │  ┌─────────────────────────────────────────────────┐  │
 * │  │           Input Handler & Focus                  │  │
 * │  └─────────────────────────────────────────────────┘  │
 * └─────────────────────────────────────────────────────────┘
 */
public class UIRoot extends UIContainer {

    private static UIRoot INSTANCE;

    // ═══════════════════════════════════════════════════════════════════════
    //  SCREEN & DISPLAY
    // ═══════════════════════════════════════════════════════════════════════

    private int screenWidth;
    private int screenHeight;
    private float scaleFactor = 1.0f;

    // ═══════════════════════════════════════════════════════════════════════
    //  FOCUS MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    private UIComponent focusedComponent;
    private UIComponent hoveredComponent;
    private UIComponent draggingComponent;
    private UIComponent lastMouseDownComponent;

    // Focus traversal
    private final List<UIComponent> focusCycle = new ArrayList<>();

    // ═══════════════════════════════════════════════════════════════════════
    //  INPUT STATE
    // ═══════════════════════════════════════════════════════════════════════

    private Vec2 lastMousePos = Vec2.ZERO;
    private Vec2 currentMousePos = Vec2.ZERO;
    private long lastRenderTime;
    private float deltaTime;

    // ═══════════════════════════════════════════════════════════════════════
    //  DRAG STATE
    // ═══════════════════════════════════════════════════════════════════════

    private boolean isDragging;
    private UIComponent dragTarget;
    private Vec2 dragStartMouse;
    private Vec2 dragStartBounds;

    // ═══════════════════════════════════════════════════════════════════════
    //  TOOLTIP
    // ═══════════════════════════════════════════════════════════════════════

    private String currentTooltip;
    private long tooltipShowTime;
    private static final long TOOLTIP_DELAY_MS = 400;
    private Vec2 tooltipPosition;

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDERING
    // ═══════════════════════════════════════════════════════════════════════

    private boolean useRenderGraph = true;
    private BackgroundAtmosphere backgroundAtmosphere;
    private GlassRenderer glassRenderer;

    // ═══════════════════════════════════════════════════════════════════════
    //  CHILDREN ORDERING
    // ═══════════════════════════════════════════════════════════════════════

    private final List<UIComponent> childOrder = new ArrayList<>();

    private UIRoot() {
        super("root");
        this.screenWidth = MinecraftClient.getInstance().getWindow().getWidth();
        this.screenHeight = MinecraftClient.getInstance().getWindow().getHeight();
        this.scaleFactor = (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
        this.backgroundAtmosphere = BackgroundAtmosphere.getInstance();
        this.glassRenderer = GlassRenderer.getInstance();
    }

    public static synchronized UIRoot getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new UIRoot();
        }
        return INSTANCE;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public void init() {
        super.init();
        rebuildFocusCycle();
    }

    /**
     * Main update loop — called every frame.
     */
    public void update() {
        long now = System.currentTimeMillis();
        deltaTime = (now - lastRenderTime) / 1000.0f;
        lastRenderTime = now;

        // Update screen dimensions (may have changed)
        updateScreenSize();

        // Update all components
        update(deltaTime);

        // Update tooltip
        updateTooltip(now);

        // Update focus cycle
        if (focusCycle.isEmpty()) {
            rebuildFocusCycle();
        }
    }

    /**
     * Main render loop — called every frame.
     */
    public void render(DrawContext context) {
        MatrixStack matrices = context.getMatrices();

        matrices.push();

        // Apply scale factor for GUI scaling
        matrices.scale(scaleFactor, scaleFactor, 1.0f);

        // Update mouse position in atmosphere/glass renderers
        backgroundAtmosphere.updateMousePosition(
            currentMousePos.x / scaleFactor,
            currentMousePos.y / scaleFactor,
            screenWidth / scaleFactor,
            screenHeight / scaleFactor
        );
        glassRenderer.updateMousePosition(
            currentMousePos.x / scaleFactor,
            currentMousePos.y / scaleFactor,
            screenWidth / scaleFactor,
            screenHeight / scaleFactor
        );

        // Render background atmosphere
        backgroundAtmosphere.render(context, screenWidth / scaleFactor, screenHeight / scaleFactor);

        // Render component tree
        renderChildren(context, deltaTime);

        matrices.pop();

        // Render tooltip (outside scaled matrix)
        renderTooltip(context);

        // Reset mouse released outside flag
        for (UIComponent child : getChildren()) {
            if (child instanceof UIRoot.UIRoot childRoot) {
                childRoot.clearMouseReleasedOutside();
            }
        }
    }

    private void updateScreenSize() {
        int newWidth = MinecraftClient.getInstance().getWindow().getWidth();
        int newHeight = MinecraftClient.getInstance().getWindow().getHeight();
        float newScale = (float) MinecraftClient.getInstance().getWindow().getScaleFactor();

        if (screenWidth != newWidth || screenHeight != newHeight || scaleFactor != newScale) {
            screenWidth = newWidth;
            screenHeight = newHeight;
            scaleFactor = newScale;
            onScreenResize(screenWidth, screenHeight);
        }
    }

    protected void onScreenResize(int width, int height) {
        setSize(width, height);
        onResize(width, height);
    }

    protected void onResize(int width, int height) {
        // Override in subclasses to respond to resize
    }

    @Override
    protected void renderSelf(DrawContext context, float deltaTime) {
        // Root doesn't render anything itself
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INPUT HANDLING
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Handle mouse movement.
     */
    public boolean onMouseMove(float mouseX, float mouseY) {
        lastMousePos = currentMousePos;
        currentMousePos = new Vec2(mouseX / scaleFactor, mouseY / scaleFactor);

        // Convert to screen-space before routing to components
        float scaledX = mouseX / scaleFactor;
        float scaledY = mouseY / scaleFactor;

        // Route to children (reverse order for top-most first)
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.isVisible() && child.isEnabled()) {
                if (child.getBounds().contains(scaledX, scaledY)) {
                    if (child.onMouseMove(scaledX, scaledY)) {
                        updateHovered(child, scaledX, scaledY);
                        return true;
                    }
                }
            }
        }

        updateHovered(null, scaledX, scaledY);
        return false;
    }

    /**
     * Handle mouse button press.
     */
    public boolean onMouseDown(float mouseX, float mouseY, int button) {
        float scaledX = mouseX / scaleFactor;
        float scaledY = mouseY / scaleFactor;

        lastMouseDownComponent = null;

        // Route to children (reverse order for top-most first)
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.isVisible() && child.isEnabled()) {
                if (child.getBounds().contains(scaledX, scaledY)) {
                    if (child.onMouseDown(scaledX, scaledY, button)) {
                        lastMouseDownComponent = child;
                        draggingComponent = child;
                        return true;
                    }
                }
            }
        }

        // Click on empty space — release focus
        if (focusedComponent != null && button == 0) {
            focusedComponent.releaseFocus();
            focusedComponent = null;
        }

        return false;
    }

    /**
     * Handle mouse button release.
     */
    public boolean onMouseUp(float mouseX, float mouseY, int button) {
        float scaledX = mouseX / scaleFactor;
        float scaledY = mouseY / scaleFactor;

        if (draggingComponent != null) {
            draggingComponent.onMouseUp(scaledX, scaledY, button);
            draggingComponent = null;
        }

        // Route to children
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.isVisible() && child.isEnabled()) {
                if (child.onMouseUp(scaledX, scaledY, button)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Handle mouse scroll.
     */
    public boolean onMouseScroll(float mouseX, float mouseY, float horizontalAmount, float verticalAmount) {
        float scaledX = mouseX / scaleFactor;
        float scaledY = mouseY / scaleFactor;

        // Route to hovered component first
        if (hoveredComponent != null) {
            if (hoveredComponent.onMouseScroll(scaledX, scaledY, horizontalAmount, verticalAmount)) {
                return true;
            }
        }

        // Route to children
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.isVisible() && child.isEnabled() && child.getBounds().contains(scaledX, scaledY)) {
                if (child.onMouseScroll(scaledX, scaledY, horizontalAmount, verticalAmount)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Handle key press.
     */
    public boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
        // First, try focused component
        if (focusedComponent != null) {
            if (focusedComponent.onKeyPress(keyCode, scanCode, modifiers)) {
                return true;
            }
        }

        // Handle focus traversal
        if (keyCode == Input.KEY_TAB) {
            if ((modifiers & Input.MOD_SHIFT) != 0) {
                focusPrevious();
            } else {
                focusNext();
            }
            return true;
        }

        // Handle special keys
        if (focusedComponent == null && isFocusableKey(keyCode)) {
            // Focus first focusable component
            if (!focusCycle.isEmpty()) {
                setFocusedComponent(focusCycle.get(0));
            }
        }

        return false;
    }

    private boolean isFocusableKey(int keyCode) {
        return keyCode == Input.KEY_UP || keyCode == Input.KEY_DOWN ||
               keyCode == Input.KEY_LEFT || keyCode == Input.KEY_RIGHT ||
               keyCode == Input.KEY_ENTER || keyCode == Input.KEY_SPACE;
    }

    /**
     * Handle key release.
     */
    public boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
        if (focusedComponent != null) {
            return focusedComponent.onKeyRelease(keyCode, scanCode, modifiers);
        }
        return false;
    }

    /**
     * Handle character input.
     */
    public boolean onCharTyped(char chr, int modifiers) {
        if (focusedComponent != null) {
            return focusedComponent.onCharTyped(chr, modifiers);
        }
        return false;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  FOCUS MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    public void setFocusedComponent(UIComponent component) {
        // Release current focus
        if (focusedComponent != null && focusedComponent != component) {
            focusedComponent.setFocused(false);
        }

        focusedComponent = component;

        if (component != null) {
            component.setFocused(true);
        }

        rebuildFocusCycle();
    }

    public UIComponent getFocusedComponent() {
        return focusedComponent;
    }

    public void focusNext() {
        if (focusCycle.isEmpty()) return;

        int currentIndex = focusedComponent != null ? focusCycle.indexOf(focusedComponent) : -1;
        int nextIndex = (currentIndex + 1) % focusCycle.size();
        setFocusedComponent(focusCycle.get(nextIndex));
    }

    public void focusPrevious() {
        if (focusCycle.isEmpty()) return;

        int currentIndex = focusedComponent != null ? focusCycle.indexOf(focusedComponent) : 0;
        int prevIndex = (currentIndex - 1 + focusCycle.size()) % focusCycle.size();
        setFocusedComponent(focusCycle.get(prevIndex));
    }

    private void rebuildFocusCycle() {
        focusCycle.clear();
        collectFocusable(this, focusCycle);
    }

    private void collectFocusable(UIComponent component, List<UIComponent> list) {
        if (component.isFocusable() && component != this) {
            list.add(component);
        }
        if (component instanceof UIContainer container) {
            for (UIComponent child : container.getChildren()) {
                collectFocusable(child, list);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  HOVER MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    private void updateHovered(UIComponent component, float x, float y) {
        if (hoveredComponent != component) {
            if (hoveredComponent != null) {
                hoveredComponent.onMouseExit();
            }
            hoveredComponent = component;
            if (component != null) {
                component.onMouseEnter();
                showTooltip(component);
            } else {
                hideTooltip();
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  TOOLTIP
    // ═══════════════════════════════════════════════════════════════════════

    private void showTooltip(UIComponent component) {
        String tooltip = component.getTooltip();
        if (tooltip != null && !tooltip.isEmpty()) {
            currentTooltip = tooltip;
            tooltipShowTime = System.currentTimeMillis();
            tooltipPosition = currentMousePos.copy();
        }
    }

    private void hideTooltip() {
        currentTooltip = null;
    }

    private void updateTooltip(long now) {
        // Tooltip shows after delay
    }

    private void renderTooltip(DrawContext context) {
        if (currentTooltip == null || currentTooltip.isEmpty()) return;

        long now = System.currentTimeMillis();
        if (now - tooltipShowTime < TOOLTIP_DELAY_MS) return;

        DrawContext ctx = context;
        float x = tooltipPosition.x + 10;
        float y = tooltipPosition.y + 10;

        // Simple tooltip rendering
        int textWidth = mc.textRenderer.getWidth(currentTooltip);
        int height = mc.textRenderer.fontHeight + 4;

        // Background
        Draw.fill(ctx, x - 2, y - 2, x + textWidth + 4, y + height + 2, 0xCC000000);

        // Text
        Draw.drawString(ctx, currentTooltip, x, y, 0xFFFFFF, true);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CHILD MANAGEMENT (Override for Z-ordering)
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public void addChild(UIComponent child) {
        super.addChild(child);
        childOrder.add(child);
        rebuildFocusCycle();
        bringChildToFront(child);
    }

    @Override
    public void removeChild(UIComponent child) {
        super.removeChild(child);
        childOrder.remove(child);
        if (focusedComponent == child) {
            focusedComponent = null;
        }
        if (hoveredComponent == child) {
            hoveredComponent = null;
        }
        rebuildFocusCycle();
    }

    public void bringToFront(UIComponent component) {
        if (childOrder.remove(component)) {
            childOrder.add(component);
        }
    }

    public void sendToBack(UIComponent component) {
        if (childOrder.remove(component)) {
            childOrder.add(0, component);
        }
    }

    @Override
    protected void bringChildToFront(UIComponent child) {
        super.bringChildToFront(child);
        bringToFront(child);
    }

    @Override
    protected void sendChildToBack(UIComponent child) {
        super.sendChildToBack(child);
        sendToBack(child);
    }

    @Override
    protected List<UIComponent> getOrderedChildren() {
        return childOrder;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  DRAG & DROP
    // ═══════════════════════════════════════════════════════════════════════

    public void startDrag(UIComponent target, float mouseX, float mouseY) {
        isDragging = true;
        dragTarget = target;
        dragStartMouse = new Vec2(mouseX, mouseY);
        dragStartBounds = target.getPosition().copy();
    }

    public void updateDrag(float mouseX, float mouseY) {
        if (!isDragging || dragTarget == null) return;

        float dx = mouseX - dragStartMouse.x;
        float dy = mouseY - dragStartMouse.y;

        float newX = dragStartBounds.x + dx;
        float newY = dragStartBounds.y + dy;

        // Clamp to bounds
        BoundingBox maxBounds = dragTarget.getDragBounds();
        if (maxBounds != null) {
            newX = Math.max(maxBounds.x1, Math.min(newX, maxBounds.x2 - dragTarget.getWidth()));
            newY = Math.max(maxBounds.y1, Math.min(newY, maxBounds.y2 - dragTarget.getHeight()));
        }

        dragTarget.setPositionImmediate(newX, newY);
    }

    public void endDrag() {
        if (isDragging && dragTarget != null) {
            dragTarget.onDragEnd();
        }
        isDragging = false;
        dragTarget = null;
    }

    public boolean isDragging() {
        return isDragging;
    }

    public UIComponent getDragTarget() {
        return dragTarget;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  GETTERS
    // ═══════════════════════════════════════════════════════════════════════

    public int getScreenWidth() {
        return screenWidth;
    }

    public int getScreenHeight() {
        return screenHeight;
    }

    public float getScaleFactor() {
        return scaleFactor;
    }

    public float getDeltaTime() {
        return deltaTime;
    }

    public Vec2 getMousePos() {
        return currentMousePos;
    }

    public UIComponent getHoveredComponent() {
        return hoveredComponent;
    }

    public boolean isUseRenderGraph() {
        return useRenderGraph;
    }

    public void setUseRenderGraph(boolean use) {
        this.useRenderGraph = use;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  DISPOSE
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public void dispose() {
        focusedComponent = null;
        hoveredComponent = null;
        draggingComponent = null;
        childOrder.clear();
        focusCycle.clear();
        super.dispose();
    }

    /**
     * Clear mouse released outside flag on all children.
     */
    public void clearMouseReleasedOutside() {
        // Implemented by child components
    }
}
