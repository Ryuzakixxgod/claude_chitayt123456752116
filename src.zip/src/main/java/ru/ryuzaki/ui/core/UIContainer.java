package ru.ryuzaki.ui.core;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import ru.ryuzaki.ui.base.*;
import ru.ryuzaki.ui.events.*;

import java.util.*;
import java.util.function.Consumer;

/**
 * UIContainer — base container for UI components.
 *
 * Features:
 * - Hierarchical child management
 * - Bounds clipping for children
 * - Layout management
 * - Event bubbling
 * - Z-ordering (bring to front, send to back)
 * - Visibility propagation
 * - Padding and margin support
 */
public class UIContainer extends UIComponent {

    // ═══════════════════════════════════════════════════════════════════════
    //  CHILDREN
    // ═══════════════════════════════════════════════════════════════════════

    protected final List<UIComponent> children = new ArrayList<>();
    protected final List<UIComponent> visibleChildren = new ArrayList<>();

    // ═══════════════════════════════════════════════════════════════════════
    //  LAYOUT
    // ═══════════════════════════════════════════════════════════════════════

    protected LayoutManager layout;
    protected boolean layoutDirty = true;

    // ═══════════════════════════════════════════════════════════════════════
    //  CLIPPING
    // ═══════════════════════════════════════════════════════════════════════

    protected boolean clipChildren = false;
    protected BoundingBox clipBounds;

    // ═══════════════════════════════════════════════════════════════════════
    //  PADDING & MARGIN
    // ═══════════════════════════════════════════════════════════════════════

    protected Insets padding = Insets.EMPTY;
    protected Insets margin = Insets.EMPTY;

    public UIContainer(String id) {
        super(id);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CHILD MANAGEMENT
    // ═══════════════════════════════════════════════════════════════════════

    public void addChild(UIComponent child) {
        if (child == null || child.getParent() == this) return;

        // Remove from previous parent
        if (child.getParent() != null) {
            child.getParent().removeChild(child);
        }

        children.add(child);
        child.setParent(this);
        child.setRoot(getRoot());

        // Initialize if we are initialized
        if (isInitialized()) {
            child.init();
        }

        onChildAdded(child);
        invalidateLayout();
    }

    public void removeChild(UIComponent child) {
        if (child == null || child.getParent() != this) return;

        children.remove(child);
        visibleChildren.remove(child);
        child.setParent(null);
        child.setRoot(null);
        child.dispose();

        onChildRemoved(child);
        invalidateLayout();
    }

    public void removeAllChildren() {
        List<UIComponent> toRemove = new ArrayList<>(children);
        for (UIComponent child : toRemove) {
            removeChild(child);
        }
    }

    public UIComponent getChildById(String id) {
        for (UIComponent child : children) {
            if (child.getId().equals(id)) {
                return child;
            }
            if (child instanceof UIContainer container) {
                UIComponent found = container.getChildById(id);
                if (found != null) return found;
            }
        }
        return null;
    }

    public List<UIComponent> getChildren() {
        return Collections.unmodifiableList(children);
    }

    public List<UIComponent> getVisibleChildren() {
        visibleChildren.clear();
        for (UIComponent child : children) {
            if (child.isVisible()) {
                visibleChildren.add(child);
            }
        }
        return visibleChildren;
    }

    public int getChildCount() {
        return children.size();
    }

    public boolean hasChildren() {
        return !children.isEmpty();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  Z-ORDERING
    // ═══════════════════════════════════════════════════════════════════════

    protected void bringChildToFront(UIComponent child) {
        if (children.remove(child)) {
            children.add(child);
        }
    }

    protected void sendChildToBack(UIComponent child) {
        if (children.remove(child)) {
            children.add(0, child);
        }
    }

    protected List<UIComponent> getOrderedChildren() {
        return children;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LAYOUT
    // ═══════════════════════════════════════════════════════════════════════

    public void setLayout(LayoutManager layout) {
        this.layout = layout;
        invalidateLayout();
    }

    public LayoutManager getLayout() {
        return layout;
    }

    public void invalidateLayout() {
        layoutDirty = true;
        if (parent != null) {
            parent.invalidateLayout();
        }
    }

    protected void validateLayout() {
        if (layoutDirty) {
            if (layout != null) {
                layout.layoutContainer(this);
            }
            layoutDirty = false;
        }

        // Validate children
        for (UIComponent child : children) {
            if (child instanceof UIContainer container) {
                container.validateLayout();
            }
        }
    }

    @Override
    protected void onBoundsChanged() {
        invalidateLayout();
        super.onBoundsChanged();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public void init() {
        super.init();
        for (UIComponent child : children) {
            child.init();
        }
    }

    @Override
    public void dispose() {
        for (UIComponent child : children) {
            child.dispose();
        }
        children.clear();
        visibleChildren.clear();
        layout = null;
        super.dispose();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  UPDATE
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public void update(float deltaTime) {
        super.update(deltaTime);

        // Validate layout before update
        validateLayout();

        // Update all children
        for (UIComponent child : children) {
            if (child.isVisible()) {
                child.update(deltaTime);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  RENDER
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    protected void renderSelf(DrawContext context, float deltaTime) {
        // Container doesn't render anything by default
    }

    protected void renderChildren(DrawContext context, float deltaTime) {
        for (UIComponent child : getOrderedChildren()) {
            if (child.isVisible()) {
                renderChild(child, context, deltaTime);
            }
        }
    }

    protected void renderChild(UIComponent child, DrawContext context, float deltaTime) {
        // Apply clip if needed
        if (clipChildren) {
            BoundingBox bounds = child.getBounds();
            if (clipBounds == null) {
                clipBounds = getBounds();
            }

            // Check if child is within clip bounds
            if (!clipBounds.intersects(bounds)) {
                return; // Fully clipped
            }
        }

        // Transform context to child's position
        context.getMatrices().push();
        context.getMatrices().translate(child.getX(), child.getY(), 0);

        // Render child
        child.render(context, deltaTime);

        context.getMatrices().pop();
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  INPUT - Override to intercept events
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public boolean onMouseMove(float mouseX, float mouseY) {
        float localX = mouseX - getX();
        float localY = mouseY - getY();

        // Route to children (reverse order for top-most first)
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.isVisible() && child.isEnabled()) {
                if (child.getBounds().contains(localX, localY)) {
                    if (child.onMouseMove(localX, localY)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Override
    public boolean onMouseDown(float mouseX, float mouseY, int button) {
        float localX = mouseX - getX();
        float localY = mouseY - getY();

        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.isVisible() && child.isEnabled()) {
                if (child.getBounds().contains(localX, localY)) {
                    if (child.onMouseDown(localX, localY, button)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Override
    public boolean onMouseUp(float mouseX, float mouseY, int button) {
        float localX = mouseX - getX();
        float localY = mouseY - getY();

        for (UIComponent child : children) {
            if (child.isVisible() && child.isEnabled()) {
                if (child.onMouseUp(localX, localY, button)) {
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public boolean onMouseScroll(float mouseX, float mouseY, float horizontalAmount, float verticalAmount) {
        float localX = mouseX - getX();
        float localY = mouseY - getY();

        // Route to hovered child first
        for (UIComponent child : children) {
            if (child.isVisible() && child.isEnabled() && child.getBounds().contains(localX, localY)) {
                if (child.onMouseScroll(localX, localY, horizontalAmount, verticalAmount)) {
                    return true;
                }
            }
        }

        return false;
    }

    @Override
    public boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
        for (UIComponent child : children) {
            if (child.isVisible() && child.isEnabled()) {
                if (child.onKeyPress(keyCode, scanCode, modifiers)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
        for (UIComponent child : children) {
            if (child.isVisible() && child.isEnabled()) {
                if (child.onKeyRelease(keyCode, scanCode, modifiers)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean onCharTyped(char chr, int modifiers) {
        for (UIComponent child : children) {
            if (child.isVisible() && child.isEnabled()) {
                if (child.onCharTyped(chr, modifiers)) {
                    return true;
                }
            }
        }
        return false;
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CALLBACKS
    // ═══════════════════════════════════════════════════════════════════════

    protected void onChildAdded(UIComponent child) {
        // Override to react to child being added
    }

    protected void onChildRemoved(UIComponent child) {
        // Override to react to child being removed
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PADDING & MARGIN
    // ═══════════════════════════════════════════════════════════════════════

    public Insets getPadding() {
        return padding;
    }

    public void setPadding(Insets padding) {
        this.padding = padding != null ? padding : Insets.EMPTY;
        invalidateLayout();
    }

    public void setPadding(int uniform) {
        setPadding(new Insets(uniform));
    }

    public void setPadding(int top, int right, int bottom, int left) {
        setPadding(new Insets(top, right, bottom, left));
    }

    public Insets getMargin() {
        return margin;
    }

    public void setMargin(Insets margin) {
        this.margin = margin != null ? margin : Insets.EMPTY;
        invalidateLayout();
    }

    public void setMargin(int uniform) {
        setMargin(new Insets(uniform));
    }

    public void setMargin(int top, int right, int bottom, int left) {
        setMargin(new Insets(top, right, bottom, left));
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  CLIPPING
    // ═══════════════════════════════════════════════════════════════════════

    public boolean isClipChildren() {
        return clipChildren;
    }

    public void setClipChildren(boolean clip) {
        this.clipChildren = clip;
        if (clip) {
            clipBounds = getBounds();
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  PREFERRED SIZE
    // ═══════════════════════════════════════════════════════════════════════

    @Override
    public Vec2 getPreferredSize() {
        if (layout != null) {
            return layout.preferredLayoutSize(this);
        }

        // Calculate based on children
        int maxWidth = 0;
        int maxHeight = 0;

        for (UIComponent child : children) {
            if (child.isVisible()) {
                Vec2 pref = child.getPreferredSize();
                maxWidth = Math.max(maxWidth, (int) pref.x);
                maxHeight = Math.max(maxHeight, (int) pref.y);
            }
        }

        // Add padding
        maxWidth += padding.left + padding.right;
        maxHeight += padding.top + padding.bottom;

        return new Vec2(maxWidth, maxHeight);
    }

    // ═══════════════════════════════════════════════════════════════════════
    //  LAYOUT MANAGER INTERFACE
    // ═══════════════════════════════════════════════════════════════════════

    public interface LayoutManager {
        void layoutContainer(UIContainer parent);

        Vec2 preferredLayoutSize(UIContainer parent);

        default void invalidateLayout(UIContainer parent) {
            parent.invalidateLayout();
        }
    }
}
