package ru.ryuzaki.ui.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.ui.base.*;
import ru.ryuzaki.ui.events.*;

import java.util.*;
import java.util.function.Consumer;

/**
 * UIComponent — core building block for AAA UI framework.
 *
 * Every UI element extends this class. Provides:
 * - Full lifecycle management (init → update → render → dispose)
 * - Delta-time animation system (easing, spring, velocity)
 * - Complete input handling (mouse, keyboard, focus, drag)
 * - Component tree with proper parent/child relationships
 * - Event bus for decoupled communication
 * - Visibility/animation transitions
 * - Dragging support with bounds clamping
 * - Z-index rendering order
 *
 * Component hierarchy:
 * UIComponent
 * ├── UIContainer (supports children)
 * │   ├── Panel
 * │   ├── Window
 * │   ├── ScrollContainer
 * │   └── Container
 * └── UIWidget (leaf components)
 *     ├── Button
 *     ├── Checkbox
 *     ├── Slider
 *     ├── Dropdown
 *     ├── TextBox
 *     ├── Label
 *     └── IconButton
 */
public abstract class UIComponent {

    // ── Component Identity ─────────────────────────────────────────────────

    protected final String id;
    protected String tooltip;
    protected boolean enabled = true;
    protected boolean visible = true;

    // ── Bounds & Transform ────────────────────────────────────────────────

    protected BoundingBox bounds = new BoundingBox();
    protected BoundingBox renderBounds = new BoundingBox();
    protected Vec2 actualPosition = Vec2.ZERO;
    protected Vec2 targetPosition = Vec2.ZERO;
    protected Vec2 velocity = Vec2.ZERO;

    // ── Parent / Children ──────────────────────────────────────────────────

    protected UIComponent parent;
    protected final ArrayList<UIComponent> children = new ArrayList<>();
    protected final ArrayList<UIComponent> childrenView = new ArrayList<>(0);

    // ── Animation System ───────────────────────────────────────────────────

    protected final AnimationState animState = new AnimationState();
    protected final LinkedHashMap<String, Animation> animations = new LinkedHashMap<>();
    protected Easing defaultEasing = Easing::easeOutCubic;
    protected float defaultDuration = 0.26f;

    // ── Input State ────────────────────────────────────────────────────────

    protected boolean focused;
    protected boolean hovered;
    protected boolean pressed;
    protected boolean dragging;
    protected Vec2 dragOffset = Vec2.ZERO;
    protected Vec2 mousePos = Vec2.ZERO;
    protected int mouseDownButton = -1;
    protected Vec2 mouseDownPos = Vec2.ZERO;
    protected boolean mouseReleasedOutside;
    protected boolean touchStartedOver;

    // ── Event Bus ──────────────────────────────────────────────────────────

    protected final ArrayList<UIEventListener> eventListeners = new ArrayList<>();

    // ── Z-Index & Rendering ────────────────────────────────────────────────

    protected int zIndex = 0;
    protected boolean clipChildren = true;
    protected BoundingBox clipRegion = new BoundingBox();
    protected boolean cacheValid = false;
    protected int lastWidth = -1;
    protected int lastHeight = -1;

    // ── Touch / Mobile ─────────────────────────────────────────────────────

    protected long lastClickTime;
    protected int clickCount;

    // ─────────────────────────────────────────────────────────────────────

    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    // ══════════════════════════════════════════════════════════════════════
    //  CONSTRUCTION
    // ══════════════════════════════════════════════════════════════════════

    public UIComponent() {
        this.id = UUID.randomUUID().toString();
    }

    public UIComponent(String id) {
        this.id = id;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  LIFECYCLE
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Called once when component is first attached to a parent or created standalone.
     */
    public void init() {
        onInit();
        for (UIComponent child : children) {
            child.init();
        }
    }

    /**
     * Override to add initialization logic.
     */
    protected void onInit() {
        // Override in subclasses
    }

    /**
     * Called every frame with delta time in seconds.
     */
    public void update(float deltaTime) {
        updateAnimations(deltaTime);
        updateDrag(deltaTime);
        updateActualPosition(deltaTime);

        for (UIComponent child : children) {
            if (child.visible) {
                child.update(deltaTime);
            }
        }

        onUpdate(deltaTime);
    }

    /**
     * Override for per-frame logic.
     */
    protected void onUpdate(float deltaTime) {
        // Override in subclasses
    }

    /**
     * Render this component and all children.
     */
    public void render(DrawContext context, float deltaTime) {
        if (!visible) return;

        preRender(context, deltaTime);

        if (isCacheable() && cacheValid && lastWidth == (int) bounds.w() && lastHeight == (int) bounds.h()) {
            renderCached(context);
        } else {
            renderSelf(context, deltaTime);
            lastWidth = (int) bounds.w();
            lastHeight = (int) bounds.h();
            cacheValid = true;
        }

        renderChildren(context, deltaTime);
        postRender(context, deltaTime);
    }

    /**
     * Override to implement component rendering.
     */
    protected abstract void renderSelf(DrawContext context, float deltaTime);

    /**
     * Override to render cached content.
     */
    protected void renderCached(DrawContext context) {
        // Override in subclasses that want caching
    }

    /**
     * Called after children are rendered.
     */
    protected void postRender(DrawContext context, float deltaTime) {
        // Override in subclasses
    }

    /**
     * Called before rendering.
     */
    protected void preRender(DrawContext context, float deltaTime) {
        animState.update(deltaTime);
    }

    /**
     * Render all children with clipping.
     */
    protected void renderChildren(DrawContext context, float deltaTime) {
        if (children.isEmpty()) return;

        Collections.sort(children, Comparator.comparingInt(c -> c.zIndex));

        if (clipChildren) {
            Draw.pushScissor(context, (int) bounds.x1, (int) bounds.y1,
                    (int) bounds.w(), (int) bounds.h());
        }

        for (UIComponent child : children) {
            if (child.visible) {
                child.render(context, deltaTime);
            }
        }

        if (clipChildren) {
            Draw.popScissor(context);
        }
    }

    /**
     * Called when component is removed from parent.
     */
    public void dispose() {
        for (UIComponent child : children) {
            child.dispose();
        }
        animations.values().forEach(Animation::stop);
        animations.clear();
        eventListeners.clear();
        onDispose();
    }

    /**
     * Override for cleanup logic.
     */
    protected void onDispose() {
        // Override in subclasses
    }

    /**
     * Check if this component can be cached between frames.
     */
    protected boolean isCacheable() {
        return false;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  BOUNDS & POSITION
    // ══════════════════════════════════════════════════════════════════════

    public void setBounds(float x, float y, float w, float h) {
        this.bounds.set(x, y, x + w, y + h);
        this.renderBounds.set(x, y, x + w, y + h);
        onBoundsChanged();
    }

    public void setBounds(BoundingBox bounds) {
        this.bounds.set(bounds);
        this.renderBounds.set(bounds);
        onBoundsChanged();
    }

    public void setPosition(float x, float y) {
        float dx = x - bounds.x1;
        float dy = y - bounds.y1;
        this.bounds.translate(dx, dy);
        this.renderBounds.translate(dx, dy);
        onBoundsChanged();
    }

    public void setSize(float w, float h) {
        this.bounds.x2 = bounds.x1 + w;
        this.bounds.y2 = bounds.y1 + h;
        this.renderBounds.x2 = bounds.x1 + w;
        this.renderBounds.y2 = bounds.y1 + h;
        onBoundsChanged();
    }

    protected void onBoundsChanged() {
        cacheValid = false;
    }

    public BoundingBox getBounds() { return bounds.copy(); }
    public Vec2 getPosition() { return bounds.pos(); }
    public Vec2 getSize() { return bounds.size(); }
    public float getWidth() { return bounds.w(); }
    public float getHeight() { return bounds.h(); }
    public float getX() { return bounds.x1; }
    public float getY() { return bounds.y1; }

    // ── Position Animation ────────────────────────────────────────────────

    /**
     * Animate position to target over duration using easing.
     */
    public void animatePosition(float targetX, float targetY, float duration, Easing easing) {
        targetPosition = new Vec2(targetX, targetY);
        animState.position.setTarget(targetX, targetY, duration, easing);
    }

    /**
     * Animate position with default easing and duration.
     */
    public void animatePosition(float targetX, float targetY) {
        animatePosition(targetX, targetY, defaultDuration, defaultEasing);
    }

    /**
     * Set position instantly (no animation).
     */
    public void setPositionImmediate(float x, float y) {
        setPosition(x, y);
        actualPosition = new Vec2(x, y);
        velocity = Vec2.ZERO;
    }

    protected void updateActualPosition(float dt) {
        if (!animState.position.isAnimating()) return;

        float newX = animState.position.getX();
        float newY = animState.position.getY();

        velocity = new Vec2(newX - actualPosition.x, newY - actualPosition.y);
        actualPosition = new Vec2(newX, newY);

        bounds.x1 = actualPosition.x;
        bounds.y1 = actualPosition.y;
        bounds.x2 = actualPosition.x + bounds.w();
        bounds.y2 = actualPosition.y + bounds.h();
        renderBounds.set(bounds);
    }

    // ══════════════════════════════════════════════════════════════════════
    //  CHILDREN & PARENT
    // ══════════════════════════════════════════════════════════════════════

    public void addChild(UIComponent child) {
        if (child.parent == this) return;
        if (child.parent != null) {
            child.parent.removeChild(child);
        }
        child.parent = this;
        children.add(child);
        childrenView.clear();
        childrenView.addAll(children);
        child.init();
        cacheValid = false;
    }

    public void removeChild(UIComponent child) {
        if (child.parent != this) return;
        children.remove(child);
        child.parent = null;
        childrenView.clear();
        childrenView.addAll(children);
        child.dispose();
        cacheValid = false;
    }

    public void removeAllChildren() {
        for (UIComponent child : children) {
            child.parent = null;
            child.dispose();
        }
        children.clear();
        childrenView.clear();
        cacheValid = false;
    }

    public List<UIComponent> getChildren() {
        return childrenView;
    }

    public UIComponent getParent() {
        return parent;
    }

    public UIComponent getRoot() {
        UIComponent root = this;
        while (root.parent != null) {
            root = root.parent;
        }
        return root;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  INPUT HANDLING
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Handle mouse movement.
     * @return true if event was consumed
     */
    public boolean onMouseMove(float mouseX, float mouseY) {
        this.mousePos = new Vec2(mouseX, mouseY);

        boolean wasHovered = hovered;
        hovered = bounds.contains(mouseX, mouseY);

        if (!wasHovered && hovered) {
            onMouseEnter();
        } else if (wasHovered && !hovered) {
            onMouseExit();
        }

        if (dragging) {
            return onDrag(mouseX, mouseY);
        }

        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible && child.enabled && child.bounds.contains(mouseX, mouseY)) {
                if (child.onMouseMove(mouseX, mouseY)) {
                    return true;
                }
            }
        }

        if (hovered) {
            return onHover(mouseX, mouseY);
        }

        return false;
    }

    /**
     * Handle mouse button press.
     * @return true if event was consumed
     */
    public boolean onMouseDown(float mouseX, float mouseY, int button) {
        this.mouseDownButton = button;
        this.mouseDownPos = new Vec2(mouseX, mouseY);
        this.mouseReleasedOutside = false;
        this.touchStartedOver = bounds.contains(mouseX, mouseY);

        if (bounds.contains(mouseX, mouseY)) {
            pressed = true;

            // Handle double-click
            long now = System.currentTimeMillis();
            if (now - lastClickTime < 300) {
                clickCount++;
            } else {
                clickCount = 1;
            }
            lastClickTime = now;

            // Handle drag initiation
            if (isDraggable()) {
                dragging = true;
                dragOffset = new Vec2(mouseX - bounds.x1, mouseY - bounds.y1);
            }

            // Handle focus
            if (isFocusable()) {
                requestFocus();
            }

            // Bubble to children (reverse order for top-most first)
            for (int i = children.size() - 1; i >= 0; i--) {
                UIComponent child = children.get(i);
                if (child.visible && child.enabled && child.bounds.contains(mouseX, mouseY)) {
                    if (child.onMouseDown(mouseX, mouseY, button)) {
                        return true;
                    }
                }
            }

            return onClick(mouseX, mouseY, button, clickCount);
        }

        // Click outside - blur if needed
        if (focused && button == 0) {
            mouseReleasedOutside = true;
        }

        return false;
    }

    /**
     * Handle mouse button release.
     * @return true if event was consumed
     */
    public boolean onMouseUp(float mouseX, float mouseY, int button) {
        pressed = false;

        boolean wasDragging = dragging;
        dragging = false;

        boolean consumed = false;

        if (bounds.contains(mouseX, mouseY) || touchStartedOver) {
            // Bubble to children
            for (int i = children.size() - 1; i >= 0; i--) {
                UIComponent child = children.get(i);
                if (child.visible && child.enabled) {
                    if (child.onMouseUp(mouseX, mouseY, button)) {
                        consumed = true;
                    }
                }
            }

            if (!consumed && touchStartedOver) {
                consumed = onRelease(mouseX, mouseY, button);
            }

            if (wasDragging && isDraggable()) {
                onDragEnd();
            }
        } else {
            if (wasDragging && isDraggable()) {
                onDragEnd();
                if (mouseReleasedOutside) {
                    onDragCancel();
                }
            }
        }

        mouseDownButton = -1;
        touchStartedOver = false;

        return consumed;
    }

    /**
     * Handle mouse scroll.
     * @return true if event was consumed
     */
    public boolean onMouseScroll(float mouseX, float mouseY, float horizontalAmount, float verticalAmount) {
        if (!bounds.contains(mouseX, mouseY)) return false;

        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible && child.enabled && child.bounds.contains(mouseX, mouseY)) {
                if (child.onMouseScroll(mouseX, mouseY, horizontalAmount, verticalAmount)) {
                    return true;
                }
            }
        }

        return onScroll(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    /**
     * Handle key press.
     * @return true if event was consumed
     */
    public boolean onKeyPress(int keyCode, int scanCode, int modifiers) {
        if (!enabled) return false;

        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible && child.enabled && child.focused) {
                if (child.onKeyPress(keyCode, scanCode, modifiers)) {
                    return true;
                }
            }
        }

        if (focused) {
            return onKey(keyCode, scanCode, modifiers);
        }

        return false;
    }

    /**
     * Handle key release.
     * @return true if event was consumed
     */
    public boolean onKeyRelease(int keyCode, int scanCode, int modifiers) {
        if (!enabled) return false;

        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible && child.enabled && child.focused) {
                if (child.onKeyRelease(keyCode, scanCode, modifiers)) {
                    return true;
                }
            }
        }

        if (focused) {
            return onKeyRelease(keyCode, scanCode, modifiers);
        }

        return false;
    }

    /**
     * Handle character input.
     * @return true if event was consumed
     */
    public boolean onCharTyped(char chr, int modifiers) {
        if (!enabled || !focused) return false;
        return onCharInput(chr, modifiers);
    }

    // ── Override Hooks ───────────────────────────────────────────────────

    protected boolean onHover(float mouseX, float mouseY) { return false; }
    protected boolean onClick(float mouseX, float mouseY, int button, int clickCount) { return false; }
    protected boolean onRelease(float mouseX, float mouseY, int button) { return false; }
    protected boolean onDrag(float mouseX, float mouseY) { return false; }
    protected boolean onScroll(float mouseX, float mouseY, float hAmount, float vAmount) { return false; }
    protected boolean onKey(int keyCode, int scanCode, int modifiers) { return false; }
    protected boolean onCharInput(char chr, int modifiers) { return false; }

    protected void onMouseEnter() {
        // Play hover sound if configured
    }

    protected void onMouseExit() {
        // Cleanup hover state
    }

    protected void onDragEnd() {
        // Finalize drag
    }

    protected void onDragCancel() {
        // Revert drag
    }

    // ══════════════════════════════════════════════════════════════════════
    //  DRAGGING
    // ══════════════════════════════════════════════════════════════════════

    protected boolean isDraggable() {
        return false;
    }

    protected boolean isDraggableFromTitleBar() {
        return false;
    }

    protected BoundingBox getDragBounds() {
        return null;
    }

    protected void updateDrag(float deltaTime) {
        if (!dragging || !isDraggable()) return;

        float newX = mousePos.x - dragOffset.x;
        float newY = mousePos.y - dragOffset.y;

        BoundingBox maxBounds = getDragBounds();
        if (maxBounds != null) {
            newX = Math.max(maxBounds.x1, Math.min(newX, maxBounds.x2 - bounds.w()));
            newY = Math.max(maxBounds.y1, Math.min(newY, maxBounds.y2 - bounds.h()));
        }

        if (isDraggableFromTitleBar()) {
            float titleBarHeight = getTitleBarHeight();
            newY = mousePos.y - dragOffset.y - titleBarHeight * 0.5f;
            if (maxBounds != null) {
                newY = Math.max(maxBounds.y1, Math.min(newY, maxBounds.y2 - bounds.h()));
            }
        }

        setPositionImmediate(newX, newY);
    }

    protected float getTitleBarHeight() {
        return 0;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  FOCUS
    // ══════════════════════════════════════════════════════════════════════

    protected boolean isFocusable() {
        return enabled && visible;
    }

    public void requestFocus() {
        UIComponent root = getRoot();
        if (root instanceof UIRoot uiRoot) {
            uiRoot.setFocusedComponent(this);
        }
    }

    public void releaseFocus() {
        if (focused) {
            focused = false;
            onFocusLost();
        }
    }

    public boolean isFocused() {
        return focused;
    }

    public void setFocused(boolean focused) {
        this.focused = focused;
        if (focused) {
            onFocusGained();
        } else {
            onFocusLost();
        }
    }

    protected void onFocusGained() {
        // Override for focus effects
    }

    protected void onFocusLost() {
        // Override for blur effects
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ANIMATIONS
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Animate a float value.
     */
    public Animation animateFloat(String name, float from, float to, float duration, Easing easing,
                                  Consumer<Float> onUpdate, Runnable onComplete) {
        Animation anim = Animation.builder()
                .floatValue(from)
                .target(to)
                .duration(duration)
                .easing(easing)
                .onUpdate(v -> onUpdate.accept(v))
                .onComplete(onComplete)
                .build();
        animations.put(name, anim);
        return anim;
    }

    /**
     * Animate opacity (0-1).
     */
    public Animation animateOpacity(float to, float duration, Easing easing) {
        float from = animState.opacity.current;
        return animateFloat("opacity", from, to, duration, easing,
                v -> animState.opacity.current = v, () -> {});
    }

    /**
     * Animate scale.
     */
    public Animation animateScale(float to, float duration, Easing easing) {
        float from = animState.scale.current;
        return animateFloat("scale", from, to, duration, easing,
                v -> animState.scale.current = v, () -> {});
    }

    /**
     * Animate rotation in degrees.
     */
    public Animation animateRotation(float to, float duration, Easing easing) {
        float from = animState.rotation.current;
        return animateFloat("rotation", from, to, duration, easing,
                v -> animState.rotation.current = v, () -> {});
    }

    /**
     * Animate alpha channel of a color.
     */
    public Animation animateAlpha(int to, float duration, Easing easing) {
        float from = animState.alpha.current;
        return animateFloat("alpha", from, to, duration, easing,
                v -> animState.alpha.current = v, () -> {});
    }

    /**
     * Stagger animation — delay between each child.
     */
    public void staggerChildren(float baseDelay, float staggerDelay, Easing easing) {
        for (int i = 0; i < children.size(); i++) {
            UIComponent child = children.get(i);
            float delay = baseDelay + i * staggerDelay;
            child.animState.appearDelay = delay;
        }
    }

    /**
     * Play appear animation.
     */
    public void playAppearAnimation() {
        animState.appearing = true;
        animState.appearProgress = 0f;
    }

    /**
     * Play disappear animation.
     */
    public void playDisappearAnimation(Runnable onComplete) {
        animateOpacity(0, defaultDuration, defaultEasing);
        animateScale(0.9f, defaultDuration, defaultEasing);
    }

    protected void updateAnimations(float deltaTime) {
        if (animState.appearing) {
            animState.appearProgress += deltaTime / defaultDuration;
            if (animState.appearProgress >= 1f) {
                animState.appearProgress = 1f;
                animState.appearing = false;
            }
        }

        animState.appearProgress = Math.min(1f, animState.appearProgress);

        if (animState.appearDelay > 0) {
            animState.appearDelay -= deltaTime;
            return;
        }

        Iterator<Map.Entry<String, Animation>> iter = animations.entrySet().iterator();
        while (iter.hasNext()) {
            Map.Entry<String, Animation> entry = iter.next();
            Animation anim = entry.getValue();
            anim.update(deltaTime);
            if (!anim.isRunning()) {
                anim.onComplete();
                iter.remove();
            }
        }
    }

    public void stopAnimation(String name) {
        Animation anim = animations.remove(name);
        if (anim != null) {
            anim.stop();
        }
    }

    public void stopAllAnimations() {
        animations.values().forEach(Animation::stop);
        animations.clear();
    }

    // ══════════════════════════════════════════════════════════════════════
    //  VISIBILITY
    // ══════════════════════════════════════════════════════════════════════

    public void show() {
        if (!visible) {
            visible = true;
            playAppearAnimation();
            onShow();
        }
    }

    public void hide() {
        if (visible) {
            visible = false;
            onHide();
        }
    }

    public void setVisible(boolean visible) {
        if (this.visible != visible) {
            this.visible = visible;
            if (visible) {
                playAppearAnimation();
                onShow();
            } else {
                onHide();
            }
        }
    }

    public boolean isVisible() {
        return visible;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (!enabled) {
            hovered = false;
            pressed = false;
            focused = false;
        }
    }

    protected void onShow() {}
    protected void onHide() {}

    // ══════════════════════════════════════════════════════════════════════
    //  EVENT BUS
    // ══════════════════════════════════════════════════════════════════════

    public void addEventListener(UIEventListener listener) {
        eventListeners.add(listener);
    }

    public void removeEventListener(UIEventListener listener) {
        eventListeners.remove(listener);
    }

    public void emit(UIEvent event) {
        event.setSource(this);
        for (UIEventListener listener : eventListeners) {
            listener.onEvent(event);
        }
        if (parent != null) {
            parent.emit(event);
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  Z-INDEX
    // ══════════════════════════════════════════════════════════════════════

    public int getZIndex() {
        return zIndex;
    }

    public void setZIndex(int zIndex) {
        this.zIndex = zIndex;
        if (parent != null) {
            parent.cacheValid = false;
        }
    }

    public void bringToFront() {
        UIComponent root = getRoot();
        if (root instanceof UIRoot uiRoot) {
            uiRoot.bringToFront(this);
        }
    }

    public void sendToBack() {
        if (parent != null) {
            parent.sendChildToBack(this);
        }
    }

    protected void sendChildToBack(UIComponent child) {
        // Override in container to reorder children
    }

    protected void bringChildToFront(UIComponent child) {
        // Override in container to reorder children
    }

    // ══════════════════════════════════════════════════════════════════════
    //  HIT TESTING
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Find component at position (for event routing).
     */
    public UIComponent getComponentAt(float x, float y) {
        if (!visible || !bounds.contains(x, y)) return null;

        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible) {
                UIComponent hit = child.getComponentAt(x, y);
                if (hit != null) return hit;
            }
        }

        return this;
    }

    /**
     * Get all components intersecting a rect (for selection/drag).
     */
    public List<UIComponent> getComponentsInRect(BoundingBox rect) {
        List<UIComponent> result = new ArrayList<>();
        collectComponentsInRect(rect, result);
        return result;
    }

    private void collectComponentsInRect(BoundingBox rect, List<UIComponent> result) {
        if (!visible || !bounds.intersects(rect)) return;

        if (rect.contains(bounds)) {
            result.add(this);
            return;
        }

        for (UIComponent child : children) {
            if (child.visible) {
                child.collectComponentsInRect(rect, result);
            }
        }
    }

    // ══════════════════════════════════════════════════════════════════════
    //  HIT TESTING
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Get tooltip text for this component.
     */
    public String getTooltip() {
        return tooltip;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }

    public String getId() {
        return id;
    }

    // ══════════════════════════════════════════════════════════════════════
    //  ANIMATION STATE
    // ══════════════════════════════════════════════════════════════════════

    /**
     * Internal animation state container.
     */
    public static final class AnimationState {
        public float appearDelay = 0f;
        public boolean appearing = false;
        public float appearProgress = 1f;

        public final AnimatableFloat opacity = new AnimatableFloat(1f);
        public final AnimatableFloat scale = new AnimatableFloat(1f);
        public final AnimatableFloat rotation = new AnimatableFloat(0f);
        public final AnimatableFloat alpha = new AnimatableFloat(1f);
        public final AnimatableVec2 position = new AnimatableVec2();

        public void update(float dt) {
            opacity.update(dt);
            scale.update(dt);
            rotation.update(dt);
            alpha.update(dt);
            position.update(dt);
        }

        public float getCombinedOpacity() {
            return opacity.current * alpha.current * appearProgress;
        }

        public float getScale() {
            return scale.current;
        }
    }

    /**
     * Animatable float channel.
     */
    public static final class AnimatableFloat {
        public float current;
        public float target;
        public float velocity;
        public float duration;
        public float elapsed;
        public Easing easing;
        public boolean animating;

        public AnimatableFloat(float initial) {
            this.current = initial;
            this.target = initial;
        }

        public void setTarget(float target, float duration, Easing easing) {
            this.target = target;
            this.duration = duration;
            this.easing = easing;
            this.elapsed = 0f;
            this.animating = true;
        }

        public void update(float dt) {
            if (!animating) return;
            elapsed += dt;
            float t = Math.min(elapsed / duration, 1f);
            float eased = easing.apply(t);
            current = current + (target - current) * eased;
            if (t >= 1f) {
                current = target;
                animating = false;
            }
        }

        public boolean isAnimating() {
            return animating;
        }
    }

    /**
     * Animatable 2D vector.
     */
    public static final class AnimatableVec2 {
        public Vec2 current = Vec2.ZERO;
        public Vec2 target = Vec2.ZERO;
        public float duration;
        public float elapsed;
        public Easing easing;
        public boolean animating;

        public void setTarget(float x, float y, float duration, Easing easing) {
            this.target = new Vec2(x, y);
            this.duration = duration;
            this.easing = easing;
            this.elapsed = 0f;
            this.animating = true;
        }

        public float getX() {
            if (!animating) return target.x;
            float t = Math.min(elapsed / duration, 1f);
            return current.x + (target.x - current.x) * easing.apply(t);
        }

        public float getY() {
            if (!animating) return target.y;
            float t = Math.min(elapsed / duration, 1f);
            return current.y + (target.y - current.y) * easing.apply(t);
        }

        public void update(float dt) {
            if (!animating) return;
            elapsed += dt;
            float t = Math.min(elapsed / duration, 1f);
            float eased = easing.apply(t);
            float newX = current.x + (target.x - current.x) * eased;
            float newY = current.y + (target.y - current.y) * eased;
            if (t >= 1f) {
                current = target;
                animating = false;
            } else {
                current = new Vec2(newX, newY);
            }
        }

        public boolean isAnimating() {
            return animating;
        }
    }
}
