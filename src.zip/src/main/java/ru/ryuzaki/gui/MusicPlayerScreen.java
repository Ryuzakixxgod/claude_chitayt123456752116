package ru.ryuzaki.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import javax.sound.sampled.*;
import java.io.BufferedInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Music Player — HTTP audio stream.
 * Работает с прямыми ссылками на .mp3/.ogg/internet-radio потоки.
 * SoundCloud, internet radio, прямые MP3 ссылки.
 */
public class MusicPlayerScreen extends Screen {
    private final Screen parent;

    private static final int W = 480, H = 320;
    private static final int C_BG     = rgba(6, 5, 14, 252);
    private static final int C_ACCENT = rgba(140, 40, 230, 255);
    private static final int C_CARD   = rgba(14, 12, 28, 245);
    private static final int C_BORDER = rgba(60, 20, 100, 180);
    private static final int C_TEXT   = 0xFFEEEEFF;
    private static final int C_DIM    = 0xFF888899;

    // ── Состояние плеера ─────────────────────────────────────────────────
    private static volatile boolean  isPlaying   = false;
    private static volatile boolean  isPaused    = false;
    private static volatile float    volume      = 0.7f;
    private static volatile String   currentUrl  = "";
    private static volatile String   currentName = "Нет трека";
    private static volatile long     startTime   = 0;
    private static volatile long     duration    = 0; // ms
    private static volatile long     position    = 0; // ms (approx)
    private static volatile String   status      = "Остановлено";

    private static Clip              audioClip;
    private static AudioInputStream  audioStream;   // для закрытия ресурсов
    private static Thread            streamThread;
    private static ExecutorService   executor;      // создаётся лениво

    // ── Плейлист ──────────────────────────────────────────────────────────
    private static final List<Track> playlist = new ArrayList<>();
    private static int               currentIndex = -1;

    static {
        // Встроенные интернет-радио потоки
        playlist.add(new Track("Lofi Hip Hop Radio",      "http://streams.iloveradio.de/iloveradio3.mp3"));
        playlist.add(new Track("Chillhop Radio",           "https://streams.fluxfm.de/Chillhop/mp3-128/streams.fluxfm.de/"));
        playlist.add(new Track("Synthwave Radio",          "https://stream.nightride.fm/nightride.mp3"));
        playlist.add(new Track("Space Ambient Radio",      "http://uk2.internet-radio.com:8024/"));
        playlist.add(new Track("[Вставь ссылку]",          ""));
        playlist.add(new Track("[Вставь ссылку 2]",        ""));
    }

    // ── UI состояние ──────────────────────────────────────────────────────
    private boolean    editingUrl      = false;
    private int        editingIndex    = -1;
    private String     editBuffer      = "";
    private boolean    editingName     = false;
    private String     nameBuffer      = "";

    private boolean    volDragging     = false;
    private boolean    seekDragging    = false;
    private boolean    showAddPrompt   = false;

    // Визуализатор
    private final float[] vizBars      = new float[24];
    private final float[] vizTargets   = new float[24];

    public MusicPlayerScreen(Screen parent) {
        super(Text.literal("Ryuzaki Music"));
        this.parent = parent;
    }

    public static boolean hasActiveTrack() {
        return isPlaying || isPaused || (currentName != null && !currentName.isBlank() && !"Нет трека".equals(currentName));
    }

    public static boolean isAudioPlaying() {
        return isPlaying && !isPaused;
    }

    public static String currentTrackName() {
        return currentName;
    }

    public static String currentTrackStatus() {
        return status;
    }

    public static float currentProgress() {
        if (duration <= 0) {
            return 0.0F;
        }
        long currentPosition = isAudioPlaying() ? System.currentTimeMillis() - startTime : position;
        return Math.max(0.0F, Math.min(1.0F, currentPosition / (float) duration));
    }

    // ── RENDER ────────────────────────────────────────────────────────────
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        int gx = (width - W) / 2, gy = (height - H) / 2;

        // ── Внешнее свечение ────────────────────────────────────────────
        for (int i = 3; i >= 1; i--)
            ctx.fill(gx-i, gy-i, gx+W+i, gy+H+i, rgba(140, 40, 230, 15*i));

        // ── Фон ──────────────────────────────────────────────────────────
        ctx.fill(gx, gy, gx+W, gy+H, C_BG);
        ctx.fill(gx, gy, gx+W, gy+1,   C_ACCENT);
        ctx.fill(gx, gy+H-1, gx+W, gy+H, rgba(140,40,230,120));
        ctx.fill(gx, gy, gx+1, gy+H,   rgba(140,40,230,120));
        ctx.fill(gx+W-1, gy, gx+W, gy+H, rgba(140,40,230,120));

        // ── Заголовок ─────────────────────────────────────────────────────
        ctx.fill(gx, gy, gx+W, gy+32, rgba(10,6,22,255));
        ctx.fill(gx, gy+31, gx+W, gy+32, C_BORDER);
        ctx.drawText(mc.textRenderer, Text.literal("§f♪  MUSIC PLAYER"),
                     gx+12, gy+12, C_ACCENT, true);
        ctx.drawText(mc.textRenderer, Text.literal("§8HTTP Audio Stream"),
                     gx+W-mc.textRenderer.getWidth("HTTP Audio Stream")-12, gy+12, C_DIM, false);

        // ── Кнопка закрыть ────────────────────────────────────────────────
        boolean closeHov = inR(mx,my, gx+W-22, gy+9, 14, 14);
        ctx.fill(gx+W-22, gy+9, gx+W-8, gy+23, closeHov?rgba(200,40,40,200):rgba(60,15,30,180));
        ctx.drawText(mc.textRenderer, Text.literal("§c✕"), gx+W-18, gy+12, 0xFFFF6666, false);

        // ── Визуализатор ─────────────────────────────────────────────────
        updateViz();
        int vizX = gx + 10, vizY = gy + 34, vizW = W - 20, vizH = 50;
        ctx.fill(vizX, vizY, vizX+vizW, vizY+vizH, rgba(8,4,16,200));
        int barW = vizW / vizBars.length - 1;
        for (int i = 0; i < vizBars.length; i++) {
            float h2 = vizBars[i] * vizH;
            float hue = i / (float)vizBars.length * 0.4f + 0.65f;
            int[] col = hsvToRgb(hue, 0.9f, 1f);
            int bx2 = vizX + i * (barW + 1);
            ctx.fill(bx2, (int)(vizY + vizH - h2), bx2 + barW, vizY + vizH,
                     rgba(col[0], col[1], col[2], 220));
        }

        // ── Трек инфо ────────────────────────────────────────────────────
        int infoY = gy + 92;
        ctx.fill(gx+10, infoY, gx+W-10, infoY+36, C_CARD);
        ctx.fill(gx+10, infoY, gx+W-10, infoY+1, C_BORDER);
        String nameStr = currentName.length() > 40 ? currentName.substring(0,38)+"…" : currentName;
        ctx.drawText(mc.textRenderer, Text.literal("§f" + nameStr),
                     gx+16, infoY+6, C_TEXT, true);
        ctx.drawText(mc.textRenderer, Text.literal("§8" + status),
                     gx+16, infoY+20, C_DIM, false);
        // Статус-точка
        int dotCol = isPlaying && !isPaused ? C_ACCENT : rgba(100,80,140,255);
        ctx.fill(gx+W-22, infoY+13, gx+W-12, infoY+23, dotCol);

        // ── Прогресс-бар ─────────────────────────────────────────────────
        int progY = gy + 134;
        ctx.fill(gx+10, progY, gx+W-10, progY+6, rgba(20,10,40,200));
        if (isPlaying && duration > 0) {
            position = System.currentTimeMillis() - startTime;
            float pct2 = Math.min(1f, (float)position / duration);
            ctx.fill(gx+10, progY, gx+10+(int)((W-20)*pct2), progY+6, C_ACCENT);
            int knobX = gx+10+(int)((W-20)*pct2);
            ctx.fill(knobX-4, progY-2, knobX+4, progY+8, 0xFFFFFFFF);
            ctx.drawText(mc.textRenderer, Text.literal("§8"+fmtTime(position)+" / "+fmtTime(duration)),
                         gx+10, progY+10, C_DIM, false);
        } else {
            ctx.fill(gx+10, progY, gx+40, progY+6, rgba(60,20,100,200));
            ctx.drawText(mc.textRenderer, Text.literal("§8Стрим / прямой эфир"),
                         gx+10, progY+10, C_DIM, false);
        }

        // ── Кнопки управления ─────────────────────────────────────────────
        int btnY = gy + 158;
        int cx2 = gx + W/2;
        drawBtn(ctx, mc, "⏮", cx2-72, btnY, 30, 22, inR(mx,my,cx2-72,btnY,30,22));
        drawBtn(ctx, mc, isPaused||!isPlaying ? "▶" : "⏸", cx2-20, btnY, 40, 22,
                inR(mx,my,cx2-20,btnY,40,22), true);
        drawBtn(ctx, mc, "⏭", cx2+24, btnY, 30, 22, inR(mx,my,cx2+24,btnY,30,22));
        drawBtn(ctx, mc, "⏹", cx2-120, btnY, 30, 22, inR(mx,my,cx2-120,btnY,30,22));
        drawBtn(ctx, mc, "+", cx2+62, btnY, 24, 22, inR(mx,my,cx2+62,btnY,24,22));

        // ── Громкость ─────────────────────────────────────────────────────
        int volY = gy + 186;
        ctx.drawText(mc.textRenderer, Text.literal("§8♪ " + (int)(volume*100) + "%"),
                     gx+10, volY+2, C_DIM, false);
        int volBarX = gx+55, volBarW = W-75;
        ctx.fill(volBarX, volY, volBarX+volBarW, volY+8, rgba(20,10,40,200));
        ctx.fill(volBarX, volY, volBarX+(int)(volBarW*volume), volY+8, C_ACCENT);
        int vkX = volBarX+(int)(volBarW*volume);
        ctx.fill(vkX-4, volY-2, vkX+4, volY+10, 0xFFFFFFFF);

        // ── Плейлист ──────────────────────────────────────────────────────
        int listY = gy + 202;
        ctx.fill(gx+10, listY, gx+W-10, listY+1, C_BORDER);
        ctx.drawText(mc.textRenderer, Text.literal("§7Плейлист"),
                     gx+10, listY+4, C_DIM, false);
        ctx.drawText(mc.textRenderer, Text.literal("§8[+ Добавить]"),
                     gx+W-80, listY+4, inR(mx,my,gx+W-80,listY+4,70,12)?0xFFCCAA55:C_DIM, false);

        int itemY = listY + 18;
        for (int i = 0; i < playlist.size() && itemY < gy+H-10; i++) {
            Track tr = playlist.get(i);
            boolean cur = i == currentIndex;
            boolean hov2 = inR(mx,my, gx+10, itemY, W-20, 16);
            if (cur) ctx.fill(gx+10, itemY, gx+W-10, itemY+16, rgba(30,12,55,200));
            if (hov2 && !cur) ctx.fill(gx+10, itemY, gx+W-10, itemY+16, rgba(20,10,35,150));
            if (cur) ctx.fill(gx+10, itemY, gx+13, itemY+16, C_ACCENT);

            String trackName = tr.name.length() > 35 ? tr.name.substring(0,33)+"…" : tr.name;
            ctx.drawText(mc.textRenderer, Text.literal(cur?"§f":"§8" + trackName),
                         gx+18, itemY+4, cur?C_TEXT:C_DIM, false);

            // Редактировать
            if (hov2) {
                ctx.drawText(mc.textRenderer, Text.literal("§8✎"),
                             gx+W-22, itemY+4, C_DIM, false);
            }
            itemY += 18;
        }

        // ── Диалог редактирования URL ─────────────────────────────────────
        if (editingUrl) drawEditDialog(ctx, mc, gx, gy);
    }

    private void drawEditDialog(DrawContext ctx, MinecraftClient mc, int gx, int gy) {
        int dw = 400, dh = editingName ? 120 : 90;
        int dx = gx + (W-dw)/2, dy = gy + (H-dh)/2;
        ctx.fill(dx-2, dy-2, dx+dw+2, dy+dh+2, C_ACCENT);
        ctx.fill(dx, dy, dx+dw, dy+dh, rgba(8,4,18,252));
        ctx.drawText(mc.textRenderer, Text.literal("§fВставь URL трека или стрима:"),
                     dx+8, dy+8, C_TEXT, true);
        // URL поле
        ctx.fill(dx+6, dy+22, dx+dw-6, dy+40, rgba(20,10,40,220));
        ctx.fill(dx+6, dy+22, dx+dw-6, dy+23, C_ACCENT);
        String disp = editBuffer.length() > 50 ? "…"+editBuffer.substring(editBuffer.length()-48) : editBuffer;
        ctx.drawText(mc.textRenderer, Text.literal("§7" + disp +
                     ((System.currentTimeMillis()/500)%2==0?"|":"")),
                     dx+10, dy+28, 0xFFDDDDFF, false);
        if (editingName) {
            ctx.drawText(mc.textRenderer, Text.literal("§7Название:"), dx+8, dy+46, C_DIM, false);
            ctx.fill(dx+6, dy+56, dx+dw-6, dy+74, rgba(20,10,40,220));
            ctx.fill(dx+6, dy+56, dx+dw-6, dy+57, C_BORDER);
            ctx.drawText(mc.textRenderer, Text.literal("§7" + nameBuffer +
                         (!editingName||((System.currentTimeMillis()/500)%2==0)?"":"│")),
                         dx+10, dy+62, 0xFFDDDDFF, false);
        }
        drawBtn(ctx, mc, "§aОК", dx+dw-70, dy+dh-20, 30, 14, false);
        drawBtn(ctx, mc, "§cОтмена", dx+dw-34, dy+dh-20, 28, 14, false);
    }

    // ── INPUT ─────────────────────────────────────────────────────────────
    @Override
    public boolean mouseClicked(double mx2, double my2, int btn) {
        int mx = (int)mx2, my = (int)my2;
        int gx = (width-W)/2, gy = (height-H)/2;
        int cx2 = gx + W/2;

        // Закрыть
        if (inR(mx,my, gx+W-22, gy+9, 14, 14)) {
            MinecraftClient.getInstance().setScreen(parent); return true;
        }

        // Диалог URL
        if (editingUrl) {
            int dw=400,dh=editingName?120:90,dx=gx+(W-dw)/2,dy=gy+(H-dh)/2;
            if (inR(mx,my, dx+dw-70, dy+dh-20, 30, 14)) { saveEdit(); return true; }
            if (inR(mx,my, dx+dw-34, dy+dh-20, 28, 14)) { editingUrl=false; return true; }
            // Переключить на name
            if (editingName && inR(mx,my, dx+6,dy+56,dw-12,18)) { editingName=false; return true; }
            if (!editingName && inR(mx,my, dx+6,dy+22,dw-12,18)) { editingName=true; return true; }
            return true;
        }

        // Кнопки управления
        int btnY = gy + 158;
        if (inR(mx,my, cx2-72, btnY, 30, 22)) { prevTrack(); return true; }
        if (inR(mx,my, cx2-20, btnY, 40, 22)) { togglePlay(); return true; }
        if (inR(mx,my, cx2+24, btnY, 30, 22)) { nextTrack(); return true; }
        if (inR(mx,my, cx2-120,btnY, 30, 22)) { stopAll(); return true; }
        if (inR(mx,my, cx2+62, btnY, 24, 22)) { showAddPrompt(); return true; }

        // Громкость
        int volY = gy+186, volBarX = gx+55, volBarW = W-75;
        if (inR(mx,my, volBarX, volY-4, volBarW, 16)) {
            volume = Math.max(0f, Math.min(1f, (mx-volBarX)/(float)volBarW));
            applyVolume(); volDragging = true; return true;
        }

        // Плейлист
        int listY = gy+202;
        if (inR(mx,my, gx+W-80, listY+4, 70, 12)) { showAddPrompt(); return true; }

        int itemY = listY+18;
        for (int i = 0; i < playlist.size(); i++) {
            if (inR(mx,my, gx+10, itemY, W-20, 16)) {
                if (inR(mx,my, gx+W-22, itemY, 12, 16)) {
                    openEditDialog(i);
                } else {
                    playTrack(i);
                }
                return true;
            }
            itemY += 18;
        }
        return super.mouseClicked(mx2, my2, btn);
    }

    @Override
    public boolean mouseDragged(double mx2, double my2, int btn, double dx, double dy) {
        int mx = (int)mx2;
        int gx = (width-W)/2, gy = (height-H)/2;
        int volBarX = gx+55, volBarW = W-75;
        if (volDragging || inR(mx,(int)my2, volBarX, gy+182, volBarW, 16)) {
            volume = Math.max(0f, Math.min(1f, (mx-volBarX)/(float)volBarW));
            applyVolume(); return true;
        }
        return super.mouseDragged(mx2, my2, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        volDragging = false; seekDragging = false;
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (editingUrl) { editingUrl = false; return true; }
            MinecraftClient.getInstance().setScreen(parent); return true;
        }
        if (editingUrl) {
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (!editingName && !editBuffer.isEmpty())
                    editBuffer = editBuffer.substring(0, editBuffer.length()-1);
                else if (editingName && !nameBuffer.isEmpty())
                    nameBuffer = nameBuffer.substring(0, nameBuffer.length()-1);
            }
            if (key == GLFW.GLFW_KEY_ENTER) saveEdit();
            if (key == GLFW.GLFW_KEY_TAB) editingName = !editingName;
            return true;
        }
        if (key == GLFW.GLFW_KEY_SPACE) { togglePlay(); return true; }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean charTyped(char c, int mods) {
        if (editingUrl) {
            if (!editingName) editBuffer += c;
            else nameBuffer += c;
            return true;
        }
        return false;
    }

    // ── AUDIO ENGINE ──────────────────────────────────────────────────────
    private void playTrack(int index) {
        if (index < 0 || index >= playlist.size()) return;
        Track tr = playlist.get(index);
        if (tr.url.isEmpty()) { openEditDialog(index); return; }
        stopAll();
        currentIndex = index;
        currentName = tr.name;
        status = "Загрузка...";
        startTime = System.currentTimeMillis();

        getExecutor().submit(() -> {
            try {
                status = "Подключение...";
                AudioInputStream rawStream = AudioSystem.getAudioInputStream(
                    new BufferedInputStream(URI.create(tr.url).toURL().openStream(), 65536)
                );
                audioStream = rawStream;
                AudioFormat base = rawStream.getFormat();
                AudioFormat decoded = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    base.getSampleRate() > 0 ? base.getSampleRate() : 44100f,
                    16, 2, 4,
                    base.getSampleRate() > 0 ? base.getSampleRate() : 44100f, false
                );
                AudioInputStream pcm = AudioSystem.getAudioInputStream(decoded, rawStream);
                DataLine.Info info2 = new DataLine.Info(Clip.class, decoded);
                Clip clip = (Clip) AudioSystem.getLine(info2);
                clip.open(pcm);
                duration = clip.getMicrosecondLength() / 1000;
                applyVolumeToClip(clip, volume);
                clip.start();
                audioClip = clip;
                isPlaying = true;
                isPaused = false;
                status = "♪ " + currentName;
            } catch (Exception e) {
                status = "Ошибка: " + e.getMessage();
                isPlaying = false;
            }
        });
    }

    private void togglePlay() {
        if (!isPlaying) {
            if (currentIndex >= 0) playTrack(currentIndex);
            else if (!playlist.isEmpty()) playTrack(0);
            return;
        }
        if (isPaused) {
            if (audioClip != null) audioClip.start();
            isPaused = false; status = "♪ " + currentName;
            startTime = System.currentTimeMillis() - position;
        } else {
            if (audioClip != null) audioClip.stop();
            isPaused = true; status = "Пауза";
        }
    }

    private void stopAll() {
        if (audioClip != null) {
            audioClip.stop(); audioClip.close(); audioClip = null;
        }
        if (audioStream != null) {
            try { audioStream.close(); } catch (Exception ignored) {}
            audioStream = null;
        }
        isPlaying = false; isPaused = false; position = 0;
        status = "Остановлено";
    }

    private static ExecutorService getExecutor() {
        if (executor == null || executor.isShutdown()) {
            executor = Executors.newSingleThreadExecutor(r -> {
                Thread t = new Thread(r, "RyuzakiMusicStream");
                t.setDaemon(true);
                return t;
            });
        }
        return executor;
    }

    public static void shutdown() {
        if (executor != null && !executor.isShutdown()) {
            executor.shutdownNow();
        }
    }

    private void nextTrack() {
        int next = (currentIndex + 1) % playlist.size();
        playTrack(next);
    }

    private void prevTrack() {
        int prev = (currentIndex - 1 + playlist.size()) % playlist.size();
        playTrack(prev);
    }

    private void applyVolume() { if (audioClip != null) applyVolumeToClip(audioClip, volume); }

    private void applyVolumeToClip(Clip clip, float vol) {
        try {
            FloatControl fc = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
            float db = vol <= 0 ? fc.getMinimum() : 20f * (float)Math.log10(vol);
            fc.setValue(Math.max(fc.getMinimum(), Math.min(fc.getMaximum(), db)));
        } catch (Exception ignored) {}
    }

    // ── Плейлист редактор ─────────────────────────────────────────────────
    private void openEditDialog(int index) {
        editingIndex = index;
        editBuffer = playlist.get(index).url;
        nameBuffer = playlist.get(index).name;
        editingUrl = true;
        editingName = false;
    }

    private void saveEdit() {
        if (editingIndex < 0) {
            playlist.add(new Track(
                nameBuffer.isEmpty() ? "Трек " + playlist.size() : nameBuffer, editBuffer));
        } else {
            Track old2 = playlist.get(editingIndex);
            playlist.set(editingIndex, new Track(
                nameBuffer.isEmpty() ? old2.name : nameBuffer, editBuffer));
        }
        editingUrl = false; editingIndex = -1;
    }

    private void showAddPrompt() {
        editingIndex = -1;
        editBuffer = ""; nameBuffer = "";
        editingUrl = true; editingName = false;
    }

    // ── Визуализатор ──────────────────────────────────────────────────────
    private void updateViz() {
        long t = System.currentTimeMillis();
        for (int i = 0; i < vizBars.length; i++) {
            if (isPlaying && !isPaused) {
                vizTargets[i] = 0.15f + 0.7f * (float)Math.abs(
                    Math.sin(t / (200.0 + i * 30.0) + i * 0.7));
            } else {
                vizTargets[i] *= 0.85f;
            }
            vizBars[i] += (vizTargets[i] - vizBars[i]) * 0.15f;
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    private void drawBtn(DrawContext ctx, MinecraftClient mc, String label,
                          int x, int y, int w, int h, boolean hov) {
        drawBtn(ctx, mc, label, x, y, w, h, hov, false);
    }

    private void drawBtn(DrawContext ctx, MinecraftClient mc, String label,
                          int x, int y, int w, int h, boolean hov, boolean accent) {
        int bg = accent ? (hov?C_ACCENT:rgba(80,20,150,220)) :
                          (hov?rgba(40,20,80,220):rgba(20,10,40,200));
        ctx.fill(x, y, x+w, y+h, bg);
        ctx.fill(x, y, x+w, y+1, accent?C_ACCENT:C_BORDER);
        int tw = mc.textRenderer.getWidth(label);
        ctx.drawText(mc.textRenderer, Text.literal("§f"+label), x+(w-tw)/2, y+(h-8)/2, C_TEXT, false);
    }

    private static String fmtTime(long ms) {
        long s = ms/1000, m2 = s/60;
        return String.format("%d:%02d", m2, s%60);
    }

    private static boolean inR(int mx,int my,int x,int y,int w,int h) {
        return mx>=x&&mx<=x+w&&my>=y&&my<=y+h;
    }
    private static int rgba(int r,int g,int b,int a) {
        return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
    private static int[] hsvToRgb(float h,float s,float v) {
        float r,g,b; if(s==0){r=g=b=v;} else {
            h*=6;int i=(int)h;float f=h-i,p=v*(1-s),q=v*(1-s*f),t=v*(1-s*(1-f));
            switch(i%6){case 0:r=v;g=t;b=p;break;case 1:r=q;g=v;b=p;break;
                case 2:r=p;g=v;b=t;break;case 3:r=p;g=q;b=v;break;
                case 4:r=t;g=p;b=v;break;default:r=v;g=p;b=q;break;}
        }
        return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};
    }

    @Override public boolean shouldPause() { return false; }

    public record Track(String name, String url) {}
}
