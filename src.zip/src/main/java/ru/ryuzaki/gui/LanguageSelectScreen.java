package ru.ryuzaki.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.lang.LanguageManager;
import ru.ryuzaki.lang.LanguageManager.Lang;

import java.util.Random;

/**
 * LanguageSelectScreen — экран выбора языка при первом запуске
 *
 * Особенности:
 *  • Сверху циклически меняются 4 фразы: "Choose a language" / "Выбери язык" /
 *    "Choisir une langue" / "Sprache wählen" — плавный fade между ними
 *  • Две карточки: 🇷🇺 Русский | 🇬🇧 English с пиксельными флагами
 *  • Выбранная карточка анимируется (zoom + glow)
 *  • Плавный вход / выход (fade + scale)
 *  • Космический анимированный фон (частицы + волны)
 */
public class LanguageSelectScreen extends Screen {

    // ─── Строки, которые циклически меняются наверху ───────────────────────
    private static final String[] CYCLE_TEXTS = {
        "Choose a language",   // EN
        "Выбери язык",         // RU
        "Choisir une langue",  // FR
        "Sprache wählen"       // DE
    };

    // ─── Время на каждую фразу (мс) ───────────────────────────────────────
    private static final long TEXT_HOLD_MS  = 1600;
    private static final long TEXT_FADE_MS  = 500;
    private static final long TEXT_CYCLE_MS = TEXT_HOLD_MS + TEXT_FADE_MS;

    // ─── Частицы фона ─────────────────────────────────────────────────────
    private static final int PN = 80;
    private final float[] px = new float[PN], py = new float[PN];
    private final float[] pvx= new float[PN], pvy= new float[PN];
    private final float[] pa = new float[PN], psz= new float[PN];

    // ─── Волны фона ───────────────────────────────────────────────────────
    private static final int WN = 6;
    private final float[] wp = new float[WN];

    // ─── Анимация экрана ──────────────────────────────────────────────────
    private float  screenAlpha  = 0f;   // fade-in
    private float  screenScale  = 0.85f;// zoom-in
    private float  exitAlpha    = 1f;   // fade-out при уходе
    private float  exitScale    = 1f;
    private boolean exiting     = false;
    private Lang    chosenLang  = null;

    // ─── Анимация карточек ────────────────────────────────────────────────
    private float  hovRU  = 0f, hovEN  = 0f;   // hover анимация
    private float  selRU  = 0f, selEN  = 0f;   // выбор анимация
    private Lang   selected= null;              // null = не выбран

    // ─── Анимация confirm кнопки ──────────────────────────────────────────
    private float  confirmAnim = 0f;
    private float  confirmHov  = 0f;

    // ─── Время ────────────────────────────────────────────────────────────
    private long lastT = 0;
    private long startT = 0;
    private long cycleStart = 0;
    private int  cycleIdx = 0;

    // ─── Callback после выбора ────────────────────────────────────────────
    private final Runnable onDone;

    public LanguageSelectScreen(Runnable onDone) {
        super(Text.literal("Language"));
        this.onDone = onDone;
    }

    @Override
    protected void init() {
        Random rnd = new Random(0xDEADBEEFL);
        for (int i = 0; i < PN; i++) {
            px[i]  = rnd.nextFloat() * 1920;
            py[i]  = rnd.nextFloat() * 1080;
            pvx[i] = (rnd.nextFloat() - 0.5f) * 0.4f;
            pvy[i] = (rnd.nextFloat() - 0.5f) * 0.4f;
            pa[i]  = 20 + rnd.nextFloat() * 90;
            psz[i] = rnd.nextInt(3);
        }
        for (int i = 0; i < WN; i++) wp[i] = i * 1.1f;
        lastT    = System.currentTimeMillis();
        startT   = lastT;
        cycleStart = lastT;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        long now = System.currentTimeMillis();
        float dt = Math.min((now - lastT) / 16f, 4f);
        lastT = now;

        // ── Анимации ────────────────────────────────────────────────────
        float sp = dt * 0.09f;
        if (!exiting) {
            screenAlpha = lerp(screenAlpha, 1f, dt * 0.07f);
            screenScale = lerp(screenScale, 1f, dt * 0.07f);
        } else {
            exitAlpha = lerp(exitAlpha, 0f, dt * 0.12f);
            exitScale = lerp(exitScale, 1.06f, dt * 0.1f);
            if (exitAlpha < 0.03f) finish();
        }

        // Карточки hover
        boolean hRU = isOverRU(mx, my);
        boolean hEN = isOverEN(mx, my);
        hovRU = lerp(hovRU, hRU ? 1f : 0f, sp * 1.5f);
        hovEN = lerp(hovEN, hEN ? 1f : 0f, sp * 1.5f);

        // Карточки select
        selRU = lerp(selRU, selected == Lang.RU ? 1f : 0f, sp * 1.2f);
        selEN = lerp(selEN, selected == Lang.EN ? 1f : 0f, sp * 1.2f);

        // Confirm кнопка
        confirmAnim = lerp(confirmAnim, selected != null ? 1f : 0f, sp * 1.2f);
        boolean hConf = isOverConfirm(mx, my);
        confirmHov  = lerp(confirmHov, hConf && selected != null ? 1f : 0f, sp * 1.5f);

        // Частицы
        for (int i = 0; i < PN; i++) {
            px[i] += pvx[i] * dt; py[i] += pvy[i] * dt;
            if (px[i] < 0) px[i] = width; if (px[i] > width) px[i] = 0;
            if (py[i] < 0) py[i] = height; if (py[i] > height) py[i] = 0;
        }
        for (int i = 0; i < WN; i++) wp[i] += dt * 0.005f;

        // Цикл текста
        long elapsed = (now - cycleStart);
        if (elapsed > TEXT_CYCLE_MS) {
            cycleIdx  = (cycleIdx + 1) % CYCLE_TEXTS.length;
            cycleStart = now;
        }

        // ── Рендер ──────────────────────────────────────────────────────
        float finalAlpha = screenAlpha * (exiting ? exitAlpha : 1f);
        int cx = width / 2, cy = height / 2;

        ctx.getMatrices().push();
        if (exiting) {
            ctx.getMatrices().translate(cx, cy, 0);
            ctx.getMatrices().scale(exitScale, exitScale, 1f);
            ctx.getMatrices().translate(-cx, -cy, 0);
        } else {
            ctx.getMatrices().translate(cx, cy, 0);
            ctx.getMatrices().scale(screenScale, screenScale, 1f);
            ctx.getMatrices().translate(-cx, -cy, 0);
        }

        drawBackground(ctx, now, finalAlpha);
        drawCycleText(ctx, now, finalAlpha, elapsed);
        drawSubtitle(ctx, now, finalAlpha);
        drawLogo(ctx, now, finalAlpha);
        drawCards(ctx, mx, my, now, finalAlpha);
        drawConfirm(ctx, mx, my, now, finalAlpha);
        drawBottomHint(ctx, now, finalAlpha);

        ctx.getMatrices().pop();

        super.render(ctx, mx, my, delta);
    }

    // =======================================================================
    //  ФОН — космический, цветовая схема под язык (пурпур→синий)
    // =======================================================================
    private void drawBackground(DrawContext ctx, long now, float a) {
        int a2 = (int)(255 * a);

        // Базовый градиент
        for (int s = 0; s < 16; s++) {
            float t = (float)s / 16f;
            int r = lerpi(4, 12, t), g = lerpi(2, 6, t), b = lerpi(18, 28, t);
            ctx.fill(0, (int)(s * height / 16f), width, (int)((s+1)*height/16f), col(r,g,b,a2));
        }

        // Волны
        for (int w = 0; w < WN; w++) {
            int wH = (int)(height * 0.3f);
            for (int seg = 0; seg < 18; seg++) {
                float xa = (float)seg/18f, xb = (float)(seg+1)/18f;
                float wA = (float)(Math.sin(xa*Math.PI*2+wp[w]) * 0.5 + 0.5);
                float wB = (float)(Math.sin(xb*Math.PI*2+wp[w]) * 0.5 + 0.5);
                int yA = (int)(height*0.58f + wA*height*0.2f + w*18);
                int yB = (int)(height*0.58f + wB*height*0.2f + w*18);
                int x0 = (int)(xa*width), x1 = (int)(xb*width);
                int yTop = Math.min(yA, yB);
                int al = (int)(14 * (WN+1-w) / (float)WN * a);
                ctx.fill(x0, yTop, x1, Math.min(height, yTop+wH), col(80,40,200,al));
            }
        }

        // Сетка
        for (int x = 0; x < width;  x += 50) ctx.fill(x, 0, x+1, height, col(80,40,200, (int)(4*a)));
        for (int y = 0; y < height; y += 50) ctx.fill(0, y, width, y+1, col(80,40,200, (int)(4*a)));

        // Частицы
        for (int i = 0; i < PN; i++) {
            int ppx = (int)px[i], ppy = (int)py[i];
            float pulse = 0.5f + 0.5f*(float)Math.sin(now*0.001f + i*0.44f);
            int pa2 = (int)(pa[i] * pulse * a);
            int sz = (int)psz[i];
            if (sz == 0) {
                ctx.fill(ppx, ppy, ppx+1, ppy+1, col(140,80,255, pa2));
            } else if (sz == 1) {
                ctx.fill(ppx-1, ppy, ppx+2, ppy+1, col(100,60,200, pa2/3));
                ctx.fill(ppx, ppy-1, ppx+1, ppy+2, col(100,60,200, pa2/3));
                ctx.fill(ppx, ppy, ppx+1, ppy+1, col(160,100,255, pa2));
            } else {
                // Крестик-звёздочка
                ctx.fill(ppx-2, ppy, ppx+3, ppy+1, col(120,70,240, pa2/2));
                ctx.fill(ppx, ppy-2, ppx+1, ppy+3, col(120,70,240, pa2/2));
                ctx.fill(ppx-1, ppy-1, ppx+2, ppy+2, col(180,120,255, pa2));
            }
        }

        // Виньетка
        int[] vS = {4,8,16,28,44}; int[] vA = {55,28,14,6,2};
        for (int i = 0; i < vS.length; i++) {
            int v = vS[i], al = (int)(vA[i]*a);
            int c = col(0,0,0,al);
            ctx.fill(0,0,width,v,c); ctx.fill(0,height-v,width,height,c);
            ctx.fill(0,v,v,height-v,c); ctx.fill(width-v,v,width,height-v,c);
        }

        // Тёмный оверлей центра (фокус на контенте)
        ctx.fill(0,0,width,height,col(0,0,0,(int)(80*a)));
    }

    // =======================================================================
    //  ЦИКЛИЧНЫЙ ТЕКСТ СВЕРХУ — 4 языка
    // =======================================================================
    private void drawCycleText(DrawContext ctx, long now, float a, long elapsed) {
        MinecraftClient mc = MinecraftClient.getInstance();

        // Текущая и следующая фраза
        String cur  = CYCLE_TEXTS[cycleIdx];
        String next = CYCLE_TEXTS[(cycleIdx + 1) % CYCLE_TEXTS.length];

        // Альфа fade между ними
        float fadeA; // 0 = полностью cur, 1 = полностью next
        if (elapsed < TEXT_HOLD_MS) {
            fadeA = 0f; // держим текущую
        } else {
            fadeA = Math.min(1f, (elapsed - TEXT_HOLD_MS) / (float)TEXT_FADE_MS);
        }

        // Плавное движение вверх при смене
        float slideY = fadeA * 6f;

        int baseY = height / 2 - 118;

        // Текущая строка — уходит вверх
        {
            int textW = mc.textRenderer.getWidth(cur);
            float curA = (1f - fadeA) * a;
            int ta = (int)(255 * curA);

            // Тень
            ctx.drawText(mc.textRenderer, Text.literal(cur),
                width/2 - textW/2 + 1, baseY - (int)slideY + 1, col(0,0,0,ta/2), false);
            // Блик под текстом
            float glowPulse = 0.5f + 0.5f*(float)Math.sin(now*0.002f);
            for (int d = 3; d >= 1; d--) {
                ctx.drawText(mc.textRenderer, Text.literal(cur),
                    width/2 - textW/2, baseY - (int)slideY,
                    col(160,100,255, (int)(ta * glowPulse * 0.35f / d)), false);
            }
            // Основной текст
            ctx.drawText(mc.textRenderer, Text.literal(cur),
                width/2 - textW/2, baseY - (int)slideY,
                col(220,190,255, ta), false);
        }

        // Следующая строка — приходит снизу
        if (fadeA > 0.01f) {
            int textW = mc.textRenderer.getWidth(next);
            float nextA = fadeA * a;
            int ta = (int)(255 * nextA);
            float enterSlide = (1f - fadeA) * 6f;

            ctx.drawText(mc.textRenderer, Text.literal(next),
                width/2 - textW/2 + 1, baseY + (int)enterSlide + 1, col(0,0,0,ta/2), false);
            ctx.drawText(mc.textRenderer, Text.literal(next),
                width/2 - textW/2, baseY + (int)enterSlide,
                col(220,190,255, ta), false);
        }

        // Декоративные линии по бокам
        int lineA = (int)(88 * a);
        int lineY = baseY + 9;
        int textW = mc.textRenderer.getWidth(cur);
        int halfText = textW / 2 + 14;
        // Левая линия
        for (int d = 0; d < 4; d++) {
            ctx.fill(width/2 - halfText - 28 + d*2, lineY, width/2 - halfText + 2, lineY+1,
                col(140,80,255, lineA * (4-d)/4));
        }
        // Правая линия
        for (int d = 0; d < 4; d++) {
            ctx.fill(width/2 + halfText - 2, lineY, width/2 + halfText + 28 - d*2, lineY+1,
                col(140,80,255, lineA * (4-d)/4));
        }
    }

    // =======================================================================
    //  ЛОГОТИП RYUZAKI
    // =======================================================================
    private void drawLogo(DrawContext ctx, long now, float a) {
        MinecraftClient mc = MinecraftClient.getInstance();
        String logo = "RYUZAKI";
        int lw = mc.textRenderer.getWidth(logo) * 2;
        int lx = width/2 - lw/2;
        int ly = height/2 - 100;

        float pulse = 0.6f + 0.4f*(float)Math.sin(now*0.0028f);
        int ta = (int)(255 * a);

        // Тень glow
        for (int d = 5; d >= 1; d--) {
            ctx.getMatrices().push();
            ctx.getMatrices().translate(width/2f, ly + 4f, 0);
            ctx.getMatrices().scale(2f, 2f, 1f);
            ctx.getMatrices().translate(-width/2f, -(ly + 4f), 0);
            ctx.drawText(mc.textRenderer, Text.literal(logo),
                width/2 - mc.textRenderer.getWidth(logo), ly,
                col(100,50,220, (int)(ta*pulse*0.18f/d)), false);
            ctx.getMatrices().pop();
        }

        // Основной текст x2
        ctx.getMatrices().push();
        ctx.getMatrices().translate(width/2f, ly + 4f, 0);
        ctx.getMatrices().scale(2f, 2f, 1f);
        ctx.getMatrices().translate(-width/2f, -(ly + 4f), 0);
        ctx.drawText(mc.textRenderer, Text.literal("§f" + logo),
            width/2 - mc.textRenderer.getWidth(logo), ly,
            col(255,255,255,ta), true);
        ctx.getMatrices().pop();
    }

    // =======================================================================
    //  ПОДЗАГОЛОВОК
    // =======================================================================
    private void drawSubtitle(DrawContext ctx, long now, float a) {
        MinecraftClient mc = MinecraftClient.getInstance();
        String sub = "Visual Mod  ·  v1.0";
        int sw = mc.textRenderer.getWidth(sub);
        int sy = height/2 - 78;
        float drift = (float)Math.sin(now*0.0012f) * 0.8f;
        int ta = (int)(150 * a);
        ctx.drawText(mc.textRenderer, Text.literal(sub),
            width/2 - sw/2, sy + (int)drift, col(130,100,200,ta), false);
        // Линия под
        ctx.fill(width/2-50, sy+11, width/2+50, sy+12, col(100,60,200,(int)(40*a)));
    }

    // =======================================================================
    //  КАРТОЧКИ ЯЗЫКОВ
    // =======================================================================
    // Размеры карточек
    private static final int CARD_W = 130, CARD_H = 155;
    private static final int CARD_GAP = 22;

    private int cardRUX() { return width/2 - CARD_GAP/2 - CARD_W; }
    private int cardENX() { return width/2 + CARD_GAP/2; }
    private int cardY()   { return height/2 - 28; }

    private boolean isOverRU(int mx, int my) {
        return inR(mx, my, cardRUX(), cardY(), CARD_W, CARD_H);
    }
    private boolean isOverEN(int mx, int my) {
        return inR(mx, my, cardENX(), cardY(), CARD_W, CARD_H);
    }

    private void drawCards(DrawContext ctx, int mx, int my, long now, float a) {
        drawCard(ctx, cardRUX(), cardY(), Lang.RU, hovRU, selRU, now, a);
        drawCard(ctx, cardENX(), cardY(), Lang.EN, hovEN, selEN, now, a);
    }

    private void drawCard(DrawContext ctx, int x, int y, Lang lang,
                           float hov, float sel, long now, float a) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int ta = (int)(255 * a);

        // Поднятие при hover/select
        float lift = hov * 4f + sel * 6f;
        int ry = y - (int)lift;

        // Glow-слои снаружи
        float glowPulse = 0.5f + 0.5f*(float)Math.sin(now*0.003f + (lang==Lang.RU?0:3.14f));
        float glowA = sel * glowPulse + hov * 0.4f;
        if (glowA > 0.01f) {
            for (int d = 8; d >= 1; d--) {
                fillR(ctx, x-d, ry-d, x+CARD_W+d, ry+CARD_H+d,
                    col(120,60,255, (int)(ta * glowA * 0.12f / d)), 10+d);
            }
        }

        // Тень карточки
        fillR(ctx, x+4, ry+4, x+CARD_W+4, ry+CARD_H+4, col(0,0,0,(int)(80*a)), 10);

        // Фон карточки
        int bgA = (int)((sel>0.5f ? 45 : hov>0.5f ? 30 : 20) * a);
        fillR(ctx, x, ry, x+CARD_W, ry+CARD_H, col(16,10,36,bgA + (int)(ta*0.6f)), 10);

        // Highlight верхней грани
        ctx.fill(x+10, ry+1, x+CARD_W-10, ry+2, col(255,255,255,(int)(20*a)));

        // Рамка
        float borderPulse = sel>0.5f ? glowPulse : 1f;
        int borderA = sel>0.5f ? (int)(ta*0.8f*borderPulse) : hov>0.5f ? (int)(ta*0.5f) : (int)(ta*0.2f);
        int[] bc = getCardColor(lang, sel, hov);
        borderR(ctx, x, ry, x+CARD_W, ry+CARD_H,
            col(bc[0],bc[1],bc[2],borderA), sel>0.5f ? 2 : 1, 10);

        // Флаг
        drawFlag(ctx, x + CARD_W/2 - 28, ry + 16, lang, (int)(ta));

        // Название языка
        String langName = lang == Lang.RU ? "Русский" : "English";
        int lw = mc.textRenderer.getWidth(langName);
        int nameColor = sel > 0.5f
            ? col(bc[0],bc[1],bc[2],ta)
            : hov > 0.5f
                ? col(220,200,255,ta)
                : col(160,140,210,ta);
        ctx.drawText(mc.textRenderer, Text.literal(langName),
            x + CARD_W/2 - lw/2, ry + 78, nameColor, false);

        // Нативное название
        String nativeName = lang == Lang.RU ? "Russian" : "Английский";
        int nw = mc.textRenderer.getWidth(nativeName);
        ctx.drawText(mc.textRenderer, Text.literal(nativeName),
            x + CARD_W/2 - nw/2, ry + 91, col(100,80,160,ta/2), false);

        // Страна
        String country = lang == Lang.RU ? "Россия" : "United Kingdom";
        int cw = mc.textRenderer.getWidth(country);
        ctx.drawText(mc.textRenderer, Text.literal(country),
            x + CARD_W/2 - cw/2, ry + 104, col(80,60,140,(int)(ta*0.55f)), false);

        // ✓ чекбокс
        if (sel > 0.01f) {
            int ckX = x + CARD_W/2 - 8;
            int ckY = ry + CARD_H - 26;
            float ckA = sel;
            // Кружок
            fillR(ctx, ckX, ckY, ckX+16, ckY+16,
                col(bc[0],bc[1],bc[2],(int)(ta*ckA)), 8);
            borderR(ctx, ckX, ckY, ckX+16, ckY+16,
                col(255,255,255,(int)(ta*ckA*0.8f)), 1, 8);
            // Галочка
            ctx.drawText(mc.textRenderer, Text.literal("§f✔"),
                ckX+3, ckY+4, col(255,255,255,(int)(ta*ckA)), false);
        }
    }

    /** Цвет акцента карточки */
    private int[] getCardColor(Lang lang, float sel, float hov) {
        if (lang == Lang.RU) {
            // Красный/синий для России
            return sel > 0.5f
                ? new int[]{200, 60, 80}
                : hov > 0.5f
                    ? new int[]{200, 80, 100}
                    : new int[]{140, 60, 80};
        } else {
            // Синий/красный для UK
            return sel > 0.5f
                ? new int[]{60, 100, 220}
                : hov > 0.5f
                    ? new int[]{80, 120, 220}
                    : new int[]{60, 80, 160};
        }
    }

    // =======================================================================
    //  ПИКСЕЛЬНЫЕ ФЛАГИ
    // =======================================================================
    private void drawFlag(DrawContext ctx, int x, int y, Lang lang, int alpha) {
        if (lang == Lang.RU) drawFlagRU(ctx, x, y, alpha);
        else                  drawFlagGB(ctx, x, y, alpha);
    }

    /**
     * Флаг России 56×38 пикселей
     * Белый / Синий / Красный полосы
     */
    private void drawFlagRU(DrawContext ctx, int x, int y, int alpha) {
        int W = 56, H = 38, r = 3;
        int h3 = H / 3;

        // Тень
        fillR(ctx, x+2, y+2, x+W+2, y+H+2, col(0,0,0,alpha/3), r);

        // Белая полоса
        fillR(ctx, x, y, x+W, y+h3, col(240,240,248,alpha), r);
        // Синяя полоса
        ctx.fill(x, y+h3, x+W, y+h3*2, col(0,57,166,alpha));
        // Красная полоса
        fillR(ctx, x, y+h3*2, x+W, y+H, col(213,43,30,alpha), r);

        // Рамка
        borderR(ctx, x, y, x+W, y+H, col(255,255,255,alpha/3), 1, r);
        // Highlight
        ctx.fill(x+3, y+1, x+W-3, y+2, col(255,255,255,alpha/5));
    }

    /**
     * Флаг Великобритании 56×38 пикселей — упрощённый Union Jack
     * Синий фон + красный крест + белые диагонали
     */
    private void drawFlagGB(DrawContext ctx, int x, int y, int alpha) {
        int W = 56, H = 38, r = 3;

        // Тень
        fillR(ctx, x+2, y+2, x+W+2, y+H+2, col(0,0,0,alpha/3), r);

        // Синий фон
        fillR(ctx, x, y, x+W, y+H, col(0,36,125,alpha), r);

        // Диагональные белые полосы (Андреевский крест)
        drawDiagonal(ctx, x, y, x+W, y+H, 4, col(255,255,255,alpha));

        // Диагональные красные полосы (тонкие)
        drawDiagonal(ctx, x, y, x+W, y+H, 2, col(200,16,46,alpha));

        // Белый прямой крест (более жирный)
        int cx2 = x + W/2, cy2 = y + H/2;
        ctx.fill(cx2-4, y, cx2+4, y+H, col(255,255,255,alpha)); // вертикаль
        ctx.fill(x, cy2-3, x+W, cy2+3, col(255,255,255,alpha)); // горизонталь

        // Красный прямой крест
        ctx.fill(cx2-2, y, cx2+2, y+H, col(200,16,46,alpha));
        ctx.fill(x, cy2-1, x+W, cy2+2, col(200,16,46,alpha));

        // Рамка
        borderR(ctx, x, y, x+W, y+H, col(255,255,255,alpha/3), 1, r);
        // Highlight
        ctx.fill(x+3, y+1, x+W-3, y+2, col(255,255,255,alpha/5));
    }

    /** Рисует X-диагонали на флаге */
    private void drawDiagonal(DrawContext ctx, int x1, int y1, int x2, int y2,
                               int thickness, int color) {
        int W = x2-x1, H = y2-y1;
        for (int px = 0; px < W; px++) {
            // Главная диагональ ↘
            int py1 = (int)((float)px / W * H);
            for (int t = -thickness/2; t <= thickness/2; t++) {
                int pp = py1 + t;
                if (pp >= 0 && pp < H) ctx.fill(x1+px, y1+pp, x1+px+1, y1+pp+1, color);
            }
            // Антидиагональ ↗
            int py2 = H - 1 - py1;
            for (int t = -thickness/2; t <= thickness/2; t++) {
                int pp = py2 + t;
                if (pp >= 0 && pp < H) ctx.fill(x1+px, y1+pp, x1+px+1, y1+pp+1, color);
            }
        }
    }

    // =======================================================================
    //  КНОПКА CONTINUE
    // =======================================================================
    private int confirmX() { return width/2 - 70; }
    private int confirmY() { return cardY() + CARD_H + 22; }
    private boolean isOverConfirm(int mx, int my) {
        return inR(mx, my, confirmX(), confirmY(), 140, 26);
    }

    private void drawConfirm(DrawContext ctx, int mx, int my, long now, float a) {
        if (confirmAnim < 0.02f) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        int bx = confirmX(), by = confirmY();
        int bw = 140, bh = 26;
        float ca = confirmAnim * a;
        int ta = (int)(255 * ca);

        // Язык для надписи
        String label = selected == Lang.RU ? "Продолжить" : "Continue";
        if (selected == null) label = "Continue";

        // Glow
        float pulse = 0.65f + 0.35f*(float)Math.sin(now*0.004f);
        float hov = confirmHov;
        for (int d = 4; d >= 1; d--) {
            fillR(ctx, bx-d, by-d, bx+bw+d, by+bh+d,
                col(120,60,255,(int)(ta*pulse*(hov*0.5f+0.3f)*0.18f/d)), 13+d);
        }

        // Фон
        int bgR = lerpi(20,70, (float)Math.sin(now*0.002f)*0.5f+0.5f);
        fillR(ctx, bx, by, bx+bw, by+bh,
            col(lerpi(18,40,hov),lerpi(10,25,hov),lerpi(50,80,hov),(int)(230*ca)), 13);

        // Highlight
        ctx.fill(bx+6, by+1, bx+bw-6, by+2, col(255,255,255,(int)(30*ca)));

        // Рамка
        borderR(ctx, bx, by, bx+bw, by+bh,
            hov > 0.5f ? col(180,120,255,ta) : col(120,70,220,(int)(ta*0.6f)), 1, 13);

        // Текст
        int lw = mc.textRenderer.getWidth(label);
        // Тень
        ctx.drawText(mc.textRenderer, Text.literal(label),
            bx+bw/2-lw/2+1, by+bh/2-4+1, col(0,0,0,(int)(ta*0.4f)), false);
        // Основной
        ctx.drawText(mc.textRenderer, Text.literal(label),
            bx+bw/2-lw/2, by+bh/2-4,
            hov > 0.5f ? col(255,220,255,ta) : col(200,170,255,ta), false);
    }

    // =======================================================================
    //  ПОДСКАЗКА ВНИЗУ
    // =======================================================================
    private void drawBottomHint(DrawContext ctx, long now, float a) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float drift = (float)Math.sin(now*0.0009f) * 1.5f;
        String hint = "Click to select  ·  Click again to confirm";
        int hw = mc.textRenderer.getWidth(hint);
        ctx.drawText(mc.textRenderer, Text.literal(hint),
            width/2 - hw/2, height - 20 + (int)drift,
            col(80,60,130,(int)(80*a)), false);
    }

    // =======================================================================
    //  INPUT
    // =======================================================================
    @Override
    public boolean mouseClicked(double mdx, double mdy, int button) {
        if (button != 0 || exiting) return false;
        int mx = (int)mdx, my = (int)mdy;

        // Клик по карточке RU
        if (isOverRU(mx, my)) {
            if (selected == Lang.RU) {
                // Второй клик = подтверждение
                startExit(Lang.RU);
            } else {
                selected = Lang.RU;
            }
            return true;
        }

        // Клик по карточке EN
        if (isOverEN(mx, my)) {
            if (selected == Lang.EN) {
                startExit(Lang.EN);
            } else {
                selected = Lang.EN;
            }
            return true;
        }

        // Клик по кнопке Confirm
        if (selected != null && isOverConfirm(mx, my)) {
            startExit(selected);
            return true;
        }

        return false;
    }

    @Override
    public boolean keyPressed(int key, int sc, int mod) {
        // ESC — нельзя закрыть экран выбора языка (первый запуск обязательный)
        if (key == GLFW.GLFW_KEY_ESCAPE) return true;
        // Enter = подтвердить текущий выбор
        if (key == GLFW.GLFW_KEY_ENTER && selected != null && !exiting) {
            startExit(selected);
            return true;
        }
        return false;
    }

    private void startExit(Lang lang) {
        chosenLang = lang;
        exiting    = true;
    }

    private void finish() {
        if (chosenLang != null) {
            LanguageManager.setLanguage(chosenLang);
        }
        MinecraftClient.getInstance().setScreen(null);
        if (onDone != null) onDone.run();
    }

    @Override
    public boolean shouldPause()            { return false; }
    @Override
    public boolean shouldCloseOnEsc()       { return false; }

    // =======================================================================
    //  УТИЛИТЫ
    // =======================================================================
    private static int col(int r, int g, int b, int a) {
        return ((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
    private static int lerpi(int a, int b, float t) {
        return (int)(a + (b-a)*Math.max(0,Math.min(1,t)));
    }
    private static float lerp(float a, float b, float t) { return a+(b-a)*t; }
    private static boolean inR(int x, int y, int rx, int ry, int rw, int rh) {
        return x>=rx && x<=rx+rw && y>=ry && y<=ry+rh;
    }

    private void fillR(DrawContext ctx, int x, int y, int x2, int y2, int c, int r) {
        if (x2<=x||y2<=y) return;
        r = Math.min(r, Math.min((x2-x)/2,(y2-y)/2));
        if (r<=0) { ctx.fill(x,y,x2,y2,c); return; }
        ctx.fill(x+r,y,x2-r,y2,c);
        ctx.fill(x,y+r,x+r,y2-r,c);
        ctx.fill(x2-r,y+r,x2,y2-r,c);
        for (int i=0;i<r;i++) {
            int w=r-(int)Math.sqrt(Math.max(0.0,(double)r*r-(double)(r-1-i)*(r-1-i)));
            ctx.fill(x+w,y+i,x+r,y+i+1,c); ctx.fill(x2-r,y+i,x2-w,y+i+1,c);
            ctx.fill(x+w,y2-i-1,x+r,y2-i,c); ctx.fill(x2-r,y2-i-1,x2-w,y2-i,c);
        }
    }

    private void borderR(DrawContext ctx, int x, int y, int x2, int y2, int c, int t, int r) {
        if (x2<=x||y2<=y) return;
        r = Math.min(r, Math.min((x2-x)/2,(y2-y)/2));
        ctx.fill(x+r,y,x2-r,y+t,c); ctx.fill(x+r,y2-t,x2-r,y2,c);
        ctx.fill(x,y+r,x+t,y2-r,c); ctx.fill(x2-t,y+r,x2,y2-r,c);
        for (int i=0;i<r;i++) {
            int w=r-(int)Math.sqrt(Math.max(0.0,(double)r*r-(double)(r-1-i)*(r-1-i)));
            ctx.fill(x+w,y+i,x+w+t,y+i+1,c); ctx.fill(x2-w-t,y+i,x2-w,y+i+1,c);
            ctx.fill(x+w,y2-i-1,x+w+t,y2-i,c); ctx.fill(x2-w-t,y2-i-1,x2-w,y2-i,c);
        }
    }
}
