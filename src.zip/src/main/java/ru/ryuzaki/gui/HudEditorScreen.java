package ru.ryuzaki.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.hud.HudManager;

public class HudEditorScreen extends Screen {

    private HudElement popupTarget = null;
    private int        popupX, popupY;
    private static final int POP_W = 180;
    private static final int POP_H = 90;
    private boolean draggingSize  = false;
    private boolean draggingScale = false;

    public HudEditorScreen() { super(Text.literal("HUD Editor")); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        MinecraftClient mc = MinecraftClient.getInstance();

        for (HudElement el : HudManager.getInstance().getElements()) {
            if (!el.enabled) continue;
            boolean applyScale = el.scale != 1.0f || el.size != 60;
            if (applyScale) {
                ctx.getMatrices().push();
                float factor = (el.size / 60f) * el.scale;
                float ox = el.dragging.getX() + el.dragging.getWidth()  / 2f;
                float oy = el.dragging.getY() + el.dragging.getHeight() / 2f;
                ctx.getMatrices().translate(ox, oy, 0);
                ctx.getMatrices().scale(factor, factor, 1f);
                ctx.getMatrices().translate(-ox, -oy, 0);
                el.renderEditor(ctx, mc, mx, my);
                ctx.getMatrices().pop();
            } else {
                el.renderEditor(ctx, mc, mx, my);
            }
        }

        int panelY = height - 30;
        ctx.fill(0, panelY, width, height, 0xDD0A0A14);
        ctx.fill(0, panelY, width, panelY + 1, 0x44AA55FF);
        boolean bgHov = inRect(mx, my, 8, panelY + 5, 114, 20);
        ctx.fill(8, panelY + 5, 122, panelY + 25,
                HudElement.showBackground
                        ? (bgHov ? 0xDD6633CC : 0xDD441188)
                        : (bgHov ? 0xDD333344 : 0xDD1A1A2A));
        ctx.drawText(mc.textRenderer, Text.literal("BG: " + (HudElement.showBackground ? "ON" : "OFF")), 15, panelY + 10, 0xFFFFFFFF, true);
        String hint = "Right Alt - close  |  RMB - size/scale";
        int hw = mc.textRenderer.getWidth(hint);
        ctx.drawText(mc.textRenderer, Text.literal(hint), width / 2 - hw / 2, panelY + 11, 0xFFAAAAAA, false);

        if (popupTarget != null) renderPopup(ctx, mc, mx, my);
        // Убран super.render() — он стирает кастомный рендер
    }

    private void renderPopup(DrawContext ctx, MinecraftClient mc, int mx, int my) {
        if (draggingSize) {
            int tX = popupX + 8, tW = POP_W - 16;
            float pct = Math.max(0f, Math.min(1f, (float)(mx - tX) / tW));
            popupTarget.size = Math.round(pct * 100);
        }
        if (draggingScale) {
            int tX = popupX + 8, tW = POP_W - 16;
            float pct = Math.max(0f, Math.min(1f, (float)(mx - tX) / tW));
            popupTarget.scale = Math.round((0.5f + pct * 1.5f) * 10f) / 10f;
        }
        ctx.fill(popupX - 1, popupY - 1, popupX + POP_W + 1, popupY + POP_H + 1, 0xFF9955FF);
        ctx.fill(popupX, popupY, popupX + POP_W, popupY + POP_H, 0xFF0E0B1C);

        ctx.drawText(mc.textRenderer, Text.literal("Size: " + popupTarget.size + "%"), popupX + 8, popupY + 6, 0xFF55AADD, true);
        int tX = popupX + 8, tY1 = popupY + 18, tW = POP_W - 16;
        ctx.fill(tX, tY1, tX + tW, tY1 + 5, 0xFF2A2040);
        ctx.fill(tX, tY1, tX + (int)(tW * popupTarget.size / 100f), tY1 + 5, 0xFF55AADD);
        ctx.fill(tX + (int)(tW * popupTarget.size / 100f) - 3, tY1 - 2, tX + (int)(tW * popupTarget.size / 100f) + 3, tY1 + 7, 0xFF88CCFF);

        ctx.drawText(mc.textRenderer, Text.literal("Scale: " + String.format("%.1fx", popupTarget.scale)), popupX + 8, popupY + 30, 0xFFAA55FF, true);
        int tY2 = popupY + 42;
        ctx.fill(tX, tY2, tX + tW, tY2 + 5, 0xFF2A2040);
        float scPct = (popupTarget.scale - 0.5f) / 1.5f;
        ctx.fill(tX, tY2, tX + (int)(tW * scPct), tY2 + 5, 0xFFAA55FF);
        ctx.fill(tX + (int)(tW * scPct) - 3, tY2 - 2, tX + (int)(tW * scPct) + 3, tY2 + 7, 0xFFDD88FF);

        String[] labels = {"0.5x", "1.0x", "1.5x", "2.0x"};
        float[] vals    = {0.5f,   1.0f,   1.5f,   2.0f};
        int btnW = (POP_W - 16) / 4 - 2;
        for (int i = 0; i < labels.length; i++) {
            int bx = popupX + 8 + i * (btnW + 2), by = popupY + 56;
            boolean hov = inRect(mx, my, bx, by, btnW, 14);
            boolean sel = Math.abs(popupTarget.scale - vals[i]) < 0.05f;
            ctx.fill(bx, by, bx + btnW, by + 14, sel ? 0xFF6622AA : (hov ? 0xFF7733CC : 0xFF221A33));
            int tw = mc.textRenderer.getWidth(labels[i]);
            ctx.drawText(mc.textRenderer, Text.literal(labels[i]), bx + (btnW - tw) / 2, by + 3, sel ? 0xFFFFFFFF : 0xFFDDAAFF, false);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        int panelY = height - 30;
        if (popupTarget != null) {
            int tX = popupX + 8, tW = POP_W - 16;
            if (btn == 0 && inRect((int)mx, (int)my, tX, popupY + 13, tW, 15)) { draggingSize = true; return true; }
            if (btn == 0 && inRect((int)mx, (int)my, tX, popupY + 37, tW, 15)) { draggingScale = true; return true; }
            float[] vals = {0.5f, 1.0f, 1.5f, 2.0f};
            int btnW = (POP_W - 16) / 4 - 2;
            for (int i = 0; i < vals.length; i++) {
                int bx = popupX + 8 + i * (btnW + 2), by = popupY + 56;
                if (btn == 0 && inRect((int)mx, (int)my, bx, by, btnW, 14)) { popupTarget.scale = vals[i]; return true; }
            }
            if (!inRect((int)mx, (int)my, popupX, popupY, POP_W, POP_H)) { popupTarget = null; draggingSize = false; draggingScale = false; }
            return true;
        }
        if (btn == 0 && inRect((int)mx, (int)my, 8, panelY + 5, 114, 20)) { HudElement.showBackground = !HudElement.showBackground; return true; }
        if (btn == 1) {
            for (HudElement el : HudManager.getInstance().getElements()) {
                if (el.enabled && isHovered(el, (int)mx, (int)my)) {
                    popupTarget = el;
                    popupX = Math.min((int)mx + 4, width  - POP_W - 4);
                    popupY = Math.min((int)my + 4, height - POP_H - 34);
                    return true;
                }
            }
        }
        if (btn == 0) for (HudElement el : HudManager.getInstance().getElements()) el.onMouseClick((int)mx, (int)my, btn);
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (draggingSize || draggingScale) return true;
        for (HudElement el : HudManager.getInstance().getElements()) el.onMouseDrag((int)mx, (int)my);
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        draggingSize = false; draggingScale = false;
        for (HudElement el : HudManager.getInstance().getElements()) el.onMouseRelease(btn);
        return super.mouseReleased(mx, my, btn);
    }

    private boolean isHovered(HudElement el, int mx, int my) {
        float factor = (el.size / 60f) * el.scale;
        float w = el.getCalculatedWidth()  * factor;
        float h = el.getCalculatedHeight() * factor;
        float ex = el.dragging.getX();
        float ey = el.dragging.getY();
        return mx >= ex && mx <= ex + w && my >= ey && my <= ey + h;
    }

    private boolean inRect(int mx, int my, int x, int y, int w, int h) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    @Override public boolean shouldPause() { return false; }
}
