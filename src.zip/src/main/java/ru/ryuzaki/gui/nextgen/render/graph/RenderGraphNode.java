package ru.ryuzaki.gui.nextgen.render.graph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class RenderGraphNode {
    private final RenderPass pass;
    private final ArrayList<PassDependency> dependencies = new ArrayList<>(4);
    private boolean dirty = true;
    private boolean executedThisFrame;
    private long lastFrame = -1L;

    public RenderGraphNode(RenderPass pass) {
        if (pass == null) throw new IllegalArgumentException("pass");
        this.pass = pass;
    }

    public RenderGraphNode dependsOn(String id) {
        dependencies.add(new PassDependency(id));
        return this;
    }

    public String id() {
        return pass.id();
    }

    public RenderPass pass() {
        return pass;
    }

    public List<PassDependency> dependencies() {
        return Collections.unmodifiableList(dependencies);
    }

    public boolean dirty() {
        return dirty;
    }

    public void markDirty() {
        dirty = true;
    }

    public void clearDirty() {
        dirty = false;
    }

    public boolean executedThisFrame() {
        return executedThisFrame;
    }

    public void beginFrame() {
        executedThisFrame = false;
    }

    public void markExecuted(long frame) {
        executedThisFrame = true;
        lastFrame = frame;
        dirty = false;
    }

    public long lastFrame() {
        return lastFrame;
    }
}
