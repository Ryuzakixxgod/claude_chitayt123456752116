package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.settings.ColorSetting;
import ru.ryuzaki.util.color.ColorRGBA;

public final class UIColorPicker extends SettingControl {
    private final ColorSetting colorSetting;
    private final SpringFloat open = new SpringFloat(0.0f).response(260.0f, 28.0f);
    private boolean expanded;
    private int draggingChannel = -1;

    public UIColorPicker(ColorSetting setting) {
        super(setting);
        this.colorSetting = setting;
    }

    @Override
    public float preferredHeight() {
        return expanded ? 142.0f : 48.0f;
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        open.target(expanded ? 1.0f : 0.0f);
        open.update(dt);
        if (draggingChannel >= 0 && input.leftDown()) {
            applyChannel(draggingChannel, input.mouseX());
        }
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        renderBase(renderer, input, "");
        ColorRGBA color = colorSetting.getColor();
        int argb = color != null ? color.getRGB() : 0xFFFFFFFF;
        float sx = bounds.right() - 47.0f;
        float sy = bounds.y + 10.0f;
        renderer.glow(sx, sy, 32.0f, 18.0f, 8.0f, argb, 0.4f);
        renderer.rounded(sx, sy, 32.0f, 18.0f, 8.0f, argb);
        renderer.reflection(sx, sy, 32.0f, 18.0f, 8.0f, 0.22f + hover.get() * 0.12f, open.get());
        renderer.outline(sx, sy, 32.0f, 18.0f, 8.0f, renderer.theme().border, 1.0f);
        if (open.get() > 0.02f) {
            renderChannel(renderer, "R", 0, color != null ? color.getRed() : 255);
            renderChannel(renderer, "G", 1, color != null ? color.getGreen() : 255);
            renderChannel(renderer, "B", 2, color != null ? color.getBlue() : 255);
            renderChannel(renderer, "A", 3, color != null ? color.getAlpha() : 255);
        }
    }

    private void renderChannel(UIRenderer renderer, String label, int channel, int value) {
        float baseY = bounds.y + 41.0f + channel * 22.0f;
        float a = open.get();
        float x = bounds.x + 13.0f;
        float w = bounds.w - 26.0f;
        renderer.text(label, x, baseY, 10.5f, UITheme.alpha(renderer.theme().textDim, a), true);
        float tx = x + 18.0f;
        float tw = w - 56.0f;
        renderer.rounded(tx, baseY + 3.0f, tw, 5.0f, 2.5f, UITheme.alpha(0xFF252525, a));
        renderer.lineGlow(tx, baseY + 3.0f, tw * (value / 255.0f), 5.0f, renderer.theme().accent, a * 0.18f);
        renderer.rounded(tx, baseY + 3.0f, tw * (value / 255.0f), 5.0f, 2.5f,
                UITheme.alpha(renderer.theme().accent, a));
        renderer.textRight(String.valueOf(value), bounds.right() - 13.0f, baseY, 10.5f,
                UITheme.alpha(renderer.theme().textDim, a), false);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!bounds.contains(mx, my) || button != 0) return false;
        int channel = channelAt((float) my);
        if (expanded && channel >= 0) {
            draggingChannel = channel;
            applyChannel(channel, (float) mx);
        } else {
            expanded = !expanded;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingChannel >= 0 && button == 0) {
            applyChannel(draggingChannel, (float) mx);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0 && draggingChannel >= 0) {
            draggingChannel = -1;
            return true;
        }
        return false;
    }

    private int channelAt(float mouseY) {
        for (int i = 0; i < 4; i++) {
            float y = bounds.y + 41.0f + i * 22.0f;
            if (mouseY >= y - 4.0f && mouseY <= y + 14.0f) return i;
        }
        return -1;
    }

    private void applyChannel(int channel, float mouseX) {
        float x = bounds.x + 31.0f;
        float w = bounds.w - 82.0f;
        int value = Math.max(0, Math.min(255, Math.round(((mouseX - x) / w) * 255.0f)));
        ColorRGBA c = colorSetting.getColor();
        int r = c != null ? c.getRed() : 255;
        int g = c != null ? c.getGreen() : 255;
        int b = c != null ? c.getBlue() : 255;
        int a = c != null ? c.getAlpha() : 255;
        if (channel == 0) r = value;
        if (channel == 1) g = value;
        if (channel == 2) b = value;
        if (channel == 3) a = value;
        colorSetting.setColor(new ColorRGBA(r, g, b, a));
    }
}
