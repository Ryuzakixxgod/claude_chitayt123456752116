package ru.ryuzaki.gui.nextgen.render;

public final class UIBloomRenderer {
    public void glow(UIRenderer renderer, float x, float y, float w, float h, float radius, int color, float power) {
        float p = Math.max(0.0f, Math.min(1.0f, power));
        if (p <= 0.001f) return;
        for (int i = 5; i >= 1; i--) {
            float spread = (5.0f + i * 4.0f) * p;
            float alpha = (0.040f + i * 0.018f) * p;
            renderer.roundedRaw(x - spread, y - spread, w + spread * 2.0f, h + spread * 2.0f,
                    radius + spread, UITheme.alpha(color, alpha));
        }
    }

    public void lineGlow(UIRenderer renderer, float x, float y, float w, float h, int color, float power) {
        float p = Math.max(0.0f, Math.min(1.0f, power));
        if (p <= 0.001f) return;
        for (int i = 4; i >= 1; i--) {
            float spread = i * 2.0f * p;
            renderer.roundedRaw(x - spread, y - spread, w + spread * 2.0f, h + spread * 2.0f,
                    h * 0.5f + spread, UITheme.alpha(color, (0.06f + i * 0.025f) * p));
        }
    }
}
