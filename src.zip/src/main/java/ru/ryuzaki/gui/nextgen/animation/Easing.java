package ru.ryuzaki.gui.nextgen.animation;

public final class Easing {
    private Easing() {
    }

    public static float clamp01(float value) {
        if (value < 0.0f) return 0.0f;
        if (value > 1.0f) return 1.0f;
        return value;
    }

    public static float cubicOut(float value) {
        float t = clamp01(value) - 1.0f;
        return t * t * t + 1.0f;
    }

    public static float quintOut(float value) {
        float t = clamp01(value) - 1.0f;
        return 1.0f + t * t * t * t * t;
    }

    public static float expoOut(float value) {
        float t = clamp01(value);
        return t >= 1.0f ? 1.0f : 1.0f - (float) Math.pow(2.0, -10.0f * t);
    }

    public static float smoothStep(float value) {
        float t = clamp01(value);
        return t * t * (3.0f - 2.0f * t);
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * clamp01(t);
    }

    public static float damp(float current, float target, float lambda, float dt) {
        float factor = 1.0f - (float) Math.exp(-lambda * Math.max(0.0f, dt));
        return current + (target - current) * factor;
    }
}
