package ru.ryuzaki.gui.nextgen.render;

public final class UIShadowRenderer {
    public void shadow(UIRenderer renderer, float x, float y, float w, float h, float radius, float depth) {
        float d = Math.max(0.0f, Math.min(1.0f, depth));
        if (renderer.graphShadow(x - 22.0f * d, y - 12.0f * d, w + 44.0f * d, h + 54.0f * d, 0.34f * d)) {
            renderer.roundedRaw(x + 3.0f, y + h - 3.0f, w - 6.0f, 7.0f, 3.5f,
                    UITheme.argb(Math.round(28.0f * d), 0, 0, 0));
            return;
        }
        for (int i = 6; i >= 1; i--) {
            float spread = i * (2.5f + d * 3.5f);
            float offset = i * (0.8f + d * 1.4f);
            renderer.roundedRaw(x - spread * 0.65f, y + offset - spread * 0.35f,
                    w + spread * 1.3f, h + spread, radius + spread,
                    UITheme.argb(Math.round((10 + i * 8) * d), 0, 0, 0));
        }
    }
}
