package ru.ryuzaki.gui.nextgen.layout;

public final class LayoutMetrics {
    public final Rect root = new Rect();
    public final Rect sidebar = new Rect();
    public final Rect content = new Rect();
    public final Rect search = new Rect();
    public final Rect modules = new Rect();
    public final Rect settings = new Rect();
    public float scale;
    public float gap;
    public float padding;

    public void compute(int screenWidth, int screenHeight) {
        scale = Math.max(0.86f, Math.min(1.08f, Math.min(screenWidth / 1060.0f, screenHeight / 650.0f)));
        gap = Math.round(16.0f * scale);
        padding = Math.round(20.0f * scale);

        float rootW = Math.min(screenWidth - 28.0f, 1040.0f * scale);
        float rootH = Math.min(screenHeight - 28.0f, 620.0f * scale);
        rootW = Math.max(720.0f * scale, rootW);
        rootH = Math.max(420.0f * scale, rootH);
        root.set((screenWidth - rootW) * 0.5f, (screenHeight - rootH) * 0.5f, rootW, rootH);

        float sidebarW = Math.round(136.0f * scale);
        float settingsW = Math.max(248.0f * scale, Math.min(304.0f * scale, rootW * 0.30f));
        sidebar.set(root.x, root.y, sidebarW, rootH);
        settings.set(root.right() - settingsW, root.y, settingsW, rootH);
        content.set(sidebar.right() + gap, root.y, settings.x - sidebar.right() - gap * 2.0f, rootH);
        search.set(content.x, content.y, content.w, Math.round(46.0f * scale));
        modules.set(content.x, search.bottom() + gap, content.w, rootH - search.h - gap);
    }
}
