package ru.ryuzaki.gui.nextgen.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import org.joml.Matrix4f;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;

import java.awt.Color;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Map;

public final class UIRenderer {
    private static final int COLOR_CACHE_LIMIT = 256;
    private static final int TEXT_CACHE_LIMIT = 512;
    private static final int LITERAL_CACHE_LIMIT = 256;

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final UITheme theme = UITheme.RYUZAKI;
    private final UIScissorStack scissor = new UIScissorStack();
    private final UIBloomRenderer bloom = new UIBloomRenderer();
    private final UIShadowRenderer shadow = new UIShadowRenderer();
    private final ArrayDeque<Float> alphaStack = new ArrayDeque<>(8);
    private final Map<Integer, Color> colorCache = new LinkedHashMap<>(COLOR_CACHE_LIMIT, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Integer, Color> eldest) {
            return size() > COLOR_CACHE_LIMIT;
        }
    };
    private final Map<String, TextMeasureBucket> textWidthCache = new LinkedHashMap<>(TEXT_CACHE_LIMIT, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, TextMeasureBucket> eldest) {
            return size() > TEXT_CACHE_LIMIT;
        }
    };
    private final Map<String, Text> literalCache = new LinkedHashMap<>(LITERAL_CACHE_LIMIT, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Text> eldest) {
            return size() > LITERAL_CACHE_LIMIT;
        }
    };

    private DrawContext context;
    private float alpha = 1.0f;
    private float localAlpha = 1.0f;

    public void begin(DrawContext context, float alpha) {
        this.context = context;
        this.alpha = Math.max(0.0f, Math.min(1.0f, alpha));
        this.localAlpha = 1.0f;
        this.alphaStack.clear();
    }

    public void end() {
        if (context != null) scissor.clear(context);
        context = null;
    }

    public UITheme theme() {
        return theme;
    }

    public void pushAlpha(float alpha) {
        alphaStack.push(localAlpha);
        localAlpha *= Math.max(0.0f, Math.min(1.0f, alpha));
    }

    public void popAlpha() {
        if (!alphaStack.isEmpty()) localAlpha = alphaStack.pop();
    }

    public void fullscreenAtmosphere(int width, int height, float time) {
        fill(0, 0, width, height, UITheme.alpha(theme.background, 0.80f));
        gradient(0, 0, width, height, UITheme.alpha(0xFF070707, 0.78f), UITheme.alpha(0xFF020202, 0.96f), 0.0f);
        float pulse = (float) Math.sin(time * 0.7f) * 0.5f + 0.5f;
        roundedRaw(width * -0.08f, height * 0.10f, width * 0.58f, height * 0.80f, height * 0.18f,
                UITheme.alpha(UITheme.argb(Math.round(12 + pulse * 7), 80, 6, 8), effectiveAlpha()));
        roundedRaw(width * 0.55f, height * -0.12f, width * 0.58f, height * 0.72f, height * 0.16f,
                UITheme.alpha(UITheme.argb(Math.round(10 + pulse * 5), 255, 48, 48), effectiveAlpha()));
        renderVignette(width, height);
        renderGrain(width, height, time);
    }

    public void glassPanel(float x, float y, float w, float h, float radius, float blurAlpha, float glowPower) {
        shadow.shadow(this, x, y, w, h, radius, 0.72f);
        if (UIRenderGraph.getInstance().ready()) {
            UIRenderGraph.getInstance().drawBlur(context.getMatrices(), Math.round(x), Math.round(y), Math.round(w), Math.round(h),
                    Math.round(blurAlpha * effectiveAlpha() * 255.0f));
        }
        bloom.glow(this, x, y, w, h, radius, theme.glow, glowPower * effectiveAlpha());
        gradient(x, y, w, h, UITheme.alpha(theme.glassTop, effectiveAlpha()), UITheme.alpha(theme.glassBottom, effectiveAlpha()), radius);
        outline(x, y, w, h, radius, UITheme.alpha(theme.border, effectiveAlpha()), 1.0f);
        roundedRaw(x + 1.0f, y + 1.0f, w - 2.0f, 1.0f, 0.5f, UITheme.alpha(0x66FFFFFF, effectiveAlpha() * 0.16f));
    }

    public void card(float x, float y, float w, float h, float radius, int top, int bottom, int border, float glow) {
        shadow.shadow(this, x, y, w, h, radius, 0.46f + glow * 0.28f);
        bloom.glow(this, x, y, w, h, radius, theme.accent, glow * 0.62f * effectiveAlpha());
        gradient(x, y, w, h, UITheme.alpha(top, effectiveAlpha()), UITheme.alpha(bottom, effectiveAlpha()), radius);
        outline(x, y, w, h, radius, UITheme.alpha(border, effectiveAlpha()), 1.0f);
        roundedRaw(x + 1.2f, y + 1.2f, w - 2.4f, 1.0f, 0.5f, UITheme.alpha(0x88FFFFFF, effectiveAlpha() * (0.045f + glow * 0.035f)));
    }

    public void material(float x, float y, float w, float h, UIMaterial material, float activation) {
        float a = Math.max(0.0f, Math.min(1.0f, activation));
        shadow.shadow(this, x, y, w, h, material.radius(), material.shadowDepth());
        if (material.blurStrength() > 0.001f && UIRenderGraph.getInstance().ready()) {
            UIRenderGraph.getInstance().drawBlur(context.getMatrices(), Math.round(x), Math.round(y), Math.round(w), Math.round(h),
                    Math.round(material.blurStrength() * effectiveAlpha() * 255.0f));
        }
        bloom.glow(this, x, y, w, h, material.radius(), material.glow(), material.glowStrength() * (0.7f + a * 0.45f) * effectiveAlpha());
        gradient(x, y, w, h, UITheme.alpha(material.backgroundTop(), effectiveAlpha()),
                UITheme.alpha(material.backgroundBottom(), effectiveAlpha()), material.radius());
        outline(x, y, w, h, material.radius(), UITheme.alpha(material.border(), effectiveAlpha()), material.emissive() ? 1.25f : 1.0f);
        if (material.emissive()) {
            roundedRaw(x + 1.5f, y + 1.5f, w - 3.0f, 1.0f, 0.5f, UITheme.alpha(material.glow(), effectiveAlpha() * 0.20f));
        }
    }

    public void materialBlend(float x, float y, float w, float h, UIMaterial from, UIMaterial to, float t, float activation) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        float a = Math.max(0.0f, Math.min(1.0f, activation));
        float radius = from.radius() + (to.radius() - from.radius()) * clamped;
        float shadowDepth = from.shadowDepth() + (to.shadowDepth() - from.shadowDepth()) * clamped;
        float blurStrength = from.blurStrength() + (to.blurStrength() - from.blurStrength()) * clamped;
        float glowStrength = from.glowStrength() + (to.glowStrength() - from.glowStrength()) * clamped;
        int top = UITheme.mix(from.backgroundTop(), to.backgroundTop(), clamped);
        int bottom = UITheme.mix(from.backgroundBottom(), to.backgroundBottom(), clamped);
        int border = UITheme.mix(from.border(), to.border(), clamped);
        int glow = UITheme.mix(from.glow(), to.glow(), clamped);
        boolean emissive = clamped >= 0.5f ? to.emissive() : from.emissive();
        shadow.shadow(this, x, y, w, h, radius, shadowDepth);
        if (blurStrength > 0.001f && UIRenderGraph.getInstance().ready()) {
            UIRenderGraph.getInstance().drawBlur(context.getMatrices(), Math.round(x), Math.round(y), Math.round(w), Math.round(h),
                    Math.round(blurStrength * effectiveAlpha() * 255.0f));
        }
        bloom.glow(this, x, y, w, h, radius, glow, glowStrength * (0.7f + a * 0.45f) * effectiveAlpha());
        gradient(x, y, w, h, UITheme.alpha(top, effectiveAlpha()), UITheme.alpha(bottom, effectiveAlpha()), radius);
        outline(x, y, w, h, radius, UITheme.alpha(border, effectiveAlpha()), emissive ? 1.25f : 1.0f);
        if (emissive) {
            roundedRaw(x + 1.5f, y + 1.5f, w - 3.0f, 1.0f, 0.5f, UITheme.alpha(glow, effectiveAlpha() * 0.20f));
        }
    }

    public void rounded(float x, float y, float w, float h, float radius, int argb) {
        roundedRaw(x, y, w, h, radius, UITheme.alpha(argb, effectiveAlpha()));
    }

    void roundedRaw(float x, float y, float w, float h, float radius, int argb) {
        if (context == null || w <= 0.0f || h <= 0.0f) return;
        DrawHelper.drawRect(context.getMatrices(), x, y, w, h, radius, color(argb));
    }

    public void gradient(float x, float y, float w, float h, int top, int bottom, float radius) {
        if (context == null || w <= 0.0f || h <= 0.0f) return;
        DrawHelper.drawRectGradient(context.getMatrices(), x, y, w, h, radius, color(top), color(bottom));
    }

    public void outline(float x, float y, float w, float h, float radius, int argb, float thickness) {
        if (context == null || w <= 0.0f || h <= 0.0f) return;
        DrawHelper.drawOutline(context.getMatrices(), x, y, w, h, radius, color(argb), thickness);
    }

    public void glow(float x, float y, float w, float h, float radius, int argb, float power) {
        bloom.glow(this, x, y, w, h, radius, argb, power * effectiveAlpha());
    }

    public void lineGlow(float x, float y, float w, float h, int argb, float power) {
        bloom.lineGlow(this, x, y, w, h, argb, power * effectiveAlpha());
    }

    public void reflection(float x, float y, float w, float h, float radius, float strength, float drift) {
        float a = Math.max(0.0f, Math.min(1.0f, strength)) * effectiveAlpha();
        if (a <= 0.001f) return;
        float bandW = Math.max(28.0f, w * 0.30f);
        float px = x + (w + bandW) * drift - bandW;
        gradient(x + 1.0f, y + 1.0f, w - 2.0f, Math.max(5.0f, h * 0.26f),
                UITheme.alpha(0x55FFFFFF, a * 0.18f),
                UITheme.alpha(0x00FFFFFF, 0.0f), Math.max(2.0f, radius - 2.0f));
        roundedRaw(px, y + 1.0f, bandW, 1.0f, 0.5f, UITheme.alpha(0xAAFFFFFF, a * 0.28f));
    }

    public void edgeGlow(float x, float y, float w, float h, float radius, int argb, float intensity) {
        float a = Math.max(0.0f, Math.min(1.0f, intensity)) * effectiveAlpha();
        if (a <= 0.001f) return;
        lineGlow(x + radius * 0.6f, y, w - radius * 1.2f, 1.0f, argb, a * 0.34f);
        lineGlow(x + radius * 0.6f, y + h - 1.0f, w - radius * 1.2f, 1.0f, argb, a * 0.24f);
        roundedRaw(x + 1.0f, y + radius * 0.8f, 1.0f, h - radius * 1.6f, 0.5f, UITheme.alpha(argb, a * 0.20f));
        roundedRaw(x + w - 2.0f, y + radius * 0.8f, 1.0f, h - radius * 1.6f, 0.5f, UITheme.alpha(argb, a * 0.16f));
    }

    public void graphGlowComposite(int screenWidth, int screenHeight, float alpha) {
        if (context != null) UIRenderGraph.getInstance().drawGlowComposite(context.getMatrices(), screenWidth, screenHeight, alpha * effectiveAlpha());
    }

    public boolean graphShadow(float x, float y, float w, float h, float alpha) {
        if (context == null) return false;
        UIRenderGraph.getInstance().drawShadow(context.getMatrices(), x, y, w, h, alpha * effectiveAlpha());
        return UIRenderGraph.getInstance().ready();
    }

    public void fill(float x, float y, float w, float h, int argb) {
        if (context == null || w <= 0.0f || h <= 0.0f) return;
        context.fill(Math.round(x), Math.round(y), Math.round(x + w), Math.round(y + h), UITheme.alpha(argb, effectiveAlpha()));
    }

    public void text(String text, float x, float y, float size, int argb, boolean bold) {
        if (context == null || text == null || text.isEmpty()) return;
        int color = UITheme.alpha(argb, effectiveAlpha());
        Matrix4f matrix = context.getMatrices().peek().getPositionMatrix();
        try {
            if (Fonts.isInitialized()) {
                DrawHelper.drawText(matrix, (bold ? Fonts.BOLD : Fonts.MEDIUM).getFont(size), text, x, y, color(color));
                return;
            }
        } catch (Throwable ignored) {
        }

        float scale = Math.max(0.65f, size / 9.0f);
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0.0f);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.drawText(mc.textRenderer, literal(text), 0, 0, color, false);
        context.getMatrices().pop();
    }

    public void textRight(String text, float right, float y, float size, int argb, boolean bold) {
        text(text, right - textWidth(text, size, bold), y, size, argb, bold);
    }

    public float textWidth(String text, float size, boolean bold) {
        if (text == null || text.isEmpty()) return 0.0f;
        TextMeasureBucket bucket = textWidthCache.get(text);
        if (bucket == null) {
            bucket = new TextMeasureBucket();
            textWidthCache.put(text, bucket);
        }
        int key = (Float.floatToIntBits(size) * 31) ^ (bold ? 0x5F3759DF : 0x45D9F3B);
        float cached = bucket.get(key);
        if (cached >= 0.0f) return cached;
        float measured;
        try {
            measured = Fonts.isInitialized() ? Fonts.getWidth(text, size, bold) : mc.textRenderer.getWidth(text) * Math.max(0.65f, size / 9.0f);
        } catch (Throwable ignored) {
            measured = mc.textRenderer.getWidth(text) * Math.max(0.65f, size / 9.0f);
        }
        bucket.put(key, measured);
        return measured;
    }

    public void pushScissor(float x, float y, float w, float h) {
        if (context != null) scissor.push(context, x, y, w, h);
    }

    public void popScissor() {
        if (context != null) scissor.pop(context);
    }

    private void renderVignette(int width, int height) {
        int steps = 18;
        for (int i = 0; i < steps; i++) {
            float p = i / (float) steps;
            int a = Math.round(10.0f + p * 8.0f);
            fill(i, i, width - i * 2.0f, 1.0f, UITheme.argb(a, 0, 0, 0));
            fill(i, height - i - 1.0f, width - i * 2.0f, 1.0f, UITheme.argb(a, 0, 0, 0));
            fill(i, i, 1.0f, height - i * 2.0f, UITheme.argb(a, 0, 0, 0));
            fill(width - i - 1.0f, i, 1.0f, height - i * 2.0f, UITheme.argb(a, 0, 0, 0));
        }
    }

    private void renderGrain(int width, int height, float time) {
        int cell = 13;
        int seed = (int) (time * 24.0f);
        for (int y = 0; y < height; y += cell) {
            for (int x = 0; x < width; x += cell) {
                int hash = x * 7349 ^ y * 9151 ^ seed * 4231;
                hash ^= hash << 13;
                hash ^= hash >>> 17;
                int a = 3 + (hash & 3);
                fill(x, y, 1.0f, 1.0f, UITheme.argb(a, 255, 255, 255));
            }
        }
    }

    private Color color(int argb) {
        Color color = colorCache.get(argb);
        if (color == null) {
            color = new Color(argb, true);
            colorCache.put(argb, color);
        }
        return color;
    }

    private Text literal(String value) {
        Text text = literalCache.get(value);
        if (text == null) {
            text = Text.literal(value);
            literalCache.put(value, text);
        }
        return text;
    }

    private float effectiveAlpha() {
        return alpha * localAlpha;
    }

    private static final class TextMeasureBucket {
        private static final int SLOTS = 8;
        private final int[] keys = new int[SLOTS];
        private final float[] values = new float[SLOTS];
        private int next;

        private TextMeasureBucket() {
            for (int i = 0; i < SLOTS; i++) values[i] = -1.0f;
        }

        float get(int key) {
            for (int i = 0; i < SLOTS; i++) {
                if (values[i] >= 0.0f && keys[i] == key) return values[i];
            }
            return -1.0f;
        }

        void put(int key, float value) {
            keys[next] = key;
            values[next] = value;
            next = (next + 1) & (SLOTS - 1);
        }
    }
}
