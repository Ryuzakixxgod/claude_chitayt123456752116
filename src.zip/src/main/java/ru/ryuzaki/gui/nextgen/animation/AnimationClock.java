package ru.ryuzaki.gui.nextgen.animation;

public final class AnimationClock {
    private long lastNanos = System.nanoTime();
    private float delta = 1.0f / 60.0f;
    private float time = 0.0f;

    public void tick(float renderDelta) {
        long now = System.nanoTime();
        float raw = (now - lastNanos) / 1_000_000_000.0f;
        lastNanos = now;
        if (raw <= 0.0f || raw > 0.1f) {
            raw = Math.max(1.0f / 120.0f, Math.min(1.0f / 30.0f, renderDelta / 20.0f));
        }
        delta = Math.max(1.0f / 240.0f, Math.min(1.0f / 20.0f, raw));
        time += delta;
    }

    public float delta() {
        return delta;
    }

    public float time() {
        return time;
    }
}
