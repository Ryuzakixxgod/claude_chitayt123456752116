package ru.ryuzaki.gui.nextgen.component;

public final class UIWindow extends UIPanel {
    public UIWindow() {
        radius(22.0f).blur(0.52f).glow(0.24f);
    }
}
