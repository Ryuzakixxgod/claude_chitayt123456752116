package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class BlurUpsamplePass implements RenderPass {
    @Override
    public String id() {
        return "blur_upsample";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        resources.blit("blur_eighth", "blur_quarter_ping", 0.25f);
        resources.blit("blur_quarter_ping", "blur_half_ping", 0.5f);
        resources.blit("blur_half_ping", "blur_full", 1.0f);
    }
}
