package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class BloomBlurPass implements RenderPass {
    @Override
    public String id() {
        return "bloom_blur";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        resources.blit("bloom_threshold", "bloom_ping", 0.25f);
        resources.blit("bloom_ping", "bloom_pong", 0.125f);
        resources.blit("bloom_pong", "bloom_ping2", 0.25f);
        resources.blit("bloom_ping2", "bloom_blur", 0.5f);
    }
}
