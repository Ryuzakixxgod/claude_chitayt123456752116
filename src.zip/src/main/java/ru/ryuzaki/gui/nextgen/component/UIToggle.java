package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.settings.BooleanSetting;

public final class UIToggle extends SettingControl {
    private final BooleanSetting booleanSetting;
    private final SpringFloat active = new SpringFloat(0.0f).response(300.0f, 30.0f);

    public UIToggle(BooleanSetting setting) {
        super(setting);
        this.booleanSetting = setting;
        active.snap(setting.isEnabled() ? 1.0f : 0.0f);
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        active.target(booleanSetting.isEnabled() ? 1.0f : 0.0f);
        active.update(dt);
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        renderBase(renderer, input, booleanSetting.isEnabled() ? "ON" : "OFF");
        float a = active.get();
        float tx = bounds.right() - 58.0f;
        float ty = bounds.y + bounds.h - 21.0f;
        float hot = Math.max(hover.get() * 0.35f, a);
        int track = UITheme.mix(0xFF252525, renderer.theme().accentDeep, a);
        renderer.glow(tx, ty, 42.0f, 16.0f, 8.0f, renderer.theme().accent, a * 0.42f + hover.get() * 0.08f);
        renderer.rounded(tx, ty, 42.0f, 16.0f, 8.0f, track);
        renderer.reflection(tx, ty, 42.0f, 16.0f, 8.0f, 0.12f + hot * 0.18f, hot);
        renderer.edgeGlow(tx, ty, 42.0f, 16.0f, 8.0f, renderer.theme().accent, a * 0.38f);
        renderer.outline(tx, ty, 42.0f, 16.0f, 8.0f, UITheme.mix(0x33FFFFFF, renderer.theme().borderHot, hot), 1.0f);
        float knob = tx + 8.0f + a * 24.0f;
        renderer.lineGlow(knob - 5.0f, ty + 3.0f, 10.0f, 10.0f, renderer.theme().accent, a * 0.55f);
        renderer.rounded(knob - 5.0f - hover.get() * 0.5f, ty + 3.0f - hover.get() * 0.35f, 10.0f + hover.get(), 10.0f + hover.get() * 0.7f, 5.0f,
                UITheme.mix(0xFFD8D8D8, 0xFFFFFFFF, a));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && bounds.contains(mx, my)) {
            booleanSetting.toggle();
            return true;
        }
        return false;
    }
}
