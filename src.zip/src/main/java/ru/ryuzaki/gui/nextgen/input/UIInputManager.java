package ru.ryuzaki.gui.nextgen.input;

import ru.ryuzaki.gui.nextgen.animation.Easing;
import ru.ryuzaki.gui.nextgen.layout.Rect;

public final class UIInputManager {
    private float mouseX;
    private float mouseY;
    private float smoothX;
    private float smoothY;
    private boolean leftDown;
    private boolean dragging;
    private boolean initialized;
    private Object capture;

    public void update(double mx, double my, float dt) {
        mouseX = (float) mx;
        mouseY = (float) my;
        if (!initialized) {
            smoothX = mouseX;
            smoothY = mouseY;
            initialized = true;
        }
        smoothX = Easing.damp(smoothX, mouseX, 30.0f, dt);
        smoothY = Easing.damp(smoothY, mouseY, 30.0f, dt);
    }

    public boolean inside(Rect rect) {
        return rect != null && rect.contains(mouseX, mouseY);
    }

    public boolean inside(float x, float y, float w, float h) {
        return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
    }

    public void press(int button, Object owner) {
        if (button == 0) {
            leftDown = true;
            capture = owner;
        }
    }

    public void release(int button) {
        if (button == 0) {
            leftDown = false;
            dragging = false;
            capture = null;
        }
    }

    public void markDragging() {
        if (leftDown) dragging = true;
    }

    public boolean isCapturedBy(Object owner) {
        return capture == owner;
    }

    public boolean leftDown() {
        return leftDown;
    }

    public boolean dragging() {
        return dragging;
    }

    public float mouseX() {
        return mouseX;
    }

    public float mouseY() {
        return mouseY;
    }

    public float smoothX() {
        return smoothX;
    }

    public float smoothY() {
        return smoothY;
    }
}
