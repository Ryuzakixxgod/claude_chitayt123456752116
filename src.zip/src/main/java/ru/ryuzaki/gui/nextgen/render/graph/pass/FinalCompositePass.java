package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class FinalCompositePass implements RenderPass {
    @Override
    public String id() {
        return "final_composite";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        resources.blit("glow_composite", "final_composite", 1.0f);
    }
}
