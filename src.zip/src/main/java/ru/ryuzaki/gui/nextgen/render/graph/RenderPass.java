package ru.ryuzaki.gui.nextgen.render.graph;

public interface RenderPass {
    String id();

    boolean alwaysDirty();

    void execute(FrameGraphResources resources, float time);
}
