package ru.ryuzaki.gui.nextgen.render.graph;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL30;

import java.util.HashMap;
import java.util.Map;

public final class FrameGraphResources {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final HashMap<String, BufferSlot> buffers = new HashMap<>(16);
    private int width;
    private int height;
    private boolean resizedThisFrame;
    private int lastBoundRead = Integer.MIN_VALUE;
    private int lastBoundDraw = Integer.MIN_VALUE;

    public void beginFrame() {
        Framebuffer main = mc.getFramebuffer();
        int nextW = Math.max(1, main.textureWidth);
        int nextH = Math.max(1, main.textureHeight);
        resizedThisFrame = nextW != width || nextH != height;
        width = nextW;
        height = nextH;
        lastBoundRead = Integer.MIN_VALUE;
        lastBoundDraw = Integer.MIN_VALUE;
    }

    public boolean resizedThisFrame() {
        return resizedThisFrame;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    public Framebuffer main() {
        return mc.getFramebuffer();
    }

    public Framebuffer buffer(String id, float scale, boolean depth) {
        int w = Math.max(1, Math.round(width * scale));
        int h = Math.max(1, Math.round(height * scale));
        BufferSlot slot = buffers.get(id);
        if (slot == null) {
            slot = new BufferSlot();
            buffers.put(id, slot);
        }
        if (slot.framebuffer == null || slot.width != w || slot.height != h || slot.depth != depth) {
            if (slot.framebuffer != null) slot.framebuffer.delete();
            slot.framebuffer = new SimpleFramebuffer(w, h, depth);
            slot.framebuffer.setClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            slot.width = w;
            slot.height = h;
            slot.depth = depth;
            slot.generation++;
        }
        slot.lastUsedFrame++;
        return slot.framebuffer;
    }

    public int texture(String id) {
        BufferSlot slot = buffers.get(id);
        return slot == null || slot.framebuffer == null ? 0 : slot.framebuffer.getColorAttachment();
    }

    public Framebuffer existing(String id) {
        BufferSlot slot = buffers.get(id);
        return slot == null ? null : slot.framebuffer;
    }

    public void captureMain(String targetId) {
        blit(main(), buffer(targetId, 1.0f, false));
    }

    public void clear(String id, float scale) {
        Framebuffer framebuffer = buffer(id, scale, false);
        int previous = GL30.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
        bindDraw(framebuffer.fbo);
        GL30.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GL30.glClear(GL30.GL_COLOR_BUFFER_BIT);
        bindFramebuffer(previous);
    }

    public void blit(String sourceId, String targetId, float targetScale) {
        Framebuffer source = existing(sourceId);
        if (source == null) return;
        blit(source, buffer(targetId, targetScale, false));
    }

    public void blit(Framebuffer source, Framebuffer target) {
        if (source == null || target == null) return;
        bindRead(source.fbo);
        bindDraw(target.fbo);
        GL30.glBlitFramebuffer(0, 0, source.textureWidth, source.textureHeight,
                0, 0, target.textureWidth, target.textureHeight,
                GL30.GL_COLOR_BUFFER_BIT, GL30.GL_LINEAR);
    }

    public void runShader(String targetId, float targetScale, FullscreenShader shader, int inputTexture,
                          float time, float threshold, float intensity) {
        Framebuffer target = buffer(targetId, targetScale, false);
        int previousFbo = GL30.glGetInteger(GL30.GL_FRAMEBUFFER_BINDING);
        int[] viewport = new int[4];
        GL30.glGetIntegerv(GL30.GL_VIEWPORT, viewport);
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, target.fbo);
        GL30.glViewport(0, 0, target.textureWidth, target.textureHeight);
        GL30.glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
        GL30.glClear(GL30.GL_COLOR_BUFFER_BIT);
        shader.draw(inputTexture, target.textureWidth, target.textureHeight, time, threshold, intensity);
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, previousFbo);
        GL30.glViewport(viewport[0], viewport[1], viewport[2], viewport[3]);
        lastBoundRead = previousFbo;
        lastBoundDraw = previousFbo;
    }

    public void drawTexture(MatrixStack matrices, int texture, float x, float y, float w, float h, float alpha) {
        if (texture == 0 || alpha <= 0.0f || w <= 0.0f || h <= 0.0f) return;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, x, y, 0.0f).texture(0.0f, 0.0f).color(1.0f, 1.0f, 1.0f, alpha);
        buffer.vertex(matrix, x, y + h, 0.0f).texture(0.0f, 1.0f).color(1.0f, 1.0f, 1.0f, alpha);
        buffer.vertex(matrix, x + w, y + h, 0.0f).texture(1.0f, 1.0f).color(1.0f, 1.0f, 1.0f, alpha);
        buffer.vertex(matrix, x + w, y, 0.0f).texture(1.0f, 0.0f).color(1.0f, 1.0f, 1.0f, alpha);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.disableBlend();
    }

    public void cleanup() {
        for (BufferSlot slot : buffers.values()) {
            if (slot.framebuffer != null) slot.framebuffer.delete();
        }
        buffers.clear();
    }

    private void bindRead(int fbo) {
        if (lastBoundRead != fbo) {
            GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, fbo);
            lastBoundRead = fbo;
        }
    }

    private void bindDraw(int fbo) {
        if (lastBoundDraw != fbo) {
            GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, fbo);
            lastBoundDraw = fbo;
        }
    }

    private void bindFramebuffer(int fbo) {
        GL30.glBindFramebuffer(GL30.GL_FRAMEBUFFER, fbo);
        lastBoundRead = fbo;
        lastBoundDraw = fbo;
    }

    private static final class BufferSlot {
        private Framebuffer framebuffer;
        private int width;
        private int height;
        private boolean depth;
        private long generation;
        private long lastUsedFrame;
    }
}
