package ru.ryuzaki.gui.nextgen.animation;

public final class KineticScroll {
    private float position;
    private float target;
    private float velocity;
    private float wheelVelocity;
    private float max;

    public void setMax(float max) {
        this.max = Math.max(0.0f, max);
        if (target > this.max) target = this.max;
        if (position > this.max) position = this.max;
    }

    public void wheel(double amount) {
        wheelVelocity -= (float) amount * 880.0f;
        wheelVelocity = clampVelocity(wheelVelocity, 2600.0f);
        velocity = velocity * 0.62f + wheelVelocity * 0.38f;
        velocity = clampVelocity(velocity, 2400.0f);
        target -= (float) amount * 58.0f;
        target = clampElastic(target);
    }

    public void drag(float dy) {
        target -= dy;
        velocity -= dy * 18.0f;
        velocity = clampVelocity(velocity, 2200.0f);
        target = clampElastic(target);
    }

    public void update(float dt) {
        float step = Math.max(0.0f, Math.min(0.05f, dt));
        target += wheelVelocity * step;
        wheelVelocity *= (float) Math.exp(-18.0f * step);
        target += velocity * step;
        velocity *= (float) Math.exp(-10.0f * step);
        if (target < 0.0f || target > max) {
            float clamped = clamp(target);
            float tension = target < 0.0f ? -target : target - max;
            target = Easing.damp(target, clamped, 14.0f + Math.min(16.0f, tension * 0.05f), step);
            velocity *= 0.38f;
            wheelVelocity *= 0.32f;
        }
        position = Easing.damp(position, target, 16.0f, step);
        if (Math.abs(position - target) < 0.01f && Math.abs(velocity) < 0.01f) {
            position = clamp(target);
            target = position;
            velocity = 0.0f;
        }
    }

    public void ensureVisible(float y, float h, float viewport) {
        if (y < position) target = y;
        else if (y + h > position + viewport) target = y + h - viewport;
        target = clamp(target);
    }

    public float get() {
        return position;
    }

    public float target() {
        return target;
    }

    public void reset() {
        position = 0.0f;
        target = 0.0f;
        velocity = 0.0f;
        wheelVelocity = 0.0f;
    }

    private float clamp(float value) {
        return Math.max(0.0f, Math.min(max, value));
    }

    private float clampElastic(float value) {
        float overscroll = 96.0f;
        return Math.max(-overscroll, Math.min(max + overscroll, value));
    }

    private float clampVelocity(float value, float limit) {
        return Math.max(-limit, Math.min(limit, value));
    }
}
