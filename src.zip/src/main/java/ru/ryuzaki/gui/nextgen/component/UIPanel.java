package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;

public class UIPanel extends UIContainer {
    private float radius = 18.0f;
    private float blur = 0.42f;
    private float glow = 0.18f;

    public UIPanel radius(float radius) {
        this.radius = radius;
        return this;
    }

    public UIPanel blur(float blur) {
        this.blur = blur;
        return this;
    }

    public UIPanel glow(float glow) {
        this.glow = glow;
        return this;
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        renderer.glassPanel(bounds.x, bounds.y, bounds.w, bounds.h, radius, blur, glow + hover.get() * 0.08f);
        super.render(renderer, input, dt);
    }
}
