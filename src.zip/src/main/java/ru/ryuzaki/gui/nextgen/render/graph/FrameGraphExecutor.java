package ru.ryuzaki.gui.nextgen.render.graph;

import java.util.LinkedHashMap;
import java.util.Map;

public final class FrameGraphExecutor {
    private final LinkedHashMap<String, RenderGraphNode> nodes = new LinkedHashMap<>();
    private long frame;

    public RenderGraphNode add(RenderPass pass) {
        RenderGraphNode node = new RenderGraphNode(pass);
        nodes.put(pass.id(), node);
        return node;
    }

    public void markDirty(String id) {
        RenderGraphNode node = nodes.get(id);
        if (node != null) node.markDirty();
    }

    public void execute(FrameGraphResources resources, float time) {
        frame++;
        for (RenderGraphNode node : nodes.values()) node.beginFrame();
        for (RenderGraphNode node : nodes.values()) executeNode(node, resources, time);
    }

    private boolean executeNode(RenderGraphNode node, FrameGraphResources resources, float time) {
        if (node.executedThisFrame()) return true;
        boolean dependencyExecuted = false;
        for (PassDependency dependency : node.dependencies()) {
            RenderGraphNode dependencyNode = nodes.get(dependency.nodeId());
            if (dependencyNode != null) {
                dependencyExecuted |= executeNode(dependencyNode, resources, time);
            }
        }
        boolean shouldRun = node.pass().alwaysDirty() || node.dirty() || dependencyExecuted || resources.resizedThisFrame();
        if (shouldRun) {
            node.pass().execute(resources, time);
            node.markExecuted(frame);
            return true;
        }
        return false;
    }

    public Map<String, RenderGraphNode> nodes() {
        return Map.copyOf(nodes);
    }
}
