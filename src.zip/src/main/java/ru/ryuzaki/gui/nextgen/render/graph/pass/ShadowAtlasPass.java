package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.GraphShaders;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class ShadowAtlasPass implements RenderPass {
    private final GraphShaders shaders;
    private boolean initialized;

    public ShadowAtlasPass(GraphShaders shaders) {
        this.shaders = shaders;
    }

    @Override
    public String id() {
        return "shadow_atlas";
    }

    @Override
    public boolean alwaysDirty() {
        return !initialized;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        resources.runShader("shadow_atlas", 0.125f, shaders.shadowAtlas(), 0, time, 0.0f, 0.92f);
        initialized = true;
    }
}
