package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class BlurDownsamplePass implements RenderPass {
    @Override
    public String id() {
        return "blur_downsample";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        resources.blit("scene", "blur_half", 0.5f);
        resources.blit("blur_half", "blur_quarter", 0.25f);
        resources.blit("blur_quarter", "blur_eighth", 0.125f);
    }
}
