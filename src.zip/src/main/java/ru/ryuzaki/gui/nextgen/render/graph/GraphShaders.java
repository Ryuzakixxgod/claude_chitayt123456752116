package ru.ryuzaki.gui.nextgen.render.graph;

public final class GraphShaders {
    private FullscreenShader bloomThreshold;
    private FullscreenShader bloomComposite;
    private FullscreenShader shadowAtlas;

    public FullscreenShader bloomThreshold() {
        if (bloomThreshold == null) {
            bloomThreshold = new FullscreenShader("""
                    #version 330 core
                    in vec2 vUv;
                    out vec4 fragColor;
                    uniform sampler2D uTexture;
                    uniform float uThreshold;
                    uniform float uIntensity;
                    void main() {
                        vec3 color = texture(uTexture, vec2(vUv.x, 1.0 - vUv.y)).rgb;
                        float luma = dot(color, vec3(0.2126, 0.7152, 0.0722));
                        float mask = smoothstep(uThreshold, 1.0, luma);
                        vec3 crimson = vec3(1.0, 0.11, 0.11);
                        fragColor = vec4(mix(color, crimson, 0.22) * mask * uIntensity, mask);
                    }
                    """);
        }
        return bloomThreshold;
    }

    public FullscreenShader bloomComposite() {
        if (bloomComposite == null) {
            bloomComposite = new FullscreenShader("""
                    #version 330 core
                    in vec2 vUv;
                    out vec4 fragColor;
                    uniform sampler2D uTexture;
                    uniform float uIntensity;
                    void main() {
                        vec3 bloom = texture(uTexture, vec2(vUv.x, 1.0 - vUv.y)).rgb;
                        fragColor = vec4(bloom * uIntensity, max(max(bloom.r, bloom.g), bloom.b));
                    }
                    """);
        }
        return bloomComposite;
    }

    public FullscreenShader shadowAtlas() {
        if (shadowAtlas == null) {
            shadowAtlas = new FullscreenShader("""
                    #version 330 core
                    in vec2 vUv;
                    out vec4 fragColor;
                    uniform float uIntensity;
                    float sdRoundRect(vec2 p, vec2 b, float r) {
                        vec2 q = abs(p) - b + vec2(r);
                        return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
                    }
                    void main() {
                        vec2 p = vUv * 2.0 - 1.0;
                        float d = sdRoundRect(p, vec2(0.48, 0.48), 0.18);
                        float outer = smoothstep(0.56, -0.08, d);
                        float inner = smoothstep(0.04, -0.04, d);
                        float alpha = max(outer - inner * 0.18, 0.0);
                        alpha *= uIntensity;
                        fragColor = vec4(0.0, 0.0, 0.0, alpha);
                    }
                    """);
        }
        return shadowAtlas;
    }

    public void cleanup() {
        if (bloomThreshold != null) bloomThreshold.close();
        if (bloomComposite != null) bloomComposite.close();
        if (shadowAtlas != null) shadowAtlas.close();
        bloomThreshold = null;
        bloomComposite = null;
        shadowAtlas = null;
    }
}
