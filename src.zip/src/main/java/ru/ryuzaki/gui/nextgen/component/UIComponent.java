package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.layout.Rect;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;

public abstract class UIComponent {
    protected final Rect bounds = new Rect();
    protected final SpringFloat hover = new SpringFloat(0.0f).response(260.0f, 28.0f);
    protected boolean visible = true;

    public void setBounds(float x, float y, float w, float h) {
        bounds.set(x, y, w, h);
    }

    public Rect bounds() {
        return bounds;
    }

    public void update(UIInputManager input, float dt) {
        hover.target(input.inside(bounds) ? 1.0f : 0.0f);
        hover.update(dt);
    }

    public abstract void render(UIRenderer renderer, UIInputManager input, float dt);

    public boolean mouseClicked(double mx, double my, int button) {
        return false;
    }

    public boolean mouseReleased(double mx, double my, int button) {
        return false;
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        return false;
    }

    public boolean mouseScrolled(double mx, double my, double amount) {
        return false;
    }

    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        return false;
    }

    public boolean charTyped(char chr, int modifiers) {
        return false;
    }

    public boolean visible() {
        return visible;
    }

    public void visible(boolean visible) {
        this.visible = visible;
    }
}
