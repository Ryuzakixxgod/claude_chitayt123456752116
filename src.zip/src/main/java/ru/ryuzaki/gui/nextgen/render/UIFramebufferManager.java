package ru.ryuzaki.gui.nextgen.render;

public final class UIFramebufferManager {
    private boolean frameCaptured;

    public void beginFrame(float time) {
        UIRenderGraph.getInstance().beginFrame(time);
        frameCaptured = UIRenderGraph.getInstance().ready();
    }

    public boolean hasBlur() {
        return frameCaptured && UIRenderGraph.getInstance().ready();
    }

    public void cleanup() {
        UIRenderGraph.getInstance().cleanup();
        frameCaptured = false;
    }
}
