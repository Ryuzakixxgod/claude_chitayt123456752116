package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.settings.NumberSetting;

import java.util.Locale;

public final class UISlider extends SettingControl {
    private final NumberSetting numberSetting;
    private final SpringFloat fill = new SpringFloat(0.0f).response(260.0f, 30.0f);
    private final SpringFloat dragFocus = new SpringFloat(0.0f).response(300.0f, 30.0f);
    private boolean dragging;
    private long formattedValueBits = Long.MIN_VALUE;
    private long formattedStepBits = Long.MIN_VALUE;
    private String formattedValue = "";

    public UISlider(NumberSetting setting) {
        super(setting);
        this.numberSetting = setting;
        fill.snap(ratio());
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        fill.target(ratio());
        fill.update(dt);
        dragFocus.target(dragging ? 1.0f : 0.0f);
        dragFocus.update(dt);
        if (dragging && input.leftDown()) {
            apply(input.mouseX());
        }
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        renderBase(renderer, input, formatted());
        float trackX = bounds.x + 13.0f;
        float trackY = bounds.y + bounds.h - 16.0f;
        float trackW = bounds.w - 26.0f;
        float progress = fill.get();
        float hot = Math.max(hover.get() * 0.45f, dragFocus.get());
        renderer.rounded(trackX, trackY, trackW, 5.0f, 2.5f, 0xFF252525);
        renderer.lineGlow(trackX, trackY, trackW * progress, 5.0f, renderer.theme().accent, 0.35f + progress * 0.25f + hot * 0.24f);
        renderer.gradient(trackX, trackY, trackW * progress, 5.0f, renderer.theme().accentDeep, renderer.theme().accent, 2.5f);
        float knobX = trackX + trackW * progress;
        renderer.glow(knobX - 5.5f, trackY - 4.5f, 11.0f, 14.0f, 7.0f, renderer.theme().accent, 0.35f + hot * 0.42f);
        renderer.rounded(knobX - 4.5f - hot, trackY - 3.0f - hot * 0.5f, 9.0f + hot * 2.0f, 11.0f + hot, 5.0f,
                UITheme.mix(0xFFD8D8D8, 0xFFFFFFFF, hot));
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && bounds.contains(mx, my)) {
            dragging = true;
            apply((float) mx);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (dragging && button == 0) {
            apply((float) mx);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (button == 0 && dragging) {
            dragging = false;
            return true;
        }
        return false;
    }

    private void apply(float mouseX) {
        float x = bounds.x + 13.0f;
        float w = bounds.w - 26.0f;
        double pct = Math.max(0.0, Math.min(1.0, (mouseX - x) / w));
        double min = numberSetting.getMin();
        double max = numberSetting.getMax();
        double value = min + (max - min) * pct;
        double step = numberSetting.getStep();
        if (step > 0.0) value = Math.round(value / step) * step;
        numberSetting.setValue(value);
    }

    private float ratio() {
        double min = numberSetting.getMin();
        double max = numberSetting.getMax();
        if (max <= min) return 0.0f;
        return (float) ((numberSetting.getValue() - min) / (max - min));
    }

    private static String format(double value, double step) {
        if (step >= 1.0) return String.valueOf(Math.round(value));
        if (step >= 0.1) return String.format(Locale.ROOT, "%.1f", value);
        return String.format(Locale.ROOT, "%.2f", value);
    }

    private String formatted() {
        long valueBits = Double.doubleToLongBits(numberSetting.getValue());
        long stepBits = Double.doubleToLongBits(numberSetting.getStep());
        if (formattedValueBits != valueBits || formattedStepBits != stepBits) {
            formattedValueBits = valueBits;
            formattedStepBits = stepBits;
            formattedValue = format(numberSetting.getValue(), numberSetting.getStep());
        }
        return formattedValue;
    }
}
