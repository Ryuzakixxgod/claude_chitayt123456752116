package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;

import java.util.ArrayList;
import java.util.List;

public class UIContainer extends UIComponent {
    protected final List<UIComponent> children = new ArrayList<>();

    public void add(UIComponent component) {
        children.add(component);
    }

    public void clear() {
        children.clear();
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        for (int i = 0; i < children.size(); i++) {
            UIComponent child = children.get(i);
            if (child.visible()) child.update(input, dt);
        }
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        for (int i = 0; i < children.size(); i++) {
            UIComponent child = children.get(i);
            if (child.visible()) child.render(renderer, input, dt);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible() && child.mouseClicked(mx, my, button)) return true;
        }
        return false;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible() && child.mouseReleased(mx, my, button)) return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible() && child.mouseDragged(mx, my, button, dx, dy)) return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible() && child.mouseScrolled(mx, my, amount)) return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible() && child.keyPressed(keyCode, scanCode, modifiers)) return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        for (int i = children.size() - 1; i >= 0; i--) {
            UIComponent child = children.get(i);
            if (child.visible() && child.charTyped(chr, modifiers)) return true;
        }
        return false;
    }
}
