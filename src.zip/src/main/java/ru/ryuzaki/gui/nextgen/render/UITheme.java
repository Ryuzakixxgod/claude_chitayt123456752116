package ru.ryuzaki.gui.nextgen.render;

public final class UITheme {
    public static final UITheme RYUZAKI = new UITheme();

    public final int background = argb(248, 4, 4, 4);
    public final int panel = argb(218, 12, 12, 12);
    public final int panelDeep = argb(238, 5, 5, 5);
    public final int panelLift = argb(188, 20, 20, 20);
    public final int card = argb(168, 14, 14, 14);
    public final int cardHot = argb(204, 20, 16, 16);
    public final int border = argb(34, 255, 255, 255);
    public final int borderHot = argb(104, 255, 64, 64);
    public final int accent = argb(255, 255, 48, 48);
    public final int accentSoft = argb(118, 255, 64, 64);
    public final int accentDeep = argb(255, 201, 31, 31);
    public final int text = argb(255, 242, 242, 242);
    public final int textSoft = argb(255, 184, 184, 184);
    public final int textDim = argb(255, 128, 128, 128);
    public final int textMuted = argb(255, 94, 94, 94);
    public final int shadow = argb(190, 0, 0, 0);
    public final int glassTop = argb(94, 22, 22, 22);
    public final int glassBottom = argb(72, 6, 6, 6);
    public final int glow = argb(36, 255, 40, 40);
    public final int glowSoft = argb(28, 255, 60, 60);

    private UITheme() {
    }

    public static int argb(int a, int r, int g, int b) {
        return ((a & 255) << 24) | ((r & 255) << 16) | ((g & 255) << 8) | (b & 255);
    }

    public static int alpha(int argb, float alpha) {
        int a = Math.max(0, Math.min(255, Math.round(((argb >>> 24) & 255) * alpha)));
        return (argb & 0x00FFFFFF) | (a << 24);
    }

    public static int mix(int a, int b, float t) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        int aa = (a >>> 24) & 255;
        int ar = (a >>> 16) & 255;
        int ag = (a >>> 8) & 255;
        int ab = a & 255;
        int ba = (b >>> 24) & 255;
        int br = (b >>> 16) & 255;
        int bg = (b >>> 8) & 255;
        int bb = b & 255;
        return argb(
                Math.round(aa + (ba - aa) * clamped),
                Math.round(ar + (br - ar) * clamped),
                Math.round(ag + (bg - ag) * clamped),
                Math.round(ab + (bb - ab) * clamped)
        );
    }
}
