package ru.ryuzaki.gui.nextgen;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.client.hud.NotificationManager;
import ru.ryuzaki.config.ConfigManager;
import ru.ryuzaki.gui.nextgen.animation.AnimationStateMachine;
import ru.ryuzaki.gui.nextgen.animation.AnimationClock;
import ru.ryuzaki.gui.nextgen.animation.Easing;
import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.animation.TransitionTimeline;
import ru.ryuzaki.gui.nextgen.component.*;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.layout.LayoutMetrics;
import ru.ryuzaki.gui.nextgen.layout.Rect;
import ru.ryuzaki.gui.nextgen.render.UIFramebufferManager;
import ru.ryuzaki.gui.nextgen.render.UIMaterial;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.settings.*;

import java.util.*;

public final class NextGenClickGuiScreen extends Screen {
    private final Screen parent;
    private final UIRenderer renderer = new UIRenderer();
    private final UIFramebufferManager framebuffers = new UIFramebufferManager();
    private final AnimationClock clock = new AnimationClock();
    private final UIInputManager input = new UIInputManager();
    private final LayoutMetrics layout = new LayoutMetrics();
    private final UISearchBar searchBar = new UISearchBar();
    private final UIScrollPanel modulesScroll = new UIScrollPanel();
    private final UIScrollPanel settingsScroll = new UIScrollPanel();
    private final UIButton saveButton = new UIButton("SAVE", () -> {
        ConfigManager.save("default");
        NotificationManager.push("Config saved", 90);
    }).accent(true);
    private final UIButton loadButton = new UIButton("LOAD", () -> {
        ConfigManager.load("default");
        NotificationManager.push("Config loaded", 90);
    });
    private final TransitionTimeline timeline = new TransitionTimeline().duration(0.52f);
    private final AnimationStateMachine<GuiLifecycle> lifecycle = new AnimationStateMachine<>(GuiLifecycle.class, GuiLifecycle.OPENING);
    private final SpringFloat open = new SpringFloat(0.0f).response(220.0f, 24.0f);
    private final SpringFloat categoryAccent = new SpringFloat(0.0f).response(260.0f, 26.0f);
    private final SpringFloat contentShift = new SpringFloat(0.0f).response(240.0f, 25.0f);
    private final SpringFloat settingsFade = new SpringFloat(1.0f).response(220.0f, 24.0f);
    private final Map<Module, ModuleCardState> cardStates = new IdentityHashMap<>();
    private final Map<Setting, SettingControl> settingControls = new IdentityHashMap<>();
    private final EnumMap<SettingGroupKind, SettingGroupState> settingGroups = new EnumMap<>(SettingGroupKind.class);
    private final List<Category> categories = new ArrayList<>(Category.values().length);
    private final EnumMap<Category, List<Module>> modulesByCategory = new EnumMap<>(Category.class);
    private final EnumMap<Category, String> categoryLabels = new EnumMap<>(Category.class);
    private final List<Module> visibleModules = new ArrayList<>(96);
    private final List<SettingControl> visibleControls = new ArrayList<>(32);

    private Category selectedCategory = Category.VISUAL;
    private Module selectedModule;
    private boolean closing;
    private float lastMouseDragY;
    private String lastQuery = "";
    private Category lastVisibleCategory;
    private int lastModuleCount = -1;
    private int categoryCacheModuleCount = -1;
    private int selectedCategoryIndex;
    private Module selectedFitModule;
    private Module selectedFitDescriptionModule;
    private String selectedFitName = "";
    private String selectedFitDescription = "";
    private int selectedFitNameWidthBits;
    private int selectedFitDescriptionWidthBits;

    public NextGenClickGuiScreen(Screen parent) {
        super(Text.literal("Ryuzaki ClickGUI"));
        this.parent = parent;
        for (SettingGroupKind kind : SettingGroupKind.values()) {
            settingGroups.put(kind, new SettingGroupState());
        }
        open.snap(0.0f);
        open.target(1.0f);
        timeline.open();
    }

    @Override
    protected void init() {
        layout.compute(width, height);
        rebuildCategories();
        searchBar.setBounds(layout.search.x, layout.search.y, layout.search.w, layout.search.h);
        modulesScroll.setBounds(layout.modules.x, layout.modules.y + 54.0f, layout.modules.w, layout.modules.h - 54.0f);
        settingsScroll.setBounds(layout.settings.x + 14.0f, layout.settings.y + 126.0f,
                layout.settings.w - 28.0f, layout.settings.h - 182.0f);
        selectFirstAvailableCategory();
        rebuildVisibleModules();
        ensureSelectedModule();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        clock.tick(delta);
        float dt = clock.delta();
        input.update(mouseX, mouseY, dt);
        layout.compute(width, height);
        updateComponentBounds();
        rebuildVisibleModules();
        ensureSelectedModule();

        framebuffers.beginFrame(clock.time());
        timeline.update(dt);
        lifecycle.set(closing ? GuiLifecycle.CLOSING : GuiLifecycle.OPENING);
        lifecycle.update(dt);
        open.update(dt);
        contentShift.update(dt);
        settingsFade.target(1.0f);
        settingsFade.update(dt);
        if (closing && timeline.closed()) {
            MinecraftClient.getInstance().setScreen(parent);
            return;
        }

        float backgroundPhase = timeline.phase(0.00f, 0.26f);
        float blurPhase = timeline.phase(0.08f, 0.42f);
        float sidebarPhase = timeline.phase(0.18f, 0.58f);
        float cardsPhase = timeline.phase(0.32f, 0.90f);
        float glowPhase = timeline.phase(0.62f, 1.00f);

        renderer.begin(context, Math.max(0.0f, Math.min(1.0f, backgroundPhase)));
        renderer.fullscreenAtmosphere(width, height, clock.time());
        renderer.graphGlowComposite(width, height, 0.18f * glowPhase);
        renderer.end();

        float progress = Easing.quintOut(timeline.value()) * Easing.smoothStep(open.get());
        float scale = 0.965f + progress * 0.035f;
        context.getMatrices().push();
        context.getMatrices().translate(width * 0.5f, height * 0.5f, 0.0f);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.getMatrices().translate(-width * 0.5f, -height * 0.5f + (1.0f - progress) * 16.0f, 0.0f);

        renderer.begin(context, progress);
        renderer.pushAlpha(blurPhase);
        renderSidebar(dt);
        renderModules(dt);
        renderSettings(dt);
        renderNotifications();
        renderer.popAlpha();
        renderer.end();
        context.getMatrices().pop();
    }

    private void updateComponentBounds() {
        searchBar.setBounds(layout.search.x, layout.search.y, layout.search.w, layout.search.h);
        modulesScroll.setBounds(layout.modules.x + 14.0f, layout.modules.y + 58.0f,
                layout.modules.w - 28.0f, layout.modules.h - 72.0f);
        settingsScroll.setBounds(layout.settings.x + 14.0f, layout.settings.y + 130.0f,
                layout.settings.w - 28.0f, layout.settings.h - 188.0f);
        float buttonY = layout.settings.bottom() - 44.0f;
        float buttonW = (layout.settings.w - 42.0f) * 0.5f;
        saveButton.setBounds(layout.settings.x + 14.0f, buttonY, buttonW, 30.0f);
        loadButton.setBounds(layout.settings.x + 28.0f + buttonW, buttonY, buttonW, 30.0f);
    }

    private void renderSidebar(float dt) {
        float slide = (1.0f - timeline.phase(0.16f, 0.52f)) * -28.0f;
        float sx = layout.sidebar.x + slide;
        renderer.material(sx, layout.sidebar.y, layout.sidebar.w, layout.sidebar.h, UIMaterial.SIDEBAR, 1.0f);
        renderer.text("RYUZAKI", sx + 18.0f, layout.sidebar.y + 22.0f, 17.0f, renderer.theme().text, true);
        renderer.text("VISUAL", sx + 19.0f, layout.sidebar.y + 43.0f, 8.5f, renderer.theme().textMuted, true);
        int enabled = 0;
        for (Module module : ModuleManager.modules) {
            if (module.isEnabled()) enabled++;
        }
        renderer.rounded(sx + 16.0f, layout.sidebar.y + 68.0f, layout.sidebar.w - 32.0f, 24.0f, 10.0f, 0x50101010);
        renderer.lineGlow(sx + 22.0f, layout.sidebar.y + 79.0f, 22.0f, 2.0f, renderer.theme().accent, 0.30f);
        renderer.text(enabled + " active", sx + 54.0f, layout.sidebar.y + 76.0f, 9.0f, renderer.theme().textDim, false);

        float y = layout.sidebar.y + 112.0f;
        float itemH = 28.0f;
        for (Category category : categories) {
            List<Module> modules = modulesFor(category);
            boolean active = category == selectedCategory;
            float target = active ? y : categoryAccent.target();
            if (active) categoryAccent.target(target);
            float hover = input.inside(sx + 13.0f, y, layout.sidebar.w - 26.0f, itemH) ? 1.0f : 0.0f;
            float activeF = active ? 1.0f : 0.0f;
            int bg = UITheme.mix(0x00101010, 0x66161212, Math.max(hover * 0.34f, activeF * 0.42f));
            renderer.rounded(sx + 12.0f + hover * 1.5f, y, layout.sidebar.w - 24.0f, itemH, 9.0f, bg);
            if (active) {
                renderer.glow(sx + 12.0f, y, layout.sidebar.w - 24.0f, itemH, 9.0f, renderer.theme().accent, 0.16f);
                renderer.rounded(sx + 15.0f, y + 7.0f, 2.0f, itemH - 14.0f, 1.0f, renderer.theme().accent);
            }
            renderer.text(categoryLabel(category), sx + 27.0f + hover * 2.0f, y + 7.0f,
                    10.5f, active ? renderer.theme().text : renderer.theme().textDim, true);
            renderer.textRight(String.valueOf(modules.size()), sx + layout.sidebar.w - 20.0f, y + 7.0f,
                    9.0f, active ? renderer.theme().accentSoft : renderer.theme().textMuted, false);
            y += itemH + 7.0f;
        }
        categoryAccent.update(dt);
    }

    private void renderModules(float dt) {
        renderer.material(layout.modules.x, layout.modules.y, layout.modules.w, layout.modules.h, UIMaterial.PANEL, 0.75f);
        searchBar.update(input, dt);
        searchBar.render(renderer, input, dt);

        renderer.text(categoryLabel(selectedCategory), layout.modules.x + 18.0f, layout.modules.y + 19.0f,
                18.0f, renderer.theme().text, true);
        renderer.text(visibleModules.size() + " modules", layout.modules.x + 20.0f, layout.modules.y + 42.0f,
                10.0f, renderer.theme().textDim, false);

        float pad = 2.0f;
        float gap = 12.0f;
        float cardH = 58.0f;
        float minCardW = 142.0f;
        int columns = Math.max(1, (int) ((modulesScroll.bounds().w + gap) / (minCardW + gap)));
        float cardW = (modulesScroll.bounds().w - gap * (columns - 1) - pad * 2.0f) / columns;
        int rows = (visibleModules.size() + columns - 1) / columns;
        float contentHeight = rows * (cardH + gap) + pad * 2.0f;
        modulesScroll.contentHeight(contentHeight);
        modulesScroll.update(input, dt);
        modulesScroll.updateScroll(dt);

        renderer.pushScissor(modulesScroll.bounds().x, modulesScroll.bounds().y, modulesScroll.bounds().w, modulesScroll.bounds().h);
        float scroll = modulesScroll.scroll();
        for (int i = 0; i < visibleModules.size(); i++) {
            int col = i % columns;
            int row = i / columns;
            float x = modulesScroll.bounds().x + pad + col * (cardW + gap);
            float y = modulesScroll.bounds().y + pad + row * (cardH + gap) - scroll;
            if (y > modulesScroll.bounds().bottom() + cardH || y + cardH < modulesScroll.bounds().y - cardH) continue;
            renderModuleCard(visibleModules.get(i), x + contentShift.get(), y, cardW, cardH, dt, i);
        }
        renderer.popScissor();
        modulesScroll.render(renderer, input, dt);
    }

    private void renderModuleCard(Module module, float x, float y, float w, float h, float dt, int index) {
        ModuleCardState state = cardState(module);
        boolean hovered = input.inside(x, y, w, h);
        boolean selected = module == selectedModule;
        state.hover.target(hovered ? 1.0f : 0.0f);
        state.enabled.target(module.isEnabled() ? 1.0f : 0.0f);
        state.selected.target(selected ? 1.0f : 0.0f);
        state.stagger.target(1.0f);
        if (!state.layoutReady) {
            state.layoutX.snap(x);
            state.layoutY.snap(y);
            state.layoutW.snap(w);
            state.layoutH.snap(h);
            state.layoutReady = true;
        }
        state.layoutX.target(x);
        state.layoutY.target(y);
        state.layoutW.target(w);
        state.layoutH.target(h);
        state.hover.update(dt);
        state.enabled.update(dt);
        state.selected.update(dt);
        state.stagger.update(dt);
        state.layoutX.update(dt);
        state.layoutY.update(dt);
        state.layoutW.update(dt);
        state.layoutH.update(dt);

        x = state.layoutX.get();
        y = state.layoutY.get();
        w = state.layoutW.get();
        h = state.layoutH.get();
        float appear = Easing.quintOut(Math.min(1.0f, state.stagger.get()));
        float hover = state.hover.get();
        float enabled = state.enabled.get();
        float selectedF = state.selected.get();
        float pulse = enabled * ((float) Math.sin(clock.time() * 2.6f + index * 0.37f) * 0.5f + 0.5f);
        float sweepPhase = (clock.time() * 0.075f + index * 0.039f) % 1.0f;
        float lift = hover * 2.3f + selectedF * 1.2f;
        float scale = 1.0f + hover * 0.018f + selectedF * 0.006f;
        float parallaxX = ((input.smoothX() - (x + w * 0.5f)) / Math.max(1.0f, w)) * hover * 2.0f;
        float parallaxY = ((input.smoothY() - (y + h * 0.5f)) / Math.max(1.0f, h)) * hover * 1.4f;
        float scaledW = w * scale;
        float scaledH = h * scale;
        float drawX = x - (scaledW - w) * 0.5f + parallaxX;
        float drawY = y - lift - (scaledH - h) * 0.5f + (1.0f - appear) * 14.0f + parallaxY;
        int top = UITheme.mix(renderer.theme().card, renderer.theme().cardHot, Math.max(enabled * 0.65f, hover * 0.24f));
        top = UITheme.mix(top, renderer.theme().accent, pulse * 0.045f);
        int bottom = UITheme.mix(renderer.theme().panelDeep, renderer.theme().accentDeep, enabled * (0.22f + pulse * 0.04f));
        int border = UITheme.mix(renderer.theme().border, renderer.theme().borderHot, Math.max(enabled, selectedF));
        renderer.pushAlpha(appear);
        renderer.materialBlend(drawX, drawY, scaledW, scaledH, UIMaterial.CARD, UIMaterial.ACTIVE_MODULE,
                Math.max(enabled, selectedF * 0.65f), Math.max(enabled, hover));
        renderer.gradient(drawX + 1.0f, drawY + 1.0f, scaledW - 2.0f, scaledH - 2.0f, top, bottom, 14.0f);
        renderer.reflection(drawX, drawY, scaledW, scaledH, 12.0f, 0.18f + hover * 0.26f + enabled * 0.14f, sweepPhase);
        renderer.edgeGlow(drawX, drawY, scaledW, scaledH, 12.0f, renderer.theme().accent, enabled * 0.36f + hover * 0.10f + pulse * 0.10f);
        renderer.outline(drawX, drawY, scaledW, scaledH, 12.0f, border, 0.75f + hover * 0.10f);
        float sweep = (clock.time() * 34.0f + index * 11.0f) % (scaledW + 80.0f) - 40.0f;
        renderer.rounded(drawX + sweep, drawY + 1.0f, 34.0f, 1.0f, 0.5f,
                UITheme.alpha(renderer.theme().accent, (0.06f + enabled * 0.14f) * (0.35f + hover * 0.45f)));
        renderer.gradient(drawX + 8.0f, drawY + 6.0f, scaledW - 16.0f, 12.0f,
                UITheme.alpha(0x44FFFFFF, 0.06f + hover * 0.08f),
                UITheme.alpha(0x00FFFFFF, 0.0f), 6.0f);
        renderer.rounded(drawX + 12.0f, drawY + 12.0f, 5.0f, 5.0f, 2.5f,
                module.isEnabled() ? renderer.theme().accent : 0xFF555555);
        if (module.isEnabled()) renderer.lineGlow(drawX + 11.0f, drawY + 11.0f, 7.0f, 7.0f, renderer.theme().accent, 0.34f + pulse * 0.12f);
        renderer.text(fitCardName(state, module.name, scaledW - 48.0f, 12.2f, true), drawX + 24.0f, drawY + 9.5f,
                12.2f, renderer.theme().text, true);
        renderer.text(fitCardDescription(state, module.description, scaledW - 22.0f, 8.8f, false), drawX + 12.0f, drawY + 30.0f,
                8.8f, renderer.theme().textMuted, false);
        renderer.rounded(drawX + 12.0f, drawY + scaledH - 10.0f, scaledW - 24.0f, 2.0f, 1.0f, 0x20252525);
        renderer.rounded(drawX + 12.0f, drawY + scaledH - 10.0f, (scaledW - 24.0f) * Math.max(enabled, selectedF * 0.35f),
                2.0f, 1.0f, UITheme.alpha(renderer.theme().accent, 0.72f));
        renderer.popAlpha();
    }

    private void renderSettings(float dt) {
        renderer.materialBlend(layout.settings.x, layout.settings.y, layout.settings.w, layout.settings.h, UIMaterial.PANEL, UIMaterial.POPUP, 0.12f, 0.86f);
        if (selectedModule == null) {
            renderer.text("No module", layout.settings.x + 18.0f, layout.settings.y + 24.0f, 18.0f, renderer.theme().text, true);
            return;
        }

        renderer.text(fitSelectedName(layout.settings.w - 36.0f),
                layout.settings.x + 18.0f, layout.settings.y + 20.0f, 18.0f, renderer.theme().text, true);
        renderer.text(fitSelectedDescription(layout.settings.w - 36.0f),
                layout.settings.x + 19.0f, layout.settings.y + 45.0f, 10.0f, renderer.theme().textDim, false);

        float statusY = layout.settings.y + 72.0f;
        float statusW = layout.settings.w - 36.0f;
        float enabled = selectedModule.isEnabled() ? 1.0f : 0.0f;
        renderer.rounded(layout.settings.x + 18.0f, statusY, statusW, 34.0f, 14.0f,
                UITheme.mix(0x70141414, 0xA8221416, enabled));
        renderer.glow(layout.settings.x + 18.0f, statusY, statusW, 34.0f, 14.0f, renderer.theme().accent, enabled * 0.34f);
        renderer.text(selectedModule.isEnabled() ? "ENABLED" : "DISABLED",
                layout.settings.x + 31.0f, statusY + 11.0f, 11.0f,
                selectedModule.isEnabled() ? renderer.theme().accent : renderer.theme().textMuted, true);
        renderer.textRight(selectedModule.category.name(), layout.settings.right() - 31.0f, statusY + 11.0f,
                10.0f, renderer.theme().textDim, false);

        renderSettingControls(dt);
        saveButton.update(input, dt);
        loadButton.update(input, dt);
        saveButton.render(renderer, input, dt);
        loadButton.render(renderer, input, dt);
    }

    private void renderSettingControls(float dt) {
        visibleControls.clear();
        List<Setting> settings = selectedModule.getAllSettings();
        float y = settingsScroll.bounds().y + 2.0f - settingsScroll.scroll();
        float contentHeight = 4.0f;
        for (SettingGroupKind kind : SettingGroupKind.values()) {
            if (!hasSettings(settings, kind)) continue;
            SettingGroupState group = settingGroups.get(kind);
            group.open.target(group.collapsed ? 0.0f : 1.0f);
            group.open.update(dt);
            float headerH = 28.0f;
            group.bounds.set(settingsScroll.bounds().x, y, settingsScroll.bounds().w - 8.0f, headerH);
            renderSettingGroupHeader(kind, group);
            y += headerH + 8.0f;
            contentHeight += headerH + 8.0f;
            float openValue = Easing.quintOut(group.open.get());
            if (openValue <= 0.01f) continue;
            renderer.pushAlpha(openValue);
            for (Setting setting : settings) {
                if (!setting.isVisible() || groupFor(setting) != kind) continue;
                SettingControl control = settingControl(setting);
                float h = control.preferredHeight();
                float fade = Easing.quintOut(settingsFade.get());
                control.setBounds(settingsScroll.bounds().x + (1.0f - fade) * 10.0f, y, settingsScroll.bounds().w - 8.0f, h);
                control.update(input, dt);
                if (y + h >= settingsScroll.bounds().y - 20.0f && y <= settingsScroll.bounds().bottom() + 20.0f) {
                    visibleControls.add(control);
                }
                y += (h + 10.0f) * openValue;
                contentHeight += (h + 10.0f) * openValue;
            }
            renderer.popAlpha();
        }
        settingsScroll.contentHeight(contentHeight);
        settingsScroll.update(input, dt);
        settingsScroll.updateScroll(dt);
        renderer.pushScissor(settingsScroll.bounds().x, settingsScroll.bounds().y, settingsScroll.bounds().w, settingsScroll.bounds().h);
        renderer.pushAlpha(Easing.quintOut(settingsFade.get()));
        for (int i = 0; i < visibleControls.size(); i++) {
            renderer.pushAlpha(Math.min(1.0f, settingsFade.get() + i * 0.045f));
            visibleControls.get(i).render(renderer, input, dt);
            renderer.popAlpha();
        }
        renderer.popAlpha();
        renderer.popScissor();
        settingsScroll.render(renderer, input, dt);
    }

    private void renderNotifications() {
        List<NotificationManager.Notification> notifications = NotificationManager.active();
        float y = height - 24.0f;
        for (int i = notifications.size() - 1; i >= 0; i--) {
            NotificationManager.Notification notification = notifications.get(i);
            float alpha = Math.min(1.0f, notification.ticksLeft() / 20.0f);
            String text = notification.text();
            float w = renderer.textWidth(text, 11.0f, true) + 28.0f;
            float x = width - w - 18.0f;
            y -= 34.0f;
            renderer.glow(x, y, w, 26.0f, 11.0f, renderer.theme().accent, 0.24f * alpha);
            renderer.rounded(x, y, w, 26.0f, 11.0f, UITheme.alpha(0xE00D0D0D, alpha));
            renderer.outline(x, y, w, 26.0f, 11.0f, UITheme.alpha(renderer.theme().borderHot, alpha), 1.0f);
            renderer.text(text, x + 14.0f, y + 8.0f, 11.0f, UITheme.alpha(renderer.theme().text, alpha), true);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        input.press(button, this);
        lastMouseDragY = (float) my;
        if (dispatchListeningMouse(mx, my, button)) return true;
        if (saveButton.mouseClicked(mx, my, button) || loadButton.mouseClicked(mx, my, button)) return true;
        if (searchBar.mouseClicked(mx, my, button)) return true;
        if (button == 0 && !searchBar.bounds().contains(mx, my)) searchBar.blur();
        if (handleSettingsClick(mx, my, button)) return true;
        if (handleModuleClick(mx, my, button)) return true;
        if (handleCategoryClick(mx, my, button)) return true;
        return true;
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        input.release(button);
        for (SettingControl control : visibleControls) {
            if (control.mouseReleased(mx, my, button)) return true;
        }
        return true;
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        input.markDragging();
        for (SettingControl control : visibleControls) {
            if (control.mouseDragged(mx, my, button, dx, dy)) return true;
        }
        if (modulesScroll.bounds().contains(mx, my)) {
            modulesScroll.drag(my - lastMouseDragY);
            lastMouseDragY = (float) my;
            return true;
        }
        if (settingsScroll.bounds().contains(mx, my)) {
            settingsScroll.drag(my - lastMouseDragY);
            lastMouseDragY = (float) my;
            return true;
        }
        return true;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double horizontalAmount, double verticalAmount) {
        if (settingsScroll.mouseScrolled(mx, my, verticalAmount)) return true;
        if (modulesScroll.mouseScrolled(mx, my, verticalAmount)) return true;
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (dispatchListeningKey(keyCode, scanCode, modifiers)) return true;
        if (searchBar.keyPressed(keyCode, scanCode, modifiers)) return true;
        if ((modifiers & GLFW.GLFW_MOD_CONTROL) != 0 && keyCode == GLFW.GLFW_KEY_F) {
            searchBar.focus();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            requestClose();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_RIGHT) {
            cycleCategory(true);
            lastVisibleCategory = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_LEFT) {
            cycleCategory(false);
            lastVisibleCategory = null;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DOWN) {
            selectModuleOffset(1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP) {
            selectModuleOffset(-1);
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_SPACE) {
            if (selectedModule != null) {
                selectedModule.toggle();
                NotificationManager.push(selectedModule.name + (selectedModule.isEnabled() ? " enabled" : " disabled"), 80);
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_TAB) {
            cycleCategory(!hasShift(modifiers));
            return true;
        }
        return true;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        return searchBar.charTyped(chr, modifiers);
    }

    @Override
    public void close() {
        requestClose();
    }

    @Override
    public void removed() {
        ConfigManager.autoSave();
        framebuffers.cleanup();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private boolean handleCategoryClick(double mx, double my, int button) {
        if (button != 0 || !layout.sidebar.contains(mx, my)) return false;
        float y = layout.sidebar.y + 112.0f;
        float itemH = 28.0f;
        for (Category category : categories) {
            if (mx >= layout.sidebar.x + 13.0f && mx <= layout.sidebar.right() - 13.0f && my >= y && my <= y + itemH) {
                if (selectedCategory != category) {
                    int direction = categoryIndex(category) >= selectedCategoryIndex ? 1 : -1;
                    selectedCategory = category;
                    selectedCategoryIndex = categoryIndex(category);
                    selectedModule = null;
                    modulesScroll.reset();
                    settingsScroll.reset();
                    contentShift.snap(24.0f * direction);
                    contentShift.target(0.0f);
                    settingsFade.snap(0.0f);
                    rebuildVisibleModules();
                    ensureSelectedModule();
                }
                return true;
            }
            y += itemH + 7.0f;
        }
        return false;
    }

    private boolean handleModuleClick(double mx, double my, int button) {
        Module module = moduleAt(mx, my);
        if (module == null) return false;
        boolean changedSelection = selectedModule != module;
        selectedModule = module;
        if (changedSelection) {
            settingsScroll.reset();
            settingsFade.snap(0.0f);
        }
        if (button == 0) {
            module.toggle();
            NotificationManager.push(module.name + (module.isEnabled() ? " enabled" : " disabled"), 80);
        }
        return true;
    }

    private boolean handleSettingsClick(double mx, double my, int button) {
        if (!layout.settings.contains(mx, my)) return false;
        if (selectedModule != null && mx >= layout.settings.x + 18.0f && mx <= layout.settings.right() - 18.0f
                && my >= layout.settings.y + 72.0f && my <= layout.settings.y + 106.0f && button == 0) {
            selectedModule.toggle();
            NotificationManager.push(selectedModule.name + (selectedModule.isEnabled() ? " enabled" : " disabled"), 80);
            return true;
        }
        if (button == 0) {
            for (SettingGroupState group : settingGroups.values()) {
                if (group.bounds.contains(mx, my)) {
                    group.collapsed = !group.collapsed;
                    return true;
                }
            }
        }
        for (int i = visibleControls.size() - 1; i >= 0; i--) {
            if (visibleControls.get(i).mouseClicked(mx, my, button)) return true;
        }
        return layout.settings.contains(mx, my);
    }

    private boolean dispatchListeningKey(int keyCode, int scanCode, int modifiers) {
        for (SettingControl control : settingControls.values()) {
            if (control instanceof UIKeybind keybind && keybind.listening()) {
                return keybind.keyPressed(keyCode, scanCode, modifiers);
            }
        }
        return false;
    }

    private boolean dispatchListeningMouse(double mx, double my, int button) {
        for (SettingControl control : settingControls.values()) {
            if (control instanceof UIKeybind keybind && keybind.listening()) {
                return keybind.mouseClicked(mx, my, button);
            }
        }
        return false;
    }

    private Module moduleAt(double mx, double my) {
        if (!modulesScroll.bounds().contains(mx, my)) return null;
        float pad = 2.0f;
        float gap = 12.0f;
        float cardH = 58.0f;
        float minCardW = 142.0f;
        int columns = Math.max(1, (int) ((modulesScroll.bounds().w + gap) / (minCardW + gap)));
        float cardW = (modulesScroll.bounds().w - gap * (columns - 1) - pad * 2.0f) / columns;
        float localY = (float) my - modulesScroll.bounds().y + modulesScroll.scroll() - pad;
        if (localY < 0.0f) return null;
        int row = (int) (localY / (cardH + gap));
        float rowY = localY - row * (cardH + gap);
        if (rowY > cardH) return null;
        float localX = (float) mx - modulesScroll.bounds().x - pad;
        if (localX < 0.0f) return null;
        int col = (int) (localX / (cardW + gap));
        float colX = localX - col * (cardW + gap);
        if (col < 0 || col >= columns || colX > cardW) return null;
        int index = row * columns + col;
        if (index < 0 || index >= visibleModules.size()) return null;
        return visibleModules.get(index);
    }

    private void rebuildVisibleModules() {
        rebuildCategories();
        String query = searchBar.text().trim().toLowerCase(Locale.ROOT);
        int moduleCount = ModuleManager.modules.size();
        if (selectedCategory == lastVisibleCategory && query.equals(lastQuery) && moduleCount == lastModuleCount) {
            return;
        }
        lastVisibleCategory = selectedCategory;
        lastQuery = query;
        lastModuleCount = moduleCount;
        visibleModules.clear();
        List<Module> modules = modulesFor(selectedCategory);
        for (Module module : modules) {
            if (query.isEmpty() || matches(module, query)) {
                visibleModules.add(module);
                ModuleCardState state = cardState(module);
                state.stagger.snap(0.0f);
                state.stagger.target(1.0f);
            }
        }
    }

    private boolean matches(Module module, String query) {
        return module.name.toLowerCase(Locale.ROOT).contains(query)
                || module.description.toLowerCase(Locale.ROOT).contains(query)
                || module.category.name().toLowerCase(Locale.ROOT).contains(query)
                || module.category.displayName.toLowerCase(Locale.ROOT).contains(query);
    }

    private void ensureSelectedModule() {
        if (selectedModule != null && visibleModules.contains(selectedModule)) return;
        Module next = visibleModules.isEmpty() ? null : visibleModules.get(0);
        if (selectedModule != next) {
            selectedModule = next;
            settingsScroll.reset();
            settingsFade.snap(0.0f);
        }
    }

    private void selectFirstAvailableCategory() {
        if (categories.contains(selectedCategory)) {
            selectedCategoryIndex = categoryIndex(selectedCategory);
            return;
        }
        for (Category category : categories) {
            if (!modulesFor(category).isEmpty()) {
                selectedCategory = category;
                selectedCategoryIndex = categoryIndex(category);
                return;
            }
        }
        if (!categories.isEmpty()) {
            selectedCategory = categories.get(0);
            selectedCategoryIndex = 0;
        }
    }

    private List<Module> modulesFor(Category category) {
        List<Module> modules = modulesByCategory.get(category);
        return modules == null ? List.of() : modules;
    }

    private void cycleCategory(boolean forward) {
        if (categories.isEmpty()) return;
        int current = selectedCategoryIndex >= 0 && selectedCategoryIndex < categories.size()
                ? selectedCategoryIndex : categoryIndex(selectedCategory);
        for (int step = 1; step <= categories.size(); step++) {
            int next = forward
                    ? (current + step) % categories.size()
                    : (current - step + categories.size()) % categories.size();
            if (!modulesFor(categories.get(next)).isEmpty()) {
                contentShift.snap(forward ? 24.0f : -24.0f);
                contentShift.target(0.0f);
                selectedCategory = categories.get(next);
                selectedCategoryIndex = next;
                selectedModule = null;
                modulesScroll.reset();
                settingsScroll.reset();
                settingsFade.snap(0.0f);
                lastVisibleCategory = null;
                return;
            }
        }
    }

    private void rebuildCategories() {
        Category[] values = Category.values();
        if (categories.size() != values.length) {
            categories.clear();
            categories.addAll(Arrays.asList(values));
            modulesByCategory.clear();
            for (Category category : values) {
                modulesByCategory.put(category, new ArrayList<>());
            }
            categoryCacheModuleCount = -1;
        }
        if (categoryCacheModuleCount == ModuleManager.modules.size()) return;
        for (Category category : values) {
            List<Module> bucket = modulesByCategory.get(category);
            if (bucket != null) bucket.clear();
        }
        for (Module module : ModuleManager.modules) {
            List<Module> bucket = modulesByCategory.get(module.category);
            if (bucket != null) bucket.add(module);
        }
        categoryCacheModuleCount = ModuleManager.modules.size();
    }

    private void selectModuleOffset(int offset) {
        if (visibleModules.isEmpty()) return;
        int index = selectedModule == null ? -1 : visibleModules.indexOf(selectedModule);
        int next = Math.max(0, Math.min(visibleModules.size() - 1, index + offset));
        if (next != index) {
            selectedModule = visibleModules.get(next);
            settingsScroll.reset();
            settingsFade.snap(0.0f);
            int row = Math.max(0, next / Math.max(1, currentModuleColumns()));
            modulesScroll.ensureVisible(row * 70.0f, 58.0f);
        }
    }

    private int currentModuleColumns() {
        float gap = 12.0f;
        float minCardW = 142.0f;
        return Math.max(1, (int) ((modulesScroll.bounds().w + gap) / (minCardW + gap)));
    }

    private boolean hasShift(int modifiers) {
        return (modifiers & GLFW.GLFW_MOD_SHIFT) != 0;
    }

    private void requestClose() {
        if (closing) return;
        closing = true;
        open.target(0.0f);
        timeline.close();
    }

    private String categoryLabel(Category category) {
        String label = categoryLabels.get(category);
        if (label == null) {
            String raw = category.name().toLowerCase(Locale.ROOT);
            label = Character.toUpperCase(raw.charAt(0)) + raw.substring(1);
            categoryLabels.put(category, label);
        }
        return label;
    }

    private String fit(String text, float maxWidth, float size, boolean bold) {
        if (text == null) return "";
        if (renderer.textWidth(text, size, bold) <= maxWidth) return text;
        String ellipsis = "...";
        int low = 0;
        int high = text.length();
        while (low < high) {
            int mid = (low + high + 1) >>> 1;
            if (renderer.textWidth(text.substring(0, mid) + ellipsis, size, bold) <= maxWidth) {
                low = mid;
            } else {
                high = mid - 1;
            }
        }
        return low <= 0 ? ellipsis : text.substring(0, low) + ellipsis;
    }

    private String fitCardName(ModuleCardState state, String text, float maxWidth, float size, boolean bold) {
        int widthBits = Float.floatToIntBits(maxWidth);
        if (state.nameFitWidthBits != widthBits || state.nameFitSource != text) {
            state.nameFitWidthBits = widthBits;
            state.nameFitSource = text;
            state.nameFitText = fit(text, maxWidth, size, bold);
        }
        return state.nameFitText;
    }

    private String fitCardDescription(ModuleCardState state, String text, float maxWidth, float size, boolean bold) {
        int widthBits = Float.floatToIntBits(maxWidth);
        if (state.descriptionFitWidthBits != widthBits || state.descriptionFitSource != text) {
            state.descriptionFitWidthBits = widthBits;
            state.descriptionFitSource = text;
            state.descriptionFitText = fit(text, maxWidth, size, bold);
        }
        return state.descriptionFitText;
    }

    private int categoryIndex(Category category) {
        for (int i = 0; i < categories.size(); i++) {
            if (categories.get(i) == category) return i;
        }
        return 0;
    }

    private String fitSelectedName(float maxWidth) {
        int widthBits = Float.floatToIntBits(maxWidth);
        if (selectedFitModule != selectedModule || selectedFitNameWidthBits != widthBits) {
            selectedFitModule = selectedModule;
            selectedFitNameWidthBits = widthBits;
            selectedFitName = selectedModule == null ? "" : fit(selectedModule.name, maxWidth, 18.0f, true);
        }
        return selectedFitName;
    }

    private String fitSelectedDescription(float maxWidth) {
        int widthBits = Float.floatToIntBits(maxWidth);
        if (selectedFitDescriptionModule != selectedModule || selectedFitDescriptionWidthBits != widthBits) {
            selectedFitDescriptionModule = selectedModule;
            selectedFitDescriptionWidthBits = widthBits;
            selectedFitDescription = selectedModule == null ? "" : fit(selectedModule.description, maxWidth, 10.0f, false);
        }
        return selectedFitDescription;
    }

    private ModuleCardState cardState(Module module) {
        ModuleCardState state = cardStates.get(module);
        if (state == null) {
            state = new ModuleCardState();
            cardStates.put(module, state);
        }
        return state;
    }

    private SettingControl settingControl(Setting setting) {
        SettingControl control = settingControls.get(setting);
        if (control == null) {
            control = SettingControl.create(setting);
            settingControls.put(setting, control);
        }
        return control;
    }

    private boolean hasSettings(List<Setting> settings, SettingGroupKind kind) {
        for (int i = 0; i < settings.size(); i++) {
            Setting setting = settings.get(i);
            if (setting.isVisible() && groupFor(setting) == kind) return true;
        }
        return false;
    }

    private SettingGroupKind groupFor(Setting setting) {
        if (setting instanceof BindSetting) return SettingGroupKind.BIND;
        if (setting instanceof BooleanSetting) return SettingGroupKind.TOGGLES;
        if (setting instanceof NumberSetting) return SettingGroupKind.VALUES;
        if (setting instanceof ModeSetting) return SettingGroupKind.MODES;
        if (setting instanceof ColorSetting) return SettingGroupKind.COLORS;
        return SettingGroupKind.OTHER;
    }

    private void renderSettingGroupHeader(SettingGroupKind kind, SettingGroupState group) {
        if (group.bounds.bottom() < settingsScroll.bounds().y - 12.0f || group.bounds.y > settingsScroll.bounds().bottom() + 12.0f) {
            return;
        }
        float hover = input.inside(group.bounds) ? 1.0f : 0.0f;
        renderer.rounded(group.bounds.x, group.bounds.y, group.bounds.w, group.bounds.h, 10.0f,
                UITheme.mix(0x66151515, 0x98201416, Math.max(hover * 0.45f, group.open.get() * 0.18f)));
        renderer.outline(group.bounds.x, group.bounds.y, group.bounds.w, group.bounds.h, 10.0f,
                UITheme.mix(renderer.theme().border, renderer.theme().borderHot, hover * 0.45f), 1.0f);
        renderer.text(kind.label, group.bounds.x + 12.0f, group.bounds.y + 8.0f, 10.5f, renderer.theme().textDim, true);
        String arrow = group.collapsed ? "+" : "-";
        renderer.textRight(arrow, group.bounds.right() - 12.0f, group.bounds.y + 8.0f, 10.5f,
                group.collapsed ? renderer.theme().textMuted : renderer.theme().accent, true);
    }

    private static final class ModuleCardState {
        private final SpringFloat hover = new SpringFloat(0.0f).response(260.0f, 28.0f);
        private final SpringFloat enabled = new SpringFloat(0.0f).response(260.0f, 28.0f);
        private final SpringFloat selected = new SpringFloat(0.0f).response(260.0f, 28.0f);
        private final SpringFloat stagger = new SpringFloat(0.0f).response(180.0f, 22.0f);
        private final SpringFloat layoutX = new SpringFloat(0.0f).response(260.0f, 30.0f);
        private final SpringFloat layoutY = new SpringFloat(0.0f).response(260.0f, 30.0f);
        private final SpringFloat layoutW = new SpringFloat(0.0f).response(260.0f, 30.0f);
        private final SpringFloat layoutH = new SpringFloat(0.0f).response(260.0f, 30.0f);
        private String nameFitSource;
        private String nameFitText = "";
        private int nameFitWidthBits;
        private String descriptionFitSource;
        private String descriptionFitText = "";
        private int descriptionFitWidthBits;
        private boolean layoutReady;
    }

    private enum GuiLifecycle {
        OPENING,
        CLOSING
    }

    private enum SettingGroupKind {
        BIND("BIND"),
        TOGGLES("TOGGLES"),
        VALUES("VALUES"),
        MODES("MODES"),
        COLORS("COLORS"),
        OTHER("OTHER");

        private final String label;

        SettingGroupKind(String label) {
            this.label = label;
        }
    }

    private static final class SettingGroupState {
        private final Rect bounds = new Rect();
        private final SpringFloat open = new SpringFloat(1.0f).response(220.0f, 24.0f);
        private boolean collapsed;
    }
}
