package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.GraphShaders;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class BloomThresholdPass implements RenderPass {
    private final GraphShaders shaders;

    public BloomThresholdPass(GraphShaders shaders) {
        this.shaders = shaders;
    }

    @Override
    public String id() {
        return "bloom_threshold";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        int scene = resources.texture("scene");
        if (scene != 0) {
            resources.runShader("bloom_threshold", 0.5f, shaders.bloomThreshold(), scene, time, 0.62f, 1.25f);
        }
    }
}
