package ru.ryuzaki.gui.nextgen.render;

import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.gui.nextgen.layout.Rect;

import java.util.ArrayDeque;

public final class UIScissorStack {
    private final ArrayDeque<Rect> stack = new ArrayDeque<>(8);

    public void push(DrawContext context, float x, float y, float w, float h) {
        Rect next = new Rect(x, y, w, h);
        if (!stack.isEmpty()) {
            Rect top = stack.peek();
            float nx = Math.max(next.x, top.x);
            float ny = Math.max(next.y, top.y);
            float nr = Math.min(next.right(), top.right());
            float nb = Math.min(next.bottom(), top.bottom());
            next.set(nx, ny, Math.max(0.0f, nr - nx), Math.max(0.0f, nb - ny));
        }
        stack.push(next);
        context.enableScissor(Math.round(next.x), Math.round(next.y), Math.round(next.right()), Math.round(next.bottom()));
    }

    public void pop(DrawContext context) {
        if (stack.isEmpty()) return;
        stack.pop();
        if (stack.isEmpty()) {
            context.disableScissor();
        } else {
            Rect top = stack.peek();
            context.enableScissor(Math.round(top.x), Math.round(top.y), Math.round(top.right()), Math.round(top.bottom()));
        }
    }

    public void clear(DrawContext context) {
        if (!stack.isEmpty()) {
            stack.clear();
            context.disableScissor();
        }
    }
}
