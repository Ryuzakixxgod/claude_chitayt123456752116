package ru.ryuzaki.gui.nextgen.component;

import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.settings.BindSetting;

public final class UIKeybind extends SettingControl {
    private final BindSetting bindSetting;
    private final SpringFloat listeningPulse = new SpringFloat(0.0f).response(260.0f, 28.0f);

    public UIKeybind(BindSetting setting) {
        super(setting);
        this.bindSetting = setting;
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        listeningPulse.target(bindSetting.isListening() ? 1.0f : 0.0f);
        listeningPulse.update(dt);
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        renderBase(renderer, input, "");
        float p = listeningPulse.get();
        String value = bindSetting.isListening() ? "PRESS KEY" : bindSetting.getDisplayName();
        float bw = Math.max(76.0f, renderer.textWidth(value, 10.5f, true) + 24.0f);
        float bx = bounds.right() - bw - 13.0f;
        float by = bounds.y + bounds.h - 24.0f;
        renderer.glow(bx, by, bw, 17.0f, 8.5f, renderer.theme().accent, p * 0.5f);
        renderer.rounded(bx, by, bw, 17.0f, 8.5f, UITheme.mix(0xFF222222, renderer.theme().accentDeep, p));
        renderer.reflection(bx, by, bw, 17.0f, 8.5f, 0.12f + Math.max(hover.get(), p) * 0.18f, Math.max(hover.get(), p));
        renderer.edgeGlow(bx, by, bw, 17.0f, 8.5f, renderer.theme().accent, p * 0.38f + hover.get() * 0.08f);
        renderer.outline(bx, by, bw, 17.0f, 8.5f, UITheme.mix(0x33FFFFFF, renderer.theme().borderHot, Math.max(hover.get(), p)), 1.0f);
        renderer.text(value, bx + 10.0f, by + 4.0f, 10.5f, renderer.theme().text, true);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (bindSetting.isListening()) {
            if (button == 1) bindSetting.clearBind();
            else bindSetting.setKey(-(button + 1));
            bindSetting.stopListening();
            return true;
        }
        if (button == 0 && bounds.contains(mx, my)) {
            bindSetting.startListening();
            return true;
        }
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!bindSetting.isListening()) return false;
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_DELETE || keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            bindSetting.clearBind();
        } else {
            bindSetting.setKey(keyCode);
        }
        bindSetting.stopListening();
        return true;
    }

    public boolean listening() {
        return bindSetting.isListening();
    }
}
