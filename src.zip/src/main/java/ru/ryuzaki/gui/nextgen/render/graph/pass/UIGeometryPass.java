package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class UIGeometryPass implements RenderPass {
    private int preparedWidth = -1;
    private int preparedHeight = -1;

    @Override
    public String id() {
        return "ui_geometry";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        preparedWidth = resources.width();
        preparedHeight = resources.height();
        resources.buffer("ui_geometry", 1.0f, false);
    }

    public boolean preparedFor(int width, int height) {
        return preparedWidth == width && preparedHeight == height;
    }
}
