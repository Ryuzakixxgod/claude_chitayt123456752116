package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.GraphShaders;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class GlowCompositePass implements RenderPass {
    private final GraphShaders shaders;

    public GlowCompositePass(GraphShaders shaders) {
        this.shaders = shaders;
    }

    @Override
    public String id() {
        return "glow_composite";
    }

    @Override
    public boolean alwaysDirty() {
        return false;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        int bloom = resources.texture("bloom_blur");
        if (bloom != 0) {
            resources.runShader("glow_composite", 1.0f, shaders.bloomComposite(), bloom, time, 0.0f, 0.32f);
        }
    }
}
