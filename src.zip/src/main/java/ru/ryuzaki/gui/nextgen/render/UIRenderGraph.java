package ru.ryuzaki.gui.nextgen.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphExecutor;
import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.GraphShaders;
import ru.ryuzaki.gui.nextgen.render.graph.pass.*;

public final class UIRenderGraph {
    private static final UIRenderGraph INSTANCE = new UIRenderGraph();

    private final FrameGraphResources resources = new FrameGraphResources();
    private final FrameGraphExecutor executor = new FrameGraphExecutor();
    private final GraphShaders shaders = new GraphShaders();
    private boolean initialized;
    private boolean ready;

    private UIRenderGraph() {
    }

    public static UIRenderGraph getInstance() {
        return INSTANCE;
    }

    public void beginFrame(float time) {
        initialize();
        resources.beginFrame();
        executor.execute(resources, time);
        ready = resources.texture("blur_full") != 0;
    }

    public boolean ready() {
        return ready;
    }

    public void drawBlur(MatrixStack matrices, int x, int y, int w, int h, int alpha) {
        if (!ready || alpha <= 0 || w <= 0 || h <= 0) return;
        drawFramebufferRegion(matrices, resources.texture("blur_full"), x, y, w, h, alpha / 255.0f);
    }

    public void drawGlowComposite(MatrixStack matrices, int screenWidth, int screenHeight, float alpha) {
        int texture = resources.texture("final_composite");
        if (texture == 0 || alpha <= 0.0f) return;
        drawTexture(matrices, texture, 0.0f, 0.0f, screenWidth, screenHeight, alpha, true);
    }

    public void drawShadow(MatrixStack matrices, float x, float y, float w, float h, float alpha) {
        int texture = resources.texture("shadow_atlas");
        if (texture == 0 || alpha <= 0.0f) return;
        drawTexture(matrices, texture, x, y, w, h, alpha, false);
    }

    public void cleanup() {
        resources.cleanup();
        shaders.cleanup();
        initialized = false;
        ready = false;
    }

    private void initialize() {
        if (initialized) return;
        executor.add(new BackgroundCapturePass());
        executor.add(new BlurDownsamplePass()).dependsOn("background_capture");
        executor.add(new BlurUpsamplePass()).dependsOn("blur_downsample");
        executor.add(new BloomThresholdPass(shaders)).dependsOn("background_capture");
        executor.add(new BloomBlurPass()).dependsOn("bloom_threshold");
        executor.add(new ShadowAtlasPass(shaders));
        executor.add(new UIGeometryPass()).dependsOn("shadow_atlas");
        executor.add(new GlowCompositePass(shaders)).dependsOn("bloom_blur");
        executor.add(new FinalCompositePass()).dependsOn("glow_composite");
        initialized = true;
    }

    private void drawFramebufferRegion(MatrixStack matrices, int texture, int x, int y, int w, int h, float alpha) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float scale = (float) mc.getWindow().getScaleFactor();
        int sw = mc.getFramebuffer().textureWidth;
        int sh = mc.getFramebuffer().textureHeight;
        float px = x * scale;
        float py = y * scale;
        float pw = w * scale;
        float ph = h * scale;
        float u0 = px / sw;
        float u1 = (px + pw) / sw;
        float v0 = 1.0f - (py + ph) / sh;
        float v1 = 1.0f - py / sh;
        drawTextureUv(matrices, texture, x, y, w, h, u0, v1, u1, v0, alpha);
    }

    private void drawTexture(MatrixStack matrices, int texture, float x, float y, float w, float h, float alpha, boolean flipY) {
        if (flipY) drawTextureUv(matrices, texture, x, y, w, h, 0.0f, 1.0f, 1.0f, 0.0f, alpha);
        else drawTextureUv(matrices, texture, x, y, w, h, 0.0f, 0.0f, 1.0f, 1.0f, alpha);
    }

    private void drawTextureUv(MatrixStack matrices, int texture, float x, float y, float w, float h,
                               float u0, float v0, float u1, float v1, float alpha) {
        if (texture == 0 || alpha <= 0.0f) return;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShaderTexture(0, texture);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(matrix, x, y, 0.0f).texture(u0, v0).color(1.0f, 1.0f, 1.0f, alpha);
        buffer.vertex(matrix, x, y + h, 0.0f).texture(u0, v1).color(1.0f, 1.0f, 1.0f, alpha);
        buffer.vertex(matrix, x + w, y + h, 0.0f).texture(u1, v1).color(1.0f, 1.0f, 1.0f, alpha);
        buffer.vertex(matrix, x + w, y, 0.0f).texture(u1, v0).color(1.0f, 1.0f, 1.0f, alpha);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.disableBlend();
    }
}
