package ru.ryuzaki.gui.nextgen.animation;

import java.util.EnumMap;

public final class AnimationStateMachine<S extends Enum<S>> {
    private final EnumMap<S, Float> phaseTargets;
    private final EnumMap<S, SpringFloat> phases;
    private S state;

    public AnimationStateMachine(Class<S> type, S initial) {
        phaseTargets = new EnumMap<>(type);
        phases = new EnumMap<>(type);
        for (S value : type.getEnumConstants()) {
            phaseTargets.put(value, value == initial ? 1.0f : 0.0f);
            phases.put(value, new SpringFloat(value == initial ? 1.0f : 0.0f).response(200.0f, 23.0f));
        }
        state = initial;
    }

    public void set(S next) {
        if (next == state) return;
        state = next;
        for (S value : phases.keySet()) {
            phaseTargets.put(value, value == next ? 1.0f : 0.0f);
        }
    }

    public void update(float dt) {
        for (S value : phases.keySet()) {
            SpringFloat spring = phases.get(value);
            spring.target(phaseTargets.get(value));
            spring.update(dt);
        }
    }

    public float value(S key) {
        SpringFloat spring = phases.get(key);
        return spring == null ? 0.0f : spring.get();
    }

    public S state() {
        return state;
    }
}
