package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.KineticScroll;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;

public final class UIScrollPanel extends UIComponent {
    private final KineticScroll scroll = new KineticScroll();
    private float contentHeight;

    public void contentHeight(float contentHeight) {
        this.contentHeight = Math.max(0.0f, contentHeight);
        scroll.setMax(Math.max(0.0f, this.contentHeight - bounds.h));
    }

    public float scroll() {
        return scroll.get();
    }

    public void updateScroll(float dt) {
        scroll.setMax(Math.max(0.0f, contentHeight - bounds.h));
        scroll.update(dt);
    }

    public void reset() {
        scroll.reset();
    }

    public void drag(double dy) {
        scroll.drag((float) dy);
    }

    public void ensureVisible(float y, float h) {
        scroll.ensureVisible(y, h, bounds.h);
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        float max = Math.max(0.0f, contentHeight - bounds.h);
        if (max <= 1.0f) return;
        float trackH = Math.max(34.0f, bounds.h * (bounds.h / contentHeight));
        float normalized = Math.max(0.0f, Math.min(1.0f, scroll.get() / max));
        float trackY = bounds.y + (bounds.h - trackH) * normalized;
        renderer.rounded(bounds.right() - 4.0f, bounds.y + 4.0f, 2.0f, bounds.h - 8.0f, 1.0f, 0x24FFFFFF);
        renderer.lineGlow(bounds.right() - 5.0f, trackY, 4.0f, trackH, renderer.theme().accent, 0.35f);
        renderer.rounded(bounds.right() - 5.0f, trackY, 4.0f, trackH, 2.0f, renderer.theme().accentSoft);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        if (!bounds.contains(mx, my)) return false;
        scroll.wheel(amount);
        return true;
    }
}
