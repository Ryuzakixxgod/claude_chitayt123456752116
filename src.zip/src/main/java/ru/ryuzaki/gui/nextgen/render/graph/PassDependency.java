package ru.ryuzaki.gui.nextgen.render.graph;

public record PassDependency(String nodeId) {
    public PassDependency {
        if (nodeId == null || nodeId.isBlank()) {
            throw new IllegalArgumentException("nodeId");
        }
    }
}
