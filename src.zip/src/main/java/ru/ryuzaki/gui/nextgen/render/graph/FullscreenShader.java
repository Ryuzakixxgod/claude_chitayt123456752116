package ru.ryuzaki.gui.nextgen.render.graph;

import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;

public final class FullscreenShader implements AutoCloseable {
    private static int sharedVao;

    private final int program;
    private final int inputTextureLoc;
    private final int resolutionLoc;
    private final int timeLoc;
    private final int thresholdLoc;
    private final int intensityLoc;

    public FullscreenShader(String fragmentSource) {
        int vertex = compile(GL20.GL_VERTEX_SHADER, vertexSource());
        int fragment = compile(GL20.GL_FRAGMENT_SHADER, fragmentSource);
        program = GL20.glCreateProgram();
        GL20.glAttachShader(program, vertex);
        GL20.glAttachShader(program, fragment);
        GL20.glLinkProgram(program);
        if (GL20.glGetProgrami(program, GL20.GL_LINK_STATUS) == GL11.GL_FALSE) {
            String log = GL20.glGetProgramInfoLog(program);
            GL20.glDeleteProgram(program);
            throw new IllegalStateException(log);
        }
        GL20.glDeleteShader(vertex);
        GL20.glDeleteShader(fragment);
        inputTextureLoc = GL20.glGetUniformLocation(program, "uTexture");
        resolutionLoc = GL20.glGetUniformLocation(program, "uResolution");
        timeLoc = GL20.glGetUniformLocation(program, "uTime");
        thresholdLoc = GL20.glGetUniformLocation(program, "uThreshold");
        intensityLoc = GL20.glGetUniformLocation(program, "uIntensity");
    }

    public void draw(int texture, int width, int height, float time, float threshold, float intensity) {
        if (sharedVao == 0) sharedVao = GL30.glGenVertexArrays();
        GL20.glUseProgram(program);
        GL30.glBindVertexArray(sharedVao);
        GL13.glActiveTexture(GL13.GL_TEXTURE0);
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
        if (inputTextureLoc >= 0) GL20.glUniform1i(inputTextureLoc, 0);
        if (resolutionLoc >= 0) GL20.glUniform2f(resolutionLoc, width, height);
        if (timeLoc >= 0) GL20.glUniform1f(timeLoc, time);
        if (thresholdLoc >= 0) GL20.glUniform1f(thresholdLoc, threshold);
        if (intensityLoc >= 0) GL20.glUniform1f(intensityLoc, intensity);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 3);
        GL30.glBindVertexArray(0);
        GL20.glUseProgram(0);
    }

    @Override
    public void close() {
        GL20.glDeleteProgram(program);
    }

    private static int compile(int type, String source) {
        int shader = GL20.glCreateShader(type);
        GL20.glShaderSource(shader, source);
        GL20.glCompileShader(shader);
        if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == GL11.GL_FALSE) {
            String log = GL20.glGetShaderInfoLog(shader);
            GL20.glDeleteShader(shader);
            throw new IllegalStateException(log);
        }
        return shader;
    }

    private static String vertexSource() {
        return """
                #version 330 core
                out vec2 vUv;
                void main() {
                    vec2 pos;
                    if (gl_VertexID == 0) pos = vec2(-1.0, -1.0);
                    else if (gl_VertexID == 1) pos = vec2(3.0, -1.0);
                    else pos = vec2(-1.0, 3.0);
                    vUv = pos * 0.5 + 0.5;
                    gl_Position = vec4(pos, 0.0, 1.0);
                }
                """;
    }
}
