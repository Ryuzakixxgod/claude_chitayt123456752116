package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.settings.*;

public abstract class SettingControl extends UIComponent {
    protected final Setting setting;

    protected SettingControl(Setting setting) {
        this.setting = setting;
    }

    public static SettingControl create(Setting setting) {
        if (setting instanceof BooleanSetting booleanSetting) return new UIToggle(booleanSetting);
        if (setting instanceof NumberSetting numberSetting) return new UISlider(numberSetting);
        if (setting instanceof ModeSetting modeSetting) return new UIDropdown(modeSetting);
        if (setting instanceof ColorSetting colorSetting) return new UIColorPicker(colorSetting);
        if (setting instanceof BindSetting bindSetting) return new UIKeybind(bindSetting);
        return new UILabelSetting(setting);
    }

    public Setting setting() {
        return setting;
    }

    public float preferredHeight() {
        return 46.0f;
    }

    protected void renderBase(UIRenderer renderer, UIInputManager input, String valueText) {
        float h = hover.get();
        renderer.card(bounds.x, bounds.y, bounds.w, bounds.h, 11.0f,
                UITheme.mix(renderer.theme().panel, renderer.theme().panelLift, h * 0.28f),
                renderer.theme().panelDeep,
                UITheme.mix(renderer.theme().border, renderer.theme().borderHot, h * 0.34f),
                h * 0.08f);
        renderer.reflection(bounds.x, bounds.y, bounds.w, bounds.h, 11.0f, 0.12f + h * 0.18f, h);
        renderer.edgeGlow(bounds.x, bounds.y, bounds.w, bounds.h, 11.0f, renderer.theme().accent, h * 0.12f);
        renderer.text(setting.getName(), bounds.x + 13.0f, bounds.y + 10.0f, 12.0f, renderer.theme().textSoft, false);
        if (valueText != null && !valueText.isEmpty()) {
            renderer.textRight(valueText, bounds.right() - 13.0f, bounds.y + 10.0f, 11.0f, renderer.theme().textDim, false);
        }
    }

    private static final class UILabelSetting extends SettingControl {
        private UILabelSetting(Setting setting) {
            super(setting);
        }

        @Override
        public void render(UIRenderer renderer, UIInputManager input, float dt) {
            renderBase(renderer, input, setting.getClass().getSimpleName());
        }
    }
}
