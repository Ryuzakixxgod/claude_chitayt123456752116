package ru.ryuzaki.gui.nextgen.render.graph.pass;

import ru.ryuzaki.gui.nextgen.render.graph.FrameGraphResources;
import ru.ryuzaki.gui.nextgen.render.graph.RenderPass;

public final class BackgroundCapturePass implements RenderPass {
    @Override
    public String id() {
        return "background_capture";
    }

    @Override
    public boolean alwaysDirty() {
        return true;
    }

    @Override
    public void execute(FrameGraphResources resources, float time) {
        resources.captureMain("scene");
    }
}
