package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;
import ru.ryuzaki.settings.ModeSetting;

public final class UIDropdown extends SettingControl {
    private final ModeSetting modeSetting;
    private final SpringFloat pulse = new SpringFloat(0.0f).response(300.0f, 30.0f);

    public UIDropdown(ModeSetting setting) {
        super(setting);
        this.modeSetting = setting;
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        pulse.update(dt);
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        renderBase(renderer, input, "");
        float bx = bounds.right() - Math.min(150.0f, bounds.w * 0.42f);
        float by = bounds.y + bounds.h - 24.0f;
        float bw = bounds.right() - bx - 13.0f;
        float p = pulse.get();
        float hot = Math.max(hover.get() * 0.35f, p);
        renderer.glow(bx, by, bw, 17.0f, 8.5f, renderer.theme().accent, p * 0.32f + hover.get() * 0.08f);
        renderer.rounded(bx, by, bw, 17.0f, 8.5f, UITheme.mix(0xFF222222, renderer.theme().accentDeep, p * 0.5f));
        renderer.reflection(bx, by, bw, 17.0f, 8.5f, 0.11f + hot * 0.16f, hot);
        renderer.edgeGlow(bx, by, bw, 17.0f, 8.5f, renderer.theme().accent, hot * 0.16f);
        renderer.outline(bx, by, bw, 17.0f, 8.5f, UITheme.mix(0x33FFFFFF, renderer.theme().borderHot, hot), 1.0f);
        renderer.text(modeSetting.getCurrent(), bx + 9.0f, by + 4.0f, 10.0f, renderer.theme().text, false);
        renderer.text(">", bx + bw - 13.0f, by + 4.0f, 10.0f, renderer.theme().accent, true);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (!bounds.contains(mx, my)) return false;
        if (button == 0) {
            modeSetting.next();
            pulse.snap(1.0f);
            pulse.target(0.0f);
            return true;
        }
        if (button == 1) {
            modeSetting.prev();
            pulse.snap(1.0f);
            pulse.target(0.0f);
            return true;
        }
        return false;
    }
}
