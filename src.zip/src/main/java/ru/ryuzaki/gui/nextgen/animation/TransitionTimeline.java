package ru.ryuzaki.gui.nextgen.animation;

public final class TransitionTimeline {
    private float value;
    private float direction = 1.0f;
    private float duration = 0.46f;

    public void open() {
        direction = 1.0f;
    }

    public void close() {
        direction = -1.0f;
    }

    public void update(float dt) {
        value += direction * dt / Math.max(0.05f, duration);
        value = Easing.clamp01(value);
    }

    public float value() {
        return value;
    }

    public boolean closed() {
        return value <= 0.001f && direction < 0.0f;
    }

    public float phase(float start, float end) {
        if (end <= start) return value >= end ? 1.0f : 0.0f;
        return Easing.quintOut((value - start) / (end - start));
    }

    public TransitionTimeline duration(float duration) {
        this.duration = Math.max(0.05f, duration);
        return this;
    }
}
