package ru.ryuzaki.gui.nextgen.layout;

public final class Rect {
    public float x;
    public float y;
    public float w;
    public float h;

    public Rect() {
    }

    public Rect(float x, float y, float w, float h) {
        set(x, y, w, h);
    }

    public Rect set(float x, float y, float w, float h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        return this;
    }

    public boolean contains(double px, double py) {
        return px >= x && px <= x + w && py >= y && py <= y + h;
    }

    public float right() {
        return x + w;
    }

    public float bottom() {
        return y + h;
    }
}
