package ru.ryuzaki.gui.nextgen.component;

import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UIMaterial;
import ru.ryuzaki.gui.nextgen.render.UITheme;

public final class UISearchBar extends UIComponent {
    private final SpringFloat focus = new SpringFloat(0.0f).response(260.0f, 28.0f);
    private final SpringFloat hintFade = new SpringFloat(1.0f).response(240.0f, 26.0f);
    private final SpringFloat caret = new SpringFloat(0.0f).response(300.0f, 30.0f);
    private final SpringFloat typePulse = new SpringFloat(0.0f).response(340.0f, 32.0f);
    private final StringBuilder text = new StringBuilder(48);
    private String cachedText = "";
    private boolean focused;
    private float caretTime;

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        focus.target(focused ? 1.0f : 0.0f);
        hintFade.target(text.isEmpty() ? 1.0f : 0.0f);
        caret.target(text.length());
        typePulse.target(0.0f);
        focus.update(dt);
        hintFade.update(dt);
        caret.update(dt);
        typePulse.update(dt);
        caretTime += dt;
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        float h = hover.get();
        float f = focus.get();
        int border = UITheme.mix(renderer.theme().border, renderer.theme().borderHot, Math.max(h * 0.45f, f));
        renderer.materialBlend(bounds.x, bounds.y, bounds.w, bounds.h, UIMaterial.SEARCH, UIMaterial.POPUP, f * 0.35f, Math.max(h, f));
        renderer.reflection(bounds.x, bounds.y, bounds.w, bounds.h, 14.0f, 0.20f + f * 0.26f + typePulse.get() * 0.22f,
                (caretTime * 0.11f) % 1.0f);
        renderer.edgeGlow(bounds.x, bounds.y, bounds.w, bounds.h, 14.0f, renderer.theme().accent, f * 0.38f + h * 0.12f);
        renderer.rounded(bounds.x + 13.0f, bounds.y + bounds.h * 0.5f - 3.0f, 6.0f, 6.0f, 3.0f,
                UITheme.mix(renderer.theme().textMuted, renderer.theme().accent, f));
        renderer.outline(bounds.x + 10.0f, bounds.y + bounds.h * 0.5f - 6.0f, 12.0f, 12.0f, 6.0f,
                UITheme.mix(0x44FFFFFF, renderer.theme().accentSoft, f), 1.0f);

        String value = cachedText;
        boolean empty = value.isEmpty();
        String shown = empty ? "Search modules and settings" : value;
        int textColor = empty ? UITheme.alpha(renderer.theme().textMuted, 0.55f + hintFade.get() * 0.45f) : renderer.theme().text;
        renderer.text(shown, bounds.x + 34.0f, bounds.y + bounds.h * 0.5f - 6.5f,
                12.5f, textColor, false);
        renderer.rounded(bounds.x + 34.0f, bounds.bottom() - 7.0f,
                (bounds.w - 54.0f) * Math.max(f, h * 0.35f), 2.0f, 1.0f,
                UITheme.alpha(renderer.theme().accent, 0.35f + f * 0.45f));
        if (focused && ((int) (caretTime * 2.0f) & 1) == 0) {
            float caretRatio = value.isEmpty() ? 0.0f : Math.max(0.0f, Math.min(1.0f, caret.get() / value.length()));
            float x = bounds.x + 34.0f + renderer.textWidth(value, 12.5f, false) * caretRatio + 2.0f;
            renderer.rounded(x, bounds.y + bounds.h * 0.5f - 8.0f, 1.0f, 16.0f, 0.5f, renderer.theme().accent);
        }
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return false;
        focused = bounds.contains(mx, my);
        return focused;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (!focused) return false;
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (!text.isEmpty()) {
                text.deleteCharAt(text.length() - 1);
                syncText();
            }
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_DELETE) {
            text.setLength(0);
            syncText();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE || keyCode == GLFW.GLFW_KEY_ENTER) {
            focused = false;
            return true;
        }
        return keyCode == GLFW.GLFW_KEY_LEFT || keyCode == GLFW.GLFW_KEY_RIGHT;
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (!focused) return false;
        if (chr >= 32 && chr != 127 && text.length() < 48) {
            text.append(chr);
            syncText();
            typePulse.snap(1.0f);
            return true;
        }
        return false;
    }

    public String text() {
        return cachedText;
    }

    public boolean focused() {
        return focused;
    }

    public void blur() {
        focused = false;
    }

    public void focus() {
        focused = true;
        caretTime = 0.0f;
    }

    private void syncText() {
        cachedText = text.toString();
    }
}
