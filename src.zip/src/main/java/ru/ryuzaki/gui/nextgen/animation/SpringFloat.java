package ru.ryuzaki.gui.nextgen.animation;

public final class SpringFloat {
    private float value;
    private float target;
    private float velocity;
    private float stiffness = 220.0f;
    private float damping = 26.0f;

    public SpringFloat(float value) {
        this.value = value;
        this.target = value;
    }

    public SpringFloat response(float stiffness, float damping) {
        this.stiffness = Math.max(1.0f, stiffness);
        this.damping = Math.max(1.0f, damping);
        return this;
    }

    public void snap(float value) {
        this.value = value;
        this.target = value;
        this.velocity = 0.0f;
    }

    public void target(float target) {
        this.target = target;
    }

    public void update(float dt) {
        float step = Math.max(0.0f, Math.min(0.05f, dt));
        float force = (target - value) * stiffness;
        velocity += force * step;
        velocity *= (float) Math.exp(-damping * step);
        value += velocity * step;
        if (Math.abs(target - value) < 0.0005f && Math.abs(velocity) < 0.0005f) {
            value = target;
            velocity = 0.0f;
        }
    }

    public float get() {
        return value;
    }

    public float target() {
        return target;
    }

    public float velocity() {
        return velocity;
    }
}
