package ru.ryuzaki.gui.nextgen.render;

public record UIMaterial(
        int backgroundTop,
        int backgroundBottom,
        int border,
        int glow,
        int shadow,
        float blurStrength,
        float glowStrength,
        float shadowDepth,
        float radius,
        boolean emissive
) {
    public static final UIMaterial CARD = new UIMaterial(
            0xA80F0F0F, 0xE0050505, 0x24FFFFFF, 0x2EFF2828, 0xB0000000,
            0.16f, 0.055f, 0.62f, 12.0f, false);

    public static final UIMaterial PANEL = new UIMaterial(
            0x95141414, 0xE0070707, 0x28FFFFFF, 0x2AFF2828, 0xCC000000,
            0.44f, 0.11f, 0.86f, 18.0f, false);

    public static final UIMaterial SIDEBAR = new UIMaterial(
            0x96101010, 0xE8040404, 0x22FFFFFF, 0x30FF2828, 0xD0000000,
            0.50f, 0.12f, 0.92f, 18.0f, false);

    public static final UIMaterial POPUP = new UIMaterial(
            0xD0181818, 0xF00A0A0A, 0x66FF4040, 0x44FF3030, 0xDD000000,
            0.56f, 0.22f, 0.94f, 16.0f, true);

    public static final UIMaterial SEARCH = new UIMaterial(
            0xA8101010, 0xE0060606, 0x26FFFFFF, 0x32FF4040, 0xB0000000,
            0.38f, 0.10f, 0.62f, 13.0f, false);

    public static final UIMaterial ACTIVE_MODULE = new UIMaterial(
            0xC81A1111, 0xEA070404, 0x78FF4040, 0x48FF3030, 0xD0000000,
            0.22f, 0.26f, 0.82f, 12.0f, true);

    public UIMaterial mix(UIMaterial other, float t) {
        float clamped = Math.max(0.0f, Math.min(1.0f, t));
        return new UIMaterial(
                UITheme.mix(backgroundTop, other.backgroundTop, clamped),
                UITheme.mix(backgroundBottom, other.backgroundBottom, clamped),
                UITheme.mix(border, other.border, clamped),
                UITheme.mix(glow, other.glow, clamped),
                UITheme.mix(shadow, other.shadow, clamped),
                blurStrength + (other.blurStrength - blurStrength) * clamped,
                glowStrength + (other.glowStrength - glowStrength) * clamped,
                shadowDepth + (other.shadowDepth - shadowDepth) * clamped,
                radius + (other.radius - radius) * clamped,
                clamped >= 0.5f ? other.emissive : emissive
        );
    }
}
