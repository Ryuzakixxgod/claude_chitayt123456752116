package ru.ryuzaki.gui.nextgen.component;

import ru.ryuzaki.gui.nextgen.animation.SpringFloat;
import ru.ryuzaki.gui.nextgen.input.UIInputManager;
import ru.ryuzaki.gui.nextgen.render.UIRenderer;
import ru.ryuzaki.gui.nextgen.render.UITheme;

public final class UIButton extends UIComponent {
    private final String label;
    private final Runnable action;
    private final SpringFloat press = new SpringFloat(0.0f).response(360.0f, 34.0f);
    private boolean accent;

    public UIButton(String label, Runnable action) {
        this.label = label;
        this.action = action;
    }

    public UIButton accent(boolean accent) {
        this.accent = accent;
        return this;
    }

    @Override
    public void update(UIInputManager input, float dt) {
        super.update(input, dt);
        press.update(dt);
    }

    @Override
    public void render(UIRenderer renderer, UIInputManager input, float dt) {
        float h = Math.max(hover.get(), press.get());
        int top = accent ? UITheme.mix(renderer.theme().accentDeep, renderer.theme().accent, h)
                : UITheme.mix(renderer.theme().panel, renderer.theme().panelLift, h);
        int bottom = accent ? renderer.theme().accentDeep : renderer.theme().panelDeep;
        renderer.glow(bounds.x, bounds.y, bounds.w, bounds.h, 10.0f, renderer.theme().accent, (accent ? 0.22f : 0.08f) + h * 0.22f);
        renderer.gradient(bounds.x, bounds.y, bounds.w, bounds.h, top, bottom, 10.0f);
        renderer.outline(bounds.x, bounds.y, bounds.w, bounds.h, 10.0f,
                UITheme.mix(renderer.theme().border, renderer.theme().borderHot, h), 1.0f);
        float tw = renderer.textWidth(label, 11.0f, true);
        renderer.text(label, bounds.x + (bounds.w - tw) * 0.5f, bounds.y + bounds.h * 0.5f - 5.5f,
                11.0f, renderer.theme().text, true);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0 && bounds.contains(mx, my)) {
            press.snap(1.0f);
            press.target(0.0f);
            if (action != null) action.run();
            return true;
        }
        return false;
    }
}
