package ru.ryuzaki.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.util.FriendManager;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * FriendListScreen — GUI для управления списком друзей.
 * Добавить / удалить / просмотреть друзей.
 * Открывается командой /friend gui или из ClickGui.
 */
public class FriendListScreen extends Screen {

    private static final float W  = 340f;
    private static final float H  = 420f;
    private static final Color C_BG   = new Color(7,5,15,250);
    private static final Color C_ACC  = new Color(34,197,94);   // green for friends
    private static final Color C_ACCD = new Color(34,197,94,30);
    private static final Color C_ACCB = new Color(34,197,94,70);
    private static final Color C_BOR  = new Color(255,255,255,14);
    private static final Color C_T1   = new Color(237,232,255);
    private static final Color C_T3   = new Color(99,88,120);

    private String inputText = "";
    private boolean typing   = false;
    private float   scroll   = 0f, animScroll = 0f;
    private int     hovered  = -1;
    private final List<Float> rowHov = new ArrayList<>();

    public FriendListScreen(){ super(Text.literal("Friends")); }
    @Override public boolean shouldPause(){ return false; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta){
        super.render(ctx,mx,my,delta);
        ctx.fill(0,0,width,height,0x90000000);

        float gx=(width-W)/2f, gy=(height-H)/2f;
        MatrixStack ms=ctx.getMatrices();
        animScroll += (scroll-animScroll)*0.2f;

        // Window
        DrawHelper.drawRect(ms,gx,gy,W,H,14,C_BG);
        DrawHelper.drawRect(ms,gx+W*0.08f,gy,W*0.84f,1.5f,0,C_ACC);
        DrawHelper.drawOutline(ms,gx,gy,W,H,14,C_BOR,1f);

        // Header
        DrawHelper.drawRect(ms,gx,gy,W,44,0,new Color(5,3,12,250));
        DrawHelper.drawRect(ms,gx,gy+43,W,1,0,new Color(255,255,255,12));
        txt(ctx,ms,"♥ Friend List",gx+14,gy+13,C_ACC,13f,true);
        String cntS=FriendManager.getFriends().size()+" friends";
        txt(ctx,ms,cntS,gx+W-14-tw(cntS,9f),gy+16,C_T3,9f,false);

        // Add input box
        float iy=gy+H-54;
        DrawHelper.drawRect(ms,gx+12,iy,W-24,32,8,new Color(255,255,255,8));
        DrawHelper.drawOutline(ms,gx+12,iy,W-24,32,8,typing?C_ACCB:C_BOR,1f);
        txt(ctx,ms,"⌕",gx+22,iy+9,C_T3,11f,false);
        String disp=inputText.isEmpty()&&!typing?"Enter name to add…":inputText+(typing?"|":"");
        txt(ctx,ms,disp,gx+36,iy+10,inputText.isEmpty()?C_T3:C_T1,10f,false);

        // Add button
        float bx=gx+W-90,by=iy+6,bw=78f;
        DrawHelper.drawRect(ms,bx,by,bw,20,8,C_ACCD);
        DrawHelper.drawOutline(ms,bx,by,bw,20,8,C_ACCB,1f);
        txt(ctx,ms,"♥ Add",bx+(bw-tw("♥ Add",10f))/2f,by+5,C_ACC,10f,true);

        // Friends list
        List<String> friends=new ArrayList<>(FriendManager.getFriends());
        float listH=H-44-60;
        ctx.enableScissor((int)(gx+1),(int)(gy+45),(int)(gx+W-1),(int)(gy+44+listH));
        float cy=gy+50-animScroll;
        for(int i=0;i<friends.size();i++){
            String name=friends.get(i);
            boolean hov=mx>=gx+12&&mx<=gx+W-12&&my>=(int)cy&&my<=(int)(cy+36);
            while(rowHov.size()<=i) rowHov.add(0f);
            rowHov.set(i,rowHov.get(i)+((hov?1f:0f)-rowHov.get(i))*0.18f);
            float ha=rowHov.get(i);

            DrawHelper.drawRect(ms,gx+12,cy,W-24,32,8,
                new Color(34,197,94,(int)(10+20*ha)));
            if(ha>0.05f) DrawHelper.drawOutline(ms,gx+12,cy,W-24,32,8,
                new Color(34,197,94,(int)(30*ha)),1f);
            DrawHelper.drawRect(ms,gx+12,cy+(32-16)/2f,2,16,1,C_ACC);

            // Avatar fallback
            DrawHelper.drawRect(ms,gx+20,cy+4,24,24,12,new Color(34,197,94,40));
            txt(ctx,ms,String.valueOf(name.charAt(0)).toUpperCase(),
                gx+20+12-tw(String.valueOf(name.charAt(0)).toUpperCase(),11f)/2f,cy+9,C_ACC,11f,true);
            txt(ctx,ms,name,gx+50,cy+8,C_T1,10.5f,true);
            txt(ctx,ms,"Friend",gx+50,cy+20,new Color(34,197,94,180),8.5f,false);

            // Remove button
            float rx=gx+W-50,ry=cy+8,rw=32;
            DrawHelper.drawRect(ms,rx,ry,rw,16,5,new Color(239,68,68,(int)(15+30*ha)));
            txt(ctx,ms,"✕",rx+(rw-tw("✕",9f))/2f,ry+3,new Color(239,68,68,200),9f,false);

            cy+=40;
        }
        ctx.disableScissor();

        // Empty state
        if(friends.isEmpty()){
            txt(ctx,ms,"No friends yet",gx+W/2f-tw("No friends yet",10f)/2f,gy+H/2f-10,C_T3,10f,false);
            txt(ctx,ms,"Type a name below and press Enter",gx+W/2f-tw("Type a name below and press Enter",8.5f)/2f,
                gy+H/2f+6,new Color(60,55,80,200),8.5f,false);
        }
    }

    @Override
    public boolean mouseClicked(double mx,double my,int btn){
        float gx=(width-W)/2f,gy=(height-H)/2f;
        // Input box click
        float iy=gy+H-54;
        if(mx>=gx+12&&mx<=gx+W-102&&my>=iy&&my<=iy+32){typing=true;return true;}

        // Add button
        float bx=gx+W-90,by=iy+6;
        if(mx>=bx&&mx<=bx+78&&my>=by&&my<=by+20){addFriend();return true;}

        // Remove buttons
        List<String> friends=new ArrayList<>(FriendManager.getFriends());
        float cy=gy+50-animScroll;
        for(String name:friends){
            float rx=gx+W-50,ry=cy+8;
            if(mx>=rx&&mx<=rx+32&&my>=ry&&my<=ry+16){
                FriendManager.remove(name); return true;
            }
            cy+=40;
        }

        typing=false;
        return super.mouseClicked(mx,my,btn);
    }

    @Override
    public boolean mouseScrolled(double mx,double my,double hx,double vy){
        float listH=H-44-60;
        float maxS=Math.max(0,FriendManager.getFriends().size()*40-listH);
        scroll=Math.max(0,Math.min(maxS,scroll-(float)vy*20));
        return true;
    }

    @Override
    public boolean keyPressed(int key,int sc,int mod){
        if(key==GLFW.GLFW_KEY_ESCAPE){
            if(typing){typing=false;return true;}
            close();return true;
        }
        if(typing&&key==GLFW.GLFW_KEY_ENTER){addFriend();return true;}
        if(typing&&key==GLFW.GLFW_KEY_BACKSPACE&&!inputText.isEmpty()){
            inputText=inputText.substring(0,inputText.length()-1);return true;
        }
        return super.keyPressed(key,sc,mod);
    }

    @Override public boolean charTyped(char c,int mod){if(typing&&inputText.length()<24){inputText+=c;return true;}return false;}

    private void addFriend(){
        if(!inputText.trim().isEmpty()){
            FriendManager.add(inputText.trim());
            inputText="";
        }
        typing=false;
    }

    private void txt(DrawContext ctx,MatrixStack ms,String t,float x,float y,Color col,float size,boolean bold){
        var f=bold?Fonts.BOLD:Fonts.MEDIUM;
        if(f!=null){try{DrawHelper.drawText(ms.peek().getPositionMatrix(),f.getFont(size),t,x,y,col);return;}catch(Exception ignored){}}
        int argb=(col.getAlpha()<<24)|(col.getRed()<<16)|(col.getGreen()<<8)|col.getBlue();
        ctx.drawText(MinecraftClient.getInstance().textRenderer,t,(int)x,(int)(y-7),argb,false);
    }
    private float tw(String s,float sz){
        if(Fonts.BOLD!=null)return Fonts.BOLD.getWidth(s,sz);
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }
}
