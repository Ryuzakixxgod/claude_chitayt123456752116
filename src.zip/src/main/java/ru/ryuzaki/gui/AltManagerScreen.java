package ru.ryuzaki.gui;
// src/main/java/ru/ryuzaki/gui/AltManagerScreen.java
// Фикс: используем Session напрямую через правильный reflection в 1.21.4
import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

public class AltManagerScreen extends Screen {
    private final Screen parent;
    private final List<String> accounts = new ArrayList<>();
    private String inputNick = "";
    private boolean inputFocused = false;
    private String status = "";
    private int statusTimer = 0;
    private static final int W=400,H=340;

    public AltManagerScreen(Screen parent) {
        super(Text.literal("Alt Manager"));
        this.parent = parent;
        loadAccounts();
    }

    private boolean isMainMenu() { return MinecraftClient.getInstance().world == null; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);
        MinecraftClient mc = MinecraftClient.getInstance();
        int gx=(width-W)/2, gy=(height-H)/2;

        // Фон
        ctx.fill(gx,gy,gx+W,gy+H,c(8,8,20,248));
        // Радужная рамка
        long t=System.currentTimeMillis();
        for(int i=0;i<W;i++){float f=(float)i/W;int[]cc=hsv((f+t%4000/4000f)%1f,0.7f,1f);ctx.fill(gx+i,gy,gx+i+1,gy+1,c(cc[0],cc[1],cc[2],200));ctx.fill(gx+i,gy+H-1,gx+i+1,gy+H,c(cc[0],cc[1],cc[2],150));}
        ctx.fill(gx,gy,gx+1,gy+H,c(140,40,230,200));ctx.fill(gx+W-1,gy,gx+W,gy+H,c(140,40,230,200));
        // Шапка
        ctx.fill(gx,gy,gx+W,gy+30,c(20,10,42,255));
        String title="★  ALT MANAGER";int[]tc=hsv((t%4000)/4000f,0.8f,1f);
        ctx.drawText(mc.textRenderer,Text.literal(title),gx+(W-mc.textRenderer.getWidth(title))/2,gy+11,c(tc[0],tc[1],tc[2],255),true);

        if(!isMainMenu()){
            String warn="§cДоступно только из главного меню";ctx.drawText(mc.textRenderer,Text.literal(warn),gx+(W-mc.textRenderer.getWidth(warn))/2,gy+H/2-6,0xFFFF5555,false);
            String back="[ Закрыть ]";boolean hov=inB(mx,my,gx+W/2-40,gy+H/2+15,80,20);ctx.fill(gx+W/2-40,gy+H/2+15,gx+W/2+40,gy+H/2+35,hov?c(80,20,150,220):c(40,10,80,200));ctx.drawText(mc.textRenderer,Text.literal(back),gx+(W-mc.textRenderer.getWidth(back))/2,gy+H/2+20,0xFFFFFFFF,false);return;
        }

        ctx.drawText(mc.textRenderer,Text.literal("§7Текущий: §f"+mc.getSession().getUsername()),gx+10,gy+35,0xFFFFFFFF,false);
        int iy=gy+48;
        ctx.fill(gx+10,iy,gx+W-80,iy+16,c(20,18,40,220));ctx.fill(gx+10,iy,gx+W-80,iy+1,c(80,50,140,200));
        String disp=inputNick.isEmpty()?"§8Введи никнейм...":(inputNick+((System.currentTimeMillis()/500)%2==0&&inputFocused?"|":""));
        ctx.drawText(mc.textRenderer,Text.literal(disp),gx+14,iy+4,0xFFFFFFFF,false);
        btn(ctx,mc,"Login",gx+W-75,iy,65,16,inB(mx,my,gx+W-75,iy,65,16));
        btn(ctx,mc,"Random",gx+W-75,iy+20,65,14,inB(mx,my,gx+W-75,iy+20,65,14));
        btn(ctx,mc,"Save",gx+W-75,iy+38,65,14,inB(mx,my,gx+W-75,iy+38,65,14));
        int ly=gy+70;ctx.drawText(mc.textRenderer,Text.literal("§7Сохранённые:"),gx+10,ly,0xFFAAAAAA,false);ly+=12;ctx.fill(gx+10,ly,gx+W-10,gy+H-30,c(14,12,28,200));
        for(int i=0;i<accounts.size();i++){int ay=ly+i*18;if(ay+18>gy+H-30)break;boolean hov=inB(mx,my,gx+10,ay,W-20,18);ctx.fill(gx+10,ay,gx+W-10,ay+18,hov?c(40,25,80,150):0);ctx.drawText(mc.textRenderer,Text.literal("§f"+accounts.get(i)),gx+14,ay+5,0xFFFFFFFF,false);ctx.drawText(mc.textRenderer,Text.literal("§c✗"),gx+W-20,ay+5,0xFFFF5555,false);}
        if(statusTimer>0){ctx.drawText(mc.textRenderer,Text.literal(status),gx+10,gy+H-20,0xFF00FF88,false);statusTimer--;}
    }

    @Override
    public boolean mouseClicked(double mdx,double mdy,int btn){
        int mx=(int)mdx,my=(int)mdy;
        if(!isMainMenu()){int gx=(width-W)/2,gy=(height-H)/2;if(inB(mx,my,gx+W/2-40,gy+height/2+15,80,20))MinecraftClient.getInstance().setScreen(parent);return true;}
        int gx=(width-W)/2,gy=(height-H)/2,iy=gy+48;
        inputFocused=inB(mx,my,gx+10,iy,W-80,16);
        if(btn==0){
            if(inB(mx,my,gx+W-75,iy,65,16)){login(inputNick.isEmpty()?"Player"+(int)(Math.random()*9999):inputNick);return true;}
            if(inB(mx,my,gx+W-75,iy+20,65,14)){String[]n={"Shadow","Void","Ghost","Ryuzaki","Storm","Neon","Cyber","Dark","Nova","Aura"};inputNick=n[(int)(Math.random()*n.length)]+(int)(Math.random()*9999);return true;}
            if(inB(mx,my,gx+W-75,iy+38,65,14)&&!inputNick.isEmpty()){accounts.add(inputNick);saveAccounts();setStatus("§aSaved: "+inputNick);return true;}
            int ly=gy+82;
            for(int i=0;i<accounts.size();i++){int ay=ly+i*18;if(ay+18>gy+H-30)break;if(inB(mx,my,gx+W-22,ay,14,14)){accounts.remove(i);saveAccounts();setStatus("§cRemoved");return true;}if(inB(mx,my,gx+10,ay,W-20,18)){login(accounts.get(i));return true;}}
        }
        return super.mouseClicked(mdx,mdy,btn);
    }

    @Override
    public boolean keyPressed(int k,int s,int m){
        if(k==256){MinecraftClient.getInstance().setScreen(parent);return true;}
        if(inputFocused){if(k==259&&!inputNick.isEmpty())inputNick=inputNick.substring(0,inputNick.length()-1);else if(k==257)login(inputNick.isEmpty()?"Player"+(int)(Math.random()*9999):inputNick);return true;}
        return super.keyPressed(k,s,m);
    }

    @Override
    public boolean charTyped(char ch,int m){
        if(inputFocused&&inputNick.length()<16&&(Character.isLetterOrDigit(ch)||ch=='_')){inputNick+=ch;return true;}
        return false;
    }

    // ФИКС: правильный поиск Session в 1.21.4
    private void login(String nick){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.world!=null){setStatus("§cНедоступно в игре");return;}
        try {
            java.lang.reflect.Field sf=null;
            // Ищем поле типа Session во всей иерархии
            Class<?> clazz=MinecraftClient.class;
            while(clazz!=null&&sf==null){
                for(java.lang.reflect.Field f:clazz.getDeclaredFields()){
                    String typeName=f.getType().getName();
                    if(typeName.contains("Session")){sf=f;break;}
                }
                clazz=clazz.getSuperclass();
            }
            if(sf==null){setStatus("§cSession field not found");return;}
            sf.setAccessible(true);
            Object oldSession=sf.get(mc);
            Class<?> sessionClass=oldSession.getClass();
            // Ищем конструктор Session(String, UUID, String, Optional, AccountType)
            Object newSession=null;
            for(java.lang.reflect.Constructor<?> ctor:sessionClass.getDeclaredConstructors()){
                ctor.setAccessible(true);
                Class<?>[]params=ctor.getParameterTypes();
                if(params.length>=1&&params[0]==String.class){
                    try{
                        Object[]args=new Object[params.length];
                        args[0]=nick;
                        if(params.length>1&&params[1]==java.util.UUID.class)args[1]=java.util.UUID.randomUUID();
                        if(params.length>2&&params[2]==String.class)args[2]="0";
                        for(int i=3;i<params.length;i++){
                            if(params[i]==java.util.Optional.class)args[i]=java.util.Optional.empty();
                            else if(params[i].isEnum())args[i]=params[i].getEnumConstants()[0];
                            else args[i]=null;
                        }
                        newSession=ctor.newInstance(args);
                        break;
                    }catch(Exception ignored){}
                }
            }
            if(newSession!=null){sf.set(mc,newSession);setStatus("§aLogged as: §f"+nick);}
            else{setStatus("§cCould not create session");}
        }catch(Exception e){setStatus("§cError: "+e.getClass().getSimpleName());}
    }

    private void setStatus(String s){status=s;statusTimer=120;}
    private void btn(DrawContext ctx,MinecraftClient mc,String text,int x,int y,int w,int h,boolean hov){ctx.fill(x,y,x+w,y+h,hov?c(100,30,180,220):c(60,20,120,200));ctx.fill(x,y,x+w,y+1,c(140,40,230,180));int tw=mc.textRenderer.getWidth(text);ctx.drawText(mc.textRenderer,Text.literal("§f"+text),x+(w-tw)/2,y+(h-8)/2,0xFFFFFFFF,true);}
    private boolean inB(int mx,int my,int x,int y,int w,int h){return mx>=x&&mx<=x+w&&my>=y&&my<=y+h;}
    private static int c(int r,int g,int b,int a){return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
    private File getFile(){File d=new File(FabricLoader.getInstance().getConfigDir().toFile(),"ryuzaki");d.mkdirs();return new File(d,"alts.json");}
    private void loadAccounts(){try(FileReader fr=new FileReader(getFile())){JsonArray arr=JsonParser.parseReader(fr).getAsJsonArray();for(JsonElement el:arr)accounts.add(el.getAsString());}catch(Exception ignored){}}
    private void saveAccounts(){try(FileWriter fw=new FileWriter(getFile())){JsonArray arr=new JsonArray();for(String a:accounts)arr.add(a);new GsonBuilder().setPrettyPrinting().create().toJson(arr,fw);}catch(Exception ignored){}}
}