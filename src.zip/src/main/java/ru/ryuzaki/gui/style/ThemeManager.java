package ru.ryuzaki.gui.style;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * Placeholder ThemeManager - будет переработан с новой GUI системой.
 */
public class ThemeManager {

    public static ThemeManager INSTANCE = new ThemeManager();
    private String currentThemeName = "Default";

    public static ThemeManager get() {
        return INSTANCE;
    }

    public Color getAccent() {
        return new Color(168, 85, 247); // Purple accent
    }

    public void setTheme(String name) {
        this.currentThemeName = name;
    }

    public String getCurrentThemeName() {
        return currentThemeName;
    }

    public List<Theme> getThemes() {
        return new ArrayList<>();
    }

    public Theme getCurrent() {
        return new Theme("Default", List.of(new Color(168, 85, 247)));
    }

    public static class Theme {
        public String name;
        public List<Color> colors;

        public Theme(String name, List<Color> colors) {
            this.name = name;
            this.colors = colors;
        }
    }
}