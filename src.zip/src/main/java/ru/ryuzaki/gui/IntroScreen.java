package ru.ryuzaki.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.ryuzaki.RyuzakiClient;
import ru.ryuzaki.ui.components.gif.Gif;

/**
 * Loading screen with GIF animation.
 */
public class IntroScreen extends Screen {

    private Gif loadingGif;
    private boolean gifInitialized = false;

    public static volatile boolean resourceReloadInProgress = false;
    public static volatile boolean sessionShown = false;
    public static long introStartTime = 0;

    public IntroScreen() {
        super(Text.literal("Intro"));
        introStartTime = System.currentTimeMillis();
    }

    @Override
    public void init() {
        if (!gifInitialized) {
            int w = MinecraftClient.getInstance().getWindow().getScaledWidth();
            int h = MinecraftClient.getInstance().getWindow().getScaledHeight();
            float gifW = w * 0.8f;
            float gifH = w * 9f / 16f * 0.5f;
            loadingGif = new Gif(RyuzakiClient.id("gifs/loading.gif"), 0, h / 2f - gifH / 2f, w, gifH);
            gifInitialized = true;
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        context.fill(0, 0, width, height, 0xFF000000);
        if (loadingGif != null) {
            loadingGif.update();
            loadingGif.render(context);
        }
        super.render(context, mouseX, mouseY, delta);
    }

    public static boolean shouldShow() {
        long elapsed = System.currentTimeMillis() - introStartTime;
        return elapsed < 5000 && resourceReloadInProgress;
    }
}
