package ru.ryuzaki.module.modules.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

public class FullbrightModule extends Module {
    private final MinecraftClient mc = MinecraftClient.getInstance();
    private final BooleanSetting ночноеЗрение = new BooleanSetting("Ночное Зрение", true);
    private double prevGamma = 1.0;

    public FullbrightModule() {
        super("Fullbright", "Максимальная яркость", Category.PLAYER);
        addSettings(ночноеЗрение);
    }

    @Override
    public void onEnable() {
        if (mc.options != null) {
            prevGamma = mc.options.getGamma().getValue();
            mc.options.getGamma().setValue(100.0);
        }
    }

    @Override
    public void onUpdate() {
        if (mc.player == null) return;
        if (ночноеЗрение.isEnabled()) {
            mc.player.addStatusEffect(
                    new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false)
            );
        }
    }

    @Override
    public void onDisable() {
        if (mc.options != null) mc.options.getGamma().setValue(prevGamma);
        if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
    }
}