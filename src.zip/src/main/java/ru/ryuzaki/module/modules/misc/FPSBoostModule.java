package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

public class FPSBoostModule extends Module {
    private static FPSBoostModule instance;

    public final BooleanSetting fastGraphics    = new BooleanSetting("Fast Graphics",  true);
    public final BooleanSetting noParticles     = new BooleanSetting("No Particles",   true);
    public final BooleanSetting noEntityShadows = new BooleanSetting("No Shadows",     true);
    public final BooleanSetting noBiomeBlend    = new BooleanSetting("No Biome Blend", true);
    public final BooleanSetting noFog           = new BooleanSetting("No Fog",         true);
    public final NumberSetting  entityDist      = new NumberSetting("Entity Dist %",   50, 10, 100, 5);
    public final NumberSetting  chunkDist       = new NumberSetting("Render Distance",  8,  2,  32, 1);

    private GraphicsMode  origGraphics;
    private ParticlesMode origParticles;
    private boolean       origEntityShadows;
    private int           origBiomeBlend;
    private double        origEntityDist;
    private int           origChunkDist;
    private boolean       saved = false;

    public FPSBoostModule() {
        super("FPS Boost", "Real FPS boost — up to 2x", Category.MISC);
        addSettings(fastGraphics, noParticles, noEntityShadows, noBiomeBlend, noFog, entityDist, chunkDist);
        instance = this;
    }

    public static FPSBoostModule getInstance() { return instance; }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        origGraphics      = mc.options.getGraphicsMode().getValue();
        origParticles     = mc.options.getParticles().getValue();
        origEntityShadows = mc.options.getEntityShadows().getValue();
        origBiomeBlend    = mc.options.getBiomeBlendRadius().getValue();
        origEntityDist    = mc.options.getEntityDistanceScaling().getValue();
        origChunkDist     = mc.options.getViewDistance().getValue();
        saved = true;
        apply(mc);
    }

    @Override
    public void onDisable() {
        if (!saved) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        mc.options.getGraphicsMode().setValue(origGraphics);
        mc.options.getParticles().setValue(origParticles);
        mc.options.getEntityShadows().setValue(origEntityShadows);
        mc.options.getBiomeBlendRadius().setValue(origBiomeBlend);
        mc.options.getEntityDistanceScaling().setValue(origEntityDist);
        mc.options.getViewDistance().setValue(origChunkDist);
        mc.options.write();
        if (mc.worldRenderer != null) mc.worldRenderer.reload();
    }

    // onTick убран — настройки не меняются пока модуль включён,
    // применять каждые 60 тиков бессмысленно и жрёт CPU
    private void apply(MinecraftClient mc) {
        if (fastGraphics.isEnabled())    mc.options.getGraphicsMode().setValue(GraphicsMode.FAST);
        if (noParticles.isEnabled())     mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
        if (noEntityShadows.isEnabled()) mc.options.getEntityShadows().setValue(false);
        if (noBiomeBlend.isEnabled())    mc.options.getBiomeBlendRadius().setValue(0);
        mc.options.getEntityDistanceScaling().setValue(entityDist.getValue() / 100.0);
        mc.options.getViewDistance().setValue((int) chunkDist.getValue().doubleValue());
    }
}
