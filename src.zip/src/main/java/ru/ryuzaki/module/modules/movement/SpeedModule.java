package ru.ryuzaki.module.modules.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

public class SpeedModule extends Module {
    public static SpeedModule INSTANCE;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final ModeSetting mode = new ModeSetting("Режим", "Strafe", 
        "Strafe", "Моментальный", "Лодка", "Транспорт", "Watchdog");
    
    public final NumberSetting speed = new NumberSetting("Скорость", 1.0, 0.1, 10.0, 0.1);
    public final NumberSetting strafeMult = new NumberSetting("Strafe Множитель", 1.0, 0.1, 3.0, 0.1);
    public final NumberSetting boost = new NumberSetting("Усиление", 0.1, 0.01, 1.0, 0.01);
    public final NumberSetting groundTimer = new NumberSetting("Таймер Земли", 5, 1, 20, 1);
    
    public final BooleanSetting onGround = new BooleanSetting("На Земле", true);
    public final BooleanSetting airBoost = new BooleanSetting("В Воздухе", true);
    public final BooleanSetting autoJump = new BooleanSetting("Авто Прыжок", false);

    private int groundTicks;
    private double baseSpeed = 0.2873;

    public SpeedModule() {
        super("Speed", "Скорость", Category.MOVEMENT);
        INSTANCE = this;
        addSettings(mode, speed, strafeMult, boost, groundTimer, onGround, airBoost, autoJump);
    }

    @Override
    public void onEnable() { groundTicks = 0; }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        ClientPlayerEntity p = mc.player;
        switch (mode.getCurrent()) {
            case "Strafe" -> handleStrafe(p);
            case "Моментальный" -> handleInstant(p);
            case "Лодка" -> handleBoat(p);
            case "Транспорт" -> handleVehicle(p);
            case "Watchdog" -> handleWatchdog(p);
        }
    }

    private void handleStrafe(ClientPlayerEntity p) {
        boolean onG = p.isOnGround();
        if (onG) {
            groundTicks++;
            if (autoJump.isEnabled() && groundTicks >= groundTimer.getValue().intValue()) p.jump();
        } else {
            groundTicks = 0;
        }
        if (!onG && airBoost.isEnabled()) {
            Vec3d v = p.getVelocity();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            double target = baseSpeed * speed.getValue();
            if (h < target && h > 0.01) p.setVelocity(v.x * target / h, v.y, v.z * target / h);
        }
    }

    private void handleInstant(ClientPlayerEntity p) {
        Vec3d v = p.getVelocity();
        double h = Math.sqrt(v.x * v.x + v.z * v.z);
        double target = baseSpeed * speed.getValue();
        if (h < target * 0.95) {
            float yaw = p.getYaw() * (float)Math.PI / 180f;
            p.addVelocity(-MathHelper.sin(yaw) * Math.min(target - h, boost.getValue()), 0, MathHelper.cos(yaw) * Math.min(target - h, boost.getValue()));
        }
    }

    private void handleBoat(ClientPlayerEntity p) {
        if (!p.hasVehicle()) {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof BoatEntity && p.distanceTo(e) < 3) { p.startRiding(e); break; }
            }
            return;
        }
        Entity v = p.getVehicle();
        if (v instanceof BoatEntity boat) {
            Vec3d vel = boat.getVelocity();
            double target = speed.getValue() * 0.5;
            if (vel.length() < target) {
                float yaw = boat.getYaw() * (float)Math.PI / 180f;
                boat.setVelocity(-MathHelper.sin(yaw) * target, vel.y, MathHelper.cos(yaw) * target);
            }
        }
    }

    private void handleVehicle(ClientPlayerEntity p) {
        if (!p.hasVehicle()) {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof BoatEntity && p.distanceTo(e) < 4) { p.startRiding(e); break; }
            }
            return;
        }
        Entity v = p.getVehicle();
        Vec3d vel = v.getVelocity();
        double h = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
        double target = speed.getValue();
        if (h < target) {
            float yaw = v.getYaw() * (float)Math.PI / 180f;
            v.setVelocity(-MathHelper.sin(yaw) * target, vel.y, MathHelper.cos(yaw) * target);
        }
    }

    private void handleWatchdog(ClientPlayerEntity p) {
        boolean onG = p.isOnGround();
        if (onG) {
            groundTicks++;
            if (autoJump.isEnabled() && groundTicks >= groundTimer.getValue().intValue()) { p.jump(); groundTicks = 0; }
            Vec3d v = p.getVelocity();
            double h = Math.sqrt(v.x * v.x + v.z * v.z);
            if (h < baseSpeed * strafeMult.getValue()) {
                float yaw = p.getYaw() * (float)Math.PI / 180f;
                p.setVelocity(-MathHelper.sin(yaw) * baseSpeed * strafeMult.getValue(), v.y, MathHelper.cos(yaw) * baseSpeed * strafeMult.getValue());
            }
        } else {
            groundTicks = 0;
            if (airBoost.isEnabled()) {
                Vec3d v = p.getVelocity();
                double h = Math.sqrt(v.x * v.x + v.z * v.z);
                if (h > baseSpeed * 0.9) {
                    float yaw = p.getYaw() * (float)Math.PI / 180f;
                    p.addVelocity(-MathHelper.sin(yaw) * boost.getValue() * 0.02, 0, MathHelper.cos(yaw) * boost.getValue() * 0.02);
                }
            }
        }
    }
}
