package ru.ryuzaki.module.modules.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Hand;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * AntiAFK — предотвращает кик за AFK путём периодических действий.
 *
 * Modes:
 *   Rotate — поворачивает камеру туда-обратно (невидимо для других)
 *   Swing  — машет рукой
 *   Sneak  — приседает на мгновение
 */
public class AntiAFKModule extends Module {

    public final NumberSetting  интервал = new NumberSetting("Интервал (с)", 30.0, 5.0, 120.0, 5.0);
    public final ModeSetting    режим    = new ModeSetting("Режим", "Вращение", "Вращение", "Качание", "Крак");

    private long lastAction = 0;
    private int  rotDir     = 1;

    public AntiAFKModule() {
        super("AntiAFK", "Предотвращает кик за бездействие", Category.PLAYER);
        addSettings(интервал, режим);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        long now = System.currentTimeMillis();
        long delay = (long)(интервал.getValue() * 1000);

        if (now - lastAction < delay) return;
        lastAction = now;

        switch (режим.getCurrent()) {
            case "Вращение" -> {
                mc.player.setYaw(mc.player.getYaw() + rotDir * 45f);
                rotDir = -rotDir;
            }
            case "Качание" -> {
                mc.player.swingHand(Hand.MAIN_HAND);
            }
            case "Крак" -> {
                mc.options.sneakKey.setPressed(true);
                // Release next tick via a flag — simplified: just toggle yaw
                mc.player.setYaw(mc.player.getYaw() + 1f);
            }
        }
    }

    @Override public void onDisable() { lastAction = 0; }
}
