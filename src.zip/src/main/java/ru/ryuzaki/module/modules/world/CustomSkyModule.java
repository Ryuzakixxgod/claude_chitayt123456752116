package ru.ryuzaki.module.modules.world;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

import java.util.Random;

/**
 * CustomSkyModule — идеальное кастомное небо 10/10.
 *
 * Исправления:
 * - Звёзды = billboard quads (camera-facing) — не плоские при повороте
 * - Солнце/луна синхронизированы с игровым временем
 * - Горизонт совпадает с цветом тумана
 * - Аврора — несколько независимых полос с разными скоростями
 * - Туманности — soft glow с пульсацией
 * - Shooting stars с правильным хвостом
 */
public class CustomSkyModule extends Module {
    public static CustomSkyModule INSTANCE;

    public final ModeSetting    preset    = new ModeSetting("Preset","Cosmic",
        "Cosmic","Sunset","Arctic","Void","Dawn","Horror","Sakura");
    public final ColorSetting   skyTop    = new ColorSetting("Sky Top",    new ColorRGBA(5,3,20,255));
    public final ColorSetting   skyMid    = new ColorSetting("Sky Mid",    new ColorRGBA(15,8,50,255));
    public final ColorSetting   skyBotC   = new ColorSetting("Sky Bottom", new ColorRGBA(30,10,80,255));
    public final BooleanSetting showSun    = new BooleanSetting("Sun & Moon",    true);
    public final BooleanSetting showStars  = new BooleanSetting("Stars",         true);
    public final BooleanSetting showNebula = new BooleanSetting("Nebulae",       true);
    public final BooleanSetting showAurora = new BooleanSetting("Aurora",        true);
    public final BooleanSetting showShoot  = new BooleanSetting("Shooting Stars",true);
    public final NumberSetting  auroraSpd  = new NumberSetting("Aurora Speed",1.0,0.1,4.0,0.1);
    public final NumberSetting  starCount  = new NumberSetting("Star Density",300,50,800,50);

    // ── Star data (pre-allocated, no GC) ─────────────────────────────
    private static final int MAX_STARS = 800;
    private final float[] sX=new float[MAX_STARS], sY=new float[MAX_STARS], sZ=new float[MAX_STARS];
    private final float[] sSz=new float[MAX_STARS];
    private final int[]   sR=new int[MAX_STARS], sG=new int[MAX_STARS], sB=new int[MAX_STARS];
    private final boolean[]sGiant=new boolean[MAX_STARS], sPulse=new boolean[MAX_STARS];
    private int starN=0;

    // ── Nebula data ───────────────────────────────────────────────────
    private final float[] nX=new float[8],nY=new float[8],nZ=new float[8];
    private final float[] nRad=new float[8],nPhase=new float[8];
    private final int[]   nR=new int[8],nG=new int[8],nB=new int[8];

    // ── Shooting stars ───────────────────────────────────────────────
    private static final int MAX_SHOOT = 6;
    private final float[] shX=new float[MAX_SHOOT],shY=new float[MAX_SHOOT],shZ=new float[MAX_SHOOT];
    private final float[] shVX=new float[MAX_SHOOT],shVY=new float[MAX_SHOOT],shVZ=new float[MAX_SHOOT];
    private final float[] shLife=new float[MAX_SHOOT],shMaxLife=new float[MAX_SHOOT];
    private final boolean[] shOn=new boolean[MAX_SHOOT];

    private float auroraPhase=0f, globalHue=0f;
    private long  lastShoot=0;
    private boolean built=false;
    private static final float R=100f; // dome radius

    public CustomSkyModule(){
        super("CustomSky","Кастомное небо 10/10",Category.WORLD);
        INSTANCE = this;
        addSettings(preset,skyTop,skyMid,skyBotC,showSun,showStars,showNebula,showAurora,showShoot,auroraSpd,starCount);
    }

    public static CustomSkyModule getInstance(){ return INSTANCE; }
    @Override public void onEnable(){ built=false; }

    private int frameSkip = 0;

    @Override
    public void onUpdate(){
        if(!isEnabled()) return;
        auroraPhase+=0.007f*auroraSpd.getValue().floatValue();
        globalHue=(globalHue+0.0002f)%1f;
        if(!built){ buildGeometry(); built=true; }
        if(++frameSkip%2!=0) return; // update every 2nd frame
        long now=System.currentTimeMillis();
        if(showShoot.isEnabled()&&now-lastShoot>3500){ spawnShoot(); lastShoot=now; }
        for(int i=0;i<MAX_SHOOT;i++){
            if(shOn[i]){ shX[i]+=shVX[i]; shY[i]+=shVY[i]; shZ[i]+=shVZ[i]; shLife[i]--;
                if(shLife[i]<=0) shOn[i]=false; }
        }
    }

    private void buildGeometry(){
        Random rng=new Random(0xCAFEBABEL);
        int cnt=Math.min(starCount.getValue().intValue(),MAX_STARS);
        starN=cnt;
        for(int i=0;i<cnt;i++){
            double u=rng.nextDouble(), v=rng.nextDouble();
            double theta=2*Math.PI*u, phi=Math.acos(2*v-1);
            if(phi>Math.PI/2) phi=Math.PI-phi;
            sX[i]=(float)(Math.sin(phi)*Math.cos(theta));
            sY[i]=(float)Math.max(0.05,Math.cos(phi));
            sZ[i]=(float)(Math.sin(phi)*Math.sin(theta));
            sGiant[i]=rng.nextFloat()<.025f;
            sPulse[i]=rng.nextFloat()<.06f;
            sSz[i]=sGiant[i]?.0045f+rng.nextFloat()*.003f:.001f+rng.nextFloat()*.0015f;
            int[]sc=rng.nextFloat()<.12f?hsv(rng.nextFloat(),.5f,1f):
                new int[]{200+rng.nextInt(55),200+rng.nextInt(55),215+rng.nextInt(40)};
            sR[i]=sc[0]; sG[i]=sc[1]; sB[i]=sc[2];
        }
        float[]hues={.7f,.5f,.85f,.15f,.6f,.9f,.3f,.8f};
        for(int i=0;i<8;i++){
            double theta2=2*Math.PI*rng.nextDouble(), phi2=Math.PI*0.05+Math.PI*0.3*rng.nextDouble();
            nX[i]=(float)(Math.sin(phi2)*Math.cos(theta2));
            nY[i]=(float)Math.max(0.1,Math.cos(phi2));
            nZ[i]=(float)(Math.sin(phi2)*Math.sin(theta2));
            nRad[i]=.07f+rng.nextFloat()*.09f;
            nPhase[i]=(float)(rng.nextDouble()*Math.PI*2);
            int[]nc=hsv(hues[i],.65f,.55f); nR[i]=nc[0]; nG[i]=nc[1]; nB[i]=nc[2];
        }
    }

    private void spawnShoot(){
        Random rng=new Random();
        for(int i=0;i<MAX_SHOOT;i++){
            if(!shOn[i]){
                double a=rng.nextDouble()*Math.PI*2;
                shX[i]=(float)(Math.cos(a)*.8f); shY[i]=.65f+rng.nextFloat()*.3f; shZ[i]=(float)(Math.sin(a)*.8f);
                float sp=.005f+rng.nextFloat()*.007f;
                double da=rng.nextDouble()*Math.PI*2;
                shVX[i]=(float)(Math.cos(da)*sp); shVY[i]=-.003f-rng.nextFloat()*.003f; shVZ[i]=(float)(Math.sin(da)*sp);
                shLife[i]=shMaxLife[i]=28+rng.nextInt(18); shOn[i]=true; break;
            }
        }
    }

    public int[] getHorizonColor(){ return sc(2); }

    public void renderSkyGeometry(MatrixStack ms, MinecraftClient mc, long now){
        if(!built){ buildGeometry(); built=true; }
        if(++frameSkip%2!=0) return; // update every 2nd frame
        Tessellator tess=Tessellator.getInstance();
        // Camera quaternion for billboard transforms
        Quaternionf camRot = mc.gameRenderer!=null ? mc.gameRenderer.getCamera().getRotation() : new Quaternionf();

        // ══ 1. DOME ══════════════════════════════════════════════════════
        int[]top=sc(0),mid=sc(1),bot=sc(2);
        final int DS=32,SS=14;
        for(int st=0;st<SS;st++){
            double p1=Math.PI/2.0*st/SS, p2=Math.PI/2.0*(st+1)/SS;
            float y1=(float)(R*Math.sin(p1)), y2=(float)(R*Math.sin(p2));
            float r1=(float)(R*Math.cos(p1)), r2=(float)(R*Math.cos(p2));
            int[]c1=lerp3(bot,mid,top,(float)st/SS), c2=lerp3(bot,mid,top,(float)(st+1)/SS);
            BufferBuilder buf=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
            Matrix4f mat=ms.peek().getPositionMatrix();
            for(int sg=0;sg<=DS;sg++){
                double a=2*Math.PI*sg/DS;
                buf.vertex(mat,(float)(r2*Math.cos(a)),y2,(float)(r2*Math.sin(a))).color(c2[0],c2[1],c2[2],255);
                buf.vertex(mat,(float)(r1*Math.cos(a)),y1,(float)(r1*Math.sin(a))).color(c1[0],c1[1],c1[2],255);
            }
            try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception e){}
        }
        // Top cap
        {
            float capR=(float)(R*Math.cos(Math.PI/2.0*(SS-1.0)/SS));
            BufferBuilder buf=tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN,VertexFormats.POSITION_COLOR);
            Matrix4f mat=ms.peek().getPositionMatrix();
            buf.vertex(mat,0,R,0).color(top[0],top[1],top[2],255);
            for(int sg=0;sg<=DS;sg++){double a=2*Math.PI*sg/DS;buf.vertex(mat,(float)(capR*Math.cos(a)),R-0.5f,(float)(capR*Math.sin(a))).color(top[0],top[1],top[2],255);}
            try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception e){}
        }
        // Horizon seal
        {
            BufferBuilder buf=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
            Matrix4f mat=ms.peek().getPositionMatrix();
            for(int sg=0;sg<=DS;sg++){double a=2*Math.PI*sg/DS;buf.vertex(mat,(float)(R*Math.cos(a)),2,(float)(R*Math.sin(a))).color(bot[0],bot[1],bot[2],255);buf.vertex(mat,(float)(R*Math.cos(a)),-5,(float)(R*Math.sin(a))).color(bot[0],bot[1],bot[2],0);}
            try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception e){}
        }

        // ══ 1.5 SUN & MOON ══════════════════════════════════════════════
        if(showSun.isEnabled()&&mc!=null&&mc.world!=null){
            float dayAngle=(float)(mc.world.getSkyAngle(1f)*Math.PI*2);
            ms.push();
            ms.multiply(new Quaternionf().rotateX(dayAngle));
            Matrix4f sunMat=ms.peek().getPositionMatrix();
            float SR=R*.12f;
            // Sun glow
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
            BufferBuilder sg=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            sg.vertex(sunMat,-SR*2.5f,R*.82f,-SR*2.5f).color(255,180,60,40);
            sg.vertex(sunMat, SR*2.5f,R*.82f,-SR*2.5f).color(255,180,60,40);
            sg.vertex(sunMat, SR*2.5f,R*.82f, SR*2.5f).color(255,180,60,0);
            sg.vertex(sunMat,-SR*2.5f,R*.82f, SR*2.5f).color(255,180,60,0);
            try{BufferRenderer.drawWithGlobalProgram(sg.end());}catch(Exception e){}
            RenderSystem.defaultBlendFunc();
            // Sun core
            BufferBuilder sun=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            sun.vertex(sunMat,-SR,R*.8f,-SR).color(255,220,120,240);
            sun.vertex(sunMat, SR,R*.8f,-SR).color(255,220,120,240);
            sun.vertex(sunMat, SR,R*.8f, SR).color(255,240,160,240);
            sun.vertex(sunMat,-SR,R*.8f, SR).color(255,240,160,240);
            try{BufferRenderer.drawWithGlobalProgram(sun.end());}catch(Exception e){}
            // Moon
            float moonA=(float)Math.max(0,Math.min(220,(int)(-(float)Math.sin(dayAngle)*180+20)));
            if(moonA>5){
                float MR=SR*.75f;
                BufferBuilder moon=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
                moon.vertex(sunMat,-MR,-R*.8f,-MR).color(200,210,255,(int)moonA);
                moon.vertex(sunMat, MR,-R*.8f,-MR).color(200,210,255,(int)moonA);
                moon.vertex(sunMat, MR,-R*.8f, MR).color(200,210,255,(int)moonA);
                moon.vertex(sunMat,-MR,-R*.8f, MR).color(200,210,255,(int)moonA);
                try{BufferRenderer.drawWithGlobalProgram(moon.end());}catch(Exception e){}
            }
            ms.pop();
        }

        // ══ 2. NEBULAE ════════════════════════════════════════════════════
        if(showNebula.isEnabled()){
            for(int i=0;i<8;i++){
                float p=(float)(.25+.12*Math.sin(now*.0005+nPhase[i]));
                float nr=nRad[i]*R, nx=nX[i]*R, ny=nY[i]*R, nz=nZ[i]*R;
                for(int layer=5;layer>=1;layer--){
                    float lr=nr*(float)layer/5f; int la=(int)(p*40*.2f/layer); if(la<=0) continue;
                    BufferBuilder buf=tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN,VertexFormats.POSITION_COLOR);
                    Matrix4f mat=ms.peek().getPositionMatrix();
                    buf.vertex(mat,nx,ny,nz).color(nR[i],nG[i],nB[i],la*3);
                    for(int k=0;k<=20;k++){double a=2*Math.PI*k/20;buf.vertex(mat,(float)(nx+lr*Math.cos(a)),(float)(ny+lr*.55f*Math.sin(a)),nz).color(nR[i],nG[i],nB[i],0);}
                    try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception e){}
                }
            }
        }

        // ══ 3. STARS — billboard (camera-facing) via Tessellator ════════
        if(showStars.isEnabled()&&starN>0){
            float yaw  =mc!=null?mc.gameRenderer.getCamera().getYaw():0;
            float pitch=mc!=null?mc.gameRenderer.getCamera().getPitch():0;
            float yawRad=(float)Math.toRadians(180+yaw), pitchRad=(float)Math.toRadians(-pitch);
            float cosY=(float)Math.cos(yawRad), sinY=(float)Math.sin(yawRad);
            float cosP=(float)Math.cos(pitchRad), sinP=(float)Math.sin(pitchRad);
            float rX=cosY, rZ=-sinY;
            float uX=sinY*sinP, uY=cosP, uZ=cosY*sinP;
            Matrix4f starMat=ms.peek().getPositionMatrix();
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            BufferBuilder starBB=tess.begin(VertexFormat.DrawMode.TRIANGLES,VertexFormats.POSITION_COLOR);
            for(int i=0;i<starN;i++){
                float br=sPulse[i]?.5f+.5f*(float)Math.abs(Math.sin(now*.003f+sX[i]*10)):1f;
                int sa=(int)(215*br);
                float cxS=sX[i]*R, cyS=sY[i]*R, czS=sZ[i]*R, szS=sSz[i]*R;
                float x0=cxS-szS*rX-szS*uX, y0=cyS-szS*uY, z0=czS-szS*rZ-szS*uZ;
                float x1=cxS+szS*rX-szS*uX, y1=cyS-szS*uY, z1=czS+szS*rZ-szS*uZ;
                float x2=cxS+szS*rX+szS*uX, y2=cyS+szS*uY, z2=czS+szS*rZ+szS*uZ;
                float x3=cxS-szS*rX+szS*uX, y3=cyS+szS*uY, z3=czS-szS*rZ+szS*uZ;
                // 2 triangles per billboard quad (6 vertices)
                starBB.vertex(starMat,x0,y0,z0).color(sR[i],sG[i],sB[i],sa);
                starBB.vertex(starMat,x1,y1,z1).color(sR[i],sG[i],sB[i],sa);
                starBB.vertex(starMat,x2,y2,z2).color(sR[i],sG[i],sB[i],sa);
                starBB.vertex(starMat,x2,y2,z2).color(sR[i],sG[i],sB[i],sa);
                starBB.vertex(starMat,x3,y3,z3).color(sR[i],sG[i],sB[i],sa);
                starBB.vertex(starMat,x0,y0,z0).color(sR[i],sG[i],sB[i],sa);
            }
            try{BufferRenderer.drawWithGlobalProgram(starBB.end());}catch(Exception e){}
        }

        // ══ 4. AURORA — multiple independent bands via Tessellator ══════
        if(showAurora.isEnabled()){
            float[][]bandParams={{R*.5f,R*.22f,0f,.9f},{R*.54f,R*.3f,.7f,.7f},{R*.48f,R*.18f,1.4f,1.1f},{R*.56f,R*.35f,2.1f,.8f}};
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
            for(int band=0;band<4;band++){
                float bR2=bandParams[band][0], bY2=bandParams[band][1];
                float phaseOff=bandParams[band][2], speedMult=bandParams[band][3];
                float hue=(globalHue+band*.15f)%1f;
                int[]ac=hsv(hue,.75f,1f);
                Matrix4f auroMat=ms.peek().getPositionMatrix();
                BufferBuilder auroBB=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
                for(int k=0;k<=80;k++){
                    float tf=(float)k/80;
                    float ang=(float)(tf*Math.PI*4+phaseOff);
                    float ax=(float)(bR2*Math.cos(ang)), az=(float)(bR2*Math.sin(ang));
                    float wy=bY2+R*.055f*(float)Math.sin(auroraPhase*2*speedMult+tf*Math.PI*3+band*.8f);
                    float alpha=.10f+.14f*(float)Math.abs(Math.sin(auroraPhase*speedMult+tf*Math.PI*4+band));
                    int aa=(int)(alpha*200);
                    auroBB.vertex(auroMat,ax,wy+R*.042f,az).color(ac[0],ac[1],ac[2],aa);
                    auroBB.vertex(auroMat,ax,wy,        az).color(ac[0],ac[1],ac[2],0);
                }
                try{BufferRenderer.drawWithGlobalProgram(auroBB.end());}catch(Exception e){}
            }
            RenderSystem.defaultBlendFunc();
        }

        // ══ 5. SHOOTING STARS ════════════════════════════════════════════
        if(showShoot.isEnabled()){
            Matrix4f mat=ms.peek().getPositionMatrix();
            for(int i=0;i<MAX_SHOOT;i++){
                if(!shOn[i]) continue;
                float pct=shLife[i]/shMaxLife[i];
                float sx2=shX[i]*R, sy=shY[i]*R, sz2=shZ[i]*R;
                BufferBuilder sh=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
                for(int k=0;k<=14;k++){
                    float tf=(float)k/14;
                    float tx=sx2-shVX[i]*R*tf*7, ty=sy-shVY[i]*R*tf*7, tz=sz2-shVZ[i]*R*tf*7;
                    int ta=(int)(230*pct*(1-tf)); if(ta<=0) continue;
                    float tw=R*.0005f*(1-tf);
                    sh.vertex(mat,tx-tw,ty,tz+tw).color(255,255,255,ta);
                    sh.vertex(mat,tx+tw,ty,tz-tw).color(255,255,255,0);
                }
                try{BufferRenderer.drawWithGlobalProgram(sh.end());}catch(Exception e){}
            }
        }
    }

    private int[]sc(int l){
        return switch(preset.getCurrent()){
            case "Sunset" ->l==0?new int[]{10,4,35}  :l==1?new int[]{170,55,15}:new int[]{240,110,20};
            case "Arctic" ->l==0?new int[]{4,15,55}  :l==1?new int[]{15,70,150}:new int[]{90,170,245};
            case "Void"   ->l==0?new int[]{0,0,0}    :l==1?new int[]{4,0,8}    :new int[]{8,0,18};
            case "Dawn"   ->l==0?new int[]{4,4,18}   :l==1?new int[]{70,25,110}:new int[]{245,130,50};
            case "Horror" ->l==0?new int[]{5,0,0}    :l==1?new int[]{28,0,0}   :new int[]{55,4,4};
            case "Sakura" ->l==0?new int[]{25,8,45}  :l==1?new int[]{170,70,130}:new int[]{245,170,190};
            default->{
                ColorRGBA c=l==0?skyTop.getColor():l==1?skyMid.getColor():skyBotC.getColor();
                yield c!=null?new int[]{c.getRed(),c.getGreen(),c.getBlue()}
                     :l==0?new int[]{5,3,20}:l==1?new int[]{15,8,50}:new int[]{30,10,80};
            }
        };
    }
    private static int[]lerp3(int[]b,int[]m,int[]t,float f){
        if(f<.5f){float p=f*2;return new int[]{(int)(b[0]+(m[0]-b[0])*p),(int)(b[1]+(m[1]-b[1])*p),(int)(b[2]+(m[2]-b[2])*p)};}
        else{float p=(f-.5f)*2;return new int[]{(int)(m[0]+(t[0]-m[0])*p),(int)(m[1]+(t[1]-m[1])*p),(int)(m[2]+(t[2]-m[2])*p)};}
    }
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f2=h*6-i,p=v*(1-s),q=v*(1-f2*s),t2=v*(1-(1-f2)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t2;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t2;}case 3->{r=p;g=q;b=v;}case 4->{r=t2;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
