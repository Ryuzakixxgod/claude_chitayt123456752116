package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * 🚀 Chunk Optimizer — снижает нагрузку от чанков.
 *
 * - Снижает render distance (основной источник FPS потерь)
 * - Снижает simulation distance
 * - Опционально: снижает при падении FPS (adaptive)
 *
 * При выключении восстанавливает оригинал.
 */
public class ChunkOptimizerModule extends Module {
    private static ChunkOptimizerModule instance;

    public final NumberSetting  renderDist    = new NumberSetting("Render Distance", 8, 2, 16, 1);
    public final NumberSetting  simDist       = new NumberSetting("Sim Distance",    5, 3, 12, 1);
    public final BooleanSetting adaptive      = new BooleanSetting("Adaptive (auto)", true);
    public final NumberSetting  targetFPS     = new NumberSetting("Target FPS", 60, 30, 120, 5);

    private int origRender = -1, origSim = -1;
    private int adaptiveTick = 0;

    public ChunkOptimizerModule() {
        super("Chunk Optimizer", "Reduce chunk render (+FPS)", Category.MISC);
        addSettings(renderDist, simDist, adaptive, targetFPS);
        instance = this;
    }

    public static ChunkOptimizerModule getInstance() { return instance; }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        origRender = mc.options.getViewDistance().getValue();
        origSim    = mc.options.getSimulationDistance().getValue();
        apply(mc, renderDist.getValue().intValue(), simDist.getValue().intValue());
    }

    @Override
    public void onDisable() {
        if (origRender < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        mc.options.getViewDistance().setValue(origRender);
        mc.options.getSimulationDistance().setValue(origSim);
        mc.options.write();
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;

        adaptiveTick++;
        if (adaptiveTick % 20 != 0) return; // раз в секунду

        if (adaptive.isEnabled()) {
            int currentFps = mc.getCurrentFps();
            int target = targetFPS.getValue().intValue();
            int currentDist = mc.options.getViewDistance().getValue();

            if (currentFps < target - 10 && currentDist > 2) {
                // FPS низкий — снижаем
                apply(mc, Math.max(2, currentDist - 1), Math.max(3, simDist.getValue().intValue() - 1));
            } else if (currentFps > target + 20 && currentDist < renderDist.getValue().intValue()) {
                // FPS высокий — повышаем
                apply(mc, Math.min(renderDist.getValue().intValue(), currentDist + 1),
                          simDist.getValue().intValue());
            }
        } else {
            apply(mc, renderDist.getValue().intValue(), simDist.getValue().intValue());
        }
    }

    private void apply(MinecraftClient mc, int rd, int sd) {
        mc.options.getViewDistance().setValue(rd);
        mc.options.getSimulationDistance().setValue(sd);
    }
}
