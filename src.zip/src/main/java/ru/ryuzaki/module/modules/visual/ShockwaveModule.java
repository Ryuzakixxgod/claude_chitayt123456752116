package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/ShockwaveModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.util.RyuzakiRenderCache;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ShockwaveModule extends Module {
    public final ModeSetting   style    = new ModeSetting("Style","Cosmic","Cosmic","Energy","Thunder","Void","Sakura","Fire");
    public final NumberSetting maxSize  = new NumberSetting("Max Size",  3.5, 0.5, 8.0, 0.5);
    public final NumberSetting speed    = new NumberSetting("Speed",     1.8, 0.5, 5.0, 0.5);
    public final BooleanSetting multi   = new BooleanSetting("Multi Ring", true);
    public final BooleanSetting tilt    = new BooleanSetting("Tilt",      true);
    public final BooleanSetting sparks  = new BooleanSetting("Sparks",    true);

    private static class Wave {
        Vec3d pos; float radius,maxRadius,life,maxLife;
        int idx; // индекс для цвета
        Wave(Vec3d p,float maxR,float life,int idx){pos=p;radius=0;maxRadius=maxR;this.life=this.maxLife=life;this.idx=idx;}
        void update(float spd){float progress=(1f-life/maxLife);radius=maxRadius*(float)Math.sqrt(progress);life-=spd*0.8f;}
    }
    private static class Spark {
        double x,y,z,vx,vy,vz; float life,maxLife,size; int r,g,b;
        Spark(double x,double y,double z,double vx,double vy,double vz,float life,int r,int g,int b){this.x=x;this.y=y;this.z=z;this.vx=vx;this.vy=vy;this.vz=vz;this.life=this.maxLife=life;this.r=r;this.g=g;this.b=b;size=0.05f;}
        void update(){x+=vx;y+=vy;z+=vz;vy-=0.004;life--;}
    }

    private final List<Wave>  waves  = new ArrayList<>();
    private final List<Spark> sparklst = new ArrayList<>();
    private final java.util.Random rng = new java.util.Random();
    private boolean wasOnGround = false;

    // Статические цвета — ноль new int[] в getWaveColor()
    private static final int[] C_ENERGY  = {50,  220, 255};
    private static final int[] C_THUNDER = {255, 240, 50};
    private static final int[] C_VOID    = {120, 0,   200};
    // Переиспользуемый буфер для hsv стилей
    private final int[] waveColorBuf = new int[3];

    public ShockwaveModule() {
        super("Shockwave", "Ударная волна при прыжке", Category.VISUAL);
        addSettings(style, maxSize, speed, multi, tilt, sparks);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        boolean onGround = mc.player.isOnGround();
        if (wasOnGround && !onGround) spawn(mc.player.getPos());
        wasOnGround = onGround;
    }

    @Override public void onDisable() { waves.clear(); sparklst.clear(); }

    public void onAttack() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) spawn(mc.player.getPos());
    }

    private void spawn(Vec3d pos) {
        float maxR = maxSize.getValue().floatValue();
        waves.add(new Wave(pos, maxR, 35, 0));
        if (multi.isEnabled()) {
            waves.add(new Wave(new Vec3d(pos.x,pos.y+0.02,pos.z), maxR*0.65f, 28, 1));
            waves.add(new Wave(new Vec3d(pos.x,pos.y+0.04,pos.z), maxR*0.35f, 20, 2));
        }
        if (sparks.isEnabled()) {
            int[] c = getWaveColor(0);
            for (int i = 0; i < 24; i++) {
                double ang = i*Math.PI/12;
                double spd = 0.06+rng.nextDouble()*0.08;
                sparklst.add(new Spark(pos.x,pos.y+0.05,pos.z, Math.cos(ang)*spd,0.04+rng.nextDouble()*0.06,Math.sin(ang)*spd, 20+rng.nextInt(15), c[0],c[1],c[2]));
            }
        }
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled()||(waves.isEmpty()&&sparklst.isEmpty())) return;
        Vec3d cam=ctx.camera().getPos();
        MatrixStack ms=ctx.matrixStack();if(ms==null)return;
        ms.push();ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.disableDepthTest();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();
        float spd=speed.getValue().floatValue();

        Iterator<Wave> wi=waves.iterator();
        while(wi.hasNext()){
            Wave w=wi.next();w.update(spd);if(w.life<=0){wi.remove();continue;}
            float pct=w.life/w.maxLife;
            float alphaMult=(float)Math.sin(pct*Math.PI); // нарастает потом убывает
            int[] c=getWaveColor(w.idx);
            int SEGS=64;

            // Наклон волны
            float tiltX = tilt.isEnabled() ? (float)(0.15f*Math.sin(w.life*0.3f)) : 0f;
            float tiltZ = tilt.isEnabled() ? (float)(0.15f*Math.cos(w.life*0.25f)) : 0f;

            // Glow (несколько колец с нарастающим радиусом)
            for(int gl=5;gl>=1;gl--){
                float gr=w.radius*(1f+gl*0.035f);
                int ga=(int)(180*alphaMult*0.12f/gl);
                drawEllipse(tess,mat,w.pos,gr,gr*0.12f,tiltX,tiltZ,c[0],c[1],c[2],ga,SEGS,true);
            }
            // Заполненный диск (прозрачный центр)
            drawFilledRing(tess,mat,w.pos,w.radius,w.radius*0.3f,tiltX,tiltZ,c[0],c[1],c[2],(int)(60*alphaMult),SEGS);
            // Основная линия
            drawEllipse(tess,mat,w.pos,w.radius,w.radius*0.12f,tiltX,tiltZ,c[0],c[1],c[2],(int)(255*alphaMult),SEGS,false);
            // Бегущие искры по кольцу
            for(int s=0;s<4;s++){
                double sparkAng=Math.PI*2*(float)s/4+(w.life*0.15f);
                float sx=(float)(w.pos.x+w.radius*Math.cos(sparkAng));
                float sy=(float)(w.pos.y+w.radius*tiltX);
                float sz=(float)(w.pos.z+w.radius*Math.sin(sparkAng));
                int[] sc=getWaveColor((w.idx+s)%3);
                for(int gl=3;gl>=1;gl--){float gd=0.06f*gl;BufferBuilder sb=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);sb.vertex(mat,sx-gd,sy-gd,sz).color(sc[0],sc[1],sc[2],(int)(200*alphaMult*0.3f/gl));sb.vertex(mat,sx+gd,sy-gd,sz).color(sc[0],sc[1],sc[2],(int)(200*alphaMult*0.3f/gl));sb.vertex(mat,sx+gd,sy+gd,sz).color(sc[0],sc[1],sc[2],0);sb.vertex(mat,sx-gd,sy+gd,sz).color(sc[0],sc[1],sc[2],0);try{BufferRenderer.drawWithGlobalProgram(sb.end());}catch(Exception ignored){}}
            }
        }

        // Искры
        if(!sparklst.isEmpty()){
            Iterator<Spark> si=sparklst.iterator();
            BufferBuilder pb=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            boolean hv=false;
            while(si.hasNext()){Spark s=si.next();s.update();if(s.life<=0){si.remove();continue;}float pct=s.life/s.maxLife;int sa=(int)(200*pct);float sz=s.size*pct;pb.vertex(mat,(float)s.x-sz,(float)s.y-sz,(float)s.z).color(s.r,s.g,s.b,sa);pb.vertex(mat,(float)s.x+sz,(float)s.y-sz,(float)s.z).color(s.r,s.g,s.b,sa);pb.vertex(mat,(float)s.x+sz,(float)s.y+sz,(float)s.z).color(s.r,s.g,s.b,0);pb.vertex(mat,(float)s.x-sz,(float)s.y+sz,(float)s.z).color(s.r,s.g,s.b,0);hv=true;}
            if(hv)try{BufferRenderer.drawWithGlobalProgram(pb.end());}catch(Exception e){try{pb.end();}catch(Exception ignored){}}else try{pb.end();}catch(Exception ignored){}
        }

        ms.pop();
        RenderSystem.enableDepthTest();RenderSystem.enableCull();RenderSystem.disableBlend();
    }

    private void drawEllipse(Tessellator tess,Matrix4f mat,Vec3d pos,float rx,float ry,float tx,float tz,int r,int g,int b,int a,int segs,boolean fat){
        BufferBuilder buf=tess.begin(fat?VertexFormat.DrawMode.TRIANGLE_STRIP:VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
        for(int i=0;i<=segs;i++){double ang=2*Math.PI*i/segs;float fx=(float)(pos.x+rx*Math.cos(ang));float fz=(float)(pos.z+rx*Math.sin(ang));float fy=(float)(pos.y+ry*Math.sin(ang));if(fat){buf.vertex(mat,fx,fy,fz).color(r,g,b,a);buf.vertex(mat,fx,fy*(1+0.1f),fz).color(r,g,b,0);}else buf.vertex(mat,fx,fy+tx,fz+tz).color(r,g,b,a);}
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }
    private void drawFilledRing(Tessellator tess,Matrix4f mat,Vec3d pos,float outer,float inner,float tx,float tz,int r,int g,int b,int a,int segs){
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
        for(int i=0;i<=segs;i++){double ang=2*Math.PI*i/segs;float c=(float)Math.cos(ang),s=(float)Math.sin(ang);buf.vertex(mat,(float)pos.x+outer*c,(float)pos.y+tx,(float)pos.z+outer*s).color(r,g,b,a);buf.vertex(mat,(float)pos.x+inner*c,(float)pos.y+tx,(float)pos.z+inner*s).color(r,g,b,0);}
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }
    /** Записывает цвет в waveColorBuf — ноль new int[] */
    private int[] getWaveColor(int idx){
        float baseHue = (float)(RyuzakiRenderCache.now % 5000) / 5000f;
        switch(style.getCurrent()){
            case "Energy"  -> { return C_ENERGY;  }
            case "Thunder" -> { return C_THUNDER; }
            case "Void"    -> { return C_VOID;    }
            case "Sakura"  -> RyuzakiRenderCache.hsvFill(0.92f+idx*0.03f, 0.5f, 1f, waveColorBuf);
            case "Fire"    -> RyuzakiRenderCache.hsvFill(0.06f-idx*0.03f, 1f,   1f, waveColorBuf);
            default        -> RyuzakiRenderCache.hsvFill((baseHue+idx*0.12f)%1f, 0.8f, 1f, waveColorBuf);
        }
        return waveColorBuf;
    }
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}