package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import net.minecraft.text.Text;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

public class AntiLagModule extends Module {

    public final NumberSetting  fpsThreshold  = new NumberSetting("FPS Threshold",   60, 20, 240, 5);
    public final NumberSetting  reactTicks    = new NumberSetting("React Delay (t)",  10,  2,  40, 1);
    public final NumberSetting  recoverTicks  = new NumberSetting("Recover Delay (t)",80, 20, 200, 10);
    public final BooleanSetting dropParticles = new BooleanSetting("Drop Particles",  true);
    public final BooleanSetting dropRenderDist= new BooleanSetting("Drop Render Dist",true);
    public final BooleanSetting dropGraphics  = new BooleanSetting("Drop Graphics",   true);
    public final BooleanSetting dropShadows   = new BooleanSetting("Drop Shadows",    true);
    public final BooleanSetting chatNotify    = new BooleanSetting("Chat Notify",     false);

    private boolean       lagMode  = false;
    private int           lagTimer = 0, okTimer = 0;

    // Храним ParticlesMode напрямую — не int
    private GraphicsMode  savedGraphics;
    private ParticlesMode savedParticles;
    private int           savedRenderDist;
    private boolean       savedShadows;

    public AntiLagModule() {
        super("Anti Lag", "Auto quality drop on FPS spike", Category.MISC);
        addSettings(fpsThreshold, reactTicks, recoverTicks,
                dropParticles, dropRenderDist, dropGraphics, dropShadows, chatNotify);
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null || mc.player == null) return;

        int fps = mc.getCurrentFps();
        int thr = fpsThreshold.getValue().intValue();

        if (fps < thr) {
            okTimer = 0;
            if (++lagTimer >= reactTicks.getValue().intValue() && !lagMode) enterLag(mc);
        } else {
            lagTimer = 0;
            if (++okTimer >= recoverTicks.getValue().intValue() && lagMode) exitLag(mc);
        }
    }

    private void enterLag(MinecraftClient mc) {
        lagMode = true;
        savedGraphics   = mc.options.getGraphicsMode().getValue();
        savedParticles  = mc.options.getParticles().getValue();
        savedRenderDist = mc.options.getViewDistance().getValue();
        savedShadows    = mc.options.getEntityShadows().getValue();

        if (dropGraphics.isEnabled())    mc.options.getGraphicsMode().setValue(GraphicsMode.FAST);
        if (dropParticles.isEnabled())   mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
        if (dropShadows.isEnabled())     mc.options.getEntityShadows().setValue(false);
        if (dropRenderDist.isEnabled())  mc.options.getViewDistance().setValue(Math.max(4, savedRenderDist - 4));

        if (chatNotify.isEnabled())
            mc.player.sendMessage(Text.literal("§d[Ryuzaki] §cAntiLag активирован"), true);
    }

    private void exitLag(MinecraftClient mc) {
        lagMode = false; okTimer = 0;
        // Восстанавливаем напрямую — без byId
        mc.options.getGraphicsMode().setValue(savedGraphics);
        mc.options.getParticles().setValue(savedParticles);
        mc.options.getEntityShadows().setValue(savedShadows);
        if (dropRenderDist.isEnabled()) mc.options.getViewDistance().setValue(savedRenderDist);

        if (chatNotify.isEnabled() && mc.player != null)
            mc.player.sendMessage(Text.literal("§d[Ryuzaki] §aAntiLag деактивирован"), true);
    }

    @Override
    public void onDisable() {
        if (lagMode) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.options != null) exitLag(mc);
        }
        lagTimer = okTimer = 0;
    }
}