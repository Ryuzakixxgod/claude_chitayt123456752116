package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import ru.ryuzaki.render.NativeGL;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.FriendManager;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.awt.Color;
import java.util.*;

public class VisualRangeModule extends Module {
    // Pre-allocated colors
    private static final Color VR_ENTER = new java.awt.Color(34,197,94,220);
    private static final Color VR_LEAVE = new java.awt.Color(239,68,68,220);
    private static final Color VR_TEXT  = new java.awt.Color(237,232,255,200);
    private static final Color VR_DIST  = new java.awt.Color(150,140,180,160);
    private static final Color VR_BG    = new java.awt.Color(0,0,0,120);

    public final BooleanSetting soundAlert = new BooleanSetting("Sound Alert",  true);
    public final BooleanSetting hudList    = new BooleanSetting("HUD List",     true);
    public final NumberSetting  alertRange = new NumberSetting("Alert Range", 30.0, 5.0, 64.0, 5.0);

    private final Set<UUID>    knownPlayers = new HashSet<>();
    private final Map<UUID,Float> fadeMap  = new LinkedHashMap<>();
    private float hue=0f, ringRot=0f;
    private float hudAlpha=0f;

    public VisualRangeModule() {
        super("VisualRange","Оповещение о входе игроков",Category.VISUAL);
        addSettings(soundAlert,hudList,alertRange);
    }

    @Override public void onTick() {
        if (!isEnabled()) return;
        hue=(hue+0.002f)%1f;
        ringRot=(ringRot+1.2f)%360f;
        MinecraftClient mc=MinecraftClient.getInstance();
        if (mc.world==null||mc.player==null) return;

        double range=alertRange.getValue();
        Set<UUID> current=new HashSet<>();

        for (PlayerEntity p:mc.world.getPlayers()) {
            if (p==mc.player) continue;
            if (mc.player.distanceTo(p)<=range) current.add(p.getUuid());
        }

        // Enter alerts
        for (UUID id:current) {
            if (!knownPlayers.contains(id)) {
                mc.world.getPlayers().stream().filter(p->p.getUuid().equals(id)).findFirst().ifPresent(p->{
                    if (soundAlert.isEnabled()&&mc.player!=null)
                        mc.player.playSound(net.minecraft.sound.SoundEvents.BLOCK_NOTE_BLOCK_PLING.value(),0.5f,1.4f);
                    fadeMap.put(id,1.2f); // slight overshoot
                });
            }
        }

        // Fade out players that left
        Iterator<Map.Entry<UUID,Float>> it=fadeMap.entrySet().iterator();
        while (it.hasNext()) {
            var e=it.next();
            if (!current.contains(e.getKey())) {
                e.setValue(e.getValue()-0.04f);
                if (e.getValue()<=0) it.remove();
            } else {
                e.setValue(Math.min(1f,e.getValue()+0.08f));
            }
        }
        // Ensure all current players have entry
        for (UUID id:current) fadeMap.putIfAbsent(id,0.01f);

        knownPlayers.clear();
        knownPlayers.addAll(current);

        float targetHud=knownPlayers.isEmpty()?0f:1f;
        hudAlpha+=( targetHud-hudAlpha)*0.06f;
    }

    /** 3D кольцо на земле — вызывается из MixinGameRenderer */
    public void renderHud(DrawContext ctx) {
        if (!isEnabled()||!hudList.isEnabled()) return;
        if (hudAlpha<0.02f||knownPlayers.isEmpty()) return;

        MinecraftClient mc=MinecraftClient.getInstance();
        if (mc.player==null||mc.world==null) return;

        MatrixStack ms=ctx.getMatrices();
        List<PlayerEntity> inRange=new ArrayList<>();
        for (PlayerEntity p:mc.world.getPlayers()) {
            if (p==mc.player) continue;
            if (knownPlayers.contains(p.getUuid())) inRange.add(p);
        }
        if (inRange.isEmpty()) return;

        float W=160f;
        float cardH=22f, gap=4f;
        float totalH=16f+inRange.size()*(cardH+gap)+4f;
        float x=6, y=mc.getWindow().getScaledHeight()/2f-totalH/2f;
        int a=(int)(hudAlpha*255);

        // Panel bg
        DrawHelper.drawRect(ms,x,y,W,totalH,8,new Color(6,4,14,(int)(230*hudAlpha)));
        DrawHelper.drawRect(ms,x,y,3,totalH,8,new Color(RyuzakiRenderCache.rgb1[0],RyuzakiRenderCache.rgb1[1],RyuzakiRenderCache.rgb1[2],(int)(200*hudAlpha)));
        DrawHelper.drawOutline(ms,x,y,W,totalH,8,new Color(255,255,255,(int)(12*hudAlpha)),1f);

        // Header
        drawT(ctx,"RANGE  "+inRange.size(),x+10,y+6,new Color(RyuzakiRenderCache.rgb1[0],RyuzakiRenderCache.rgb1[1],RyuzakiRenderCache.rgb1[2],a),9f,true);

        float cy=y+18;
        for (PlayerEntity p:inRange) {
            float fa=Math.min(1f,fadeMap.getOrDefault(p.getUuid(),0f));
            int ea=(int)(fa*a);
            if (ea<4) {cy+=cardH+gap;continue;}
            boolean friend=FriendManager.isFriend(p.getName().getString());
            int[]col=friend?new int[]{34,197,94}:RyuzakiRenderCache.rgb1;

            DrawHelper.drawRect(ms,x+6,cy,W-12,cardH,5,new Color(col[0],col[1],col[2],(int)(15*fa*hudAlpha)));
            DrawHelper.drawOutline(ms,x+6,cy,W-12,cardH,5,new Color(col[0],col[1],col[2],(int)(35*fa*hudAlpha)),1f);

            // HP bar micro
            float hp=p.getHealth()/p.getMaxHealth();
            float hpW=(W-12-10)*hp;
            DrawHelper.drawRect(ms,x+8,cy+cardH-4,(W-12-4),2,1,new Color(255,255,255,(int)(20*fa*hudAlpha)));
            Color hpC=hp>.5f?new Color(34,197,94):hp>.25f?new Color(234,179,8):new Color(239,68,68);
            DrawHelper.drawRect(ms,x+8,cy+cardH-4,hpW,2,1,new Color(hpC.getRed(),hpC.getGreen(),hpC.getBlue(),(int)(160*fa*hudAlpha)));

            // Name
            String name=p.getName().getString();
            drawT(ctx,(friend?"♥ ":"")+name,x+10,cy+5,new Color(col[0],col[1],col[2],ea),9.5f,false);
            // Distance
            String dist=String.format("%.0fm",mc.player.distanceTo(p));
            float dw=textW(dist,8.5f);
            drawT(ctx,dist,x+W-12-dw-2,cy+6,new Color(100,90,120,ea),8.5f,false);
            cy+=cardH+gap;
        }
    }

    private void drawT(DrawContext ctx,String text,float x,float y,Color col,float size,boolean bold){
        var f=bold?Fonts.BOLD:Fonts.MEDIUM;
        if(f!=null){try{DrawHelper.drawText(ctx.getMatrices().peek().getPositionMatrix(),f.getFont(size),text,x,y,col);return;}catch(Exception ignored){}}
        int argb=(col.getAlpha()<<24)|(col.getRed()<<16)|(col.getGreen()<<8)|col.getBlue();
        ctx.drawText(MinecraftClient.getInstance().textRenderer,text,(int)x,(int)(y-7),argb,false);
    }
    private float textW(String s,float sz){if(Fonts.BOLD!=null)return Fonts.BOLD.getWidth(s,sz);return MinecraftClient.getInstance().textRenderer.getWidth(s);}
    private double lerp(double a,double b,float t){return a+(b-a)*t;}
}
