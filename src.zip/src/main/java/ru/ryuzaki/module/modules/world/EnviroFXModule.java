package ru.ryuzaki.module.modules.world;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * EnviroFX — атмосферные эффекты биомов с плавными переходами.
 *
 * Улучшения:
 * - Плавный lerp при смене биома (не резкий прыжок)
 * - Высотный туман с градиентом (не линейный)
 * - Реакция на время суток (темнее ночью)
 * - Эффект при нырянии в воду
 */
public class EnviroFXModule extends Module {
    private static EnviroFXModule instance;

    public final BooleanSetting biomeTint  = new BooleanSetting("Biome Tint",  true);
    public final BooleanSetting heightFog  = new BooleanSetting("Height Fog",  true);
    public final BooleanSetting nightDark  = new BooleanSetting("Night Dark",  true);
    public final BooleanSetting waterTint  = new BooleanSetting("Water Tint",  true);
    public final NumberSetting  opacity    = new NumberSetting("Opacity",  15, 3, 50, 1);

    // Smooth transition state
    private float tR=0, tG=0, tB=0, tA=0; // current tint (animated)
    // Biome cache — update every 40 frames not every render
    private String cachedBiome = "";
    private int    biomeTimer  = 0;
    private float hA=0; // height fog alpha (animated)
    private float nA=0; // night darkness (animated)
    private float wA=0; // water tint (animated)
    private String lastBiome = "";

    public EnviroFXModule() {
        super("EnviroFX","Atmospheric biome effects — плавные переходы",Category.WORLD);
        addSettings(biomeTint, heightFog, nightDark, waterTint, opacity);
        instance = this;
    }

    public static EnviroFXModule getInstance(){ return instance; }

    @Override public void onEnable(){ tR=tG=tB=tA=hA=nA=wA=0; lastBiome=""; }

    public void render(DrawContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player==null||mc.world==null) return;

        int sw=mc.getWindow().getScaledWidth(), sh=mc.getWindow().getScaledHeight();
        float spd=0.018f; // lerp speed
        float maxOp=opacity.getValue().intValue()/255f;

        // ── Biome tint ────────────────────────────────────────────────
        if (biomeTint.isEnabled()) {
            // Throttle expensive biome lookup to every 40 frames
            if (++biomeTimer >= 40) {
                biomeTimer = 0;
                cachedBiome = mc.world.getBiome(mc.player.getBlockPos())
                    .getKey().map(k->k.getValue().toString()).orElse("");
            }
            String biomeId = cachedBiome;

            float tr=0,tg=0,tb=0,ta=0;
            if (biomeId.contains("desert")||biomeId.contains("badlands"))
                { tr=1f; tg=0.55f; tb=0.16f; ta=maxOp; }
            else if (biomeId.contains("jungle"))
                { tr=0.12f; tg=0.7f; tb=0.12f; ta=maxOp*0.6f; }
            else if (biomeId.contains("ice")||biomeId.contains("snowy")||biomeId.contains("frozen"))
                { tr=0.59f; tg=0.82f; tb=1f; ta=maxOp; }
            else if (biomeId.contains("swamp"))
                { tr=0.24f; tg=0.47f; tb=0.16f; ta=maxOp*0.7f; }
            else if (biomeId.contains("mushroom"))
                { tr=0.8f; tg=0.2f; tb=0.8f; ta=maxOp*0.4f; }
            else if (biomeId.contains("lush_caves"))
                { tr=0.1f; tg=0.9f; tb=0.3f; ta=maxOp*0.5f; }
            else if (biomeId.contains("deep_dark"))
                { tr=0f; tg=0f; tb=0.05f; ta=maxOp*1.5f; }

            tR=lerp(tR,tr,spd); tG=lerp(tG,tg,spd);
            tB=lerp(tB,tb,spd); tA=lerp(tA,ta,spd);

            if (tA > 0.002f)
                ctx.fill(0,0,sw,sh, rgba((int)(tR*255),(int)(tG*255),(int)(tB*255),(int)(tA*255)));
        } else { tA=lerp(tA,0,spd*2); }

        // ── Height fog ────────────────────────────────────────────────
        if (heightFog.isEnabled()) {
            double y=mc.player.getY();
            float target=0;
            if (y>100)      target=(float)Math.min(1,(y-100)/120.0)*maxOp*2.5f;
            else if (y<30)  target=(float)Math.min(1,(30-y)/60.0)*maxOp*1.5f; // подземный туман
            hA=lerp(hA,target,spd);
            if (hA>0.003f) {
                int hr,hg,hb;
                if (y>100){ hr=220;hg=235;hb=255; }       // горный туман — голубоватый
                else      { hr=20; hg=15; hb=10;  }       // подземный — тёмный
                ctx.fill(0,0,sw,sh,rgba(hr,hg,hb,(int)(hA*255)));
            }
        } else hA=lerp(hA,0,spd*2);

        // ── Night darkness ────────────────────────────────────────────
        if (nightDark.isEnabled()) {
            float skyA=(float)mc.world.getSkyBrightness(1f);
            float target=(1f-skyA)*maxOp*1.8f;
            nA=lerp(nA,target,spd*0.5f); // slow transition
            if (nA>0.003f) ctx.fill(0,0,sw,sh,rgba(0,0,5,(int)(nA*255)));
        } else nA=lerp(nA,0,spd);

        // ── Water tint ────────────────────────────────────────────────
        if (waterTint.isEnabled()) {
            boolean inWater=mc.player.isSubmergedInWater();
            wA=lerp(wA,inWater?maxOp*4f:0,spd*2);
            if (wA>0.003f) {
                // Gradient — тёмнее к краям как реальная вода
                for (int i=0;i<3;i++) {
                    float f=(float)i/3;
                    ctx.fill(0,0,sw,sh,rgba(0,(int)(40*(1-f)),(int)(120*(1-f*0.5f)),(int)(wA*255*(0.4f+f*0.3f))));
                }
            }
        } else wA=lerp(wA,0,spd*3);
    }

    private static float lerp(float a,float b,float t){ return a+(b-a)*Math.min(1,t); }
    private static int rgba(int r,int g,int b,int a){
        a=Math.max(0,Math.min(255,a));
        return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
}
