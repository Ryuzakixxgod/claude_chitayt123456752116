package ru.ryuzaki.module.modules.particles;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

import java.util.ArrayList;
import java.util.List;

/**
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║  JumpParticle — 3D круг в мире при каждом прыжке                ║
 * ║                                                                  ║
 * ║  • Горизонтальный круг лежит на земле под ногами                 ║
 * ║  • 3 слоя glow (расширяющиеся копии с прозрачностью)            ║
 * ║  • Градиент от центра к краю                                     ║
 * ║  • 12 искр-точек вращаются по орбите                            ║
 * ║  • Billboard текст "Ryuzaki Visuals" висит в центре              ║
 * ║  • Второй кольцевой шлейф расширяется быстрее основного         ║
 * ║  • Полностью 3D — никакой кривой 2D проекции                    ║
 * ╚══════════════════════════════════════════════════════════════════╝
 */
public class JumpParticleModule extends Module {

    public final ModeSetting    style    = new ModeSetting("Style","Cosmic","Cosmic","Nova","Thunder","Sakura","Void","Ice");
    public final ColorSetting   color    = new ColorSetting("Color",      new ColorRGBA(140, 80, 255, 255));
    public final BooleanSetting rainbow  = new BooleanSetting("Rainbow",  false);
    public final BooleanSetting showText = new BooleanSetting("Text",     false);
    public final BooleanSetting sparks   = new BooleanSetting("Sparks",   true);
    public final BooleanSetting multiRing= new BooleanSetting("Multi Ring",true);
    public final NumberSetting  maxSize  = new NumberSetting("Max Size",  1.8, 0.5, 4.0, 0.1);
    public final NumberSetting  lifetime = new NumberSetting("Lifetime",  40.0, 15.0, 80.0, 1.0);

    private boolean wasOnGround = true;
    private final List<JumpRing> rings = new ArrayList<>();

    public JumpParticleModule() {
        super("JumpParticle", "3D-кольцо с частицами при прыжке", Category.PARTICLES);
        addSettings(style, color, rainbow, showText, sparks, multiRing, maxSize, lifetime);
    }


    // Публичный триггер — вызывается из RyuzakiClient при прыжке
    public void onPlayerJump(net.minecraft.util.math.Vec3d pos) {
        if (!isEnabled()) return;
        rings.add(new JumpRing(pos.x, pos.y, pos.z, lifetime.getValue().intValue()));
    }

    // ── Рендер 3D — вызывается из RyuzakiClient WorldRenderEvents ────────
    public void render3D(MatrixStack matrices, float tickDelta) {
        if (!isEnabled() || rings.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null || mc.gameRenderer == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.lineWidth(1.5f);

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);

        // Обновляем и рендерим кольца
        rings.removeIf(ring -> !ring.tick());
        for (JumpRing ring : rings) {
            ring.render(matrices, mc, tickDelta);
        }

        matrices.pop();
        RenderSystem.enableDepthTest();
        RenderSystem.disableBlend();
    }

    // ════════════════════════════════════════════════════════════════════
    //  КОЛЬЦО — один эффект прыжка
    // ════════════════════════════════════════════════════════════════════
    private class JumpRing {
        final double ox, oy, oz;
        final int maxLife;
        int life;
        // Угол вращения искр — накапливается каждый тик
        float sparkAngle = 0f;

        JumpRing(double x, double y, double z, int life) {
            ox = x; oy = y; oz = z;
            maxLife = life; this.life = life;
        }

        /** @return false если кольцо умерло */
        boolean tick() {
            life--;
            sparkAngle += 0.06f; // искры вращаются
            return life > 0;
        }

        void render(MatrixStack ms, MinecraftClient mc, float td) {
            // progress: 0.0=старт, 1.0=смерть
            float progress = 1f - (float) life / maxLife;

            // Альфа: быстро появляется, медленно гаснет
            float alpha;
            if (progress < 0.15f) {
                alpha = progress / 0.15f;
            } else {
                alpha = 1f - (progress - 0.15f) / 0.85f;
            }
            alpha = Math.max(0f, Math.min(1f, alpha));

            // Радиус растёт от 0 до maxSize
            float eased = easeOutCubic(progress);
            float radius = (float)(maxSize.getValue() * eased);

            // Цвет
            int[] rgb = getColorRgb(mc);
            int r = rgb[0], g = rgb[1], b = rgb[2];

            Matrix4f mat = ms.peek().getPositionMatrix();
            Tessellator tess = Tessellator.getInstance();

            // ── 1. Glow слои — расширенные полупрозрачные кольца ─────
            for (int layer = 3; layer >= 1; layer--) {
                float glowR   = radius + layer * 0.12f;
                float glowA   = alpha * (0.10f / layer);
                drawHorizontalRing(tess, mat, ox, oy, oz, glowR, r, g, b, (int)(glowA * 255), 48);
            }

            // ── 2. Основное кольцо (яркое) ───────────────────────────
            drawHorizontalRing(tess, mat, ox, oy, oz, radius, r, g, b, (int)(alpha * 220), 64);

            // ── 3. Внутреннее кольцо (тоньше, быстрее расширяется) ───
            float innerRadius = radius * 0.55f;
            float innerAlpha  = alpha * 0.6f;
            drawHorizontalRing(tess, mat, ox, oy, oz, innerRadius, r, g, b, (int)(innerAlpha * 255), 48);

            // ── 4. Шлейф — кольцо убегает быстрее основного ──────────
            float trailRadius = (float)(maxSize.getValue() * Math.min(1f, eased * 1.4f));
            float trailAlpha  = alpha * 0.25f;
            drawHorizontalRing(tess, mat, ox, oy, oz, trailRadius, r, g, b, (int)(trailAlpha * 255), 48);

            // ── 5. Заполненный диск (очень прозрачный) ───────────────
            drawFilledDisk(tess, mat, ox, oy, oz, radius, r, g, b, (int)(alpha * 18), 48);

            // ── 6. Искры — 12 точек вращаются по орбите ─────────────
            if (sparks.isEnabled()) {
                drawSparks(tess, mat, ox, oy, oz, radius, r, g, b, alpha);
            }

            // ── 7. Billboard текст "Ryuzaki Visuals" ─────────────────
            if (showText.isEnabled() && radius > 0.3f && alpha > 0.1f) {
                drawBillboardText(ms, mc, ox, oy + 0.05, oz, r, g, b, alpha);
            }
        }

        // ── Горизонтальное кольцо (лежит в плоскости XZ) ─────────────
        private void drawHorizontalRing(Tessellator tess, Matrix4f mat,
                                        double cx, double cy, double cz,
                                        float radius, int r, int g, int b, int a,
                                        int segments) {
            if (a <= 0) return;
            BufferBuilder buf = tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,
                    VertexFormats.POSITION_COLOR);
            for (int i = 0; i <= segments; i++) {
                double angle = 2.0 * Math.PI * i / segments;
                float x = (float)(cx + radius * Math.cos(angle));
                float z = (float)(cz + radius * Math.sin(angle));
                buf.vertex(mat, x, (float)cy, z).color(r, g, b, a);
            }
            drawBuf(tess, buf);
        }

        // ── Заполненный диск из треугольников (TRIANGLE_FAN через QUADS) ──
        private void drawFilledDisk(Tessellator tess, Matrix4f mat,
                                    double cx, double cy, double cz,
                                    float radius, int r, int g, int b, int a,
                                    int segments) {
            if (a <= 0) return;
            BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN,
                    VertexFormats.POSITION_COLOR);
            // Центральная вершина
            buf.vertex(mat, (float)cx, (float)cy, (float)cz).color(r, g, b, a);
            for (int i = 0; i <= segments; i++) {
                double angle = 2.0 * Math.PI * i / segments;
                float x = (float)(cx + radius * Math.cos(angle));
                float z = (float)(cz + radius * Math.sin(angle));
                // К краю альфа падает до нуля — красивый градиент
                buf.vertex(mat, x, (float)cy, z).color(r, g, b, 0);
            }
            drawBuf(tess, buf);
        }

        // ── 12 искр вращаются по орбите ──────────────────────────────
        private void drawSparks(Tessellator tess, Matrix4f mat,
                                double cx, double cy, double cz,
                                float radius, int r, int g, int b, float alpha) {
            int count = 12;
            float progress = 1f - (float) life / maxLife;

            for (int i = 0; i < count; i++) {
                double angle = sparkAngle + 2.0 * Math.PI * i / count;
                // Каждая искра чуть дальше/ближе основного кольца
                float orbitR = radius * (1f + 0.12f * (float)Math.sin(sparkAngle * 3 + i));
                float sx = (float)(cx + orbitR * Math.cos(angle));
                float sz = (float)(cz + orbitR * Math.sin(angle));

                // Мерцание
                float flicker = 0.5f + 0.5f * (float)Math.sin(sparkAngle * 5f + i * 1.3f);
                int sa = (int)(alpha * flicker * 255);
                if (sa <= 0) continue;

                // Рисуем искру как маленький крест
                float d = 0.04f;
                BufferBuilder buf = tess.begin(VertexFormat.DrawMode.DEBUG_LINES,
                        VertexFormats.POSITION_COLOR);
                buf.vertex(mat, sx-d, (float)cy, sz).color(r,g,b,sa);
                buf.vertex(mat, sx+d, (float)cy, sz).color(r,g,b,sa);
                buf.vertex(mat, sx, (float)cy, sz-d).color(r,g,b,sa);
                buf.vertex(mat, sx, (float)cy, sz+d).color(r,g,b,sa);
                drawBuf(tess, buf);
            }
        }

        // ── Billboard текст — всегда смотрит на камеру ───────────────
        private void drawBillboardText(MatrixStack ms, MinecraftClient mc,
                                       double wx, double wy, double wz,
                                       int r, int g, int b, float alpha) {
            if (mc.gameRenderer == null) return;
            Camera cam = mc.gameRenderer.getCamera();
            Vec3d camPos = cam.getPos();

            ms.push();
            ms.translate(wx, wy, wz);

            // Поворачиваем к камере (billboard)
            ms.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y
                    .rotationDegrees(-cam.getYaw()));
            ms.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X
                    .rotationDegrees(cam.getPitch()));

            // Масштаб — маленький, элегантный
            float scale = 0.025f;
            ms.scale(-scale, -scale, scale);

            TextRenderer tr = mc.textRenderer;
            String text = "✦ Ryuzaki Visuals ✦";
            int textWidth = tr.getWidth(text);

            // Цвет текста с alpha
            int color = (((int)(alpha * 200)) << 24) | (r << 16) | (g << 8) | b;

            Matrix4f mat = ms.peek().getPositionMatrix();
            var immediate = mc.getBufferBuilders().getEntityVertexConsumers();

            tr.draw(text, -textWidth / 2f, -tr.fontHeight / 2f,
                    color, true, mat, immediate,
                    TextRenderer.TextLayerType.NORMAL, 0, 0xF000F0);
            immediate.draw();

            ms.pop();
        }
    }

    // ════════════════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════════════════

    private int[] getColorRgb(MinecraftClient mc) {
        if (rainbow.isEnabled()) {
            long now = System.currentTimeMillis();
            return hsvToRgb((now % 3000) / 3000f, 0.9f, 1f);
        }
        return switch(style.getCurrent()) {
            case "Nova"    -> hsvToRgb(0.12f, 0.9f, 1f);
            case "Thunder" -> hsvToRgb(0.16f, 0.4f, 1f);
            case "Sakura"  -> hsvToRgb(0.92f, 0.5f, 1f);
            case "Void"    -> hsvToRgb(0.73f, 0.9f, 0.7f);
            case "Ice"     -> hsvToRgb(0.56f, 0.65f, 1f);
            default -> {
                ColorRGBA c = color.getColor();
                yield c == null ? new int[]{140, 80, 255} : new int[]{c.getRed(), c.getGreen(), c.getBlue()};
            }
        };
    }

    /** Плавное замедление — красивее линейного */
    private static float easeOutCubic(float t) {
        float f = 1f - t;
        return 1f - f * f * f;
    }

    private static void drawBuf(Tessellator tess, BufferBuilder buf) {
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); }
        catch (Exception ignored) {}
    }

    private static int[] hsvToRgb(float h, float s, float v) {
        h = h % 1f; if (h < 0) h += 1f;
        int i=(int)(h*6); float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);
        float r,g,b;
        switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}
            case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}
        return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};
    }
}