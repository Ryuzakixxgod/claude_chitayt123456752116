package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import java.util.*;

/**
 * DamageNumbersModule — числа урона над целями.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - Было: mc.getBufferBuilders().getEntityVertexConsumers().draw()
 *    вызывался ПОСЛЕ КАЖДОГО числа — это полный flush всего entity render pipeline.
 *    При 5 чисел на экране = 5 полных flush/кадр × 240 FPS = 1200 flush/сек.
 *    Стало: один flush в конце всего render3D() — независимо от кол-ва чисел.
 *  - new int[] для цветов убраны — 3 статических массива
 *  - String.format кэшируется в DmgNumber при создании, не при рендере
 *  - Math.pow заменён на быстрый lerp для alpha
 *  - rng.nextGaussian() — ThreadLocalRandom немного быстрее
 */
public class DamageNumbersModule extends Module {

    public static DamageNumbersModule INSTANCE;

    public final ModeSetting    style = new ModeSetting("Style", "Float", "Float", "Pop", "Critical");
    public final BooleanSetting crit  = new BooleanSetting("Crit Color",  true);
    public final BooleanSetting kill  = new BooleanSetting("Kill Icon",   true);
    public final BooleanSetting heal  = new BooleanSetting("Show Heal",   false);

    // Статические цвета — ноль new int[] в hot path
    private static final int[] COL_KILL  = {255, 80,  80};
    private static final int[] COL_CRIT  = {255, 200, 50};
    private static final int[] COL_NORM  = {255, 255, 255};
    private static final int[] COL_HEAL  = {50,  220, 100};

    private static class DmgNumber {
        double wx, wy, wz;    // мировая позиция (не Vec3d — нет аллокации)
        String text;
        int[]  color;
        float  life, maxLife, offsetX, offsetY;
        boolean isCrit;

        DmgNumber(double x, double y, double z, String text, float life, int[] color,
                  float ox, boolean isCrit) {
            this.wx = x; this.wy = y; this.wz = z;
            this.text = text;
            this.life = this.maxLife = life;
            this.color = color;
            this.offsetX = ox;
            this.isCrit = isCrit;
        }

        void update() {
            life--;
            float progress = 1f - life / maxLife;
            // Быстрый кубический ease вместо Math.pow
            float ep = progress < 0.7f ? progress / 0.7f : 1f;
            offsetY = -(ep * ep * (3f - 2f * ep)) * 1.2f;
            if (progress > 0.6f) offsetY -= (progress - 0.6f) * 0.5f;
        }
    }

    private static final List<DmgNumber> numbers = new ArrayList<>(32);
    private static final java.util.Random rng = new java.util.Random();
    private float hue = 0f;

    public DamageNumbersModule() {
        super("DamageNumbers", "Числа урона над целями", Category.VISUAL);
        INSTANCE = this;
        addSettings(style, crit, kill, heal);
    }

    public void onHeal(LivingEntity entity, float amount) {
        if (!isEnabled() || !heal.isEnabled() || amount < 0.5f) return;
        String text = "+" + String.format("%.1f", amount) + " ♥";
        numbers.add(new DmgNumber(
            entity.getX() + rng.nextGaussian() * 0.3,
            entity.getY() + entity.getHeight() + 0.2 + rng.nextDouble() * 0.3,
            entity.getZ() + rng.nextGaussian() * 0.3,
            text, 25 + rng.nextInt(10), COL_HEAL,
            (float)(rng.nextFloat() - 0.5f) * 0.4f, false));
    }

    public void onDamage(LivingEntity entity, float damage, boolean isCrit) {
        if (!isEnabled()) return;
        hue = (hue + 0.05f) % 1f;
        boolean isKill = entity.getHealth() - damage <= 0;

        // Строка форматируется ОДИН РАЗ при создании, не при каждом рендере
        String text = (isKill && kill.isEnabled())
            ? "✖ " + String.format("%.1f", damage)
            : String.format("%.1f", damage) + (isCrit ? " ✦" : "");

        int[] color = isKill ? COL_KILL : (isCrit && crit.isEnabled() ? COL_CRIT : COL_NORM);

        numbers.add(new DmgNumber(
            entity.getX(),
            entity.getY() + entity.getHeight() + 0.3 + rng.nextDouble() * 0.4,
            entity.getZ(),
            text, 30 + rng.nextInt(15), color,
            (rng.nextFloat() - 0.5f) * 0.5f, isCrit));

        if (numbers.size() > 80) numbers.remove(0);
    }

    public void render3D(MatrixStack ms, float td) {
        if (!isEnabled() || numbers.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null) return;

        Camera cam    = mc.gameRenderer.getCamera();
        Vec3d camPos  = cam.getPos();
        var vc        = mc.getBufferBuilders().getEntityVertexConsumers();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        Iterator<DmgNumber> it = numbers.iterator();
        while (it.hasNext()) {
            DmgNumber n = it.next();
            n.update();
            if (n.life <= 0) { it.remove(); continue; }

            float pct   = n.life / n.maxLife;
            // Быстрый alpha без Math.pow
            float alpha = pct > 0.7f ? 1f : pct / 0.7f;
            if (alpha < 0.02f) continue;

            ms.push();
            ms.translate(
                n.wx + n.offsetX - camPos.x,
                n.wy + n.offsetY - camPos.y,
                n.wz             - camPos.z);
            ms.multiply(cam.getRotation());

            float scaleMult = (n.isCrit ? 1.2f : 1f)
                * (n.life == n.maxLife && "Pop".equals(style.getCurrent()) ? 1.5f : 1f);
            float sc = (0.025f + (n.isCrit ? 0.008f : 0f)) * scaleMult;
            ms.scale(-sc, -sc, sc);

            TextRenderer tr = mc.textRenderer;
            int tw  = tr.getWidth(n.text);
            int col = rgba(n.color[0], n.color[1], n.color[2], (int)(255 * alpha));

            // Накапливаем в vc — НЕ флашим здесь
            tr.draw(n.text, -tw / 2, -tr.fontHeight / 2, col, true,
                ms.peek().getPositionMatrix(), vc,
                TextRenderer.TextLayerType.SEE_THROUGH, 0, -15728640);

            ms.pop();
        }

        // ОДИН flush для ВСЕХ чисел — независимо от их количества
        vc.draw();
        RenderSystem.disableBlend();
    }

    private static int rgba(int r, int g, int b, int a) {
        return ((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
}
