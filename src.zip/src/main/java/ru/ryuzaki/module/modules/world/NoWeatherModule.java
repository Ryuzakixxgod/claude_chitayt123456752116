package ru.ryuzaki.module.modules.world;

import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.BooleanSetting;

public class NoWeatherModule extends Module {
    public static NoWeatherModule INSTANCE;
    public final BooleanSetting noRain = new BooleanSetting("No Rain", true);
    public final BooleanSetting noSnow = new BooleanSetting("No Snow", true);
    public final BooleanSetting noThunder = new BooleanSetting("No Thunder", true);

    public NoWeatherModule(){super("NoWeather","Убирает дождь и снег",Category.WORLD);
        INSTANCE = this;addSettings(noRain,noSnow,noThunder);}
}
