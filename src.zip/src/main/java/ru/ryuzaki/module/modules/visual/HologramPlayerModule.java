package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/HologramPlayerModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

public class HologramPlayerModule extends Module {
    public final ModeSetting   style   = new ModeSetting("Style","Cosmic","Cosmic","Energy","Reaper","Neon","Ghost");
    public final NumberSetting opacity = new NumberSetting("Opacity",  50,  10, 150, 5);
    public final BooleanSetting rings  = new BooleanSetting("Rings",    true);
    public final BooleanSetting scanLine=new BooleanSetting("Scan Line",true);
    public final BooleanSetting glow   = new BooleanSetting("Glow",     true);
    public final BooleanSetting friends= new BooleanSetting("Friends Only",false);

    private float hue=0f;

    public HologramPlayerModule(){
        super("Hologram","Голографические контуры игроков",Category.VISUAL);
        addSettings(style,opacity,rings,scanLine,glow,friends);
    }

    public void render3D(MatrixStack ms, float td){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.world==null||mc.player==null||mc.gameRenderer==null) return;
        hue=(hue+0.002f)%1f;
        Vec3d cam=mc.gameRenderer.getCamera().getPos();
        long now=System.currentTimeMillis();

        ms.push();
        ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();

        for(PlayerEntity p:mc.world.getPlayers()){
            if(p==mc.player) continue;
            if(friends.isEnabled()&&!ru.ryuzaki.util.FriendManager.isFriend(p.getName().getString())) continue;

            Vec3d pos=p.getLerpedPos(td);
            float h=p.getHeight(), w=p.getWidth()/2f+0.05f;
            float pulse=0.6f+0.4f*(float)Math.sin(now*0.003f+p.getId()*0.5f);
            int[]c=getColor(p,now);
            int op=opacity.getValue().intValue();
            Matrix4f mat=ms.peek().getPositionMatrix();
            float px=(float)pos.x, py=(float)pos.y, pz=(float)pos.z;
            Box box=p.getBoundingBox();

            // ── Glow слои ───────────────────────────────────────────
            if(glow.isEnabled()){
                for(int gl=4;gl>=1;gl--){
                    float ex=gl*0.04f; int ga=(int)(op*0.12f/gl*pulse);
                    drawBoxOutline(tess,mat,box.expand(ex),c[0],c[1],c[2],ga);
                }
            }

            // ── Голографические горизонтальные слои ─────────────────
            int SLICES=8;
            for(int sl=0;sl<=SLICES;sl++){
                float fy=py+(h*sl/SLICES);
                float sliceAlpha=(float)Math.sin(Math.PI*sl/SLICES); // сильнее по центру
                int sa=(int)(op*pulse*sliceAlpha*0.7f);
                if(sa<=0) continue;
                // Сканирующая строка
                if(scanLine.isEnabled()){
                    float scanY=py+(h*((float)((now%2000)/2000.0)));
                    if(Math.abs(fy-scanY)<h/SLICES){
                        sa=Math.min(255,(int)(sa*2.5f));
                    }
                }
                BufferBuilder lb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                for(int i=0;i<=16;i++){double a=2*Math.PI*i/16;lb.vertex(mat,(float)(px+w*Math.cos(a)),fy,(float)(pz+w*Math.sin(a))).color(c[0],c[1],c[2],sa);}
                try{BufferRenderer.drawWithGlobalProgram(lb.end());}catch(Exception ignored){}
            }

            // ── Вертикальные рёбра ──────────────────────────────────
            for(int i=0;i<4;i++){
                double ang=Math.PI/2*i;
                float ex2=(float)(px+w*Math.cos(ang)), ez2=(float)(pz+w*Math.sin(ang));
                BufferBuilder vb=tess.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
                vb.vertex(mat,ex2,py,ez2).color(c[0],c[1],c[2],(int)(op*pulse*0.8f));
                vb.vertex(mat,ex2,py+h,ez2).color(c[0],c[1],c[2],0);
                try{BufferRenderer.drawWithGlobalProgram(vb.end());}catch(Exception ignored){}
            }

            // ── Кольца ─────────────────────────────────────────────
            if(rings.isEnabled()){
                float rRot=(float)(now*0.001f+p.getId()*0.3f);
                for(int ri=0;ri<3;ri++){
                    float ry=py+h*(0.2f+ri*0.3f);
                    float rr=w*(0.7f+0.3f*(float)Math.sin(now*0.002f+ri*2));
                    int ra=(int)(op*pulse*0.5f);
                    // Вращающееся кольцо
                    BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                    for(int i=0;i<=24;i++){double a=2*Math.PI*i/24+rRot*(ri%2==0?1:-1);rb.vertex(mat,(float)(px+rr*Math.cos(a)),ry,(float)(pz+rr*Math.sin(a))).color(c[0],c[1],c[2],ra);}
                    try{BufferRenderer.drawWithGlobalProgram(rb.end());}catch(Exception ignored){}
                }
            }
        }

        ms.pop();
        RenderSystem.enableDepthTest(); RenderSystem.enableCull(); RenderSystem.disableBlend();
    }

    private int[]getColor(PlayerEntity p,long now){
        boolean friend=ru.ryuzaki.util.FriendManager.isFriend(p.getName().getString());
        if(friend) return new int[]{50,255,100};
        return switch(style.getCurrent()){
            case"Energy" ->new int[]{50,255,150};
            case"Reaper" ->hsv(0.75f+p.getId()*0.05f,0.9f,0.8f);
            case"Neon"   ->new int[]{255,50,200};
            case"Ghost"  ->new int[]{200,200,255};
            default      ->hsv((hue+p.getId()*0.07f)%1f,0.8f,1f);
        };
    }
    private void drawBoxOutline(Tessellator t,Matrix4f m,Box b,int r,int g,int bl,int a){
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ,x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        BufferBuilder buf=t.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
        ln(buf,m,x1,y1,z1,x2,y1,z1,r,g,bl,a);ln(buf,m,x2,y1,z1,x2,y1,z2,r,g,bl,a);ln(buf,m,x2,y1,z2,x1,y1,z2,r,g,bl,a);ln(buf,m,x1,y1,z2,x1,y1,z1,r,g,bl,a);
        ln(buf,m,x1,y2,z1,x2,y2,z1,r,g,bl,a);ln(buf,m,x2,y2,z1,x2,y2,z2,r,g,bl,a);ln(buf,m,x2,y2,z2,x1,y2,z2,r,g,bl,a);ln(buf,m,x1,y2,z2,x1,y2,z1,r,g,bl,a);
        ln(buf,m,x1,y1,z1,x1,y2,z1,r,g,bl,a);ln(buf,m,x2,y1,z1,x2,y2,z1,r,g,bl,a);ln(buf,m,x2,y1,z2,x2,y2,z2,r,g,bl,a);ln(buf,m,x1,y1,z2,x1,y2,z2,r,g,bl,a);
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }
    private static void ln(BufferBuilder b,Matrix4f m,float x1,float y1,float z1,float x2,float y2,float z2,int r,int g,int c,int a){b.vertex(m,x1,y1,z1).color(r,g,c,a);b.vertex(m,x2,y2,z2).color(r,g,c,a);}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
