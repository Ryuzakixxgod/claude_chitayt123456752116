package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.FriendManager;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * NameTagsModule — теги над игроками.
 *
 * ОПТИМИЗАЦИИ vs предыдущая версия:
 *  - drawQuad() создавал новый BufferBuilder на каждый прямоугольник.
 *    Один тег = 4-5 quad вызовов × 10 игроков = 40-50 BufferBuilder/кадр → 1 на тег.
 *    Теперь: ОДИН BufferBuilder открывается для всех quad одного тега,
 *    пишем все вершины, закрываем один раз.
 *  - getWaveColor кэшированных статических массивов нет — используем hsvFill в colorBuf
 *  - Текстовые draw накапливаются в vc, один flush в конце тега
 */
public class NameTagsModule extends Module {

    private static NameTagsModule instance;

    public final BooleanSetting showHP    = new BooleanSetting("HP Bar",     true);
    public final BooleanSetting showPing  = new BooleanSetting("Ping",       true);
    public final BooleanSetting showDist  = new BooleanSetting("Distance",   true);
    public final BooleanSetting showArmor = new BooleanSetting("Armor Icon", true);
    public final BooleanSetting rainbow   = new BooleanSetting("Rainbow",    true);
    public final NumberSetting  scale     = new NumberSetting("Scale", 1.0, 0.4, 2.5, 0.1);

    private float hue = 0f;

    private static final int[] HP_GREEN  = {50,  220, 50};
    private static final int[] HP_YELLOW = {255, 180, 0};
    private static final int[] HP_RED    = {220, 50,  50};

    private final int[] accentColor = new int[3];

    public NameTagsModule() {
        super("NameTags", "Красивые теги над игроками", Category.VISUAL);
        addSettings(showHP, showPing, showDist, showArmor, rainbow, scale);
        instance = this;
    }

    public static NameTagsModule getInstance() { return instance; }

    @Override public void onUpdate() { hue = (hue + 0.002f) % 1f; }

    public void render3D(MatrixStack ms, float td) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        Camera cam   = mc.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();
        var vc       = mc.getBufferBuilders().getEntityVertexConsumers();

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(net.minecraft.client.gl.ShaderProgramKeys.POSITION_COLOR);

        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            double dist = mc.player.distanceTo(p);
            if (dist > 64) continue;

            boolean friend = FriendManager.isFriend(p.getName().getString());

            if (friend) {
                accentColor[0] = 50; accentColor[1] = 255; accentColor[2] = 100;
            } else if (rainbow.isEnabled()) {
                RyuzakiRenderCache.hsvFill((hue + p.getId() * 0.07f) % 1f, 0.75f, 1f, accentColor);
            } else {
                RyuzakiRenderCache.hsvFill(0.73f, 0.7f, 1f, accentColor);
            }

            var entry = mc.getNetworkHandler() != null
                ? mc.getNetworkHandler().getPlayerListEntry(p.getUuid()) : null;
            int ping = entry != null ? entry.getLatency() : 0;

            TextRenderer tr  = mc.textRenderer;
            String name      = p.getName().getString();
            float  hp        = p.getHealth();
            float  maxHp     = p.getMaxHealth();
            String pingStr   = showPing.isEnabled() ? " [" + ping + "]" : "";
            String distStr   = showDist.isEnabled() ? String.format("%.0fm", dist) : "";

            int nw   = tr.getWidth(name);
            int pingW = showPing.isEnabled() ? tr.getWidth(pingStr) : 0;
            int distW = showDist.isEnabled() ? tr.getWidth(distStr) : 0;
            int bgW  = Math.max(nw + pingW + distW, 80) + 14;
            int bgH  = showHP.isEnabled() ? 28 : 16;

            Vec3d pos = p.getLerpedPos(td).add(0, p.getHeight() + 0.55, 0);
            ms.push();
            ms.translate(pos.x - camPos.x, pos.y - camPos.y, pos.z - camPos.z);
            ms.multiply(cam.getRotation());
            float sc = scale.getValue().floatValue() * 0.022f
                * (float)Math.min(1.0, 2.0 / Math.max(1.0, dist * 0.15));
            ms.scale(-sc, -sc, sc);

            Matrix4f mat = ms.peek().getPositionMatrix();

            // ── Все quad одного тега — ОДИН BufferBuilder ─────────────
            // Было: 4-5 отдельных begin/end → Стало: 1 begin/end
            Tessellator tess = Tessellator.getInstance();
            BufferBuilder quads = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);

            // Фон
            quad(quads, mat, 0, 0, bgW, bgH, 0, 0, 0, 175);

            // Левый акцент
            quad(quads, mat, 0, 1, 2, bgH - 1, accentColor[0], accentColor[1], accentColor[2], 200);

            // HP бар
            if (showHP.isEnabled()) {
                float ratio  = hp / maxHp;
                int   bx     = 5, by = bgH - 8, bw = bgW - 10, bh = 4;
                quad(quads, mat, bx, by, bx + bw, by + bh, 15, 10, 30, 200);
                int filled = (int)(bw * ratio);
                if (filled > 0) {
                    int[] hpc = ratio > 0.6f ? HP_GREEN : ratio > 0.3f ? HP_YELLOW : HP_RED;
                    quad(quads, mat, bx, by, bx + filled, by + bh, hpc[0], hpc[1], hpc[2], 220);
                    quad(quads, mat, bx, by, bx + filled, by + 1,  255,    255,    255,    40);
                }
            }

            // Один draw call для всех quad
            try { BufferRenderer.drawWithGlobalProgram(quads.end()); }
            catch (Exception ignored) {}

            // Радужная верхняя линия — градиентный quad (отдельный т.к. разные цвета вершин)
            int[] cL = RyuzakiRenderCache.hsv(hue % 1f, 0.8f, 1f);
            int[] cR = RyuzakiRenderCache.hsv((hue + 0.2f) % 1f, 0.8f, 1f);
            BufferBuilder grad = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            grad.vertex(mat,   0, 0, 0).color(cL[0], cL[1], cL[2], 220);
            grad.vertex(mat, bgW, 0, 0).color(cR[0], cR[1], cR[2], 220);
            grad.vertex(mat, bgW, 1, 0).color(cR[0], cR[1], cR[2], 220);
            grad.vertex(mat,   0, 1, 0).color(cL[0], cL[1], cL[2], 220);
            try { BufferRenderer.drawWithGlobalProgram(grad.end()); }
            catch (Exception ignored) {}

            // ── Весь текст → один flush ───────────────────────────────
            int nameColor = friend ? 0xFF32FF64 : rgba(accentColor[0], accentColor[1], accentColor[2], 255);
            tr.draw(Text.literal((friend ? "✦ " : "") + name), 5, 3, nameColor, true,
                mat, vc, TextRenderer.TextLayerType.NORMAL, 0, -15728640);

            if (showPing.isEnabled()) {
                int pingCol = ping < 80 ? 0xFF64FF64 : ping < 150 ? 0xFFFFCC44 : 0xFFFF4444;
                tr.draw(Text.literal(pingStr), nw + 5, 3, pingCol, false,
                    mat, vc, TextRenderer.TextLayerType.NORMAL, 0, -15728640);
            }
            if (showDist.isEnabled()) {
                tr.draw(Text.literal(distStr), bgW - tr.getWidth(distStr) - 5, 3, 0xFF888899, false,
                    mat, vc, TextRenderer.TextLayerType.NORMAL, 0, -15728640);
            }
            if (showHP.isEnabled()) {
                String hpStr = String.format("%.0f/%.0f", hp, maxHp);
                tr.draw(Text.literal(hpStr), 5, bgH - 16, 0xFF888899, false,
                    mat, vc, TextRenderer.TextLayerType.NORMAL, 0, -15728640);
            }

            vc.draw(); // один flush на тег
            RenderSystem.disableBlend();
            ms.pop();
        }
    }

    /** Добавляет quad в открытый BufferBuilder — ноль begin/end overhead */
    private static void quad(BufferBuilder b, Matrix4f m,
                              int x1, int y1, int x2, int y2,
                              int r, int g, int bl, int a) {
        b.vertex(m, x1, y1, 0).color(r, g, bl, a);
        b.vertex(m, x2, y1, 0).color(r, g, bl, a);
        b.vertex(m, x2, y2, 0).color(r, g, bl, a);
        b.vertex(m, x1, y2, 0).color(r, g, bl, a);
    }

    private static int rgba(int r, int g, int b, int a) {
        return ((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
}
