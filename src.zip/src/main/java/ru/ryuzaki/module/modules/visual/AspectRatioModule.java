package ru.ryuzaki.module.modules.visual;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.NumberSetting;

/**
 * AspectRatioModule — изменяет соотношение сторон экрана.
 * Порт из Plintus (AspectModule).
 */
public class AspectRatioModule extends Module {
    public static AspectRatioModule INSTANCE;

    public final NumberSetting ratio = new NumberSetting("Ratio", 1.8, 0.6, 6.0, 0.1);

    public AspectRatioModule() {
        super("AspectRatio", "Кастомное соотношение сторон экрана", Category.VISUAL);
        INSTANCE = this;
        addSettings(ratio);
    }

    /** Called from MixinWindow — returns modified aspect ratio */
    public float getRatio() { return isEnabled() ? ratio.getValue().floatValue() : -1f; }

    public float getAspect() {
        if (!isEnabled()) return -1;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.getWindow() == null) return -1;
        return ratio.getValue().floatValue();
    }
}
