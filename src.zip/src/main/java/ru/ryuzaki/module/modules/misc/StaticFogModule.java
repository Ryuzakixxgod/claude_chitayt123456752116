package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * StaticFogModule — зафиксировать туман на определённой дистанции.
 * Не реагирует на биомы (лава, вода) — всегда одинаков.
 * Используется для скриншотов или эстетики.
 */
public class StaticFogModule extends Module {
    public static StaticFogModule INSTANCE;

    public final NumberSetting  start  = new NumberSetting("Start",   48, 4,  256, 4);
    public final NumberSetting  end    = new NumberSetting("End",     96, 8,  512, 8);
    public final BooleanSetting sphere = new BooleanSetting("Sphere", true);
    public final NumberSetting  r      = new NumberSetting("R", 0.6, 0.0, 1.0, 0.05);
    public final NumberSetting  g      = new NumberSetting("G", 0.6, 0.0, 1.0, 0.05);
    public final NumberSetting  b2     = new NumberSetting("B", 0.8, 0.0, 1.0, 0.05);

    public StaticFogModule() {
        super("StaticFog","Зафиксированный туман любого цвета",Category.MISC);
        INSTANCE = this;
        addSettings(start, end, sphere, r, g, b2);
    }

    public static StaticFogModule getInstance(){ return INSTANCE; }
    public float getStart(){ return start.getValue().floatValue(); }
    public float getEnd()  { return end.getValue().floatValue(); }
    public float getR()    { return r.getValue().floatValue(); }
    public float getG()    { return g.getValue().floatValue(); }
    public float getB()    { return b2.getValue().floatValue(); }
    public boolean isSphere(){ return sphere.isEnabled(); }
}
