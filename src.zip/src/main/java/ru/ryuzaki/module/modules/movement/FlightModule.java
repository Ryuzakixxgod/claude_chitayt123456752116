package ru.ryuzaki.module.modules.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.BoatEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

public class FlightModule extends Module {
    public static FlightModule INSTANCE;
    private final MinecraftClient mc = MinecraftClient.getInstance();

    public final ModeSetting mode = new ModeSetting("Режим", "Ванильный",
        "Ванильный", "Пакет", "Креатив", "Элитра", "Транспорт");

    public final NumberSetting speed = new NumberSetting("Скорость", 1.0, 0.1, 10.0, 0.1);
    public final NumberSetting vertSpeed = new NumberSetting("Верт. Скорость", 1.0, 0.1, 5.0, 0.1);
    public final NumberSetting fakeGroundTicks = new NumberSetting("Фейк Земля Тики", 10, 0, 40, 1);
    
    public final BooleanSetting noFallBypass = new BooleanSetting("NoFall Обход", true);
    public final BooleanSetting spoofGround = new BooleanSetting("Спуф Земли", true);

    private int groundSpoofTicks;

    public FlightModule() {
        super("Flight", "Полёт", Category.MOVEMENT);
        INSTANCE = this;
        addSettings(mode, speed, vertSpeed, fakeGroundTicks, noFallBypass, spoofGround);
    }

    @Override
    public void onEnable() { groundSpoofTicks = 0; }

    @Override
    public void onUpdate() {
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        ClientPlayerEntity p = mc.player;
        switch (mode.getCurrent()) {
            case "Ванильный" -> handleVanilla(p);
            case "Пакет" -> handlePacket(p);
            case "Креатив" -> handleCreative(p);
            case "Элитра" -> handleElytra(p);
            case "Транспорт" -> handleVehicle(p);
        }
    }

    private void handleVanilla(ClientPlayerEntity p) {
        double spd = speed.getValue() * 0.05;
        float yaw = p.getYaw() * (float)Math.PI / 180f;
        
        if (mc.options.forwardKey.isPressed()) p.addVelocity(-MathHelper.sin(yaw) * spd, 0, MathHelper.cos(yaw) * spd);
        if (mc.options.jumpKey.isPressed()) p.addVelocity(0, vertSpeed.getValue() * 0.05, 0);
        if (mc.options.sneakKey.isPressed()) p.addVelocity(0, -vertSpeed.getValue() * 0.05, 0);

        if (noFallBypass.isEnabled() && spoofGround.isEnabled()) {
            groundSpoofTicks++;
            if (groundSpoofTicks >= fakeGroundTicks.getValue().intValue()) {
                groundSpoofTicks = 0;
                p.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, p.horizontalCollision));
            }
        }
    }

    private void handlePacket(ClientPlayerEntity p) {
        Vec3d pos = p.getPos();
        double spd = speed.getValue() * 0.5;
        float yaw = p.getYaw() * (float)Math.PI / 180f;
        
        if (mc.options.forwardKey.isPressed()) {
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                pos.x - MathHelper.sin(yaw) * spd, pos.y, pos.z + MathHelper.cos(yaw) * spd, p.isOnGround(), p.horizontalCollision
            ));
        }
    }

    private void handleCreative(ClientPlayerEntity p) {
        Vec3d vel = p.getVelocity();
        double spd = speed.getValue() * 0.1;
        float yaw = p.getYaw() * (float)Math.PI / 180f;
        double vx = 0, vy = 0, vz = 0;

        if (mc.options.forwardKey.isPressed()) { vx -= MathHelper.sin(yaw) * spd; vz += MathHelper.cos(yaw) * spd; }
        if (mc.options.jumpKey.isPressed()) vy += vertSpeed.getValue() * 0.1;
        if (mc.options.sneakKey.isPressed()) vy -= vertSpeed.getValue() * 0.1;

        p.setVelocity(vx, vel.y + vy * 0.1, vz);
    }

    private void handleElytra(ClientPlayerEntity p) {
        if (!p.isGliding()) {
            if (mc.options.jumpKey.isPressed() && !p.isOnGround()) p.addVelocity(0, 0.1, 0);
            return;
        }

        Vec3d vel = p.getVelocity();
        double spd = speed.getValue() * 0.1;
        float yaw = p.getYaw() * (float)Math.PI / 180f;
        
        if (mc.options.forwardKey.isPressed()) p.addVelocity(-MathHelper.sin(yaw) * spd, 0.02, MathHelper.cos(yaw) * spd);
        if (mc.options.jumpKey.isPressed()) p.addVelocity(0, vertSpeed.getValue() * 0.05, 0);
        if (mc.options.sneakKey.isPressed()) p.addVelocity(0, -vertSpeed.getValue() * 0.05, 0);

        double h = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
        if (h < 0.3) p.addVelocity(-MathHelper.sin(yaw) * 0.05, 0, MathHelper.cos(yaw) * 0.05);
    }

    private void handleVehicle(ClientPlayerEntity p) {
        if (!p.hasVehicle()) {
            for (Entity e : mc.world.getEntities()) {
                if (e instanceof BoatEntity && p.distanceTo(e) < 4) { p.startRiding(e); break; }
            }
            return;
        }

        Entity v = p.getVehicle();
        if (v == null) return;

        Vec3d vel = v.getVelocity();
        double spd = speed.getValue() * 0.2;
        float yaw = v.getYaw() * (float)Math.PI / 180f;

        if (mc.options.forwardKey.isPressed()) v.setVelocity(-MathHelper.sin(yaw) * spd, vel.y, MathHelper.cos(yaw) * spd);
        if (mc.options.jumpKey.isPressed()) v.addVelocity(0, vertSpeed.getValue() * 0.1, 0);
    }

    @Override
    public void onDisable() {
        groundSpoofTicks = 0;
        if (mc.player != null && mc.player.hasVehicle()) mc.player.dismountVehicle();
    }
}
