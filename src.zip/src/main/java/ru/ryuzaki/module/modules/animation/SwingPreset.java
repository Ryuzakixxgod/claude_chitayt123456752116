package ru.ryuzaki.module.modules.animation;

/** Swing animation preset — start and end phase transforms + bezier params */
public class SwingPreset {
    public final String name;
    // Start phase
    public final float sAncX,sAncY,sAncZ,sMvX,sMvY,sMvZ,sRotX,sRotY,sRotZ;
    // End phase
    public final float eAncX,eAncY,eAncZ,eMvX,eMvY,eMvZ,eRotX,eRotY,eRotZ;
    // Bezier control points P1 and P2
    public final float bx1,by1,bx2,by2;
    public final boolean back;
    public final float speed;

    public SwingPreset(String name,
                       float sAX,float sAY,float sAZ, float sMX,float sMY,float sMZ, float sRX,float sRY,float sRZ,
                       float eAX,float eAY,float eAZ, float eMX,float eMY,float eMZ, float eRX,float eRY,float eRZ,
                       float bx1,float by1,float bx2,float by2, boolean back, float speed){
        this.name=name;
        this.sAncX=sAX;this.sAncY=sAY;this.sAncZ=sAZ;
        this.sMvX=sMX; this.sMvY=sMY; this.sMvZ=sMZ;
        this.sRotX=sRX;this.sRotY=sRY;this.sRotZ=sRZ;
        this.eAncX=eAX;this.eAncY=eAY;this.eAncZ=eAZ;
        this.eMvX=eMX; this.eMvY=eMY; this.eMvZ=eMZ;
        this.eRotX=eRX;this.eRotY=eRY;this.eRotZ=eRZ;
        this.bx1=bx1;this.by1=by1;this.bx2=bx2;this.by2=by2;
        this.back=back;this.speed=speed;
    }

    /** Interpolate between start and end phase at given progress (0-1) */
    public float[] transform(float progress){
        // Bezier easing
        float t = bezier(progress);
        if(back) t = (float)(Math.sin(Math.sqrt(t)*Math.PI));

        return new float[]{
            lerp(sAncX,eAncX,t), lerp(sAncY,eAncY,t), lerp(sAncZ,eAncZ,t),
            lerp(sMvX, eMvX, t), lerp(sMvY, eMvY, t), lerp(sMvZ, eMvZ, t),
            lerp(sRotX,eRotX,t), lerp(sRotY,eRotY,t), lerp(sRotZ,eRotZ,t)
        };
    }

    private float lerp(float a, float b, float t){ return a+(b-a)*t; }

    /** Cubic bezier approximation */
    private float bezier(float t){
        // Newton-Raphson approximation for cubic bezier
        float x = t;
        for(int i=0;i<4;i++){
            float bx = 3*bx1*x*(1-x)*(1-x) + 3*bx2*x*x*(1-x) + x*x*x;
            float dx = 3*bx1*(1-x)*(1-2*x) + 3*bx2*(2*x-3*x*x) + 3*x*x;
            if(Math.abs(dx)<0.001f) break;
            x -= (bx-t)/dx;
        }
        float y = 3*by1*x*(1-x)*(1-x) + 3*by2*x*x*(1-x) + x*x*x;
        return Math.max(0f,Math.min(1f,y));
    }
}
