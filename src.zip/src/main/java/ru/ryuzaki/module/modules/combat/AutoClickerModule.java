package ru.ryuzaki.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.Random;

/**
 * AutoClicker — автоматически атакует сущностей с заданным CPS.
 *
 * ОБХОДЫ АНТИЧИТА:
 *  - ClickPacket: использует пакет вместо interactionManager
 *  - Blocked hand: иногда использует offhand вместо mainhand
 *  - Jitter: небольшое движение мыши после клика (имитация человека)
 *  - Pause: периодические паузы (сброс счётчика кликов)
 *  - Ground check: не кликает если игрок прыгает (глайд детект)
 *  - Burst режим: иногда спамит, иногда пауза
 */
public class AutoClickerModule extends Module {

    private final Random random = new Random();

    public final NumberSetting минCPS   = new NumberSetting("Мин CPS",  8.0, 1.0, 15.0, 1.0);
    public final NumberSetting максCPS   = new NumberSetting("Макс CPS", 12.0, 1.0, 20.0, 1.0);
    public final ModeSetting    режим     = new ModeSetting("Режим","Обычный","Обычный","Прицел");
    public final BooleanSetting толькоЗажато = new BooleanSetting("Только ЛКМ Зажата", true);
    public final BooleanSetting игроки  = new BooleanSetting("Игроки", true);
    public final BooleanSetting мобы     = new BooleanSetting("Мобы",    true);

    // ── Обходы античита ────────────────────────────────────────────
    public final BooleanSetting кликПакет = new BooleanSetting("Клик Пакет", true);
    public final BooleanSetting дрожание = new BooleanSetting("Дрожание", true);
    public final BooleanSetting пауза = new BooleanSetting("Пауза", true);
    public final BooleanSetting проверкаЗемли = new BooleanSetting("Проверка Земли", true);
    public final NumberSetting шансПаузы = new NumberSetting("Шанс Паузы", 20.0, 5.0, 50.0, 5.0);
    public final NumberSetting тикиПаузы = new NumberSetting("Тики Паузы", 10.0, 5.0, 30.0, 1.0);
    public final BooleanSetting сменаOffhand = new BooleanSetting("Смена Offhand", true);

    // ── Состояние для обходов ───────────────────────────────────────
    private long nextClickTime = 0;
    private int clickCounter = 0;
    private int pauseCounter = 0;
    private boolean isPaused = false;
    private Hand lastHand = Hand.MAIN_HAND;

    public AutoClickerModule() {
        super("AutoClicker", "Авто-атака с заданным CPS", Category.COMBAT);
        addSettings(минCPS, максCPS, режим, толькоЗажато, игроки, мобы,
                    кликПакет, дрожание, пауза, проверкаЗемли, шансПаузы, тикиПаузы, сменаOffhand);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        // ── Only held check ──────────────────────────────────────────
        if (толькоЗажато.isEnabled() && !mc.options.attackKey.isPressed()) return;

        // ── Ground check: не кликаем в воздухе (глайд детект) ──────
        if (проверкаЗемли.isEnabled() && !mc.player.isOnGround() && mc.player.fallDistance < 1.0f) {
            return;
        }

        // ── Pause system ──────────────────────────────────────────────
        if (пауза.isEnabled()) {
            if (isPaused) {
                pauseCounter++;
                if (pauseCounter > тикиПаузы.getValue()) {
                    isPaused = false;
                    pauseCounter = 0;
                }
                return;
            }
            clickCounter++;
            if (random.nextDouble() * 100 < шансПаузы.getValue()) {
                isPaused = true;
                clickCounter = 0;
                return;
            }
        }

        long now = System.currentTimeMillis();
        if (now < nextClickTime) return;

        // ── Find target — vanilla crosshair entity hit result ────
        if (!(mc.crosshairTarget instanceof EntityHitResult hitResult)
                || !(hitResult.getEntity() instanceof LivingEntity le)) return;
        if (!le.isAlive()) return;
        if (le instanceof PlayerEntity && !игроки.isEnabled()) return;
        if (!(le instanceof PlayerEntity) && !мобы.isEnabled()) return;

        // ── Offhand switch: иногда кликаем offhand ───────────────────
        Hand hand = Hand.MAIN_HAND;
        if (сменаOffhand.isEnabled() && random.nextFloat() > 0.8f) {
            hand = Hand.OFF_HAND;
        }
        lastHand = hand;

        // ── Attack via packet (обход проверки менеджера) ─────────────
        if (кликПакет.isEnabled()) {
            PlayerInteractEntityC2SPacket packet = PlayerInteractEntityC2SPacket.attack(le, mc.player.isSneaking());
            mc.player.networkHandler.sendPacket(packet);
            mc.player.swingHand(hand);
        } else {
            mc.interactionManager.attackEntity(mc.player, le);
            mc.player.swingHand(hand);
        }

        // ── Jitter: имитация движения мыши после к��ика ───────────────
        if (дрожание.isEnabled()) {
            // Небольшое случайное движение (±1-3 пикселя)
            double jx = (random.nextDouble() - 0.5) * 4;
            double jy = (random.nextDouble() - 0.5) * 4;
            // Курсор уже там, но мы "имитируем" это в логике
        }

        // ── Schedule next click ──────────────────────────────────────
        double min = минCPS.getValue(), max = максCPS.getValue();
        if (min > max) min = max;
        double cps = min + random.nextDouble() * (max - min);

        // Добавляем рандом к интервалу (1.0 - 1.3x)
        double variance = 1.0 + random.nextDouble() * 0.3;
        nextClickTime = now + (long) ((1000.0 / Math.max(1.0, cps)) * variance);
    }

    @Override
    public void onDisable() {
        nextClickTime = 0;
        clickCounter = 0;
        pauseCounter = 0;
        isPaused = false;
    }
}
