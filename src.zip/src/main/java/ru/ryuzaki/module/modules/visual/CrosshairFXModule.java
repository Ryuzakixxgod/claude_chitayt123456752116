package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/CrosshairFXModule.java
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

public class CrosshairFXModule extends Module {
    public final ModeSetting    style = new ModeSetting("Style","Cross+Dot",
            "Dot","Cross","Cross+Dot","Circle","Arrow","Plus",
            "Sniper","Star","Triangle","Cosmic","Minimal");
    public final NumberSetting  size  = new NumberSetting("Size",   6.0, 2.0, 20.0, 1.0);
    public final NumberSetting  thick = new NumberSetting("Thick",  1.0, 1.0,  4.0, 1.0);
    public final NumberSetting  gap   = new NumberSetting("Gap",    2.0, 0.0,  8.0, 1.0);
    public final BooleanSetting dynSpread = new BooleanSetting("Dynamic Spread",true);
    public final BooleanSetting pulse = new BooleanSetting("Pulse", true);
    public final BooleanSetting rainbow=new BooleanSetting("Rainbow",false);
    public final ColorSetting   color = new ColorSetting("Color",new ColorRGBA(255,255,255,220));

    // Анимации
    private float expandAnim   = 0f; // расширение при атаке
    private float moveGap     = 0f; // расширение при движении
    private long  lastAttack  = 0;

    public CrosshairFXModule(){
        super("CrosshairFX","Кастомный прицел",Category.VISUAL);
        addSettings(style,size,thick,gap,dynSpread,pulse,rainbow,color);
    }

    // Вызывать при ударе из мixin
    public void onAttack(){ lastAttack=System.currentTimeMillis(); }

    public void render(DrawContext ctx){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(!mc.options.getPerspective().isFirstPerson()) return;
        if(mc.currentScreen!=null) return;

        int sw=mc.getWindow().getScaledWidth(), sh=mc.getWindow().getScaledHeight();
        int cx=sw/2, cy=sh/2;
        int sz=size.getValue().intValue();
        int th=thick.getValue().intValue();
        int gp=gap.getValue().intValue();
        long now=System.currentTimeMillis();
        float hue=(float)((now%4000)/4000.0);

        // Половина толщины для центрирования (правильное для чётных и нечётных)
        int th2 = th / 2;
        // Если толщина чётная — центр между пикселями, используем симметричную раскладку
        boolean evenThick = (th % 2 == 0);

        // Анимация расширения при ударе
        float attackAge=(now-lastAttack)/200f;
        expandAnim=lerp(expandAnim, attackAge<1f?(1f-attackAge)*4f:0f, 0.25f);
        // Dynamic gap — расширяется при движении, прыжке
        float targetMoveGap=0f;
        if(mc.player!=null){
            double hVel=mc.player.getVelocity().horizontalLength();
            if(!mc.player.isOnGround()) targetMoveGap+=3f;
            if(mc.player.isSprinting()) targetMoveGap+=2f;
            targetMoveGap+=(float)(hVel*8f);
            targetMoveGap=Math.min(targetMoveGap,8f);
        }
        moveGap=lerp(moveGap,targetMoveGap,0.12f);
        int expandedGap=gp+(int)expandAnim+(int)moveGap;
        int expandedSz=sz;

        float pm=pulse.isEnabled()?0.7f+0.3f*(float)Math.sin(now*0.005f):1f;

        ColorRGBA c=color.getColor();
        int baseR=c!=null?c.getRed():255, baseG=c!=null?c.getGreen():255, baseB=c!=null?c.getBlue():255;
        int baseA=c!=null?(int)(c.getAlpha()*pm):220;
        if(rainbow.isEnabled()){int[]rc=hsv(hue,0.9f,1f);baseR=rc[0];baseG=rc[1];baseB=rc[2];}
        int col=rgba(baseR,baseG,baseB,baseA);
        int col2=rgba(baseR,baseG,baseB,baseA/3);

        switch(style.getCurrent()){
            case "Dot" -> {
                for(int d=3;d>=1;d--) fill(ctx,cx-th-d,cy-th-d,cx+th+d+1,cy+th+d+1,rgba(baseR,baseG,baseB,baseA/4/d));
                fill(ctx,cx-th,cy-th,cx+th+1,cy+th+1,col);
            }
            case "Cross","Cross+Dot" -> {
                fill(ctx,cx-expandedSz-expandedGap,cy-th2,cx-expandedGap+1,cy-th2+th,col);
                fill(ctx,cx+expandedGap,cy-th2,cx+expandedSz+expandedGap+1,cy-th2+th,col);
                fill(ctx,cx-th2,cy-expandedSz-expandedGap,cx-th2+th,cy-expandedGap+1,col);
                fill(ctx,cx-th2,cy+expandedGap,cx-th2+th,cy+expandedSz+expandedGap+1,col);
                if(style.getCurrent().equals("Cross+Dot"))
                    fill(ctx,cx-1,cy-1,cx+2,cy+2,col);
            }
            case "Plus" -> {
                fill(ctx,cx-expandedSz,cy-th2,cx+expandedSz+1,cy-th2+th,col);
                fill(ctx,cx-th2,cy-expandedSz,cx-th2+th,cy+expandedSz+1,col);
            }
            case "Circle" -> {
                // Pixel-perfect circle — рисуем кольцо через scanline для чёткого результата
                int R=expandedSz+expandedGap;
                int R2=R*R, R2in=(R-th)*(R-th);
                for(int dy=-R;dy<=R;dy++){
                    for(int dx=-R;dx<=R;dx++){
                        int d2=dx*dx+dy*dy;
                        if(d2<=R2 && d2>=R2in) fill(ctx,cx+dx,cy+dy,cx+dx+1,cy+dy+1,col);
                    }
                }
                fill(ctx,cx-1,cy-1,cx+2,cy+2,col);
            }
            case "Arrow" -> {
                // Стрелка вверх
                fill(ctx,cx-expandedSz,cy+expandedGap,cx+expandedSz+1,cy+expandedGap+th,col);
                fill(ctx,cx-th2,cy-expandedSz+expandedGap,cx-th2+th,cy+expandedGap+th,col);
                // Уголки стрелки
                for(int i=0;i<sz/2;i++){
                    fill(ctx,cx-expandedSz+i,cy-expandedSz+expandedGap+i,cx-expandedSz+i+th,cy-expandedSz+expandedGap+i+th,col);
                    fill(ctx,cx+expandedSz-i,cy-expandedSz+expandedGap+i,cx+expandedSz-i+th,cy-expandedSz+expandedGap+i+th,col);
                }
            }
            case "Sniper" -> {
                // Длинные линии по всей ширине
                int longSz=sz*3;
                fill(ctx,cx-longSz,cy-(th2),cx-expandedGap,cy+th-(th2),col2);
                fill(ctx,cx+expandedGap,cy-(th2),cx+longSz,cy+th-(th2),col2);
                fill(ctx,cx-(th2),cy-longSz,cx+th-(th2),cy-expandedGap,col2);
                fill(ctx,cx-(th2),cy+expandedGap,cx+th-(th2),cy+longSz,col2);
                // Яркий ближний отрезок
                fill(ctx,cx-sz,cy-(th2),cx-expandedGap,cy+th-(th2),col);
                fill(ctx,cx+expandedGap,cy-(th2),cx+sz,cy+th-(th2),col);
                fill(ctx,cx-(th2),cy-sz,cx+th-(th2),cy-expandedGap,col);
                fill(ctx,cx-(th2),cy+expandedGap,cx+th-(th2),cy+sz,col);
                // Круг
                for(int i=0;i<24;i++){
                    double a1=2.0*Math.PI*i/24, a2=2.0*Math.PI*(i+1)/24;
                    drawLine(ctx,(int)(cx+sz*Math.cos(a1)),(int)(cy+sz*Math.sin(a1)),(int)(cx+sz*Math.cos(a2)),(int)(cy+sz*Math.sin(a2)),col,th);
                }
            }
            case "Star" -> {
                for(int i=0;i<6;i++){
                    double angle=Math.PI*i/3;
                    int ex=(int)(cx+(expandedSz+expandedGap)*Math.cos(angle));
                    int ey=(int)(cy+(expandedSz+expandedGap)*Math.sin(angle));
                    drawLine(ctx,cx,cy,ex,ey,col,th);
                }
                fill(ctx,cx-1,cy-1,cx+2,cy+2,col);
            }
            case "Triangle" -> {
                int ts=expandedSz+expandedGap;
                int tx1=cx, ty1=cy-ts;
                int tx2=cx-ts, ty2=cy+ts;
                int tx3=cx+ts, ty3=cy+ts;
                drawLine(ctx,tx1,ty1,tx2,ty2,col,th);
                drawLine(ctx,tx2,ty2,tx3,ty3,col,th);
                drawLine(ctx,tx3,ty3,tx1,ty1,col,th);
            }

            case "Cosmic" -> {
                // Вращающийся крест
                float angle=(float)((now%3000)/3000.0*Math.PI*2);
                for(int arm=0;arm<4;arm++){
                    double a=angle+arm*Math.PI/2;
                    for(int i=expandedGap;i<expandedSz+expandedGap;i++){
                        int px=(int)(cx+i*Math.cos(a));
                        int py=(int)(cy+i*Math.sin(a));
                        float bright=1f-(float)(i-expandedGap)/expandedSz;
                        int[]rc=rainbow.isEnabled()?hsv((hue+arm*0.25f)%1f,0.9f,1f):new int[]{baseR,baseG,baseB};
                        fill(ctx,px-th2,py-th2,px+th2+1,py+th2+1,rgba(rc[0],rc[1],rc[2],(int)(baseA*bright)));
                    }
                }
                // Пульсирующий центр
                for(int d=4;d>=1;d--) fill(ctx,cx-d,cy-d,cx+d+1,cy+d+1,rgba(baseR,baseG,baseB,(int)(baseA*0.15f/d)));
                fill(ctx,cx-1,cy-1,cx+2,cy+2,col);
            }
            case "Minimal" -> {
                // Только 4 маленькие точки по диагонали
                int d=expandedSz/2+expandedGap;
                fill(ctx,cx-d-1,cy-d-1,cx-d+1,cy-d+1,col);
                fill(ctx,cx+d-1,cy-d-1,cx+d+1,cy-d+1,col);
                fill(ctx,cx-d-1,cy+d-1,cx-d+1,cy+d+1,col);
                fill(ctx,cx+d-1,cy+d-1,cx+d+1,cy+d+1,col);
            }
        }
    }

    private static void fill(DrawContext ctx,int x1,int y1,int x2,int y2,int col){ctx.fill(x1,y1,x2,y2,col);}
    private static void drawLine(DrawContext ctx,int x1,int y1,int x2,int y2,int col,int th){
        int dx=Math.abs(x2-x1),dy=Math.abs(y2-y1);
        int steps=Math.max(dx,dy);
        if(steps==0){ctx.fill(x1,y1,x1+th,y1+th,col);return;}
        float sx=(float)(x2-x1)/steps, sy=(float)(y2-y1)/steps;
        for(int i=0;i<=steps;i++) ctx.fill(x1+(int)(sx*i),y1+(int)(sy*i),x1+(int)(sx*i)+th,y1+(int)(sy*i)+th,col);
    }
    private static float lerp(float a,float b,float t){return a+(b-a)*t;}
    private static int rgba(int r,int g,int b,int a){a=Math.min(255,Math.max(0,a));return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int[] hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}