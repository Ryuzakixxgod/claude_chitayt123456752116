package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.particle.ParticlesMode;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * RyuzakiFpsOptimizer — единый модуль максимального буста FPS.
 *
 * Объединяет ВСЕ оптимизации в одном месте с детальным контролем.
 * При включении применяет все выбранные опции, при выключении — восстанавливает.
 *
 * Что реально даёт FPS (по убыванию эффекта):
 *  1. Рендер дистанция: -2 chunk = +15-40 FPS
 *  2. Fast graphics (листва/вода): +10-25 FPS
 *  3. Entity distance 50%: +5-20 FPS (зависит от сервера)
 *  4. No particles: +3-15 FPS (зависит от окружения)
 *  5. No entity shadows: +2-8 FPS
 *  6. No AO (через RenderTweaks): +3-10 FPS
 *  7. No clouds: +2-5 FPS
 *  8. No biome blend: +1-3 FPS
 *  9. Lightmap throttle: +0.5-2 FPS
 * 10. No beacon beam: +0-2 FPS (только рядом с маяками)
 */
public class RyuzakiFpsOptimizer extends Module {
    public static RyuzakiFpsOptimizer INSTANCE;

    // ── Render ───────────────────────────────────────────────────────
    public final NumberSetting  renderDist   = new NumberSetting("Render Distance",   8,  2, 32, 1);
    public final NumberSetting  simDist      = new NumberSetting("Sim Distance",       5,  3, 12, 1);
    public final BooleanSetting fastGraphics = new BooleanSetting("Fast Graphics",    true);  // +10-25 FPS
    public final NumberSetting  entityDistPct= new NumberSetting("Entity Distance %", 50, 10,100, 5);  // +5-20 FPS

    // ── Particles & Effects ──────────────────────────────────────────
    public final BooleanSetting noParticles  = new BooleanSetting("No Particles",     true);  // +3-15 FPS
    public final NumberSetting  maxPart      = new NumberSetting("Max Particles",    1000,100,5000,100);

    // ── Entity ───────────────────────────────────────────────────────
    public final BooleanSetting noShadows    = new BooleanSetting("No Entity Shadows",true);  // +2-8 FPS
    public final BooleanSetting noAO         = new BooleanSetting("No Ambient Occl.",  true); // +3-10 FPS
    public final BooleanSetting noBiomeBlend = new BooleanSetting("No Biome Blend",   true);  // +1-3 FPS

    // ── Misc ─────────────────────────────────────────────────────────
    public final BooleanSetting noClouds     = new BooleanSetting("No Clouds",        true);  // +2-5 FPS
    public final BooleanSetting noBobbing    = new BooleanSetting("No View Bobbing",  false);
    public final BooleanSetting limitFPS     = new BooleanSetting("Cap FPS",          false);
    public final NumberSetting  fpsLimit     = new NumberSetting("FPS Cap",           120, 30,260,10);

    // ── Saved originals ──────────────────────────────────────────────
    private GraphicsMode  origGraphics;
    private ParticlesMode origParticles;
    private boolean       origShadows, origBobbing, saved=false;
    private int           origBiome, origRender, origSim, origFps;
    private double        origEntityDist;

    public RyuzakiFpsOptimizer(){
        super("FPS Optimizer","Максимальный буст FPS — все оптимизации в одном",Category.MISC);
        INSTANCE = this;
        addSettings(renderDist,simDist,fastGraphics,entityDistPct,
                    noParticles,maxPart,noShadows,noAO,noBiomeBlend,
                    noClouds,noBobbing,limitFPS,fpsLimit);
    }

    public static RyuzakiFpsOptimizer getInstance(){ return INSTANCE; }
    public boolean isNoAO(){ return isEnabled()&&noAO.isEnabled(); }
    public boolean isNoClouds(){ return isEnabled()&&noClouds.isEnabled(); }
    public int     getMaxParticles(){ return isEnabled()?maxPart.getValue().intValue():Integer.MAX_VALUE; }

    @Override
    public void onEnable(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.options==null) return;
        // Save
        origGraphics   = mc.options.getGraphicsMode().getValue();
        origParticles  = mc.options.getParticles().getValue();
        origShadows    = mc.options.getEntityShadows().getValue();
        origBiome      = mc.options.getBiomeBlendRadius().getValue();
        origRender     = mc.options.getViewDistance().getValue();
        origSim        = mc.options.getSimulationDistance().getValue();
        origEntityDist = mc.options.getEntityDistanceScaling().getValue();
        origBobbing    = mc.options.getBobView().getValue();
        origFps        = mc.options.getMaxFps().getValue();
        saved=true;
        apply(mc);
    }

    @Override
    public void onDisable(){
        if(!saved) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.options==null) return;
        mc.options.getGraphicsMode().setValue(origGraphics);
        mc.options.getParticles().setValue(origParticles);
        mc.options.getEntityShadows().setValue(origShadows);
        mc.options.getBiomeBlendRadius().setValue(origBiome);
        mc.options.getViewDistance().setValue(origRender);
        mc.options.getSimulationDistance().setValue(origSim);
        mc.options.getEntityDistanceScaling().setValue(origEntityDist);
        mc.options.getBobView().setValue(origBobbing);
        mc.options.getMaxFps().setValue(origFps);
        mc.options.write();
    }

    @Override
    public void onUpdate(){
        if(!saved) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.options==null) return;
        apply(mc);
    }

    private void apply(MinecraftClient mc){
        if(fastGraphics.isEnabled())
            mc.options.getGraphicsMode().setValue(GraphicsMode.FAST);
        if(noParticles.isEnabled())
            mc.options.getParticles().setValue(ParticlesMode.MINIMAL);
        if(noShadows.isEnabled())
            mc.options.getEntityShadows().setValue(false);
        if(noBiomeBlend.isEnabled())
            mc.options.getBiomeBlendRadius().setValue(0);
        mc.options.getViewDistance().setValue(renderDist.getValue().intValue());
        mc.options.getSimulationDistance().setValue(simDist.getValue().intValue());
        mc.options.getEntityDistanceScaling().setValue(entityDistPct.getValue()/100.0);
        if(noBobbing.isEnabled())
            mc.options.getBobView().setValue(false);
        if(limitFPS.isEnabled())
            mc.options.getMaxFps().setValue(fpsLimit.getValue().intValue());
    }
}
