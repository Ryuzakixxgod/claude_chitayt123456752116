package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * ParticleCuller — ограничивает максимальное число частиц в мире.
 *
 * Vanilla: нет жёсткого лимита, частицы копятся до сотен тысяч.
 * Sodium: обрезает очередь частиц и не рендерит дальние.
 * Мы: то же самое через MixinParticleManager.
 *
 * На ферме мобов или при взрывах — разница +40-80 FPS.
 */
public class ParticleCullerModule extends Module {
    public static ParticleCullerModule INSTANCE;

    public final NumberSetting  maxParticles = new NumberSetting("Max Particles", 2000, 100, 10000, 100);
    public final BooleanSetting noExplosion  = new BooleanSetting("No Explosion Particles", false);
    public final BooleanSetting noFire       = new BooleanSetting("No Fire Particles",      false);
    public final BooleanSetting noBlockBreak = new BooleanSetting("No Block Break",         false);

    public ParticleCullerModule() {super("Particle Culler", "Limit particle count (+FPS on farms)", Category.MISC);
                INSTANCE = this;
addSettings(maxParticles, noExplosion, noFire, noBlockBreak);
    }
}
