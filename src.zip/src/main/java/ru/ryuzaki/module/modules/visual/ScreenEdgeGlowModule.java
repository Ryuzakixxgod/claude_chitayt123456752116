package ru.ryuzaki.module.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.RyuzakiRenderCache;
import ru.ryuzaki.util.color.ColorRGBA;

/**
 * ScreenEdgeGlowModule — цветное свечение по краям экрана.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - 128 draw calls → 4 draw calls через ctx.fillGradient()
 *    Было: 32 слоя × 4 fill() = 128 вызовов + 32 new int[] каждый кадр
 *    Стало: 4 fillGradient() — GPU делает плавный градиент сам
 *  - Цвет пересчитывается только при изменении hue (каждые 4 кадра),
 *    не каждый кадр
 *  - Damage flash использует простой fillGradient вместо цикла
 */
public class ScreenEdgeGlowModule extends Module {
    public static ScreenEdgeGlowModule INSTANCE;

    public final NumberSetting  size    = new NumberSetting("Size",   50.0, 10.0, 150.0, 5.0);
    public final NumberSetting  alpha   = new NumberSetting("Alpha",  90.0, 10.0, 220.0, 5.0);
    public final BooleanSetting pulse   = new BooleanSetting("Pulse",   true);
    public final BooleanSetting rainbow = new BooleanSetting("Rainbow", true);
    public final BooleanSetting corners = new BooleanSetting("Corners", true);
    public final BooleanSetting breathe = new BooleanSetting("Breathe",true);
    public final BooleanSetting hpReact = new BooleanSetting("HP React",true);
    public final ColorSetting   color   = new ColorSetting("Color", new ColorRGBA(120, 50, 255, 180));

    private float hue          = 0f;
    private float breathePhase = 0f;
    private float dmgFlash     = 0f;

    // Кэш цвета — обновляется только когда hue реально меняется
    private int   cachedR = 120, cachedG = 50, cachedB = 255;
    private float lastCachedHue = -1f;

    public ScreenEdgeGlowModule() {
        super("ScreenEdgeGlow", "Атмосферный ореол по краям", Category.VISUAL);
        INSTANCE = this;
        addSettings(size, alpha, pulse, rainbow, corners, breathe, hpReact, color);
    }

    public void onTick() {
        if (!isEnabled()) return;
        hue = (hue + 0.0007f) % 1f;
        breathePhase += 0.018f;
        dmgFlash = Math.max(0f, dmgFlash - 0.06f);
    }

    public void onDamage() { dmgFlash = Math.min(1f, dmgFlash + 0.85f); }

    public void render(DrawContext ctx, int sw, int sh) {
        if (!isEnabled()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        float baseAlpha = alpha.getValue().floatValue();

        // ── Модификаторы яркости ────────────────────────────────────
        float hpMult = 1f;
        boolean lowHp = false;
        if (hpReact.isEnabled() && mc.player != null) {
            float hp = mc.player.getHealth() / mc.player.getMaxHealth();
            if (hp < 0.3f) {
                lowHp = true;
                hpMult = 1.5f + 0.5f * (float)Math.sin(RyuzakiRenderCache.now * 0.008f);
            }
        }
        float pMult = pulse.isEnabled()
            ? 0.6f + 0.4f * (float)Math.abs(Math.sin(RyuzakiRenderCache.now * 0.002f)) : 1f;
        float bMult = breathe.isEnabled()
            ? 1f + 0.15f * (float)Math.sin(breathePhase) : 1f;

        float finalAlpha = Math.min(255f, baseAlpha * pMult * bMult * hpMult);
        int   sz         = (int)(size.getValue() * bMult);

        // ── Определяем RGB ───────────────────────────────────────────
        // Пересчитываем только если hue изменился (не каждый кадр)
        if (rainbow.isEnabled()) {
            if (Math.abs(hue - lastCachedHue) > 0.002f) {
                int[] c = RyuzakiRenderCache.hsv(hue, 0.85f, 1f);
                cachedR = c[0]; cachedG = c[1]; cachedB = c[2];
                lastCachedHue = hue;
            }
        } else if (lowHp) {
            cachedR = 255; cachedG = 50; cachedB = 50;
        } else {
            ColorRGBA c = color.getColor();
            if (c == null) return;
            cachedR = c.getRed(); cachedG = c.getGreen(); cachedB = c.getBlue();
        }

        int a0  = (int)finalAlpha;        // у края — максимум
        int aFar = 0;                      // в центре — прозрачно
        int colEdge = rgba(cachedR, cachedG, cachedB, a0);
        int colFar  = rgba(cachedR, cachedG, cachedB, aFar);

        // ── 4 draw calls вместо 128 ──────────────────────────────────
        // Верх: градиент сверху вниз (от яркого к прозрачному)
        ctx.fillGradient(0, 0, sw, sz, colEdge, colFar);
        // Низ: снизу вверх
        ctx.fillGradient(0, sh - sz, sw, sh, colFar, colEdge);
        // Лево: слева направо
        ctx.fillGradient(0, sz, sz, sh - sz, colEdge, colFar);
        // Право: справа налево
        ctx.fillGradient(sw - sz, sz, sw, sh - sz, colFar, colEdge);

        // ── Углы — 4 дополнительных call при включённой настройке ───
        if (corners.isEnabled()) {
            int cSz = (int)(sz * 0.7f);
            // Угловые акценты — чуть ярче
            int colCorner = rgba(cachedR, cachedG, cachedB, Math.min(255, (int)(a0 * 1.3f)));
            ctx.fillGradient(0, 0, cSz, cSz, colCorner, colFar);
            ctx.fillGradient(sw - cSz, 0, sw, cSz, colCorner, colFar);
            ctx.fillGradient(0, sh - cSz, cSz, sh, colFar, colCorner);
            ctx.fillGradient(sw - cSz, sh - cSz, sw, sh, colFar, colCorner);
        }

        // ── Damage flash — красный пульс ─────────────────────────────
        if (dmgFlash > 0.01f) {
            int dA  = (int)(dmgFlash * 140);
            int dSz = (int)(sw * 0.12f * dmgFlash);
            int dCol = rgba(255, 30, 30, dA);
            // 4 call для флэша тоже
            ctx.fillGradient(0, 0, dSz, sh, dCol, rgba(255, 30, 30, 0));
            ctx.fillGradient(sw - dSz, 0, sw, sh, rgba(255, 30, 30, 0), dCol);
            ctx.fillGradient(dSz, 0, sw - dSz, dSz, dCol, rgba(255, 30, 30, 0));
            ctx.fillGradient(dSz, sh - dSz, sw - dSz, sh, rgba(255, 30, 30, 0), dCol);
        }
    }

    private static int rgba(int r, int g, int b, int a) {
        a = Math.max(0, Math.min(255, a));
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    private static int[] hsv(float h, float s, float v) {
        h = h % 1f; if (h < 0) h += 1f;
        int i = (int)(h * 6);
        float f = h*6-i, p=v*(1-s), q=v*(1-f*s), t=v*(1-(1-f)*s);
        float r, g, b;
        switch (i % 6) {
            case 0 -> {r=v;g=t;b=p;} case 1 -> {r=q;g=v;b=p;}
            case 2 -> {r=p;g=v;b=t;} case 3 -> {r=p;g=q;b=v;}
            case 4 -> {r=t;g=p;b=v;} default -> {r=v;g=p;b=q;}
        }
        return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};
    }
}
