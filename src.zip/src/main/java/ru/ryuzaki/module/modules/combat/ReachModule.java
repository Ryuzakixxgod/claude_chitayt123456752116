package ru.ryuzaki.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.Random;

/**
 * Reach — увеличивает дальность атаки.
 *
 * ОБХОДЫ АНТИЧИТА:
 *  - Hybrid attack: ближний бой через пакет (без проверки reach)
 *  - Reach smoothing: плавное увеличение reach, не резкое
 *  - Conditional: только при необходимости (атака, не idle)
 *  - Distance threshold: работает только на дистанции > vanilla (3.0)
 *  - Hitbox expand: небольшое расширение хитбокса вместо рейча
 */
public class ReachModule extends Module {

    private final Random random = new Random();

    public final NumberSetting дальность = new NumberSetting("Дальность", 3.5, 3.0, 5.0, 0.1);
    public final BooleanSetting гибрид = new BooleanSetting("Гибрид", true); // пакетный аттак
    public final BooleanSetting плавность = new BooleanSetting("Плавность", true); // плавное
    public final BooleanSetting расширитьХитбокс = new BooleanSetting("Расширение Хитбокса", false); // взамен
    public final NumberSetting величинаХитбокса = new NumberSetting("Величина Хитбокса", 0.1, 0.0, 0.3, 0.01);

    // Внутреннее
    private double currentReach = 3.0;
    private long lastAttackTime = 0;
    private static final double VANILLA_REACH = 3.0;
    private static final double REACH_STEP = 0.05; // шаг smoothing

    public ReachModule() {
        super("Reach", "Увеличивает дальность атаки", Category.COMBAT);
        addSettings(дальность, гибрид, плавность, расширитьХитбокс, величинаХитбокса);
    }

    public float getReach() {
        return isEnabled() ? дальность.getValue().floatValue() : (float) VANILLA_REACH;
    }

    /**
     * Плавное увеличение reach — для обхода "instant reach" детекта.
     */
    public double getSmoothReach() {
        if (!isEnabled()) return VANILLA_REACH;

        double target = дальность.getValue();
        if (!плавность.isEnabled()) return target;

        // Плавно двигаемся к цели
        if (currentReach < target) {
            currentReach = Math.min(currentReach + REACH_STEP, target);
        } else if (currentReach > target) {
            currentReach = Math.max(currentReach - REACH_STEP, target);
        }
        return currentReach;
    }

    /**
     * Расширение хитбокса для альтернативы reach.
     * Возвращает дополнительное расширение.
     */
    public double getHitboxExpand() {
        if (!isEnabled() || !расширитьХитбокс.isEnabled()) return 0;
        return величинаХитбокса.getValue();
    }

    /**
     * Проверка: пора ли атаковать (cooldown между проверками).
     * Нужно чтобы не спамить проверки на сервере.
     */
    public boolean shouldCheckAttack() {
        long now = System.currentTimeMillis();
        if (now - lastAttackTime < 100) return false; // мин 100ms между проверками
        lastAttackTime = now;
        return true;
    }

    @Override
    public void onDisable() {
        currentReach = VANILLA_REACH;
    }

    @Override
    public void onEnable() {
        currentReach = VANILLA_REACH;
    }
}
