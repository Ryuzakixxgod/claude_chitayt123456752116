package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/ScreenShakeModule.java
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

public class ScreenShakeModule extends Module {
    public static ScreenShakeModule INSTANCE;
    public final NumberSetting  intensity = new NumberSetting("Intensity", 1.8, 0.3, 6.0, 0.1);
    public final NumberSetting  duration  = new NumberSetting("Duration",  10.0, 3.0, 30.0, 1.0);
    public final ModeSetting    style     = new ModeSetting("Style","Directional","Directional","Random","Vertical","Horizontal");
    public final BooleanSetting fadeOut   = new BooleanSetting("Fade Out", true);

    private float shakeX=0,shakeY=0;
    private float decayX=0,decayY=0;
    private int   shakeTicks=0;
    private float originX=0,originY=0;

    public ScreenShakeModule(){
        super("ScreenShake","Эпическая тряска экрана при уроне",Category.VISUAL);
        INSTANCE = this;
        addSettings(intensity,duration,style,fadeOut);
    }

    // Вызывается из MixinLivingEntity при получении урона
    public void triggerShake(){
        if(!isEnabled()) return;
        double intens=intensity.getValue();
        switch(style.getCurrent()){
            case "Vertical"    -> { shakeX=0; shakeY=(float)(intens*1.8f); }
            case "Horizontal"  -> { shakeX=(float)(intens*1.8f); shakeY=0; }
            case "Directional" -> {
                double ang=Math.random()*Math.PI*2;
                shakeX=(float)(Math.cos(ang)*intens*1.5f);
                shakeY=(float)(Math.sin(ang)*intens*1.5f);
            }
            default -> {
                shakeX=(float)(Math.random()*intens*2-intens);
                shakeY=(float)(Math.random()*intens*2-intens);
            }
        }
        originX=shakeX; originY=shakeY;
        shakeTicks=duration.getValue().intValue();
        decayX=shakeX/Math.max(1,shakeTicks);
        decayY=shakeY/Math.max(1,shakeTicks);
    }

    // Вызывается из RyuzakiClient каждый тик
    public void onTick(){
        if(!isEnabled()||shakeTicks<=0){shakeX=0;shakeY=0;return;}
        if(fadeOut.isEnabled()){
            float progress=(float)shakeTicks/duration.getValue().floatValue();
            // Затухающая синусоида
            shakeX=originX*(float)Math.sin(shakeTicks*1.2f)*progress;
            shakeY=originY*(float)Math.cos(shakeTicks*1.0f)*progress;
        } else {
            shakeX-=decayX; shakeY-=decayY;
        }
        shakeTicks--;
    }

    public float getShakeX(){return isEnabled()?shakeX:0f;}
    public float getShakeY(){return isEnabled()?shakeY:0f;}
}
