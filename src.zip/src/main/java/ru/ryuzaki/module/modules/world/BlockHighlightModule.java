package ru.ryuzaki.module.modules.world;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.ArrayList;
import java.util.List;

public class BlockHighlightModule extends Module {

    public final NumberSetting  range   = new NumberSetting("Range", 16.0, 4.0, 32.0, 2.0);
    public final BooleanSetting diamond = new BooleanSetting("Diamonds",       true);
    public final BooleanSetting emerald = new BooleanSetting("Emeralds",       true);
    public final BooleanSetting gold    = new BooleanSetting("Gold",           true);
    public final BooleanSetting iron    = new BooleanSetting("Iron",           false);
    public final BooleanSetting ancient = new BooleanSetting("Ancient Debris", true);
    public final NumberSetting  glowLyr = new NumberSetting("Glow Layers", 3.0, 1.0, 6.0, 1.0);

    // int[] вместо long[] для безопасности, копируем координаты сразу
    private final List<int[]> cache = new ArrayList<>();
    private int tickCounter = 0;

    public BlockHighlightModule() {
        super("BlockHighlight", "Подсвечивает руды и ценные блоки", Category.WORLD);
        addSettings(range, diamond, emerald, gold, iron, ancient, glowLyr);
    }

    @Override
    public void onTick() {
        if (++tickCounter < 40) return; // раз в 40 тиков — меньше нагрузки
        tickCounter = 0;
        rebuildCache();
    }

    private void rebuildCache() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        List<int[]> newCache = new ArrayList<>();
        int r = Math.min(range.getValue().intValue(), 24); // максимум 24 блока
        BlockPos center = mc.player.getBlockPos();

        // Явно копируем координаты через иммутабельный BlockPos
        for (int x = -r; x <= r; x++) {
            for (int y = -r; y <= r; y++) {
                for (int z = -r; z <= r; z++) {
                    int bx = center.getX() + x;
                    int by = center.getY() + y;
                    int bz = center.getZ() + z;
                    try {
                        Block block = mc.world.getBlockState(new BlockPos(bx, by, bz)).getBlock();
                        int color = getColor(block);
                        if (color != 0) {
                            newCache.add(new int[]{bx, by, bz, color});
                        }
                    } catch (Exception ignored) {}
                }
            }
        }

        cache.clear();
        cache.addAll(newCache);
    }

    private int getColor(Block b) {
        if (diamond.isEnabled() && (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE))  return 0x00FFFF;
        if (emerald.isEnabled() && (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE))  return 0x00FF44;
        if (gold.isEnabled()    && (b == Blocks.GOLD_ORE    || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE)) return 0xFFCC00;
        if (iron.isEnabled()    && (b == Blocks.IRON_ORE    || b == Blocks.DEEPSLATE_IRON_ORE))     return 0xDDAA88;
        if (ancient.isEnabled() &&  b == Blocks.ANCIENT_DEBRIS)                                      return 0xFF4400;
        return 0;
    }

    public void render3D(MatrixStack ms, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!isEnabled() || mc.world == null || mc.player == null || cache.isEmpty()) return;

        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);

        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Tessellator tess = Tessellator.getInstance();
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        Matrix4f mat = ms.peek().getPositionMatrix();

        int layers = glowLyr.getValue().intValue();

        for (int[] d : cache) {
            int cr = (d[3] >> 16) & 0xFF, cg = (d[3] >> 8) & 0xFF, cb = d[3] & 0xFF;
            for (int gl = layers; gl >= 1; gl--) {
                float exp = gl * 0.035f;
                int a = Math.max(1, (int)(35f / gl));
                Box box = new Box(d[0]-exp, d[1]-exp, d[2]-exp,
                                  d[0]+1+exp, d[1]+1+exp, d[2]+1+exp);
                appendBox(buf, mat, box, cr, cg, cb, a);
            }
        }

        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception ignored) {}

        ms.pop();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    @Override public void onDisable() { cache.clear(); tickCounter = 0; }

    private static void appendBox(BufferBuilder b, Matrix4f m, Box box, int r, int g, int c, int a) {
        float x1=(float)box.minX, y1=(float)box.minY, z1=(float)box.minZ;
        float x2=(float)box.maxX, y2=(float)box.maxY, z2=(float)box.maxZ;
        b.vertex(m,x1,y1,z1).color(r,g,c,a); b.vertex(m,x2,y1,z1).color(r,g,c,a); b.vertex(m,x2,y1,z2).color(r,g,c,a); b.vertex(m,x1,y1,z2).color(r,g,c,a);
        b.vertex(m,x1,y2,z2).color(r,g,c,a); b.vertex(m,x2,y2,z2).color(r,g,c,a); b.vertex(m,x2,y2,z1).color(r,g,c,a); b.vertex(m,x1,y2,z1).color(r,g,c,a);
        b.vertex(m,x1,y1,z1).color(r,g,c,a); b.vertex(m,x1,y2,z1).color(r,g,c,a); b.vertex(m,x2,y2,z1).color(r,g,c,a); b.vertex(m,x2,y1,z1).color(r,g,c,a);
        b.vertex(m,x2,y1,z2).color(r,g,c,a); b.vertex(m,x2,y2,z2).color(r,g,c,a); b.vertex(m,x1,y2,z2).color(r,g,c,a); b.vertex(m,x1,y1,z2).color(r,g,c,a);
        b.vertex(m,x1,y1,z2).color(r,g,c,a); b.vertex(m,x1,y2,z2).color(r,g,c,a); b.vertex(m,x1,y2,z1).color(r,g,c,a); b.vertex(m,x1,y1,z1).color(r,g,c,a);
        b.vertex(m,x2,y1,z1).color(r,g,c,a); b.vertex(m,x2,y2,z1).color(r,g,c,a); b.vertex(m,x2,y2,z2).color(r,g,c,a); b.vertex(m,x2,y1,z2).color(r,g,c,a);
    }
}
