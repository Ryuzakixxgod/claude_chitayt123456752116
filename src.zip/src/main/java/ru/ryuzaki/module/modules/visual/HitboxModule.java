package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.FriendManager;
import ru.ryuzaki.util.RyuzakiRenderCache;

public class HitboxModule extends Module {
    public final ModeSetting   target  = new ModeSetting("Target","All","All","Players","Mobs","Hostile");
    public final ModeSetting   style   = new ModeSetting("Style","Cosmic","Cosmic","Pulse","Rainbow","Solid");
    public final BooleanSetting filled = new BooleanSetting("Filled",   false);
    public final BooleanSetting headBox= new BooleanSetting("Head Box", true);
    public final BooleanSetting eyeLine= new BooleanSetting("Eye Ray",  true);
    public final BooleanSetting dColor = new BooleanSetting("Dist Color",true);
    public final NumberSetting  alpha  = new NumberSetting("Alpha",160,30,255,5);

    private float hue=0f;

    public HitboxModule(){
        super("Hitboxes","Визуализация хитбоксов сущностей",Category.VISUAL);
        addSettings(target,style,filled,headBox,eyeLine,dColor,alpha);
        WorldRenderEvents.AFTER_ENTITIES.register(this::render);
    }

    private void render(WorldRenderContext ctx){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.world==null||mc.player==null) return;
        hue=(hue+0.002f)%1f;
        Vec3d cam=ctx.camera().getPos();
        float td=ctx.tickCounter().getTickDelta(true);
        MatrixStack ms=ctx.matrixStack(); ms.push();
        ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(net.minecraft.client.gl.ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        long now=System.currentTimeMillis();

        for(Entity e:mc.world.getEntities()){
            if(e==mc.player||!(e instanceof LivingEntity le)||!le.isAlive()) continue;
            if(!shouldTarget(le)) continue;
            // Невидимые: показываем только если есть броня
            if(le.isInvisible() && !hasVisibleArmor(le)) continue; // всё невидимое (зелье, флаг, команда)
            double dist=mc.player.squaredDistanceTo(e);
            if(dist>2500) continue; // 50 блоков

            Box box=le.getBoundingBox();
            int[]c=getColor(le,now,dist);
            float pulse=0.6f+0.4f*(float)Math.sin(now*0.004f+le.getId()*0.5f);
            int a=alpha.getValue().intValue();
            Matrix4f mat=ms.peek().getPositionMatrix();

            // Glow (additive)
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
            for(int gl=4;gl>=1;gl--){
                int ga=(int)(a*0.07f/gl*pulse);
                drawBoxEdges(tess,mat,box.expand(gl*0.06f),c,ga);
            }
            RenderSystem.defaultBlendFunc();

            // Fill
            if(filled.isEnabled()) drawBoxFill(tess,mat,box,c,(int)(a*0.12f));

            // Core
            drawBoxEdges(tess,mat,box,c,(int)(a*pulse));

            // Head box
            if(headBox.isEnabled()){
                double cx=(box.minX+box.maxX)/2, cy=box.maxY-0.3, cz=(box.minZ+box.maxZ)/2;
                float hw=0.35f;
                Box hBox=new Box(cx-hw,cy-0.3,cz-hw,cx+hw,cy+0.3,cz+hw);
                int[]hc=hsv((hue+0.33f)%1f,0.75f,1f);
                drawBoxEdges(tess,mat,hBox,hc,(int)(a*0.7f));
            }

            // Eye ray — луч взгляда с точкой попадания
            if(eyeLine.isEnabled()&&le instanceof PlayerEntity pe){
                Vec3d eyePos=pe.getEyePos();
                Vec3d lookVec=pe.getRotationVec(td);
                Vec3d endPos=eyePos.add(lookVec.multiply(20));

                // Check if looking at our player
                boolean lookingAtUs=pe.getVelocity().length()>0;
                int[]rc=lookingAtUs?new int[]{255,60,60}:new int[]{100,100,200};

                BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
                rb.vertex(mat,(float)eyePos.x,(float)eyePos.y,(float)eyePos.z).color(rc[0],rc[1],rc[2],180);
                rb.vertex(mat,(float)endPos.x,(float)endPos.y,(float)endPos.z).color(rc[0],rc[1],rc[2],0);
                try{BufferRenderer.drawWithGlobalProgram(rb.end());}catch(Exception ignored){}

                // Eye dot
                ms.push();
                ms.translate(eyePos.x,eyePos.y,eyePos.z);
                float yaw=(float)Math.toRadians(mc.gameRenderer.getCamera().getYaw());
                float pitch=(float)Math.toRadians(mc.gameRenderer.getCamera().getPitch());
                ms.multiply(new Quaternionf().rotateY((float)(Math.PI+yaw)));
                ms.multiply(new Quaternionf().rotateX(-pitch));
                Matrix4f dotMat=ms.peek().getPositionMatrix();
                RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
                BufferBuilder db=tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN,VertexFormats.POSITION_COLOR);
                db.vertex(dotMat,0,0,0).color(rc[0],rc[1],rc[2],200);
                for(int i=0;i<=8;i++){float ang=(float)(i*2*Math.PI/8);db.vertex(dotMat,(float)Math.cos(ang)*.06f,(float)Math.sin(ang)*.06f,0).color(rc[0],rc[1],rc[2],0);}
                try{BufferRenderer.drawWithGlobalProgram(db.end());}catch(Exception ignored){}
                RenderSystem.defaultBlendFunc();
                ms.pop();
            }
        }

        ms.pop();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private int[]getColor(LivingEntity e,long now,double dist){
        if(FriendManager.isFriend(e.getName().getString())) return new int[]{34,197,94};
        return switch(style.getCurrent()){
            case "Rainbow" -> hsv((now%5000)/5000f,0.85f,1f);
            case "Cosmic"  -> hsv((hue+e.getId()*0.1f)%1f,0.85f,1f);
            case "Solid"   -> RyuzakiRenderCache.rgb1;
            case "Pulse"   -> {
                float p=0.5f+0.5f*(float)Math.abs(Math.sin(now*0.004f+e.getId()));
                int[]b=RyuzakiRenderCache.rgb1;
                yield new int[]{(int)(b[0]*p+255*(1-p)),(int)(b[1]*p+255*(1-p)),(int)(b[2]*p+255*(1-p))};
            }
            default -> {
                if(dColor.isEnabled()){
                    // Close = red, far = theme color
                    float df=Math.min(1f,(float)(dist/2500f));
                    int[]t=RyuzakiRenderCache.rgb1;
                    yield new int[]{(int)(255*(1-df)+t[0]*df),(int)(60*(1-df)+t[1]*df),(int)(60*(1-df)+t[2]*df)};
                }
                yield RyuzakiRenderCache.rgb1;
            }
        };
    }

    private boolean shouldTarget(LivingEntity e){
        return switch(target.getCurrent()){
            case "Players"  -> e instanceof PlayerEntity;
            case "Mobs"     -> !(e instanceof PlayerEntity);
            case "Hostile"  -> e instanceof HostileEntity;
            default         -> true;
        };
    }

    private boolean hasVisibleArmor(LivingEntity le){
        for(ItemStack stack : le.getArmorItems()){
            if(!stack.isEmpty() && stack.getItem() != Items.AIR) return true;
        }
        return false;
    }

    private void drawBoxEdges(Tessellator tess,Matrix4f mat,Box b,int[]c,int a){
        if(a<=0) return;
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ;
        float x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
        int[][]edges={{0,1},{1,3},{3,2},{2,0},{4,5},{5,7},{7,6},{6,4},{0,4},{1,5},{2,6},{3,7}};
        float[][]pts={{x1,y1,z1},{x2,y1,z1},{x1,y1,z2},{x2,y1,z2},{x1,y2,z1},{x2,y2,z1},{x1,y2,z2},{x2,y2,z2}};
        for(int[]e:edges){float[]p1=pts[e[0]],p2=pts[e[1]];buf.vertex(mat,p1[0],p1[1],p1[2]).color(c[0],c[1],c[2],a);buf.vertex(mat,p2[0],p2[1],p2[2]).color(c[0],c[1],c[2],a);}
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private void drawBoxFill(Tessellator tess,Matrix4f mat,Box b,int[]c,int a){
        if(a<=0) return;
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ;
        float x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        buf.vertex(mat,x1,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z1).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z1).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x2,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z1).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y2,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y1,z2).color(c[0],c[1],c[2],a);
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}