package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.gui.FriendListScreen;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.BooleanSetting;

public class FriendsModule extends Module {

    public static FriendsModule INSTANCE;
    public final ModeSetting friendMode = new ModeSetting("Friend Mode", "Friends", "Friends", "Enemies");
    public final BooleanSetting notifications = new BooleanSetting("Notifications", true);

    public FriendsModule() {
        super("Friends", "Upravlenie druzьяmi", Category.MISC);
        INSTANCE = this;
        addSettings(friendMode, notifications);
        setEnabled(true);
    }

    public void openScreen() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.currentScreen == null || !(mc.currentScreen instanceof FriendListScreen)) {
            mc.setScreen(new FriendListScreen());
        }
    }
}
