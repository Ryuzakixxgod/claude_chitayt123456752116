package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;

import java.util.ArrayList;
import java.util.List;

/**
 * ChatHighlight — подсвечивает сообщения в чате.
 * Ключевые слова: твой ник, "tp", "trade", задаются ниже.
 * Inject: MixinChatHud
 */
public class ChatHighlightModule extends Module {
    private static ChatHighlightModule instance;

    public final BooleanSetting highlightName  = new BooleanSetting("Your Name", true);
    public final BooleanSetting highlightTrade = new BooleanSetting("Trade/TP",  true);
    public final BooleanSetting soundAlert     = new BooleanSetting("Sound",     true);

    public ChatHighlightModule() {
        super("Chat Highlight", "Highlight keywords in chat", Category.MISC);
        addSettings(highlightName, highlightTrade, soundAlert);
        instance = this;
    }

    public static ChatHighlightModule getInstance() { return instance; }

    /** Возвращает цвет подсветки или -1 если не нужно */
    public int getHighlightColor(String message) {
        if (!isEnabled()) return -1;
        net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
        String lower = message.toLowerCase();

        if (highlightName.isEnabled() && mc.player != null) {
            String name = mc.player.getName().getString().toLowerCase();
            if (lower.contains(name)) return 0xFFFFAA00; // золото — упомянули тебя
        }
        if (highlightTrade.isEnabled()) {
            if (lower.contains("trade") || lower.contains("продам") ||
                    lower.contains("куплю") || lower.contains("/tp")) {
                return 0xFF44FF44; // зелёный — торговля
            }
        }
        return -1;
    }
}