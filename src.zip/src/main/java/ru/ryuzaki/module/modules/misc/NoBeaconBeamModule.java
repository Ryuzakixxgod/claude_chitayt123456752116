package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;

/**
 * 🚀 No Beacon Beam
 *
 * Луч маяка — один из самых дорогих рендер-объектов в Minecraft:
 * • Пересчитывается каждый ТАЙМ (не кадр) — VBO rebuild
 * • Использует многослойный прозрачный рендер (дорогой blending)
 * • На серверах с 5+ маяками это может стоить 3-8ms/frame
 *
 * Подключается через MixinBeaconBlockEntityRenderer
 * (добавить в mixins.json + создать mixin).
 *
 * Статический геттер: используется из Mixin.
 */
public class NoBeaconBeamModule extends Module {
    private static NoBeaconBeamModule instance;

    public NoBeaconBeamModule() {
        super("No Beacon Beam", "Skip beacon beam render (+FPS on hubs)", Category.MISC);
        instance = this;
    }

    public static NoBeaconBeamModule getInstance() { return instance; }
    public static boolean shouldSkip() { return instance != null && instance.isEnabled(); }
}
