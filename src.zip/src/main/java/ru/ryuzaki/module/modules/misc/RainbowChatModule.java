package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * ✨ Rainbow Chat
 *
 * Раскрашивает каждый символ исходящего сообщения
 * в радужный цвет перед отправкой на сервер.
 * Использует §-коды Minecraft — работает на любом сервере.
 *
 * Подключается через MixinChatScreen (перехват sendMessage).
 * Геттер transformMessage() используется из Mixin.
 */
public class RainbowChatModule extends Module {
    private static RainbowChatModule instance;

    public final ModeSetting   style = new ModeSetting("Style",
        "Rainbow", "Rainbow", "Sunset", "Ocean", "Neon", "Gold");
    public final NumberSetting speed = new NumberSetting("Speed", 1.0, 0.1, 3.0, 0.1);

    // Цветовые схемы: массив §-кодов для каждого стиля
    private static final char[][] PALETTES = {
        {'4','c','6','e','a','2','b','3','9','5','d'}, // Rainbow
        {'4','c','6','e','6','e'},                      // Sunset
        {'1','3','b','f','9'},                          // Ocean
        {'5','d','b','a','e'},                          // Neon
        {'6','e','6','e','6'},                          // Gold
    };

    private static int globalOffset = 0;

    public RainbowChatModule() {
        super("Rainbow Chat", "Colorize outgoing chat messages", Category.MISC);
        addSettings(style, speed);
        instance = this;
    }

    public static RainbowChatModule getInstance() { return instance; }

    /** Вызывается из MixinChatScreen перед отправкой */
    public static String transformMessage(String original) {
        if (instance == null || !instance.isEnabled()) return original;
        if (original.startsWith("/")) return original; // команды не трогаем

        char[] palette = switch (instance.style.getCurrent()) {
            case "Sunset" -> PALETTES[1];
            case "Ocean"  -> PALETTES[2];
            case "Neon"   -> PALETTES[3];
            case "Gold"   -> PALETTES[4];
            default       -> PALETTES[0];
        };

        StringBuilder sb = new StringBuilder();
        int colIdx = globalOffset;
        for (char c : original.toCharArray()) {
            if (c == ' ') { sb.append(c); continue; }
            sb.append('§').append(palette[colIdx % palette.length]).append(c);
            colIdx++;
        }
        globalOffset = (int)(globalOffset + instance.speed.getValue()) % 100;
        return sb.toString();
    }
}
