package ru.ryuzaki.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import com.professor.cyberhacks.MC;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * AimAssist — интеллектуальный помощник прицеливания с предсказанием.
 *
 * Ключевые фичи:
 * 1. Linear & Acceleration Prediction:
 *    - PredictedPos = TargetPos + (TargetVelocity * PingFactor)
 *    - PingFactor = (ClientPing + ServerPing) / 1000.0 * 20.0
 *
 * 2. Gravity Compensation: для airborne-целей компенсируем гравитацию
 *    на время пинга. Формула: vy_comp = vy - 0.08 * 20 * PingFactor
 *
 * 3. Rotation Clamp:
 *    - Pitch: MathHelper.clamp(-90..+90)
 *    - Yaw: MathHelper.wrapDegrees (предотвращает 360° петли)
 *
 * 4. Inter-Tick Lerp:
 *    - frame-rate-independent smooth tracking
 *    - Lerp между последней известной позицией и предсказанной
 *    - Предотвращает "stutter" кроссхейра
 *
 * 5. Bounding Box Validation:
 *    - Raytrace использует ПРЕДСКАЗАННЫЙ хитбокс
 *    - Не теряем цель при резких движениях
 */
public final class AimAssistModule extends Module {

    public static AimAssistModule INSTANCE;

    // ── Settings ──────────────────────────────────────────────────
    public final NumberSetting максУгол = new NumberSetting("Макс Угол", 60.0, 5.0, 180.0, 1.0);
    public final NumberSetting максДист  = new NumberSetting("Макс Дистанция", 5.0, 1.0, 12.0, 0.1);
    public final NumberSetting скорость   = new NumberSetting("Скорость", 0.15, 0.01, 1.0, 0.01);
    public final NumberSetting силаПредсказания = new NumberSetting("Предсказание", 1.0, 0.0, 2.0, 0.05);
    public final NumberSetting серверПинг = new NumberSetting("Сервер Пинг", 50.0, 0.0, 500.0, 5.0);
    public final BooleanSetting гравитация = new BooleanSetting("Гравитация", true);
    public final BooleanSetting ускорение = new BooleanSetting("Ускорение", true);

    // ── Lerp State (inter-tick interpolation) ──────────────────────
    private Vec3d lastTargetPos = Vec3d.ZERO;
    private Vec3d lerpTargetPos = Vec3d.ZERO;
    private Box   lastTargetBox = null;
    private Box   lerpTargetBox = null;
    private float lerpProgress = 1.0f;
    private long  lastTargetTime = 0;

    // ── Target tracking & prediction ───────────────────────────────
    private LivingEntity trackedEntity = null;
    private Vec3d lastEntityVelocity = Vec3d.ZERO;
    private Vec3d lastEntityPos = Vec3d.ZERO;
    private long  lastEntityUpdateTime = 0;

    // ── Поправка для KillAura ─────────────────────────────────────
    private static float assistYawDelta = 0f;
    private static float assistPitchDelta = 0f;

    public AimAssistModule() {
        super("AimAssist", "Помощник прицеливания с предсказанием", Category.COMBAT);
        INSTANCE = this;
        addSettings(максУгол, максДист, скорость, силаПредсказания, серверПинг, гравитация, ускорение);
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;

        if (player == null || world == null) return;
        if (mc.currentScreen != null) return;
        if (player.isUsingItem()) return;

        calculateAssist(player, world);
    }

    private void calculateAssist(ClientPlayerEntity player, ClientWorld world) {
        long now = System.nanoTime();

        // ── 1. Find and track target ────────────────────────────────
        LivingEntity target = findTarget(player, world);
        if (target == null) {
            assistYawDelta = 0f;
            assistPitchDelta = 0f;
            trackedEntity = null;
            return;
        }

        // ── 2. Calculate PingFactor ────────────────────────────────
        // PingFactor = (ClientPing + ServerPing) / 1000.0 * 20.0
        // 20.0 = тиков в секунду (tick per second)
        long clientPing = getClientPing();
        long srvPing = серверПинг.getValue().longValue();
        double pingFactor = ((double) clientPing + (double) srvPing) / 1000.0 * 20.0;

        // ── 3. Extract current target position & velocity ──────────
        Vec3d targetPos = target.getBoundingBox().getCenter();
        Box   targetBox = target.getBoundingBox();

        Vec3d velocity;
        if (trackedEntity == target) {
            // Acceleration prediction: smooth velocity over time
            double dt = Math.max((now - lastEntityUpdateTime) / 1_000_000_000.0, 0.001);
            Vec3d rawVel = targetPos.subtract(lastEntityPos).multiply(1.0 / dt);

            // Lerp between last velocity and new velocity for smoothness
            double smooth = Math.min(dt * 8.0, 1.0);
            if (ускорение.isEnabled()) {
                velocity = lastEntityVelocity.add(rawVel.subtract(lastEntityVelocity).multiply(smooth));
            } else {
                velocity = rawVel;
            }
        } else {
            velocity = target.getVelocity();
            if (velocity.lengthSquared() < 0.0001) {
                velocity = Vec3d.ZERO;
            }
        }

        // ── 4. Predict future position ────────────────────────────
        double strength = силаПредсказания.getValue();
        double pf = pingFactor * strength;

        // PredictedPos = TargetPos + (TargetVelocity * PingFactor)
        double px = targetPos.x + velocity.x * pf;
        double py = targetPos.y;
        double pz = targetPos.z + velocity.z * pf;

        // ── 5. Gravity compensation for airborne targets ───────────
        if (гравитация.isEnabled() && !target.isOnGround()) {
            // vy изменяется как: vy - 0.08 * ticks
            // Интеграл: vy * pf - 0.08 * pf * (pf + 1) / 2
            double vyComp = velocity.y * pf - 0.08 * pf * (pf + 1.0) / 2.0;
            // Смещение вверх (для прыжка) или вниз (для падения)
            py += vyComp;
            // Не ниже начальной высоты (floor clamp)
            World w = target.getEntityWorld();
            if (py < targetPos.y && w != null && w.getBlockState(
                    target.getBlockPos().down()).isSolid()) {
                py = targetPos.y;
            }
        }

        // ── 6. Build predicted bounding box ────────────────────────
        // Используем ПРЕДСКАЗАННУЮ позицию для хитбокса
        double hw = (targetBox.maxX - targetBox.minX) / 2.0;
        double hd = (targetBox.maxZ - targetBox.minZ) / 2.0;
        double h  =  targetBox.maxY - targetBox.minY;

        Box predBox = new Box(
            px - hw, py,         pz - hd,
            px + hw, py + h,     pz + hd
        );

        // ── 7. Inter-Tick Lerp interpolation ───────────────────────
        // lerpProgress: 1.0 = на предсказанной позиции, 0.0 = на последней известной
        float spd = MathHelper.clamp(скорость.getValue().floatValue(), 0.01f, 1.0f);

        if (trackedEntity == target) {
            double dtMs = (now - lastTargetTime) / 1_000_000.0;
            lerpProgress = Math.min(1.0f, lerpProgress + (float) (spd * dtMs * 0.06));
        } else {
            lerpProgress = 0.0f;
        }

        // Lerp между lastTargetPos и предсказанной
        float t = lerpProgress;
        lerpTargetPos = new Vec3d(
            lerp(lastTargetPos.x, px, t),
            lerp(lastTargetPos.y, py, t),
            lerp(lastTargetPos.z, pz, t)
        );

        // Lerp хитбокс
        if (lastTargetBox != null) {
            lerpTargetBox = lerpBox(lastTargetBox, predBox, t);
        } else {
            lerpTargetBox = predBox;
        }

        // ── 8. Calculate rotation to lerpTargetPos ────────────────
        Vec3d eyePos = player.getEyePos();
        Vec3d delta = lerpTargetPos.subtract(eyePos);
        double dist = delta.length();
        if (dist < 0.01) return;

        float neededYaw   = (float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90f;
        float neededPitch = (float) Math.toDegrees(Math.atan2(-delta.y, Math.sqrt(delta.x * delta.x + delta.z * delta.z)));

        // Rotation clamp: pitch -90..+90, yaw via wrapDegrees
        neededYaw    = MathHelper.wrapDegrees(neededYaw);
        neededPitch  = MathHelper.clamp(neededPitch, -90f, 90f);

        // ── 9. Delta relative to current angle ────────────────────
        float currentYaw   = player.getYaw();
        float currentPitch = player.getPitch();

        float deltaYaw   = MathHelper.wrapDegrees(neededYaw - currentYaw);
        float deltaPitch = neededPitch - currentPitch;

        // Clamp delta to максУгол setting
        float максУголVal = максУгол.getValue().floatValue();
        if (deltaYaw > максУголVal)   deltaYaw   =  максУголVal;
        if (deltaYaw < -максУголVal)  deltaYaw   = -максУголVal;
        if (deltaPitch > максУголVal) deltaPitch =  максУголVal;
        if (deltaPitch < -максУголVal)deltaPitch = -максУголVal;

        assistYawDelta   = deltaYaw;
        assistPitchDelta = deltaPitch;

        // ── 10. Update tracking state ────────────────────────────
        trackedEntity = target;
        lastEntityPos = targetPos;
        lastEntityVelocity = velocity;
        lastEntityUpdateTime = now;

        if (lerpProgress < 1.0f) {
            lastTargetPos = targetPos;
            lastTargetBox = targetBox;
            lastTargetTime = now;
        }
    }

    /**
     * Raytrace using the PREDICTED bounding box (not current one).
     * Validates that the predicted position is reachable.
     */
    public static Vec3d getPredictedTargetPos() {
        if (INSTANCE == null) return Vec3d.ZERO;
        return INSTANCE.lerpTargetPos;
    }

    public static Box getPredictedTargetBox() {
        if (INSTANCE == null) return null;
        return INSTANCE.lerpTargetBox;
    }

    private LivingEntity findTarget(ClientPlayerEntity player, ClientWorld world) {
        double maxRange = максДист.getValue();
        double maxFov   = максУгол.getValue();

        Vec3d eyePos = player.getEyePos();
        Vec3d lookDir = player.getRotationVec(1.0f);

        LivingEntity closest = null;
        double bestScore = Double.MAX_VALUE;

        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e == player) continue;
            if (!le.isAlive()) continue;

            double d = le.distanceTo(player);
            if (d > maxRange) continue;

            Vec3d toTarget = le.getBoundingBox().getCenter().subtract(eyePos).normalize();
            double dot = lookDir.dotProduct(toTarget);
            double angle = Math.toDegrees(Math.acos(MathHelper.clamp(dot, -1.0, 1.0)));
            if (angle > maxFov) continue;

            double score = d + angle * 0.05;
            if (score < bestScore) {
                bestScore = score;
                closest = le;
            }
        }
        return closest;
    }

    private long getClientPing() {
        return MC.getPing();
    }

    private static double lerp(double a, double b, float t) {
        return a + (b - a) * t;
    }

    private static Box lerpBox(Box a, Box b, float t) {
        return new Box(
            lerp(a.minX, b.minX, t),
            lerp(a.minY, b.minY, t),
            lerp(a.minZ, b.minZ, t),
            lerp(a.maxX, b.maxX, t),
            lerp(a.maxY, b.maxY, t),
            lerp(a.maxZ, b.maxZ, t)
        );
    }

    /** Поправка yaw для KillAura. */
    public static float getAssistYawDelta() { return assistYawDelta; }
    /** Поправка pitch для KillAura. */
    public static float getAssistPitchDelta() { return assistPitchDelta; }
}
