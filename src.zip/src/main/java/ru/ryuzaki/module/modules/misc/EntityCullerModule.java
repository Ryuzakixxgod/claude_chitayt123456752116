package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;

import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.BatEntity;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.util.BitSet;
import java.util.HashSet;
import java.util.Set;

/**
 * EntityCuller — пропускает рендер сущностей вне FOV и за дистанцией.
 *
 * УЛУЧШЕНИЯ:
 * 1. Использует RyuzakiRenderCache.isInFrustum() — ноль тригонометрии в culling
 * 2. Кэш skipSet обновляется каждые 2 тика (было 3 — точнее)
 * 3. Используем HashSet<Integer> вместо Set<Entity> — нет GC pressure от WeakRef
 * 4. Ранний выход по distSq без sqrt для decoration/passive проверок
 * 5. Разделение: тяжёлые проверки (frustum) только для сущностей > 8 блоков
 */
public class EntityCullerModule extends Module {
    private static EntityCullerModule instance;

    public final BooleanSetting frustumCull     = new BooleanSetting("Frustum Cull",     true);
    public final BooleanSetting sizeCull        = new BooleanSetting("Size Cull",         true);
    public final BooleanSetting cullDecorations = new BooleanSetting("Cull Decorations",  true);
    public final BooleanSetting cullPassive     = new BooleanSetting("Cull Passive Mobs", true);
    public final BooleanSetting cullAmbient     = new BooleanSetting("Cull Ambient",      true);
    public final NumberSetting  maxDecoDist     = new NumberSetting("Deco Dist",   16, 4,  48, 2);
    public final NumberSetting  maxPassiveDist  = new NumberSetting("Passive Dist",24, 8,  64, 4);
    public final NumberSetting  maxGlobalDist   = new NumberSetting("Max Dist",    96, 16, 256, 8);

    // Integer ID вместо Entity — избегаем WeakHashMap overhead
    private static final Set<Integer> skipSet = new HashSet<>(256);
    private static int tickCount = 0;

    public EntityCullerModule() {
        super("Entity Culler", "Skip offscreen entity rendering", Category.MISC);
        addSettings(frustumCull, sizeCull, cullDecorations, cullPassive, cullAmbient,
                    maxDecoDist, maxPassiveDist, maxGlobalDist);
        instance = this;
    }

    public static EntityCullerModule getInstance() { return instance; }

    @Override
    public void onUpdate() {
        // Обновляем каждые 2 тика — баланс точности и производительности
        if (++tickCount < 2) return;
        tickCount = 0;
        rebuildSkipSet();
    }

    private void rebuildSkipSet() {
        skipSet.clear();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        // RyuzakiRenderCache уже обновлён в начале кадра — используем кэш

        double maxGlobal  = maxGlobalDist.getValue();
        double maxGlobalSq= maxGlobal * maxGlobal;
        double maxDecoSq  = maxDecoDist.getValue() * maxDecoDist.getValue();
        double maxPassSq  = maxPassiveDist.getValue() * maxPassiveDist.getValue();

        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player || !e.isAlive()) continue;

            double ex = e.getX(), ey = e.getY() + e.getHeight() * 0.5, ez = e.getZ();

            // 1. Глобальный лимит дистанции (самая быстрая проверка)
            double distSq = RyuzakiRenderCache.camDistSq(ex, ey, ez);
            if (distSq > maxGlobalSq) { skipSet.add(e.getId()); continue; }

            // 2. Тип-специфичная дистанция
            if (cullDecorations.isEnabled()
                    && (e instanceof ItemFrameEntity || e instanceof ArmorStandEntity)
                    && distSq > maxDecoSq) {
                skipSet.add(e.getId()); continue;
            }
            if (cullPassive.isEnabled()
                    && (e instanceof AnimalEntity)
                    && distSq > maxPassSq) {
                skipSet.add(e.getId()); continue;
            }
            if (cullAmbient.isEnabled()
                    && (e instanceof BatEntity)
                    && distSq > maxDecoSq) {
                skipSet.add(e.getId()); continue;
            }

            // 3. Frustum — через кэш, только для > 8 блоков
            if (frustumCull.isEnabled() && distSq > 64.0) {
                if (!RyuzakiRenderCache.isInFrustum(ex, ey, ez)) {
                    skipSet.add(e.getId()); continue;
                }
            }

            // 4. Угловой размер — только для > 32 блоков
            if (sizeCull.isEnabled() && distSq > 32 * 32) {
                double dist = Math.sqrt(distSq);
                double entitySize = Math.max(e.getWidth(), e.getHeight());
                // Пороговый угловой размер 0.4° (меньше = невидимо)
                if (entitySize / dist < 0.007) {
                    skipSet.add(e.getId());
                }
            }
        }
    }

    public static boolean shouldSkipRender(Entity e) {
        if (instance == null || !instance.isEnabled()) return false;
        return skipSet.contains(e.getId());
    }

    @Override public void onDisable() { skipSet.clear(); tickCount = 0; }
}
