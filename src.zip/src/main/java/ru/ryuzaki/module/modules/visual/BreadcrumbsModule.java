package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.RyuzakiRenderCache;
import ru.ryuzaki.util.Vec3RingBuffer;

/**
 * BreadcrumbsModule — след пройденного пути.
 * Оптимизации:
 * - Vec3RingBuffer вместо Deque → ноль GC
 * - Один DEBUG_LINE_STRIP вместо N draw calls
 */
public class BreadcrumbsModule extends Module {
    public final NumberSetting  length  = new NumberSetting("Length",  200, 20, 500, 10);
    public final ModeSetting    style   = new ModeSetting("Style","Cosmic","Cosmic","Rainbow","Solid","Void");
    public final BooleanSetting glow    = new BooleanSetting("Glow",   true);
    public final NumberSetting  opacity = new NumberSetting("Opacity", 180, 50, 255, 5);

    private static final int MAX = 512;
    private final Vec3RingBuffer crumbs = new Vec3RingBuffer(MAX);
    private float hue = 0f;
    private boolean registered = false;

    public BreadcrumbsModule() {
        super("Breadcrumbs","След пройденного пути",Category.VISUAL);
        addSettings(length, style, glow, opacity);
    }

    @Override
    public void onEnable() {
        crumbs.clear();
        if (!registered) {
            WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
            registered = true;
        }
    }

    @Override public void onDisable() { crumbs.clear(); }

    public void tick() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        hue = (hue + 0.002f) % 1f;
        double px = mc.player.getX(), py = mc.player.getY(), pz = mc.player.getZ();
        boolean onGround = mc.player.isOnGround();
        boolean meaningful = crumbs.isEmpty() ||
            Math.abs(crumbs.getX(0)-px) > 0.35 ||
            Math.abs(crumbs.getZ(0)-pz) > 0.35;
        // Don't record mid-air jumps (Y spike) — only record on ground or landing
        boolean recordY = onGround || (crumbs.size()>0 && Math.abs(crumbs.getY(0)-py)<0.6);
        if (meaningful) {
            double recY = recordY ? py : crumbs.size()>0?crumbs.getY(0):py;
            crumbs.push(px, recY, pz);
        }
    }

    private void render(WorldRenderContext ctx) {
        int total = Math.min(crumbs.size(), length.getValue().intValue());
        if (!isEnabled() || total < 2) return;
        var cam = ctx.camera().getPos();
        MatrixStack ms = ctx.matrixStack(); if (ms==null) return;
        ms.push(); ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Matrix4f mat = ms.peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        int baseA = opacity.getValue().intValue();

        // Glow — один проход additive
        if (glow.isEnabled()) {
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
            BufferBuilder gb = tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
            for (int i = total-1; i >= 0; i--) {
                float f = 1f-(float)i/(total-1);
                int[] c = getColor(i, total);
                gb.vertex(mat, crumbs.getX(i), crumbs.getY(i)+0.1f, crumbs.getZ(i))
                  .color(c[0],c[1],c[2],(int)(baseA*f*0.25f));
            }
            try{ BufferRenderer.drawWithGlobalProgram(gb.end()); }catch(Exception e){}
            RenderSystem.defaultBlendFunc();
        }

        // Core — один draw call
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = total-1; i >= 0; i--) {
            float f = 1f-(float)i/(total-1);
            int[] c = getColor(i, total);
            buf.vertex(mat, crumbs.getX(i), crumbs.getY(i)+0.1f, crumbs.getZ(i))
               .color(c[0],c[1],c[2],(int)(baseA*f));
        }
        try{ BufferRenderer.drawWithGlobalProgram(buf.end()); }catch(Exception e){}
        ms.pop();
        RenderSystem.enableCull(); RenderSystem.disableBlend();
    }

    private int[] getColor(int i, int total) {
        float f = 1f-(float)i/(total-1);
        int[] r1=RyuzakiRenderCache.rgb1, r2=RyuzakiRenderCache.rgb2;
        return switch(style.getCurrent()) {
            case "Rainbow" -> hsv((hue+f*0.4f)%1f,0.9f,1f);
            case "Solid"   -> r1;
            case "Void"    -> new int[]{(int)(40*f),0,(int)(80*f)};
            default        -> new int[]{(int)(r1[0]+(r2[0]-r1[0])*f),(int)(r1[1]+(r2[1]-r1[1])*f),(int)(r1[2]+(r2[2]-r1[2])*f)};
        };
    }
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
