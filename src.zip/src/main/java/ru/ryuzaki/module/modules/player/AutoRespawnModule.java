package ru.ryuzaki.module.modules.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.NumberSetting;

/**
 * AutoRespawn — автоматически возрождается после смерти.
 * Отправляет пакет respawn через заданную задержку (мс).
 */
public class AutoRespawnModule extends Module {

    public final NumberSetting delay = new NumberSetting("Delay (ms)", 500.0, 0.0, 3000.0, 100.0);

    private long deathTime = -1;

    public AutoRespawnModule() {
        super("AutoRespawn", "Авто-возрождение после смерти", Category.PLAYER);
        addSettings(delay);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        if (mc.currentScreen instanceof DeathScreen) {
            if (deathTime < 0) deathTime = System.currentTimeMillis();

            long elapsed = System.currentTimeMillis() - deathTime;
            if (elapsed >= delay.getValue().longValue()) {
                mc.player.networkHandler.sendPacket(
                    new ClientStatusC2SPacket(ClientStatusC2SPacket.Mode.PERFORM_RESPAWN)
                );
                deathTime = -1;
                mc.setScreen(null);
            }
        } else {
            deathTime = -1;
        }
    }

    @Override public void onDisable() { deathTime = -1; }
}
