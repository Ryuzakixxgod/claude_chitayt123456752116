package ru.ryuzaki.module.modules.animation;
// src/main/java/ru/ryuzaki/module/modules/animation/SmoothCameraModule.java
import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

public class SmoothCameraModule extends Module {
    public static SmoothCameraModule INSTANCE;
    public final NumberSetting  smoothing  = new NumberSetting("Smoothing",  0.12, 0.01, 0.5, 0.01);
    public final NumberSetting  cinematic  = new NumberSetting("Cinematic",  0.08, 0.01, 0.4, 0.01);
    public final BooleanSetting enabledPitchSmooth = new BooleanSetting("Smooth Pitch", true);
    public final BooleanSetting enabledYawSmooth   = new BooleanSetting("Smooth Yaw",   true);

    private float smoothYaw   = 0f;
    private float smoothPitch = 0f;
    private boolean initialized = false;

    public SmoothCameraModule(){
        super("SmoothCamera","Плавная кинематографическая камера",Category.ANIMATION);
        addSettings(smoothing,cinematic,enabledPitchSmooth,enabledYawSmooth);
    }

    @Override public void onEnable()  { initialized=false; }
    @Override public void onDisable() { initialized=false; }

    // Вызывается из MixinCamera перед применением углов
    // Возвращает интерполированный yaw
    public float getSmoothYaw(float realYaw) {
        if(!isEnabled()||!enabledYawSmooth.isEnabled()) return realYaw;
        if(!initialized){smoothYaw=realYaw;initialized=true;}
        float sp=smoothing.getValue().floatValue();
        // Интерполяция с учётом wrap-around
        float diff=realYaw-smoothYaw;
        while(diff>180)diff-=360;
        while(diff<-180)diff+=360;
        smoothYaw+=diff*sp;
        return smoothYaw;
    }

    // Вызывается из MixinCamera
    public float getSmoothPitch(float realPitch) {
        if(!isEnabled()||!enabledPitchSmooth.isEnabled()) return realPitch;
        float sp=smoothing.getValue().floatValue()*1.2f;
        smoothPitch=smoothPitch+(realPitch-smoothPitch)*sp;
        return smoothPitch;
    }
}
