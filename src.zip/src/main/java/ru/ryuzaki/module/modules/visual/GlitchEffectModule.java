package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/GlitchEffectModule.java
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;
import java.util.Random;

public class GlitchEffectModule extends Module {
    public final NumberSetting  chance    = new NumberSetting("Chance",    12.0, 1.0, 60.0, 1.0);
    public final NumberSetting  intensity = new NumberSetting("Intensity",  1.2, 0.1, 3.0, 0.1);
    public final ModeSetting    style     = new ModeSetting("Style","Cyber","Cyber","VHS","Digital","Static","Horror");
    public final BooleanSetting scanLines = new BooleanSetting("Scan Lines",true);

    private final Random rng=new Random();
    private long nextGlitch=0;
    private int  glitchTicks=0;
    private float hue=0f;
    private final int[]sY=new int[12],sH=new int[12],sOff=new int[12];
    private final int[]sCol=new int[12];
    private float staticNoise=0f;

    public GlitchEffectModule(){super("GlitchEffect","Кинематографический глитч",Category.VISUAL);addSettings(chance,intensity,style,scanLines);}

    public void onTick(){
        if(!isEnabled())return;
        hue=(hue+0.008f)%1f;
        long now=System.currentTimeMillis();
        if(now>=nextGlitch){
            if(rng.nextInt(100)<chance.getValue().intValue()){
                glitchTicks=2+rng.nextInt(6);
                regenStrips();
                staticNoise=0.3f+rng.nextFloat()*0.5f;
            }
            nextGlitch=now+150+rng.nextInt(600);
        }
        if(glitchTicks>0){glitchTicks--;staticNoise*=0.85f;}
        else staticNoise=0f;
    }

    private void regenStrips(){
        int sh=MinecraftClient.getInstance().getWindow().getScaledHeight();
        int sw=MinecraftClient.getInstance().getWindow().getScaledWidth();
        double intens=intensity.getValue();
        for(int i=0;i<12;i++){
            sY[i]=rng.nextInt(Math.max(1,sh));
            sH[i]=1+rng.nextInt(Math.max(1,(int)(8*intens)));
            sOff[i]=(int)((rng.nextInt(60)-30)*intens);
            sCol[i]=switch(style.getCurrent()){
                case"VHS"     ->rgba(255,50,50,60+rng.nextInt(40));
                case"Digital" ->rgba(0,255,100,50+rng.nextInt(40));
                case"Horror"  ->rgba(180,0,0,80+rng.nextInt(60));
                case"Static"  ->rgba(200,200,200,40+rng.nextInt(40));
                default       ->hsv2int((hue+i*0.08f)%1f,0.9f,1f,50+rng.nextInt(40));
            };
        }
    }

    public void render(DrawContext ctx,int sw,int sh){
        if(!isEnabled()||glitchTicks<=0) return;
        double intens=intensity.getValue();
        int off=(int)(2.5*intens);

        // ── Хроматическая аберрация ──────────────────────────────────────
        switch(style.getCurrent()){
            case"VHS" -> {
                ctx.fill(off,0,sw,sh,rgba(255,0,0,(int)(20*intens)));
                ctx.fill(0,0,Math.max(0,sw-off),sh,rgba(0,0,255,(int)(20*intens)));
                ctx.fill(0,off,sw,sh,rgba(0,255,0,(int)(10*intens)));
            }
            case"Horror" -> {
                ctx.fill(0,0,sw,sh,rgba(140,0,0,(int)(30*intens)));
                ctx.fill(off*2,0,sw,sh,rgba(80,0,0,(int)(15*intens)));
            }
            case"Cyber" -> {
                ctx.fill(off,0,sw,sh,rgba(0,255,200,(int)(15*intens)));
                ctx.fill(0,0,Math.max(0,sw-off),sh,rgba(255,0,100,(int)(15*intens)));
            }
            case"Digital" -> ctx.fill(off,0,sw,sh,rgba(0,255,80,(int)(18*intens)));
            default -> {
                ctx.fill(off,0,sw,sh,rgba(255,50,50,(int)(20*intens)));
                ctx.fill(0,0,Math.max(0,sw-off),sh,rgba(50,50,255,(int)(20*intens)));
            }
        }

        // ── Полосы смещения ───────────────────────────────────────────────
        for(int i=0;i<12;i++){
            if(sH[i]<=0) continue;
            int y2=Math.min(sh,sY[i]+sH[i]);
            int x1=Math.max(0,sOff[i]),x2=Math.min(sw,sw+sOff[i]);
            if(x1<x2) ctx.fill(x1,sY[i],x2,y2,sCol[i]);
        }

        // ── Scan lines ────────────────────────────────────────────────────
        if(scanLines.isEnabled()){
            int step=(int)(3/intens+1);
            for(int y=0;y<sh;y+=step*2) ctx.fill(0,y,sw,y+1,rgba(0,0,0,(int)(20*intens)));
        }

        // ── Статик шум ────────────────────────────────────────────────────
        if(staticNoise>0.05f){
            for(int i=0;i<(int)(200*staticNoise*intens);i++){
                int nx=rng.nextInt(sw), ny=rng.nextInt(sh);
                int na=(int)(staticNoise*200);
                ctx.fill(nx,ny,nx+rng.nextInt(4)+1,ny+1,rgba(255,255,255,na));
            }
        }
    }

    private static int rgba(int r,int g,int b,int a){a=Math.min(255,a);return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int hsv2int(float h,float s,float v,int a){int[]c=hsv(h,s,v);return rgba(c[0],c[1],c[2],a);}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
