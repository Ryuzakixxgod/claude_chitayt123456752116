package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * BlockEntityCuller — пропускает рендер BlockEntity (сундуки, знаки,
 * маяки, шалкеры и т.д.) вне поля зрения и за максимальной дистанцией.
 *
 * Это ГЛАВНАЯ оптимизация Sodium для серверов и хабов.
 * На хабе с 500+ сундуками даёт +30-60 FPS.
 *
 * Подключается через MixinBlockEntityRenderDispatcher.
 */
public class BlockEntityCullerModule extends Module {
    public static BlockEntityCullerModule INSTANCE;

    public final BooleanSetting frustumCull = new BooleanSetting("Frustum Cull", true);
    public final NumberSetting  maxDist     = new NumberSetting("Max Distance", 64, 16, 256, 8);
    public final BooleanSetting skipSigns   = new BooleanSetting("Skip Signs",  true);

    public BlockEntityCullerModule() {super("Block Entity Culler", "Skip offscreen block entity render (+FPS)", Category.MISC);
                INSTANCE = this;
addSettings(frustumCull, maxDist, skipSigns);
    }
}
