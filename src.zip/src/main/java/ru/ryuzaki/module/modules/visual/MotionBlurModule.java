package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * MotionBlur 10/10 — аккумуляционный blur.
 *
 * Алгоритм: держим отдельный Framebuffer (accum).
 * Каждый кадр: accum = lerp(accum, current_frame, 1-blur).
 * Рисуем accum поверх экрана с нужной прозрачностью.
 *
 * Это тот же алгоритм что в Lunar Client и большинстве клиентов.
 * Не требует кастомных шейдеров.
 */
public class MotionBlurModule extends Module {
    public static MotionBlurModule INSTANCE;

    public final NumberSetting  strength  = new NumberSetting("Strength",  0.5, 0.1, 0.9, 0.05);
    public final BooleanSetting pauseGUI  = new BooleanSetting("Pause on GUI",true);

    private Framebuffer accumBuffer = null;
    private int         lastW = 0, lastH = 0;

    public MotionBlurModule(){
        super("MotionBlur","Аккумуляционный motion blur",Category.VISUAL);
        INSTANCE = this;
        addSettings(strength, pauseGUI);
    }

    public static MotionBlurModule getInstance(){ return INSTANCE; }

    @Override public void onDisable(){ deleteAccum(); }
    @Override public void onEnable() { lastW=0; lastH=0; }

    private void deleteAccum(){
        if(accumBuffer!=null){ accumBuffer.delete(); accumBuffer=null; }
    }

    /**
     * Called from MixinGameRenderer after world render.
     * Accumulates current framebuffer into accumBuffer.
     */
    public void onPostRender(){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc==null||mc.getFramebuffer()==null) return;
        if(pauseGUI.isEnabled()&&mc.currentScreen!=null) return;

        int w=mc.getFramebuffer().textureWidth, h=mc.getFramebuffer().textureHeight;
        if(w!=lastW||h!=lastH||accumBuffer==null){
            deleteAccum();
            try{
                accumBuffer=new SimpleFramebuffer(w,h,true);
                accumBuffer.setClearColor(0,0,0,0);
                // Init with current frame
                copyFramebuffer(mc.getFramebuffer(), accumBuffer, w, h, 1f);
            }catch(Exception e){ accumBuffer=null; return; }
            lastW=w; lastH=h;
        }

        float blend=1f-strength.getValue().floatValue();
        // Blend current into accum: accum = accum*(1-blend) + current*blend
        blendIntoAccum(mc.getFramebuffer(), w, h, blend);

        // Draw accum over current frame
        mc.getFramebuffer().beginWrite(false);
        drawAccumOverlay(w, h);
    }

    private void copyFramebuffer(Framebuffer src, Framebuffer dst, int w, int h, float alpha){
        dst.beginWrite(true);
        RenderSystem.clearColor(0,0,0,0);
        RenderSystem.clear(16384);
        drawTexture(src.getColorAttachment(), w, h, alpha);
        src.beginWrite(false);
    }

    private void blendIntoAccum(Framebuffer current, int w, int h, float blend){
        if(accumBuffer==null) return;
        accumBuffer.beginWrite(false);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);
        drawTexture(current.getColorAttachment(), w, h, blend);
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    private void drawAccumOverlay(int w, int h){
        if(accumBuffer==null) return;
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);
        drawTexture(accumBuffer.getColorAttachment(), w, h, strength.getValue().floatValue()*0.85f);
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    private void drawTexture(int texId, int w, int h, float alpha){
        RenderSystem.setShaderTexture(0, texId);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        Matrix4f mat = new Matrix4f().ortho(0, w, h, 0, -1, 1);
        int a = Math.max(0, Math.min(255, (int)(alpha*255)));
        BufferBuilder buf = Tessellator.getInstance()
            .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buf.vertex(mat, 0, 0, 0).texture(0, 1).color(255,255,255,a);
        buf.vertex(mat, w, 0, 0).texture(1, 1).color(255,255,255,a);
        buf.vertex(mat, w, h, 0).texture(1, 0).color(255,255,255,a);
        buf.vertex(mat, 0, h, 0).texture(0, 0).color(255,255,255,a);
        try{ BufferRenderer.drawWithGlobalProgram(buf.end()); }catch(Exception e){}
    }
}
