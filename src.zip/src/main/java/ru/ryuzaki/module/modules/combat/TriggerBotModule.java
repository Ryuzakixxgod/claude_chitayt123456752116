package ru.ryuzaki.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.Random;

/**
 * TriggerBot — автоматическая атака по цели под прицелом.
 *
 * Математика:
 * - RayTracing для точного обнаружения
 * - Гауссово распределение интервалов между кликами (Box-Muller)
 * - Рандомизированная задержка реакции
 */
public final class TriggerBotModule extends Module {

    public static TriggerBotModule INSTANCE;

    // ── Settings ──────────────────────────────────────────────────
    public final NumberSetting максДистанция = new NumberSetting("Макс Дистанция", 4.5, 1.0, 6.0, 0.1);
    public final NumberSetting минCPS = new NumberSetting("Мин CPS", 7.0, 1.0, 20.0, 1.0);
    public final NumberSetting максCPS = new NumberSetting("Макс CPS", 12.0, 1.0, 20.0, 1.0);
    public final NumberSetting задержкаРеакции = new NumberSetting("Задержка Реакции (мс)", 120, 50, 300, 10);
    public final BooleanSetting толькоОружие = new BooleanSetting("Только Оружие", false);
    public final BooleanSetting рейтрейс = new BooleanSetting("Рейтрейс", true);
    public final NumberSetting сигмаГаусса = new NumberSetting("Сигма Гаусса", 0.5, 0.1, 2.0, 0.1);

    // ── Внутреннее состояние ────────────────────────────────────────
    private long lastAttackTime = 0;
    private long nextAttackDelay = 0;
    private long targetLockTime = 0;
    private LivingEntity lockedTarget = null;

    private final Random random = new Random();
    private double gaussSpare = 0.0;  // Box-Muller запас
    private boolean gaussHasSpare = false;

    public TriggerBotModule() {
        super("TriggerBot", "Автоатака под прицелом", Category.COMBAT);
        INSTANCE = this;
        addSettings(максДистанция, минCPS, максCPS, задержкаРеакции, толькоОружие, рейтрейс, сигмаГаусса);
    }

    @Override
    public void onDisable() {
        lockedTarget = null;
        lastAttackTime = 0;
        gaussHasSpare = false;
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity player = mc.player;
        ClientWorld world = mc.world;

        if (player == null || world == null) return;
        if (mc.currentScreen != null) return;
        if (player.isUsingItem()) return;

        long now = System.currentTimeMillis();

        // Проверяем cooldown на основе CPS
        long cooldownMs = calculateCooldown();
        if (now - lastAttackTime < cooldownMs) {
            return;
        }

        // Ищем цель под прицелом через raytrace
        LivingEntity target = raycastTarget(player, world);
        if (target == null) {
            lockedTarget = null;
            return;
        }

        // Проверка дистанции
        double dist = target.distanceTo(player);
        if (dist > максДистанция.getValue()) {
            lockedTarget = null;
            return;
        }

        // Проверка оружия
        if (толькоОружие.isEnabled()) {
            var mainHand = player.getMainHandStack();
            var offHand = player.getOffHandStack();
            if (!mainHand.isEmpty() || !offHand.isEmpty()) {
                // Есть предмет в руке - ок
            }
        }

        // Система блокировки на цель
        if (lockedTarget != target) {
            lockedTarget = target;
            targetLockTime = now;

            // Рандомизированная задержка реакции
            int baseDelay = задержкаРеакции.getValue().intValue();
            nextAttackDelay = baseDelay + random.nextInt(50) - 25; // ±25ms variation
        }

        // Ждём время реакции
        if (now - targetLockTime < nextAttackDelay) {
            return;
        }

        // АТАКА!
        attack(player, target);
        lastAttackTime = now;
        
        // Следующая задержка - новая рандомизация
        nextAttackDelay = calculateCooldown() + random.nextInt(50) - 25;
    }

    /**
     * Raycast для точного обнаружения сущности под прицелом.
     */
    private LivingEntity raycastTarget(ClientPlayerEntity player, ClientWorld world) {
        Vec3d start = player.getEyePos();
        Vec3d lookDir = player.getRotationVec(1.0f);
        double maxDistVal = максДистанция.getValue();

        HitResult hit = world.raycast(new RaycastContext(
                start,
                start.add(lookDir.multiply(maxDistVal)),
                RaycastContext.ShapeType.VISUAL,
                RaycastContext.FluidHandling.NONE,
                player
        ));

        if (hit == null) return null;

        // Если есть EntityHitResult - берём её
        if (hit instanceof EntityHitResult ehr) {
            Entity entity = ehr.getEntity();
            if (entity instanceof LivingEntity le && le.isAlive() && entity != player) {
                return le;
            }
        }

        return null;
    }

    /**
     * Расчёт cooldown на основе CPS с Гауссовым распределением.
     * Использует Box-Muller transform для нормального распределения.
     */
    private long calculateCooldown() {
        double minCPSVal = минCPS.getValue();
        double maxCPSVal = максCPS.getValue();

        // Центр диапазона
        double meanCPS = (minCPSVal + maxCPSVal) / 2.0;
        // Стандартное отклонение = полуразмах * sigma
        double halfRange = (maxCPSVal - minCPSVal) / 2.0;
        double sigma = сигмаГаусса.getValue().doubleValue();

        // Гауссово распределение через Box-Muller (polar variant)
        double gaussianCPS;
        if (gaussHasSpare) {
            gaussianCPS = gaussSpare * halfRange * sigma + meanCPS;
            gaussHasSpare = false;
        } else {
            double u1 = random.nextDouble();
            double u2 = random.nextDouble();
            // polar transform — более вычислительно стабильный
            double radius = Math.sqrt(-2.0 * Math.log(u1));
            double theta = 2.0 * Math.PI * u2;
            gaussianCPS = radius * Math.cos(theta) * halfRange * sigma + meanCPS;
            gaussSpare = radius * Math.sin(theta);
            gaussHasSpare = true;
        }

        // Ограничиваем в допустимый диапазон
        gaussianCPS = MathHelper.clamp(gaussianCPS, minCPSVal, maxCPSVal);
        return (long) (1000.0 / gaussianCPS);
    }

    /**
     * Выполнение атаки - напрямую отправляем пакеты.
     */
    private void attack(ClientPlayerEntity player, LivingEntity target) {
        // Проверяем cooldown игры
        if (player.getAttackCooldownProgress(0.5f) < 1.0f) {
            return;
        }

        // Пакет взаимодействия
        PlayerInteractEntityC2SPacket interactPacket = 
            PlayerInteractEntityC2SPacket.attack(target, player.isSneaking());
        
        // Пакет анимации руки
        HandSwingC2SPacket swingPacket = new HandSwingC2SPacket(Hand.MAIN_HAND);

        player.networkHandler.sendPacket(interactPacket);
        player.networkHandler.sendPacket(swingPacket);
        player.swingHand(Hand.MAIN_HAND);
    }
}
