package ru.ryuzaki.module.modules.animation;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.joml.Quaternionf;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

import java.util.ArrayList;
import java.util.List;

/**
 * SwingModule — кастомные анимации удара.
 * Система пресетов как в Rockstar: start/end фаза с 9 параметрами,
 * bezier easing, back-swing option.
 *
 * Пресеты (1:1 с Rockstar):
 *  Block Hit, Bonk, Rotate 360, From Me, Sword Slash, Smooth, Old 1.7
 */
public class SwingModule extends Module {

    public static SwingModule INSTANCE;

    public final ModeSetting preset = new ModeSetting("Preset",
        "Block Hit","Block Hit","Bonk","Rotate 360","From Me","Sword","Smooth","Old 1.7","Custom");

    public final NumberSetting speed   = new NumberSetting("Speed",   2,  1, 5, 1);
    public final BooleanSetting back   = new BooleanSetting("Back Swing", true);
    public final BooleanSetting noSwing= new BooleanSetting("No Swing", false);

    // Custom preset settings (only shown when preset=Custom)
    // Start phase
    public final NumberSetting sAncX = new NumberSetting("Start AnchorX",0,-5,5,0.05);
    public final NumberSetting sAncY = new NumberSetting("Start AnchorY",-.05,-5,5,0.05);
    public final NumberSetting sAncZ = new NumberSetting("Start AnchorZ",-.7,-5,5,0.05);
    public final NumberSetting sMoveX = new NumberSetting("Start MoveX",1.05,-5,5,0.05);
    public final NumberSetting sMoveY = new NumberSetting("Start MoveY",-.7,-5,5,0.05);
    public final NumberSetting sMoveZ = new NumberSetting("Start MoveZ",-1.1,-3,3,0.05);
    public final NumberSetting sRotX  = new NumberSetting("Start RotX",-120,-360,360,15);
    public final NumberSetting sRotY  = new NumberSetting("Start RotY",-135,-360,360,15);
    public final NumberSetting sRotZ  = new NumberSetting("Start RotZ",-60,-360,360,15);
    // End phase
    public final NumberSetting eAncX = new NumberSetting("End AnchorX",0,-5,5,0.05);
    public final NumberSetting eAncY = new NumberSetting("End AnchorY",-.05,-5,5,0.05);
    public final NumberSetting eAncZ = new NumberSetting("End AnchorZ",-.7,-5,5,0.05);
    public final NumberSetting eMoveX = new NumberSetting("End MoveX",1.05,-5,5,0.05);
    public final NumberSetting eMoveY = new NumberSetting("End MoveY",-.7,-5,5,0.05);
    public final NumberSetting eMoveZ = new NumberSetting("End MoveZ",-1.1,-3,3,0.05);
    public final NumberSetting eRotX  = new NumberSetting("End RotX",-120,-360,360,15);
    public final NumberSetting eRotY  = new NumberSetting("End RotY",-180,-360,360,15);
    public final NumberSetting eRotZ  = new NumberSetting("End RotZ",-60,-360,360,15);

    // Legacy ViewModel settings
    public final NumberSetting posX = new NumberSetting("View X",0,-2,2,0.1);
    public final NumberSetting posY = new NumberSetting("View Y",0,-2,2,0.1);
    public final NumberSetting posZ = new NumberSetting("View Z",0,-2,2,0.1);
    public final NumberSetting rotX = new NumberSetting("View RotX",0,-180,180,5);
    public final NumberSetting rotY = new NumberSetting("View RotY",0,-180,180,5);
    public final NumberSetting rotZ = new NumberSetting("View RotZ",0,-180,180,5);
    public final NumberSetting scale = new NumberSetting("Scale",1,0.5,2,0.1);
    public final BooleanSetting mainHandOnly = new BooleanSetting("Main Hand Only",false);

    // Built-in presets (1:1 with Rockstar)
    private static final List<SwingPreset> PRESETS = new ArrayList<>();
    static {
        // Block Hit
        PRESETS.add(new SwingPreset("Block Hit",
            0,-.05f,-.7f, 1.05f,-.7f,-1.1f, -120,-135,-60,
            0,-.05f,-.7f, 1.05f,-.7f,-1.1f, -120,-180,-60,
            .5f,1f,.5f,0f, true, 2));
        // Bonk
        PRESETS.add(new SwingPreset("Bonk",
            0,-.4f,-.65f, 0,0,0, 0,0,0,
            0,-.4f,-.65f, 0,0,0, -45,0,0,
            .4f,.54f, 0f,-.24f, true, 2));
        // Rotate 360
        PRESETS.add(new SwingPreset("Rotate 360",
            0,-.4f,-.65f, 0,0,0, 0,0,0,
            0,-.4f,-.65f, 0,0,0, -360,0,0,
            .43f,.61f, .046f,-.27f, false, 2));
        // From Me
        PRESETS.add(new SwingPreset("From Me",
            0,0,-1.1f, .2f,0,-.1f, -135,45,60,
            0,0,-1.1f, .2f,0,-.3f, -180,45,60,
            .42f,.87f, .39f,-.46f, true, 2));
        // Sword
        PRESETS.add(new SwingPreset("Sword",
            0,-.05f,-.7f, .8f,-.5f,-.8f, -90,-90,-30,
            0,-.05f,-.7f, .8f,-.5f,-.8f, -90,-180,-30,
            .5f,1f,.5f,0f, true, 3));
        // Smooth
        PRESETS.add(new SwingPreset("Smooth",
            0,-.05f,-.7f, .3f,-.3f,-.5f, -60,-45,-20,
            0,-.05f,-.7f, .3f,-.3f,-.5f, -60,-90,-20,
            .5f,.9f,.5f,.1f, true, 2));
        // Old 1.7
        PRESETS.add(new SwingPreset("Old 1.7",
            0,0,0, .56f,0,0, 0,0,0,
            0,0,0, .56f,-.52f,-.72f, 0,0,0,
            .5f,1f,.5f,0f, false, 2));
    }

    public SwingModule(){
        super("Swing","Анимации удара с пресетами",Category.ANIMATION);
        addSettings(preset,speed,back,noSwing,
            posX,posY,posZ,rotX,rotY,rotZ,scale,mainHandOnly,
            sAncX,sAncY,sAncZ,sMoveX,sMoveY,sMoveZ,sRotX,sRotY,sRotZ,
            eAncX,eAncY,eAncZ,eMoveX,eMoveY,eMoveZ,eRotX,eRotY,eRotZ);
        INSTANCE = this;
    }

    /** Get current preset (or custom built from settings) */
    public SwingPreset getCurrentPreset(){
        String name = preset.getCurrent();
        if("Custom".equals(name)){
            return new SwingPreset("Custom",
                sAncX.getValue().floatValue(),sAncY.getValue().floatValue(),sAncZ.getValue().floatValue(),
                sMoveX.getValue().floatValue(),sMoveY.getValue().floatValue(),sMoveZ.getValue().floatValue(),
                sRotX.getValue().floatValue(),sRotY.getValue().floatValue(),sRotZ.getValue().floatValue(),
                eAncX.getValue().floatValue(),eAncY.getValue().floatValue(),eAncZ.getValue().floatValue(),
                eMoveX.getValue().floatValue(),eMoveY.getValue().floatValue(),eMoveZ.getValue().floatValue(),
                eRotX.getValue().floatValue(),eRotY.getValue().floatValue(),eRotZ.getValue().floatValue(),
                .5f,1f,.5f,0f, back.isEnabled(), speed.getValue().floatValue()
            );
        }
        for(SwingPreset p : PRESETS) if(p.name.equals(name)) return p;
        return PRESETS.get(0);
    }

    /** Apply preset transform to MatrixStack */
    public void applyPresetSwing(MatrixStack ms, float progress, int armX){
        SwingPreset p = getCurrentPreset();
        float spd = p.speed;
        // Clamp progress
        float prog = Math.max(0f, Math.min(1f, progress));
        float[] t = p.transform(prog);
        // t = [ancX,ancY,ancZ, mvX,mvY,mvZ, rotX,rotY,rotZ]
        // Apply: translate to anchor, translate move, rotate, translate back from anchor
        ms.translate(t[3], t[4], t[5]); // move
        if(Math.abs(t[0])+Math.abs(t[1])+Math.abs(t[2]) > 0.001f)
            ms.translate(t[0]*armX, t[1], t[2]); // anchor
        if(Math.abs(t[6])>0.1f) ms.multiply(new Quaternionf().rotateX((float)Math.toRadians(t[6])));
        if(Math.abs(t[7])>0.1f) ms.multiply(new Quaternionf().rotateY((float)Math.toRadians(t[7]*armX)));
        if(Math.abs(t[8])>0.1f) ms.multiply(new Quaternionf().rotateZ((float)Math.toRadians(t[8]*armX)));
        if(Math.abs(t[0])+Math.abs(t[1])+Math.abs(t[2]) > 0.001f)
            ms.translate(-t[0]*armX, -t[1], -t[2]); // back from anchor
    }

    /** Returns swing duration in ticks (lower = faster). Speed 1=fast(3t), Speed 5=slow(8t) */
    public int getSwingDuration(){ return Math.max(1, 9 - speed.getValue().intValue()); }

    public boolean isMainHandOnly(){ return mainHandOnly.isEnabled(); }
    public float getScale(){ return scale.getValue().floatValue(); }
    public float getPositionX(){ return posX.getValue().floatValue(); }
    public float getPositionY(){ return posY.getValue().floatValue(); }
    public float getPositionZ(){ return posZ.getValue().floatValue(); }
    public float getRotationX(){ return rotX.getValue().floatValue(); }
    public float getRotationY(){ return rotY.getValue().floatValue(); }
    public float getRotationZ(){ return rotZ.getValue().floatValue(); }
}
