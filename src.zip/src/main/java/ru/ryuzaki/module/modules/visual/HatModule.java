package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.gui.style.ThemeManager;
import ru.ryuzaki.settings.ModeSetting;

import java.awt.Color;

/**
 * HatModule — шляпа с плавной анимацией.
 * Покачивание: лёгкий синус-боб.
 * При движении: наклоняется вперёд (velocity tilt) с плавным spring-возвратом.
 * Стили: Conical, Wizard, Crown.
 */
public class HatModule extends Module {

    public final ModeSetting style = new ModeSetting("Style", "Conical", "Conical", "Wizard", "Crown");

    // Анимация
    private float bobPhase    = 0f;
    private float tiltAngle   = 0f;   // наклон вперёд при движении
    private float tiltVel     = 0f;
    private float strafeTilt  = 0f;
    private float strafeTiltVel=0f;
    private long  lastTime    = -1;

    public HatModule() {
        super("Hat", "Шляпа с анимацией над игроком", Category.VISUAL);
        addSettings(style);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.gameRenderer == null) return;
        // Не показывать от первого лица
        if (mc.options.getPerspective().isFirstPerson()) return;

        long now = System.currentTimeMillis();
        float dt = lastTime < 0 ? 0.016f : Math.min((now - lastTime) / 1000f, 0.08f);
        lastTime = now;

        // Боб: медленное покачивание
        bobPhase = (bobPhase + dt * 1.8f) % (float)(Math.PI * 2);
        float bob = (float)Math.sin(bobPhase) * 0.025f;

        // Velocity tilt: наклон вперёд-назад при движении
        float pt = ctx.tickCounter().getTickDelta(true);
        double velX = mc.player.getX() - mc.player.prevX;
        double velZ = mc.player.getZ() - mc.player.prevZ;
        float speed = (float)Math.sqrt(velX*velX + velZ*velZ) * 20f; // блоков/сек

        // Направление движения относительно взгляда → tilt
        float playerYawRad = (float)Math.toRadians(MathHelper.lerp(pt, mc.player.prevYaw, mc.player.getYaw()));
        float moveYaw = (float)Math.atan2(velZ, velX) + (float)Math.PI;
        float relAngle = moveYaw - playerYawRad;
        float forwardVel = speed * (float)Math.cos(relAngle);

        float targetTilt = forwardVel * 2.5f;
        targetTilt = MathHelper.clamp(targetTilt, -12f, 12f);
        tiltVel += (targetTilt - tiltAngle) * 0.18f * (dt * 60f);
        tiltVel *= 0.82f;
        tiltAngle += tiltVel;

        // Strafe tilt: наклон вбок при движении
        float sideVel = (float)(mc.player.getX()-mc.player.prevX) * (float)Math.cos(playerYawRad)
                - (float)(mc.player.getZ()-mc.player.prevZ) * (float)Math.sin(playerYawRad);
        sideVel *= 20f;
        float targetStrafe = MathHelper.clamp(-sideVel * 2.0f, -10f, 10f);
        strafeTiltVel += (targetStrafe - strafeTilt) * 0.15f * (dt * 60f);
        strafeTiltVel *= 0.82f;
        strafeTilt += strafeTiltVel;

        Camera cam = mc.gameRenderer.getCamera();
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        double px = MathHelper.lerp(pt, mc.player.prevX, mc.player.getX());
        double py = MathHelper.lerp(pt, mc.player.prevY, mc.player.getY());
        double pz = MathHelper.lerp(pt, mc.player.prevZ, mc.player.getZ());
        float yaw = MathHelper.lerp(pt, mc.player.prevYaw, mc.player.getYaw());

        double dx = px - cam.getPos().x;
        double dy = py + mc.player.getHeight() + 0.20 + bob - cam.getPos().y;
        double dz = pz - cam.getPos().z;

        ms.push();
        ms.translate(dx, dy, dz);
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        // Tilt вперёд при движении — по оси X
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-tiltAngle));
        ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(-strafeTilt));

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();

        Color accent = ThemeManager.get().getAccent();
        switch (style.getCurrent()) {
            case "Conical" -> drawConical(ms, accent);
            case "Wizard"  -> drawWizard(ms, accent);
            case "Crown"   -> drawCrownHat(ms, accent);
        }

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        ms.pop();
    }

    private void drawConical(MatrixStack ms, Color accent) {
        Matrix4f mat = ms.peek().getPositionMatrix();
        int segs = 40;
        float tipY = 0.48f, brimR = 0.56f;
        int hatR = 0xC8, hatG = 0x8A, hatB = 0x00;
        int rimR = 0xDA, rimG = 0xA5, rimB = 0x20;
        int ar = accent.getRed(), ag = accent.getGreen(), ab = accent.getBlue();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder cone = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            float a = (float)(i * 2 * Math.PI / segs);
            float sh = 0.65f + 0.35f * Math.abs((float)Math.cos(a));
            cone.vertex(mat, 0, tipY, 0).color(ar, ag, ab, 230);
            cone.vertex(mat, brimR*(float)Math.cos(a), 0, brimR*(float)Math.sin(a))
                    .color((int)(hatR*sh), (int)(hatG*sh), (int)(hatB*sh), 230);
        }
        BufferRenderer.drawWithGlobalProgram(cone.end());

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder brim = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            float a = (float)(i * 2 * Math.PI / segs);
            float c = (float)Math.cos(a), s = (float)Math.sin(a);
            brim.vertex(mat, brimR*c, -0.01f, brimR*s).color(rimR, rimG, rimB, 230);
            brim.vertex(mat, (brimR+0.13f)*c, -0.05f, (brimR+0.13f)*s)
                    .color(hatR, hatG, hatB, 230);
        }
        BufferRenderer.drawWithGlobalProgram(brim.end());
    }

    private void drawWizard(MatrixStack ms, Color accent) {
        Matrix4f mat = ms.peek().getPositionMatrix();
        int segs = 32;
        float brimR = 0.50f, hatH = 0.72f;
        int ar = accent.getRed(), ag = accent.getGreen(), ab = accent.getBlue();
        int dark = 0x18, darkG = 0x08, darkB = 0x30;

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder body = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            float a = (float)(i * 2 * Math.PI / segs);
            float c = (float)Math.cos(a), s = (float)Math.sin(a);
            body.vertex(mat, 0.03f*(float)Math.cos(a*2), hatH, 0.03f*(float)Math.sin(a*2))
                    .color(ar, ag, ab, 225);
            body.vertex(mat, brimR*c, 0, brimR*s).color(dark, darkG, darkB, 240);
        }
        BufferRenderer.drawWithGlobalProgram(body.end());

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder brim = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            float a = (float)(i * 2 * Math.PI / segs);
            float c = (float)Math.cos(a), s = (float)Math.sin(a);
            brim.vertex(mat, brimR*c, -0.01f, brimR*s).color(dark, darkG, darkB, 240);
            brim.vertex(mat, (brimR+0.16f)*c, -0.06f, (brimR+0.16f)*s)
                    .color((int)(ar*0.45), (int)(ag*0.45), (int)(ab*0.45), 230);
        }
        BufferRenderer.drawWithGlobalProgram(brim.end());

        // Светящаяся полоска
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        float bandY = 0.17f;
        BufferBuilder band = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= segs; i++) {
            float a = (float)(i * 2 * Math.PI / segs);
            float br = brimR * (1f - bandY / hatH);
            float c = (float)Math.cos(a), s = (float)Math.sin(a);
            band.vertex(mat, br*c, bandY,       br*s).color(ar, ag, ab, 150);
            band.vertex(mat, br*c, bandY+0.035f, br*s).color(255, 255, 255, 200);
        }
        BufferRenderer.drawWithGlobalProgram(band.end());
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
    }

    private void drawCrownHat(MatrixStack ms, Color accent) {
        Matrix4f mat = ms.peek().getPositionMatrix();
        int segs = 5, circleSegs = 32;
        float baseR = 0.22f, spikeH = 0.34f;
        int ar = accent.getRed(), ag = accent.getGreen(), ab = accent.getBlue();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder spikes = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < segs; i++) {
            float a1 = (float)(i     * 2 * Math.PI / segs);
            float a2 = (float)((i+0.5f) * 2 * Math.PI / segs);
            float a3 = (float)((i+1) * 2 * Math.PI / segs);
            float tipH = i % 2 == 0 ? spikeH : spikeH * 0.55f;
            spikes.vertex(mat, baseR*(float)Math.cos(a1), 0, baseR*(float)Math.sin(a1)).color(ar, ag, ab, 230);
            spikes.vertex(mat, baseR*(float)Math.cos(a3), 0, baseR*(float)Math.sin(a3)).color(ar, ag, ab, 230);
            spikes.vertex(mat, baseR*0.65f*(float)Math.cos(a2), tipH, baseR*0.65f*(float)Math.sin(a2)).color(255, 255, 255, 220);
        }
        BufferRenderer.drawWithGlobalProgram(spikes.end());

        // Glow ring
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder ring = Tessellator.getInstance().begin(
                VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int i = 0; i <= circleSegs; i++) {
            float a = (float)(i * 2 * Math.PI / circleSegs);
            ring.vertex(mat, (baseR-0.03f)*(float)Math.cos(a), 0.01f, (baseR-0.03f)*(float)Math.sin(a))
                    .color(ar, ag, ab, 60);
            ring.vertex(mat, (baseR+0.03f)*(float)Math.cos(a), 0.01f, (baseR+0.03f)*(float)Math.sin(a))
                    .color(ar, ag, ab, 180);
        }
        BufferRenderer.drawWithGlobalProgram(ring.end());
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
    }
}