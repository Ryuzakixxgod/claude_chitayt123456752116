package ru.ryuzaki.module.modules.particles;
// src/main/java/ru/ryuzaki/module/modules/particles/KillEffectModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class KillEffectModule extends Module {
    public static KillEffectModule INSTANCE;
    public final ModeSetting   style = new ModeSetting("Style","Cosmic","Cosmic","Explosion","Stars","Shatter","Reaper","Nova");
    public final NumberSetting count = new NumberSetting("Count",  30, 10, 80, 5);
    public final BooleanSetting shockwave = new BooleanSetting("Shockwave", true);
    public final BooleanSetting skull    = new BooleanSetting("Skull Text", true);

    private static class KP {
        double x,y,z,vx,vy,vz;
        float life,maxLife,size;
        int r,g,b;
        float rotSpeed,rot;
        KP(double x,double y,double z,double vx,double vy,double vz,float life,float size,int r,int g,int b){
            this.x=x;this.y=y;this.z=z;this.vx=vx;this.vy=vy;this.vz=vz;
            this.life=this.maxLife=life;this.size=size;this.r=r;this.g=g;this.b=b;
            this.rotSpeed=(float)(Math.random()*0.2-0.1);
        }
        void update(){x+=vx;y+=vy;z+=vz;vy-=0.003;life--;rot+=rotSpeed;
            vx*=0.96;vy*=0.96;vz*=0.96;}
    }
    private static class Ring {
        Vec3d pos; float radius,maxRadius,life,maxLife; int r,g,b;
        Ring(Vec3d p,float maxR,float life,int r,int g,int b){pos=p;radius=0;maxRadius=maxR;this.life=this.maxLife=life;this.r=r;this.g=g;this.b=b;}
        void update(){radius=maxRadius*(1f-life/maxLife);life--;}
    }

    private static final List<KP>   particles = new ArrayList<>();
    private static final List<Ring> rings     = new ArrayList<>();
    private static final Random rng = new Random();

    public KillEffectModule() {
        super("Kill Effect", "Эпический эффект убийства", Category.PARTICLES);
        INSTANCE = this;
        addSettings(style, count, shockwave, skull);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }

    public void spawnAt(Vec3d pos) {
        if (!isEnabled()) return;
        int n = count.getValue().intValue();
        String s = style.getCurrent();

        // Кольца взрыва
        if (shockwave.isEnabled()) {
            int[] c1 = getBaseColor(0);
            int[] c2 = getBaseColor(1);
            rings.add(new Ring(pos, 2.5f, 30, c1[0],c1[1],c1[2]));
            rings.add(new Ring(pos, 1.5f, 20, c2[0],c2[1],c2[2]));
            rings.add(new Ring(pos, 4.0f, 40, c1[0],c1[1],c1[2]));
        }

        // Частицы
        for (int i = 0; i < n; i++) {
            float angle  = (float)(Math.PI*2*rng.nextFloat());
            float elevat = (float)(Math.PI*(rng.nextFloat()-0.5f));
            float spd    = 0.04f + rng.nextFloat()*0.12f;
            double vx = Math.cos(angle)*Math.cos(elevat)*spd;
            double vy = Math.sin(elevat)*spd + 0.04f;
            double vz = Math.sin(angle)*Math.cos(elevat)*spd;
            int[] c = getParticleColor(i, n);
            float sz = 0.06f+rng.nextFloat()*0.10f;
            float life = 30+rng.nextInt(40);
            particles.add(new KP(pos.x+rng.nextGaussian()*0.1, pos.y+0.5+rng.nextDouble()*0.5, pos.z+rng.nextGaussian()*0.1, vx,vy,vz, life,sz, c[0],c[1],c[2]));
        }

        // Дополнительные стильные эффекты
        if (s.equals("Reaper")) {
            // Столб вверх
            for (int i = 0; i < 20; i++) {
                double t = i/20.0;
                double ang = t*Math.PI*4;
                float r = 0.3f;
                int[] c = getBaseColor(i);
                particles.add(new KP(pos.x+Math.cos(ang)*r, pos.y+t*3, pos.z+Math.sin(ang)*r, 0,0.02,0, 60, 0.05f, c[0],c[1],c[2]));
            }
        }
        if (s.equals("Nova")) {
            // 8 лучей в стороны
            for (int beam = 0; beam < 8; beam++) {
                double ang = beam*Math.PI/4;
                for (int j = 0; j < 8; j++) {
                    float t = j/8f;
                    int[] c = getBaseColor(j);
                    double spd2 = 0.05+j*0.02;
                    particles.add(new KP(pos.x,pos.y+0.5,pos.z, Math.cos(ang)*spd2,0.01,Math.sin(ang)*spd2, 25+j*3, 0.07f*(1-t), c[0],c[1],c[2]));
                }
            }
        }

        while (particles.size()>600) particles.remove(0);
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled()||(particles.isEmpty()&&rings.isEmpty())) return;
        Vec3d cam=ctx.camera().getPos();
        MatrixStack ms=ctx.matrixStack();if(ms==null)return;
        ms.push();ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.disableDepthTest();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();

        // ── Кольца ──────────────────────────────────────────────────────
        Iterator<Ring> ri=rings.iterator();
        while(ri.hasNext()){
            Ring ring=ri.next(); ring.update(); if(ring.life<=0){ri.remove();continue;}
            float pct=ring.life/ring.maxLife;
            int ra=(int)(220*pct);
            // Glow кольца (несколько слоёв)
            for(int gl=4;gl>=1;gl--){
                float gr=ring.radius*(1f+gl*0.04f);
                int ga=(int)(ra*0.15f/gl);
                BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                for(int s=0;s<=48;s++){double a=2*Math.PI*s/48;rb.vertex(mat,(float)(ring.pos.x+gr*Math.cos(a)),(float)ring.pos.y,(float)(ring.pos.z+gr*Math.sin(a))).color(ring.r,ring.g,ring.b,ga);}
                try{BufferRenderer.drawWithGlobalProgram(rb.end());}catch(Exception ignored){}
            }
            // Основное кольцо
            BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
            for(int s=0;s<=64;s++){
                double a=2*Math.PI*s/64;
                float bright=0.5f+0.5f*(float)Math.sin(pct*Math.PI);
                rb.vertex(mat,(float)(ring.pos.x+ring.radius*Math.cos(a)),(float)ring.pos.y,(float)(ring.pos.z+ring.radius*Math.sin(a))).color(ring.r,ring.g,ring.b,(int)(ra*bright));
            }
            try{BufferRenderer.drawWithGlobalProgram(rb.end());}catch(Exception ignored){}
        }

        // ── Частицы ──────────────────────────────────────────────────────
        if(!particles.isEmpty()){
            Iterator<KP> it=particles.iterator();
            BufferBuilder pb=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            boolean hasVerts=false;
            while(it.hasNext()){
                KP p=it.next();p.update();if(p.life<=0){it.remove();continue;}
                float pct=p.life/p.maxLife;
                int pa=(int)(220*pct*(0.5f+0.5f*(float)Math.sin(pct*Math.PI)));
                float s=p.size*pct;
                // Вращающийся квадрат
                float cos=(float)Math.cos(p.rot)*s, sin=(float)Math.sin(p.rot)*s;
                pb.vertex(mat,(float)p.x-cos,(float)p.y-sin,(float)p.z).color(p.r,p.g,p.b,pa);
                pb.vertex(mat,(float)p.x+sin,(float)p.y-cos,(float)p.z).color(p.r,p.g,p.b,pa);
                pb.vertex(mat,(float)p.x+cos,(float)p.y+sin,(float)p.z).color(p.r,p.g,p.b,0);
                pb.vertex(mat,(float)p.x-sin,(float)p.y+cos,(float)p.z).color(p.r,p.g,p.b,0);
                hasVerts=true;
            }
            if(hasVerts)try{BufferRenderer.drawWithGlobalProgram(pb.end());}catch(Exception e){try{pb.end();}catch(Exception ignored){}}
            else try{pb.end();}catch(Exception ignored){}
        }

        ms.pop();
        RenderSystem.enableDepthTest();RenderSystem.enableCull();RenderSystem.disableBlend();
    }

    private int[] getBaseColor(int i){
        return switch(style.getCurrent()){
            case"Explosion"->new int[]{255,(int)(100+i*10),0};
            case"Stars"    ->hsv((float)i/10*0.3f,0.2f,1f);
            case"Shatter"  ->new int[]{180,220,255};
            case"Reaper"   ->new int[]{120,0,180};
            case"Nova"     ->hsv(i*0.12f,0.9f,1f);
            default        ->hsv(0.68f+i*0.02f,0.8f,1f);
        };
    }
    private int[] getParticleColor(int i,int n){
        float t=(float)i/n;
        return switch(style.getCurrent()){
            case"Explosion"->hsv(0.06f-t*0.06f,1f,1f);
            case"Stars"    ->hsv(t*0.15f,0.1f,1f);
            case"Shatter"  ->hsv(0.55f+t*0.05f,0.5f,1f);
            case"Reaper"   ->hsv(0.75f+t*0.08f,0.95f,0.8f+t*0.2f);
            case"Nova"     ->hsv(t,0.85f,1f);
            default        ->hsv((float)(System.currentTimeMillis()%4000)/4000f+t*0.2f,0.85f,1f);
        };
    }
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}