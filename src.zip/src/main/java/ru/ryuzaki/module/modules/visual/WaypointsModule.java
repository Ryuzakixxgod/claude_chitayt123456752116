package ru.ryuzaki.module.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.awt.Color;
import java.util.*;

/**
 * WaypointsModule — Rockstar-style.
 * Установка: команда /wp add <name> или /wp here
 * Отображение: 2D overlay поверх экрана (нет 3D beam, нет lag)
 */
public class WaypointsModule extends Module {

    public static WaypointsModule INSTANCE;

    public static class Waypoint {
        public String name;
        public Vec3d pos;
        public int color;        // ARGB
        public boolean temp;
        public long created;
        public UUID playerUuid;  // если следит за игроком

        public Waypoint(String name, Vec3d pos, int color, boolean temp, UUID uuid){
            this.name=name; this.pos=pos; this.color=color;
            this.temp=temp; this.created=System.currentTimeMillis();
            this.playerUuid=uuid;
        }
    }

    private final Map<String, Waypoint> waypoints = new LinkedHashMap<>();

    // Static for command access
    public static final Color C_LABEL_BG = new Color(0,0,0,120);
    public static final Color C_TEXT     = new Color(237,232,255,230);

    public WaypointsModule(){
        super("Waypoints","2D screen-space маршрутные точки",Category.VISUAL);
        INSTANCE = this;
    }

    // ── Public API (called from CommandManager) ───────────────────────

    public void add(String name, double x, double y, double z, int color, boolean temp, UUID uuid){
        if(waypoints.containsKey(name)){
            mc.player.sendMessage(
                net.minecraft.text.Text.literal("§c[Ryuzaki] Waypoint '"+name+"' already exists"), false);
            return;
        }
        waypoints.put(name, new Waypoint(name, new Vec3d(x,y,z), color, temp, uuid));
        if(mc.player!=null)
            mc.player.sendMessage(net.minecraft.text.Text.literal(
                "§a[Ryuzaki] Waypoint §f'"+name+"'§a added"), false);
    }

    public void remove(String name){
        if(waypoints.remove(name)!=null && mc.player!=null)
            mc.player.sendMessage(net.minecraft.text.Text.literal(
                "§c[Ryuzaki] Waypoint §f'"+name+"'§c removed"), false);
    }

    public void clear(){
        waypoints.clear();
        if(mc.player!=null)
            mc.player.sendMessage(net.minecraft.text.Text.literal(
                "§c[Ryuzaki] All waypoints cleared"), false);
    }

    public Map<String,Waypoint> getAll(){ return Collections.unmodifiableMap(waypoints); }

    public List<String> getNames(){ return new ArrayList<>(waypoints.keySet()); }

    // ── Tick: update player-tracking waypoints ────────────────────────
    @Override
    public void onUpdate(){
        if(mc.world==null||mc.player==null) return;
        long now = System.currentTimeMillis();
        waypoints.entrySet().removeIf(e -> {
            Waypoint w = e.getValue();
            // Remove temp after 5s
            if(w.temp && now-w.created>5000) return true;
            // Update player-tracking waypoints
            if(w.playerUuid!=null){
                PlayerEntity p = mc.world.getPlayerByUuid(w.playerUuid);
                if(p==null){ waypoints.remove(w.name); return true; }
                // Smooth lerp toward player
                Vec3d target = p.getPos();
                float alpha = 0.2f;
                w.pos = w.pos.lerp(target, MathHelper.clamp(alpha,0f,1f));
            }
            return false;
        });
    }

    // ── 2D HUD render ─────────────────────────────────────────────────
    public void renderHud(DrawContext ctx, int sw, int sh){
        if(!isEnabled()||mc.player==null||mc.world==null) return;

        for(Waypoint wp : waypoints.values()){
            Vec3d pos = wp.pos.add(0,0.5,0);
            float[] screen = worldToScreen(pos, sw, sh);
            if(screen==null) continue;

            float sx=screen[0], sy=screen[1];
            float dist = (float)mc.player.getPos().distanceTo(wp.pos);

            // Scale by distance (closer = bigger)
            float scale = MathHelper.clamp(1f - dist/200f, 0.5f, 1f);

            String label = wp.name+" ("+Math.round(dist)+"m)";
            float tw = twOf(label, 10f);

            ctx.getMatrices().push();
            ctx.getMatrices().translate(sx, sy, 0);
            ctx.getMatrices().scale(scale,scale,1f);

            // Background pill
            int bx=(int)(-tw/2f-4), bw=(int)(tw+8);
            DrawHelper.drawRect(ctx.getMatrices(),bx,0,bw,16,4,C_LABEL_BG);

            // Colored dot
            int cr=(wp.color>>16)&0xFF,cg=(wp.color>>8)&0xFF,cb=wp.color&0xFF;
            DrawHelper.drawRect(ctx.getMatrices(),-tw/2f-2,5,6,6,3,new Color(cr,cg,cb,220));

            // Label
            drawTxt(ctx,label,-tw/2f+6,2,C_TEXT,10f);

            // Arrow if off-screen
            if(screen[2]<0||sx<0||sx>sw||sy<0||sy>sh){
                // Draw directional indicator at edge
                ctx.getMatrices().pop();
                drawEdgeArrow(ctx, pos, sw, sh, new Color(cr,cg,cb,200));
                continue;
            }

            ctx.getMatrices().pop();
        }
    }

    private void drawEdgeArrow(DrawContext ctx, Vec3d pos, int sw, int sh, Color col){
        if(mc.player==null) return;
        Vec3d dir = pos.subtract(mc.player.getCameraPosVec(1f)).normalize();
        float camYaw = (float)Math.toRadians(mc.player.getYaw());
        float camPitch = (float)Math.toRadians(mc.player.getPitch());
        // Project direction to screen angle
        float dx=(float)(dir.x*Math.cos(camYaw)-dir.z*Math.sin(camYaw));
        float ang = (float)Math.atan2(dx, dir.y);
        float ex = sw/2f + (float)Math.sin(ang)*Math.min(sw,sh)*0.44f;
        float ey = sh/2f - (float)Math.cos(ang)*Math.min(sw,sh)*0.44f;
        ex=MathHelper.clamp(ex,16,sw-16);
        ey=MathHelper.clamp(ey,16,sh-16);
        // Draw small triangle
        int r=col.getRed(),g=col.getGreen(),b=col.getBlue();
        DrawHelper.drawRect(ctx.getMatrices(),ex-5,ey-5,10,10,5,new Color(r,g,b,180));
    }

    /** Project world position to screen [x,y,depth] or null if behind */
    private float[] worldToScreen(Vec3d world, int sw, int sh){
        try{
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            double rx=world.x-cam.x, ry=world.y-cam.y, rz=world.z-cam.z;
            Vector4f v = new Vector4f((float)rx,(float)ry,(float)rz,1f);
            com.mojang.blaze3d.systems.RenderSystem.getModelViewMatrix().transform(v);
            com.mojang.blaze3d.systems.RenderSystem.getProjectionMatrix().transform(v);
            if(v.w<=0) return null;
            float ndcX=v.x/v.w, ndcY=v.y/v.w;
            return new float[]{(ndcX*.5f+.5f)*sw,(1f-(ndcY*.5f+.5f))*sh,v.w};
        }catch(Exception e){ return null; }
    }

    private float twOf(String s, float size){
        if(Fonts.MEDIUM!=null) return Fonts.MEDIUM.getWidth(s,size);
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }

    private void drawTxt(DrawContext ctx, String s, float x, float y, Color col, float size){
        try{
            if(Fonts.MEDIUM!=null){
                DrawHelper.drawText(ctx.getMatrices().peek().getPositionMatrix(),
                    Fonts.MEDIUM.getFont(size),s,x,y,col);
                return;
            }
        }catch(Exception ignored){}
        int argb=(col.getAlpha()<<24)|(col.getRed()<<16)|(col.getGreen()<<8)|col.getBlue();
        ctx.drawText(mc.textRenderer,s,(int)x,(int)(y-7),argb,false);
    }
}
