package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.RyuzakiRenderCache;

public class BlockOutlineModule extends Module {

    public final ModeSetting   mode   = new ModeSetting("Mode","Glow","Normal","Glow","Pulse","Rainbow","Cosmic");
    public final NumberSetting width  = new NumberSetting("Width", 2.0, 0.5, 5.0, 0.5);
    public final BooleanSetting fill  = new BooleanSetting("Fill", false);
    public final BooleanSetting depth = new BooleanSetting("Through Walls", false);

    // Preset modes
    private static final String[] PRESETS = {"16:9","21:9","4:3","1:1"};
    private float pulsePhase = 0f;
    private float appearAnim = 0f;  // 0..1 плавное появление
    private Box   lastBox    = null;

    public BlockOutlineModule() {
        super("Block Outline","Подсветка блока под прицелом",Category.VISUAL);
        addSettings(mode,width,fill,depth);
    }

    @Override public void onUpdate() {
        pulsePhase = (pulsePhase + 0.05f) % (float)(Math.PI*2);
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean looking = mc.crosshairTarget!=null && mc.crosshairTarget.getType()==HitResult.Type.BLOCK;
        appearAnim += ((looking?1f:0f) - appearAnim) * 0.18f;
        appearAnim = Math.max(0f, Math.min(1f, appearAnim));
    }

    public void render3D(MatrixStack ms, float tickDelta) {
        if (!isEnabled()&&appearAnim<0.02f) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world==null||mc.player==null) return;
        if (mc.crosshairTarget==null||mc.crosshairTarget.getType()!=HitResult.Type.BLOCK) return;

        BlockHitResult hit = (BlockHitResult)mc.crosshairTarget;
        Vec3d cam = mc.gameRenderer.getCamera().getPos();
        Box blockBox = mc.world.getBlockState(hit.getBlockPos())
                .getOutlineShape(mc.world,hit.getBlockPos()).getBoundingBox();

        double bx=hit.getBlockPos().getX()-cam.x;
        double by=hit.getBlockPos().getY()-cam.y;
        double bz=hit.getBlockPos().getZ()-cam.z;
        float exp=0.002f + (1f-appearAnim)*0.03f;
        Box box=new Box(bx+blockBox.minX-exp,by+blockBox.minY-exp,bz+blockBox.minZ-exp,
                bx+blockBox.maxX+exp,by+blockBox.maxY+exp,bz+blockBox.maxZ+exp);
        lastBox = box;

        ms.push();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        if (!depth.isEnabled()) RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        long now = System.currentTimeMillis();
        int[] rgb = getOutlineColor(now);
        float baseAlpha = switch(mode.getCurrent()){
            case "Pulse"   -> 0.5f + 0.5f*(float)Math.abs(Math.sin(pulsePhase));
            case "Cosmic"  -> 0.7f + 0.3f*(float)Math.sin(pulsePhase*1.3f);
            default        -> 0.88f;
        } * appearAnim;

        Tessellator tess = Tessellator.getInstance();
        Matrix4f mat = ms.peek().getPositionMatrix();

        // Fill
        if (fill.isEnabled()) drawFill(tess,mat,box,rgb,(int)(55*baseAlpha));

        if (mode.getCurrent().equals("Cosmic")) {
            // ── COSMIC: анимированный космос — 3 цикличных цвета, глубокое свечение, бегущие искры
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);

            // Три цветовые полосы, сдвинутые по фазе — имитируют туманность
            for (int layer = 0; layer < 3; layer++) {
                float hOffset = layer / 3f;
                float hue = ((now % 8000) / 8000f + hOffset) % 1f;
                int[] lc = hsv(hue, 0.92f, 1f);
                float pulse2 = 0.5f + 0.5f * (float)Math.sin(now * 0.0024f + layer * 2.1f);
                // Слои свечения (6 слоёв на каждый цвет)
                for (int gl = 6; gl >= 1; gl--) {
                    float ex = gl * 0.009f + layer * 0.006f;
                    int ga = (int)(baseAlpha * pulse2 * 22 / gl);
                    drawOutlineBox(tess, mat, box.expand(ex), lc, ga);
                }
            }
            // Движущиеся "звёздные искры" по рёбрам
            float edgeT = (now % 2200) / 2200f;
            for (int spark = 0; spark < 4; spark++) {
                float st = (edgeT + spark * 0.25f) % 1f;
                float hue = ((now % 5000) / 5000f + spark * 0.22f) % 1f;
                int[] sc = hsv(hue, 0.8f, 1f);
                drawEdgeSpark(tess, mat, box, st, sc, (int)(200 * baseAlpha));
            }
            RenderSystem.defaultBlendFunc();
            // Основная линия (тонкая, яркая)
            float w2 = width.getValue().floatValue();
            RenderSystem.lineWidth(w2);
            drawOutlineBox(tess, mat, box, rgb, (int)(200 * baseAlpha));
            // Corner dots с двойным цветом
            drawCornerDots(tess, mat, box, rgb, (int)(255 * baseAlpha));
        } else {
            // Обычные режимы
            if (!mode.getCurrent().equals("Normal")) {
                RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
                for (int gl = 4; gl >= 1; gl--) {
                    float ex = gl * 0.012f; int ga = (int)(baseAlpha * 28 / gl);
                    drawOutlineBox(tess, mat, box.expand(ex), rgb, ga);
                }
                RenderSystem.defaultBlendFunc();
            }
            float w = width.getValue().floatValue();
            RenderSystem.lineWidth(w);
            drawOutlineBox(tess, mat, box, rgb, (int)(220 * baseAlpha));
            drawCornerDots(tess, mat, box, rgb, (int)(255 * baseAlpha));
        }

        ms.pop();
        RenderSystem.depthMask(true);
        if (!depth.isEnabled()) RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(1f);
    }

    private int[] getOutlineColor(long now) {
        return switch(mode.getCurrent()) {
            case "Rainbow" -> {
                float h=(now%4000)/4000f;
                yield hsv(h,0.85f,1f);
            }
            case "Cosmic" -> {
                float h=(now%6000)/6000f;
                float[] c1=hsvf(h,0.9f,1f), c2=hsvf((h+0.15f)%1f,0.9f,1f);
                float t=0.5f+0.5f*(float)Math.sin(now*0.003f);
                yield new int[]{(int)(c1[0]+(c2[0]-c1[0])*t),(int)(c1[1]+(c2[1]-c1[1])*t),(int)(c1[2]+(c2[2]-c1[2])*t)};
            }
            default -> RyuzakiRenderCache.rgb1;
        };
    }

    /** Движущаяся искра вдоль рёбер — анимация "бегущего огня" */
    private void drawEdgeSpark(Tessellator tess, Matrix4f mat, Box b, float t, int[] c, int a) {
        if (a <= 0) return;
        float x1=(float)b.minX, y1=(float)b.minY, z1=(float)b.minZ;
        float x2=(float)b.maxX, y2=(float)b.maxY, z2=(float)b.maxZ;
        // 12 рёбер куба — искра пробегает по каждому
        float[][][] edges = {
                {{x1,y1,z1},{x2,y1,z1}}, {{x2,y1,z1},{x2,y1,z2}},
                {{x2,y1,z2},{x1,y1,z2}}, {{x1,y1,z2},{x1,y1,z1}},
                {{x1,y2,z1},{x2,y2,z1}}, {{x2,y2,z1},{x2,y2,z2}},
                {{x2,y2,z2},{x1,y2,z2}}, {{x1,y2,z2},{x1,y2,z1}},
                {{x1,y1,z1},{x1,y2,z1}}, {{x2,y1,z1},{x2,y2,z1}},
                {{x2,y1,z2},{x2,y2,z2}}, {{x1,y1,z2},{x1,y2,z2}}
        };
        int edgeIdx = (int)(t * 12) % 12;
        float localT = (t * 12) % 1f;
        float[][] e = edges[edgeIdx];
        float sx = e[0][0] + (e[1][0]-e[0][0]) * localT;
        float sy = e[0][1] + (e[1][1]-e[0][1]) * localT;
        float sz = e[0][2] + (e[1][2]-e[0][2]) * localT;
        float sz2 = 0.035f;
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(mat,sx-sz2,sy-sz2,sz-sz2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,sx+sz2,sy-sz2,sz-sz2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,sx+sz2,sy+sz2,sz+sz2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,sx-sz2,sy+sz2,sz+sz2).color(c[0],c[1],c[2],0);
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch(Exception ignored) {}
    }

    private void drawOutlineBox(Tessellator tess,Matrix4f mat,Box b,int[]c,int a){
        if(a<=0) return;
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ;
        float x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
        // 12 рёбер
        int[][]edges={{0,1},{1,3},{3,2},{2,0},{4,5},{5,7},{7,6},{6,4},{0,4},{1,5},{2,6},{3,7}};
        float[][]pts={{x1,y1,z1},{x2,y1,z1},{x1,y1,z2},{x2,y1,z2},{x1,y2,z1},{x2,y2,z1},{x1,y2,z2},{x2,y2,z2}};
        for(int[]e:edges){
            float[]p1=pts[e[0]],p2=pts[e[1]];
            buf.vertex(mat,p1[0],p1[1],p1[2]).color(c[0],c[1],c[2],a);
            buf.vertex(mat,p2[0],p2[1],p2[2]).color(c[0],c[1],c[2],(int)(a*0.4f));
        }
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private void drawCornerDots(Tessellator tess,Matrix4f mat,Box b,int[]c,int a){
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ;
        float x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        float s=0.025f;
        float[][]corners={{x1,y1,z1},{x2,y1,z1},{x1,y1,z2},{x2,y1,z2},{x1,y2,z1},{x2,y2,z1},{x1,y2,z2},{x2,y2,z2}};
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        for(float[]p:corners){
            buf.vertex(mat,p[0]-s,p[1]-s,p[2]).color(c[0],c[1],c[2],a);
            buf.vertex(mat,p[0]+s,p[1]-s,p[2]).color(c[0],c[1],c[2],a);
            buf.vertex(mat,p[0]+s,p[1]+s,p[2]).color(c[0],c[1],c[2],a);
            buf.vertex(mat,p[0]-s,p[1]+s,p[2]).color(c[0],c[1],c[2],a);
        }
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private void drawFill(Tessellator tess,Matrix4f mat,Box b,int[]c,int a){
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ;
        float x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        // 6 граней
        buf.vertex(mat,x1,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z1).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z1).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x2,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z1).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y2,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y2,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y2,z2).color(c[0],c[1],c[2],a);
        buf.vertex(mat,x1,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z1).color(c[0],c[1],c[2],a);buf.vertex(mat,x2,y1,z2).color(c[0],c[1],c[2],a);buf.vertex(mat,x1,y1,z2).color(c[0],c[1],c[2],a);
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
    private static float[]hsvf(float h,float s,float v){int[]c=hsv(h,s,v);return new float[]{c[0],c[1],c[2]};}
}