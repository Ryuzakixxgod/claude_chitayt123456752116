package ru.ryuzaki.module.modules.particles;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleFactory;
import net.minecraft.entity.LivingEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.Vec3d;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ColorSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.util.color.ColorRGBA;

/**
 * HitParticle — кастомные частицы при попадании по врагу.
 *
 * Вызывается из mixin при DamageEvent или напрямую через метод spawnHitParticles().
 * Поддерживает несколько стилей: звёзды, искры, сердца, взрыв.
 */
public class HitParticleModule extends Module {

    public final ModeSetting    style  = new ModeSetting("Style","Stars","Stars","Sparks","Hearts","Explosion","Slash");
    public final NumberSetting  count  = new NumberSetting("Count",  8.0,  1.0, 20.0, 1.0);
    public final NumberSetting  speed  = new NumberSetting("Speed",  0.3,  0.1,  1.0, 0.05);
    public final ColorSetting   color  = new ColorSetting("Color", new ColorRGBA(255,200,50,255));

    public HitParticleModule() {
        super("HitParticle", "Частицы при попадании по врагу", Category.PARTICLES);
        addSettings(style, count, speed, color);
    }

    /**
     * Spawn particles at the hit entity's position.
     * Call this from a mixin when the player lands a hit.
     */
    public void spawnHitParticles(LivingEntity target) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!isEnabled() || mc.world == null) return;

        Vec3d pos = target.getPos().add(0, target.getHeight() * 0.5, 0);
        int cnt = count.getValue().intValue();
        double sp = speed.getValue();

        for (int i = 0; i < cnt; i++) {
            double angle = (2 * Math.PI / cnt) * i;
            double vx = Math.cos(angle) * sp;
            double vy = (Math.random() - 0.3) * sp;
            double vz = Math.sin(angle) * sp;

            var particleType = switch (style.getCurrent()) {
                case "Hearts"    -> ParticleTypes.HEART;
                case "Explosion" -> ParticleTypes.EXPLOSION;
                case "Sparks"    -> ParticleTypes.CRIT;
                case "Slash"     -> ParticleTypes.SWEEP_ATTACK;
                default          -> ParticleTypes.ENCHANTED_HIT; // Stars
            };

            mc.world.addParticle(particleType,
                pos.x + (Math.random()-0.5)*0.5,
                pos.y + (Math.random()-0.5)*0.5,
                pos.z + (Math.random()-0.5)*0.5,
                vx, vy, vz);
        }
    }
}
