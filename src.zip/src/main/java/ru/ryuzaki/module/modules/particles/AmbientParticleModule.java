package ru.ryuzaki.module.modules.particles;
// src/main/java/ru/ryuzaki/module/modules/particles/AmbientParticleModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import java.util.*;

public class AmbientParticleModule extends Module {
    public final ModeSetting   style   = new ModeSetting("Style","Cosmic","Cosmic","Sakura","Snow","Fireflies","Embers","Matrix","Void");
    public final NumberSetting density = new NumberSetting("Density", 25, 5,  80, 5);
    public final NumberSetting area    = new NumberSetting("Area",    8,  2,  20, 1);
    public final NumberSetting height  = new NumberSetting("Height",  4,  1,  10, 1);

    private static class AP {
        double x,y,z,vx,vy,vz;
        float life,maxLife,size,hue,rot,rotSpeed;
        AP(double x,double y,double z,double vx,double vy,double vz,float life,float size,float hue){
            this.x=x;this.y=y;this.z=z;this.vx=vx;this.vy=vy;this.vz=vz;
            this.life=this.maxLife=life;this.size=size;this.hue=hue;
            rot=(float)(Math.random()*Math.PI*2);
            rotSpeed=(float)(Math.random()*0.06-0.03);
        }
        void update(){
            x+=vx;y+=vy;z+=vz;
            rot+=rotSpeed;
            // Лёгкое раскачивание
            vx+=(Math.random()-0.5)*0.0002;
            vz+=(Math.random()-0.5)*0.0002;
            life--;
        }
    }

    private final List<AP> pool=new ArrayList<>();
    private final java.util.Random rng=new java.util.Random();
    private int spawnTick=0;
    private float globalHue=0f;
    private final int[] colorBuf=new int[3]; // переиспользуемый — ноль new int[] в render

    public AmbientParticleModule(){
        super("AmbientParticles","Атмосферные частицы окружения",Category.PARTICLES);
        addSettings(style,density,area,height);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }
    @Override public void onDisable(){pool.clear();}

    @Override
    public void onUpdate(){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null) return;
        globalHue=(globalHue+0.001f)%1f;
        spawnTick++;

        // Обновляем и убираем мёртвых
        pool.removeIf(p->{p.update();return p.life<=0;});

        // Спаун каждые N тиков
        int interval=Math.max(1,4-(int)(density.getValue()/30));
        if(spawnTick%interval==0&&pool.size()<density.getValue().intValue()){
            float ar=area.getValue().floatValue();
            float ht=height.getValue().floatValue();
            Vec3d base=mc.player.getPos();
            float hue2=getStyleHue();
            double ang=rng.nextDouble()*Math.PI*2;
            double dist=ar*0.3+rng.nextDouble()*ar;
            double spawnX=base.x+Math.cos(ang)*dist;
            double spawnZ=base.z+Math.sin(ang)*dist;
            double spawnY=base.y+ht*rng.nextDouble();

            double[] vel=getStyleVel(style.getCurrent());
            float life=getStyleLife();
            float sz=getStyleSize();
            pool.add(new AP(spawnX,spawnY,spawnZ,vel[0],vel[1],vel[2],life,sz,hue2));
        }
    }

    private void render(WorldRenderContext ctx){
        if(!isEnabled()||pool.isEmpty()) return;
        Vec3d cam=ctx.camera().getPos();
        MatrixStack ms=ctx.matrixStack();if(ms==null)return;
        ms.push();ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.disableDepthTest();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();

        boolean hv=false;
        BufferBuilder pb=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        for(AP p:pool){
            float pct=p.life/p.maxLife;
            ru.ryuzaki.util.RyuzakiRenderCache.hsvFill(p.hue,getStyleSat(),1f,colorBuf); int[]c=colorBuf;
            // Мерцание для светлячков
            float flicker=style.getCurrent().equals("Fireflies")?0.4f+0.6f*(float)Math.abs(Math.sin(p.life*0.3f+p.hue*10)):1f;
            int a=(int)(200*pct*(style.getCurrent().equals("Fireflies")?flicker:Math.sin(pct*Math.PI)));
            float sz=p.size*(style.getCurrent().equals("Snow")?1f:pct*0.7f+0.3f);
            // Вращающийся квадрат
            float cos=(float)Math.cos(p.rot)*sz, sin=(float)Math.sin(p.rot)*sz;
            pb.vertex(mat,(float)p.x-cos,(float)p.y-sin,(float)p.z).color(c[0],c[1],c[2],a);
            pb.vertex(mat,(float)p.x+sin,(float)p.y-cos,(float)p.z).color(c[0],c[1],c[2],a);
            pb.vertex(mat,(float)p.x+cos,(float)p.y+sin,(float)p.z).color(c[0],c[1],c[2],0);
            pb.vertex(mat,(float)p.x-sin,(float)p.y+cos,(float)p.z).color(c[0],c[1],c[2],0);
            hv=true;

            // Светлячки — glow
            if(style.getCurrent().equals("Fireflies")&&flicker>0.6f){
                for(int gl=2;gl>=1;gl--){
                    float gs=sz*(1+gl*0.8f); int ga=(int)(a*0.2f/gl);
                    pb.vertex(mat,(float)p.x-gs,(float)p.y-gs,(float)p.z).color(c[0],c[1],c[2],ga);
                    pb.vertex(mat,(float)p.x+gs,(float)p.y-gs,(float)p.z).color(c[0],c[1],c[2],ga);
                    pb.vertex(mat,(float)p.x+gs,(float)p.y+gs,(float)p.z).color(c[0],c[1],c[2],0);
                    pb.vertex(mat,(float)p.x-gs,(float)p.y+gs,(float)p.z).color(c[0],c[1],c[2],0);
                }
            }
        }
        if(hv)try{BufferRenderer.drawWithGlobalProgram(pb.end());}catch(Exception e){try{pb.end();}catch(Exception ignored){}}
        else try{pb.end();}catch(Exception ignored){}

        ms.pop();RenderSystem.enableDepthTest();RenderSystem.enableCull();RenderSystem.disableBlend();
    }

    private float getStyleHue(){
        return switch(style.getCurrent()){
            case"Sakura"    ->0.9f+rng.nextFloat()*0.06f;
            case"Snow"      ->0.55f+rng.nextFloat()*0.05f;
            case"Fireflies" ->0.2f+rng.nextFloat()*0.1f;
            case"Embers"    ->0.05f+rng.nextFloat()*0.08f;
            case"Matrix"    ->0.33f;
            case"Void"      ->0.73f+rng.nextFloat()*0.06f;
            default         ->(globalHue+rng.nextFloat()*0.2f)%1f;
        };
    }
    private float getStyleSat(){return switch(style.getCurrent()){case"Snow"->0.1f;case"Sakura"->0.4f;default->0.85f;};}
    private double[]getStyleVel(){return getStyleVel(style.getCurrent());}
    private double[]getStyleVel(String s){
        double w=(rng.nextDouble()-0.5)*0.003;
        return switch(s){
            case"Snow"      ->new double[]{w,-0.008-rng.nextDouble()*0.004,w};
            case"Embers"    ->new double[]{w, 0.006+rng.nextDouble()*0.008,w};
            case"Fireflies" ->new double[]{(rng.nextDouble()-0.5)*0.008, (rng.nextDouble()-0.5)*0.004, (rng.nextDouble()-0.5)*0.008};
            case"Matrix"    ->new double[]{0,-0.015-rng.nextDouble()*0.01,0};
            default         ->new double[]{w, 0.004+rng.nextDouble()*0.008,w};
        };
    }
    private float getStyleLife(){return switch(style.getCurrent()){case"Snow"->40+rng.nextInt(30);case"Fireflies"->60+rng.nextInt(60);default->25+rng.nextInt(30);};}
    private float getStyleSize(){return switch(style.getCurrent()){case"Snow"->0.04f+rng.nextFloat()*0.06f;case"Sakura"->0.05f+rng.nextFloat()*0.05f;default->0.03f+rng.nextFloat()*0.04f;};}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
