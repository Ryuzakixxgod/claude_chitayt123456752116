package ru.ryuzaki.module.modules.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.Random;

/**
 * NoFall — отменяет урон от падения.
 *
 * ОБХОДЫ АНТИЧИТА:
 *  - Packet mode: отправляет OnGround пакет когда падаешь
 *  - Vanilla mode: сбрасывает fallDistance (без пакетов)
 *  - Delay: не сразу, а через N тиков после прыжка
 *  - Height threshold: работает только выше определённой высоты
 *  - Min fall: игнорирует падения меньше N блоков
 *  - Packet spam prevention: не спамит пакеты, использует throttle
 */
public class NoFallModule extends Module {

    private final Random random = new Random();
    private int packetCooldown = 0;
    private int ticksSinceGround = 0;

    // ── Режимы ─────────────────────────────────────────────────────
    public final ModeSetting режим = new ModeSetting("Режим", "Пакет", "Пакет", "Ванильный", "Спуф");

    // ── Обходы античита ────────────────────────────────────────────
    public final NumberSetting задержка = new NumberSetting("Задержка", 5.0, 0.0, 20.0, 1.0);
    public final NumberSetting минПадение = new NumberSetting("Мин Падение", 2.5, 1.0, 10.0, 0.5);
    public final BooleanSetting рандомизация = new BooleanSetting("Рандомизация", true);
    public final NumberSetting троттлинг = new NumberSetting("Троттлинг", 10.0, 5.0, 30.0, 1.0);
    public final BooleanSetting фейкЗемля = new BooleanSetting("Фейк Земля", false);

    public NoFallModule() {
        super("NoFall", "Отменяет урон от падения", Category.PLAYER);
        addSettings(режим, задержка, минПадение, рандомизация, троттлинг, фейкЗемля);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        // ── Отслеживаем время на земле ──────────────────────────────
        if (mc.player.isOnGround()) {
            ticksSinceGround = 0;
        } else {
            ticksSinceGround++;
        }

        // ── Packet throttle ──────────────────────────────────────────
        if (packetCooldown > 0) {
            packetCooldown--;
            return;
        }

        // ── Min fall check ───────────────────────────────────────────
        float fallDist = mc.player.fallDistance;
        if (fallDist < минПадение.getValue()) return;

        // ── Delay check ─────────────────────────────────────────────
        int d = задержка.getValue().intValue();
        if (ticksSinceGround < d) return;

        if (режим.is("Ванильный")) {
            // Vanilla: сбрасываем fallDistance
            if (mc.player.getVelocity().y < 0 && !mc.player.isOnGround()) {
                mc.player.fallDistance = 0f;
            }
        } else if (режим.is("Пакет")) {
            // Packet: отправляем on ground пакет
            int throttle = троттлинг.getValue().intValue();
            if (packetCooldown <= 0) {
                mc.player.networkHandler.sendPacket(
                    new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision)
                );
                packetCooldown = throttle;
            }
        } else if (режим.is("Спуф")) {
            // Spoof: чередуем ground/unground для обхода
            int throttle = троттлинг.getValue().intValue();
            boolean sendGround = рандомизация.isEnabled()
                ? random.nextBoolean()
                : true;

            if (sendGround) {
                mc.player.networkHandler.sendPacket(
                    new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision)
                );
            }

            // Ground spoof: всегда шлём ground
            if (фейкЗемля.isEnabled()) {
                // Отправляем каждые N тиков
                if (ticksSinceGround % 4 == 0) {
                    mc.player.networkHandler.sendPacket(
                        new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision)
                    );
                }
            }

            packetCooldown = throttle;
        }
    }

    @Override
    public void onDisable() {
        packetCooldown = 0;
        ticksSinceGround = 0;
    }
}
