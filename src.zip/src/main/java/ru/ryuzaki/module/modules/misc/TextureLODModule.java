package ru.ryuzaki.module.modules.misc;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL14;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * TextureLOD — адаптивный LOD текстур по FPS через GL Mipmap LOD Bias.
 *
 * БЫЛО: меняли options.mipmapLevels, но это требует полной перезагрузки
 * текстурного атласа — НЕ применялось без /reload.
 *
 * СТАЛО: используем GL_TEXTURE_LOD_BIAS через RenderSystem.
 * LOD Bias смещает выбор mipmap уровня:
 *   +2.0 = использует mip-уровень на 2 ниже (менее детальный, быстрее)
 *   0.0  = нормально (без смещения)
 *  -1.0  = более детальный (анизотропия)
 *
 * Применяется мгновенно, без перезагрузки текстур.
 * На слабых GPU даёт +2-8 FPS при снижении VRAM bandwidth.
 */
public class TextureLODModule extends Module {
    private static TextureLODModule instance;

    public final BooleanSetting adaptive   = new BooleanSetting("Adaptive", true);
    public final NumberSetting  targetFPS  = new NumberSetting("Target FPS", 100, 30, 260, 10);
    public final NumberSetting  maxBias    = new NumberSetting("Max LOD Bias", 2.0, 0.0, 4.0, 0.5);

    private float currentBias = 0f;
    private int   tickCount   = 0;
    private boolean applied   = false;

    public TextureLODModule() {
        super("Texture LOD", "Адаптивный mipmap bias по FPS", Category.MISC);
        addSettings(adaptive, targetFPS, maxBias);
        instance = this;
    }

    @Override
    public void onEnable() { applied = false; }

    @Override
    public void onDisable() {
        // Сбрасываем LOD Bias в нормальное состояние
        RenderSystem.assertOnRenderThread();
        GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, 0f);
        currentBias = 0f;
        applied = false;
    }

    @Override
    public void onUpdate() {
        if (++tickCount % 20 != 0) return; // раз в секунду

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return;

        float targetBias;
        if (!adaptive.isEnabled()) {
            targetBias = maxBias.getValue().floatValue();
        } else {
            int fps    = mc.getCurrentFps();
            int target = targetFPS.getValue().intValue();
            float max  = maxBias.getValue().floatValue();

            if (fps >= target) {
                targetBias = 0f; // хороший FPS — максимальное качество
            } else {
                // Линейно увеличиваем bias при снижении FPS
                float ratio = Math.max(0f, 1f - (float) fps / target);
                targetBias = ratio * max;
            }
        }

        // Плавное изменение
        currentBias += (targetBias - currentBias) * 0.3f;

        if (Math.abs(currentBias - targetBias) < 0.01f) currentBias = targetBias;

        // Применяем через OpenGL на render thread
        final float bias = currentBias;
        MinecraftClient.getInstance().execute(() -> {
            if (!isEnabled()) return;
            GL11.glTexParameterf(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_LOD_BIAS, bias);
        });
    }
}
