package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.awt.Color;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * MusicPlayerModule — отображает что сейчас играет в системе.
 *
 * Работает через Windows PowerShell + WinRT Media.Control API.
 * Читает SMTC (System Media Transport Controls) — стандартный
 * Windows интерфейс медиа-информации.
 *
 * Поддерживает ЛЮБОЙ плеер:
 *   - Spotify Desktop (exe, не браузер)
 *   - Яндекс Музыка Desktop
 *   - YouTube Music PWA (Chrome/Edge)
 *   - VK Music Desktop
 *   - Windows Media Player, Groove Music, etc.
 *
 * Без OAuth. Без браузера. Читает то что играет прямо сейчас.
 */
public class MusicPlayerModule extends Module {
    private static MusicPlayerModule instance;

    public final ModeSetting    style    = new ModeSetting("Style","Minimal","Minimal","Full","Compact");
    public final BooleanSetting showArtist= new BooleanSetting("Show Artist",  true);
    public final BooleanSetting showTime  = new BooleanSetting("Show Progress",false);
    public final BooleanSetting pulse     = new BooleanSetting("Pulse",        true);
    public final NumberSetting  opacity   = new NumberSetting("Opacity",      200, 50, 255, 5);
    public final NumberSetting  posX      = new NumberSetting("X", 8, 0, 1000, 1);
    public final NumberSetting  posY      = new NumberSetting("Y", 8, 0, 600, 1);

    // Track info (updated async)
    private volatile String title   = "";
    private volatile String artist  = "";
    private volatile String source  = ""; // Spotify, YandexMusic, etc.
    private volatile boolean playing = false;

    private ScheduledExecutorService scheduler;
    private float animAlpha = 0f;
    private float scrollOffset = 0f;
    private boolean isWindows = false;

    // PowerShell script to get SMTC info
    private static final String PS_SCRIPT =
        "$manager = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime]" +
        "::RequestAsync().GetAwaiter().GetResult();" +
        "$session = $manager.GetCurrentSession();" +
        "if ($session) {" +
        "  $info = $session.TryGetMediaPropertiesAsync().GetAwaiter().GetResult();" +
        "  $playback = $session.GetPlaybackInfo();" +
        "  $appId = $session.SourceAppUserModelId;" +
        "  Write-Output ($info.Title + '|' + $info.Artist + '|' + $playback.PlaybackStatus + '|' + $appId)" +
        "} else { Write-Output 'NONE' }";

    public MusicPlayerModule() {
        super("MusicPlayer","Now Playing — читает системный медиаплеер",Category.MISC);
        addSettings(style, showArtist, showTime, pulse, opacity, posX, posY);
        instance = this;
        isWindows = System.getProperty("os.name","").toLowerCase().contains("windows");
    }

    public static MusicPlayerModule getInstance(){ return instance; }

    @Override
    public void onEnable() {
        if (!isWindows) {
            title = "Только Windows";
            artist = "SMTC API";
            playing = false;
            return;
        }
        // Защита от двойного enable — старый scheduler надо закрыть
        if (scheduler != null) {
            scheduler.shutdownNow();
        }
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r,"RyuzakiSMTC");
            t.setDaemon(true);
            return t;
        });
        scheduler.scheduleAtFixedRate(this::fetchSMTC, 0, 2, TimeUnit.SECONDS);
    }

    @Override
    public void onDisable() {
        if (scheduler != null) {
            scheduler.shutdownNow();
            scheduler = null;
        }
        title=""; artist=""; playing=false; animAlpha=0f;
    }

    private void fetchSMTC() {
        try {
            ProcessBuilder pb = new ProcessBuilder(
                "powershell.exe", "-NonInteractive", "-NoProfile",
                "-Command", PS_SCRIPT
            );
            pb.redirectErrorStream(true);
            Process proc = pb.start();
            String out;
            try (BufferedReader br = new BufferedReader(
                    new InputStreamReader(proc.getInputStream()))) {
                out = br.readLine();
            }
            proc.waitFor(3, TimeUnit.SECONDS);
            proc.destroyForcibly();

            if (out == null || out.equals("NONE") || out.isEmpty()) {
                title = "";
                artist = "";
                source = "";
                playing = false;
                return;
            }

            String[] parts = out.split("\\|", -1);
            title   = parts.length > 0 ? parts[0].trim() : "";
            artist  = parts.length > 1 ? parts[1].trim() : "";
            playing = parts.length > 2 && parts[2].trim().equals("Playing");
            source  = parts.length > 3 ? friendlySource(parts[3].trim()) : "";

        } catch (Exception e) {
            // Silent fail — PowerShell не доступен или ошибка
            playing = false;
        }
    }

    private String friendlySource(String appId) {
        if (appId.contains("Spotify"))     return "Spotify";
        if (appId.contains("Yandex"))      return "Яндекс";
        if (appId.contains("chrome"))      return "Chrome";
        if (appId.contains("msedge"))      return "Edge";
        if (appId.contains("VK"))          return "VK";
        if (appId.contains("Groove"))      return "Groove";
        if (appId.contains("MediaPlayer")) return "WMP";
        return "♪";
    }

    public boolean hasMedia() {
        return !title.isBlank() || !artist.isBlank() || !source.isBlank();
    }

    public String getTrackTitle() {
        return title;
    }

    public String getArtistName() {
        return artist;
    }

    public String getSourceName() {
        return source;
    }

    public boolean isPlayingTrack() {
        return playing;
    }

    // ── HUD Render ────────────────────────────────────────────────────
    public void renderHud(DrawContext ctx, int sw, int sh) {
        if (!isEnabled()) return;
        if (title.isEmpty() && !playing) { animAlpha=Math.max(0f,animAlpha-0.05f); if(animAlpha<=0) return; }
        else animAlpha = Math.min(1f, animAlpha+0.08f);
        if (animAlpha < 0.02f) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        int baseA = (int)(opacity.getValue() * animAlpha);
        float x = posX.getValue().floatValue();
        float y = posY.getValue().floatValue();
        MatrixStack ms = ctx.getMatrices();

        float pulseM = pulse.isEnabled()
            ? (playing ? 0.85f + 0.15f*(float)Math.sin(System.currentTimeMillis()*0.003f) : 0.6f)
            : 1f;

        switch(style.getCurrent()) {
            case "Full"    -> renderFull   (ctx, ms, x, y, baseA, pulseM);
            case "Compact" -> renderCompact(ctx, ms, x, y, baseA, pulseM);
            default        -> renderMinimal(ctx, ms, x, y, baseA, pulseM);
        }
    }

    private void renderMinimal(DrawContext ctx, MatrixStack ms, float x, float y, int a, float pulse2) {
        // ♪ Title — Artist   [Source]
        String icon = playing ? "♪" : "⏸";
        int[]c = ru.ryuzaki.util.RyuzakiRenderCache.rgb1;
        float ix = x;

        // Icon
        txt(ctx, ms, icon, ix, y, new Color(c[0],c[1],c[2],(int)(a*pulse2)), 10f, false);
        ix += tw(icon, 10f) + 5;

        // Title
        String disp = title.isEmpty() ? "Нет трека" : title;
        if (showArtist.isEnabled() && !artist.isEmpty()) disp = title+" — "+artist;
        txt(ctx, ms, disp, ix, y, new Color(237,232,255,(int)(a*0.9f)), 10f, false);

        // Source badge
        if (!source.isEmpty()) {
            float sw2 = tw(source, 8f)+8;
            float sx = ix + tw(disp,10f) + 6;
            DrawHelper.drawRect(ms, sx, y-3, sw2, 14, 7f,
                new Color(c[0],c[1],c[2],(int)(a*0.15f)));
            txt(ctx, ms, source, sx+4, y, new Color(c[0],c[1],c[2],(int)(a*0.8f)), 8f, false);
        }
    }

    private void renderFull(DrawContext ctx, MatrixStack ms, float x, float y, int a, float pulse2) {
        float W = 220f, H = showArtist.isEnabled() ? 52f : 38f;
        DrawHelper.drawRect(ms, x, y, W, H, 10f, new Color(8,6,18,(int)(235*animAlpha)));
        DrawHelper.drawOutline(ms, x, y, W, H, 10f,
            new Color(ru.ryuzaki.util.RyuzakiRenderCache.rgb1[0],
                      ru.ryuzaki.util.RyuzakiRenderCache.rgb1[1],
                      ru.ryuzaki.util.RyuzakiRenderCache.rgb1[2], (int)(50*animAlpha)), 1f);

        // Left accent playing indicator
        if (playing) DrawHelper.drawRect(ms, x, y+(H-16)/2f, 2f, 16f, 1f,
            new Color(ru.ryuzaki.util.RyuzakiRenderCache.rgb1[0],
                      ru.ryuzaki.util.RyuzakiRenderCache.rgb1[1],
                      ru.ryuzaki.util.RyuzakiRenderCache.rgb1[2], (int)(220*pulse2)));

        // Title
        String t2 = title.isEmpty()?"Нет трека":title;
        txt(ctx, ms, t2, x+10, y+10, new Color(237,232,255,a), 10.5f, true);

        // Artist
        if (showArtist.isEnabled() && !artist.isEmpty())
            txt(ctx, ms, artist, x+10, y+24, new Color(150,140,180,a), 9f, false);

        // Source + play status icon
        String status = (playing?"▶ ":"⏸ ") + (source.isEmpty()?"♪":source);
        txt(ctx, ms, status, x+10, y+H-12, new Color(ru.ryuzaki.util.RyuzakiRenderCache.rgb1[0],
            ru.ryuzaki.util.RyuzakiRenderCache.rgb1[1],
            ru.ryuzaki.util.RyuzakiRenderCache.rgb1[2],(int)(180*pulse2)), 8f, false);
    }

    private void renderCompact(DrawContext ctx, MatrixStack ms, float x, float y, int a, float pulse2) {
        // Одна строка, маленький
        int[]c=ru.ryuzaki.util.RyuzakiRenderCache.rgb1;
        String s=(playing?"▶ ":"⏸ ")+title+(showArtist.isEnabled()&&!artist.isEmpty()?" — "+artist:"");
        float w=tw(s,9.5f)+14;
        DrawHelper.drawRect(ms, x, y, w, 18, 9f, new Color(8,6,18,(int)(220*animAlpha)));
        txt(ctx, ms, s, x+7, y+4, new Color(237,232,255,a), 9.5f, false);
    }

    private void txt(DrawContext ctx, MatrixStack ms, String t2, float x, float y, Color col, float size, boolean bold) {
        var f = bold ? Fonts.BOLD : Fonts.MEDIUM;
        if (f!=null) { try{ DrawHelper.drawText(ms.peek().getPositionMatrix(),f.getFont(size),t2,x,y,col); return; }catch(Exception ignored){} }
        int argb=(col.getAlpha()<<24)|(col.getRed()<<16)|(col.getGreen()<<8)|col.getBlue();
        ctx.drawText(MinecraftClient.getInstance().textRenderer, t2,(int)x,(int)(y-7),argb,false);
    }
    private float tw(String s, float size) {
        if(Fonts.BOLD!=null) return Fonts.BOLD.getWidth(s,size);
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }
}
