package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * DrawCallBatcher — счётчик и диагностика draw calls + GL state changes.
 *
 * Draw call = команда GPU. Типично MC: 1000-3000/кадр.
 * Каждый draw call = ~0.002-0.01ms driver overhead.
 * С нашим модом визуалки добавляется 100-300 draw calls.
 *
 * GlStateCache сокращает redundant state changes в нашем рендере.
 * Счётчик помогает найти узкие места если FPS упал.
 *
 * showCounter — показывает draw calls/frame под F3 экраном.
 * logSpikes   — логирует в консоль если draw calls > порога.
 */
public class DrawCallBatcherModule extends Module {
    private static volatile boolean active = false;
    public static boolean isActive() { return active; }
    @Override public void onEnable()  { active = true; }
    @Override public void onDisable() { active = false; }

    public final BooleanSetting showCounter = new BooleanSetting("Show Counter", false);
    public final BooleanSetting logSpikes   = new BooleanSetting("Log Spikes",   false);

    private static volatile int  frameDrawCalls     = 0;
    private static volatile int  lastFrameDrawCalls = 0;
    private static          long lastResetFrame     = -1;
    private static DrawCallBatcherModule instance;

    public DrawCallBatcherModule() {
        super("Draw Call Batcher", "Диагностика draw calls + GL state cache", Category.MISC);
        addSettings(showCounter, logSpikes);
        instance = this;
    }

    public static void onDrawCall() {
        if (instance == null || !instance.isEnabled()) return;
        frameDrawCalls++;
    }

    @Override
    public void onUpdate() {
        long frame = RyuzakiRenderCache.getFrameCount();
        if (frame == lastResetFrame) return;

        lastFrameDrawCalls = frameDrawCalls;
        frameDrawCalls = 0;
        lastResetFrame = frame;

        if (logSpikes.isEnabled() && lastFrameDrawCalls > 4000) {
            System.out.printf("[Ryuzaki] Draw call spike: %d/frame%n", lastFrameDrawCalls);
        }
    }

    public static int getLastFrameDrawCalls() { return lastFrameDrawCalls; }
    public static DrawCallBatcherModule getInstance() { return instance; }
}
