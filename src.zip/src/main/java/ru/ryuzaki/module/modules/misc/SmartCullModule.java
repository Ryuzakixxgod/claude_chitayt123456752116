package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * SmartCull — пропускает рендер сущностей вне FOV.
 *
 * ОПТИМИЗАЦИИ:
 *  - FOV кэшируется в RyuzakiRenderCache — ноль Math.toRadians на сущность
 *  - screenWOverFovRad кэшируется — ноль деления на сущность
 *  - Все вычисления в hot path — только умножения
 *  При 50 сущностях × 240 FPS: было ~12000 Math.toRadians/сек → 0
 */
public class SmartCullModule extends Module {

    private static volatile boolean _enabled = false;
    @Override public void onEnable()  { _enabled = true; }
    @Override public void onDisable() { _enabled = false; }
    private static SmartCullModule instance;

    public final BooleanSetting frustumCull = new BooleanSetting("Frustum Cull", true);
    public final BooleanSetting sizeCull    = new BooleanSetting("Size Cull",    true);
    public final NumberSetting  minSizePx   = new NumberSetting("Min Size px", 2, 1, 20, 1);

    public SmartCullModule() {
        super("Smart Cull", "Skip off-screen entity rendering", Category.MISC);
        addSettings(frustumCull, sizeCull, minSizePx);
        instance = this;
    }

    public static SmartCullModule getInstance() { return instance; }

    /**
     * true = рендерить, false = пропустить.
     * Вызывается из MixinEntityRenderDispatcher для каждой сущности каждый кадр.
     * Абсолютно никакой тригонометрии — всё через RyuzakiRenderCache.
     */
    public static boolean shouldRender(Entity e) {
        SmartCullModule mod = instance;
        if (!_enabled || mod == null) return true;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.world == null || mc.player == null) return true;
        if (e == null || e == mc.player || !e.isAlive()) return true;

        // Не режем игроков: TargetESP/nametags и ванильный рендер игроков
        // должны оставаться предсказуемыми даже при агрессивном culling.
        if (e instanceof net.minecraft.entity.player.PlayerEntity) return true;

        double ex = e.getX();
        double ey = e.getY() + e.getHeight() * 0.5;
        double ez = e.getZ();
        double distSq = RyuzakiRenderCache.camDistSq(ex, ey, ez);

        if (mod.frustumCull.isEnabled() && distSq > 64.0) {
            if (!RyuzakiRenderCache.isInFrustum(ex, ey, ez)) return false;
        }

        if (mod.sizeCull.isEnabled() && distSq > 32.0 * 32.0) {
            double dist = Math.sqrt(distSq);
            double size = Math.max(e.getWidth(), e.getHeight());
            double px = size / dist * RyuzakiRenderCache.screenWOverFovRad;
            return px >= mod.minSizePx.getValue();
        }

        return true;
    }
}
