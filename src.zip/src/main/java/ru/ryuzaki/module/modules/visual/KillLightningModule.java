package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/KillLightningModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import java.util.*;

public class KillLightningModule extends Module {
    public static KillLightningModule INSTANCE;
    private static KillLightningModule instance;
    public final ModeSetting  style  = new ModeSetting("Style","Cosmic","Cosmic","Lightning","Nova","Reaper","Explosion");
    public final NumberSetting count = new NumberSetting("Particles", 70, 20, 150, 10);

    private static class Bolt {
        double x,y,z,vx,vy,vz; float life,maxLife,size,hue;
        Bolt(double x,double y,double z,double vx,double vy,double vz,float life,float size,float hue){this.x=x;this.y=y;this.z=z;this.vx=vx;this.vy=vy;this.vz=vz;this.life=this.maxLife=life;this.size=size;this.hue=hue;}
        void update(){x+=vx;y+=vy;z+=vz;vy-=0.005;life--;vx*=0.94;vy*=0.94;vz*=0.94;}
    }
    private static class Ring {
        Vec3d pos; float radius,maxR,life,maxLife; int[]color;
        Ring(Vec3d p,float maxR,float life,int[]c){pos=p;radius=0;this.maxR=maxR;this.life=this.maxLife=life;this.color=c;}
        void update(){float p=1f-life/maxLife;radius=(float)(maxR*Math.sqrt(p));life--;}
    }

    private static final List<Bolt> bolts = new ArrayList<>();
    private static final List<Ring> rings = new ArrayList<>();
    private static final Random rng = new Random();
    private float globalHue = 0f;

    public KillLightningModule(){super("KillLightning","VFX при убийстве",Category.VISUAL);addSettings(style,count);WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);INSTANCE=this;instance=this;}
    public static KillLightningModule getInstance(){return instance;}

    public void onKill(Vec3d pos){
        if(!isEnabled()) return;
        globalHue=(globalHue+0.1f)%1f;
        int n=count.getValue().intValue();
        int[]c1=getBaseColor(0), c2=getBaseColor(1);

        // Кольца
        rings.add(new Ring(pos,3.0f,30,c1));
        rings.add(new Ring(pos,2.0f,22,c2));
        rings.add(new Ring(pos,5.0f,40,c1));

        // Частицы
        for(int i=0;i<n;i++){
            float ang=(float)(Math.PI*2*rng.nextFloat());
            float el=(float)(Math.PI*(rng.nextFloat()-0.5f));
            float spd=0.05f+rng.nextFloat()*0.12f;
            float hue=globalHue+rng.nextFloat()*0.2f;
            bolts.add(new Bolt(pos.x+rng.nextGaussian()*0.1,pos.y+0.5+rng.nextDouble()*0.5,pos.z+rng.nextGaussian()*0.1,
                Math.cos(ang)*Math.cos(el)*spd,Math.sin(el)*spd+0.05,Math.sin(ang)*Math.cos(el)*spd,
                25+rng.nextInt(35),0.05f+rng.nextFloat()*0.08f,hue));
        }

        // Столб вверх для Reaper
        if(style.getCurrent().equals("Reaper")){
            for(int i=0;i<30;i++){double t=i/30.0;double ang=t*Math.PI*6;bolts.add(new Bolt(pos.x+Math.cos(ang)*0.3,pos.y+t*4,pos.z+Math.sin(ang)*0.3,0,0.05,0,50+rng.nextInt(20),0.06f,(float)t));}
        }
        while(bolts.size()>500)bolts.remove(0);
    }

    private void render(WorldRenderContext ctx){
        if(!isEnabled()||(bolts.isEmpty()&&rings.isEmpty())) return;
        Vec3d cam=ctx.camera().getPos(); MatrixStack ms=ctx.matrixStack(); if(ms==null)return;
        ms.push(); ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.disableDepthTest(); RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull(); RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();

        // Кольца
        Iterator<Ring> ri=rings.iterator();
        while(ri.hasNext()){Ring ring=ri.next();ring.update();if(ring.life<=0){ri.remove();continue;}
            float pct=ring.life/ring.maxLife,bright=(float)Math.sin(pct*Math.PI);
            for(int gl=4;gl>=1;gl--){float gr=ring.radius*(1+gl*0.04f);int ga=(int)(200*bright*0.15f/gl);drawRing(tess,mat,ring.pos,gr,ring.color,(int)ga);}
            drawRing(tess,mat,ring.pos,ring.radius,ring.color,(int)(220*bright));}

        // Частицы
        Iterator<Bolt> bi=bolts.iterator();
        boolean hv=false; BufferBuilder pb=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        while(bi.hasNext()){Bolt b=bi.next();b.update();if(b.life<=0){bi.remove();continue;}
            float pct=b.life/b.maxLife; int ba=(int)(220*pct*(0.5f+0.5f*(float)Math.sin(pct*Math.PI)));
            int[]c=hsv(b.hue,0.85f,1f); float sz=b.size*(0.3f+0.7f*pct);
            pb.vertex(mat,(float)b.x-sz,(float)b.y-sz,(float)b.z).color(c[0],c[1],c[2],ba);
            pb.vertex(mat,(float)b.x+sz,(float)b.y-sz,(float)b.z).color(c[0],c[1],c[2],ba);
            pb.vertex(mat,(float)b.x+sz,(float)b.y+sz,(float)b.z).color(c[0],c[1],c[2],0);
            pb.vertex(mat,(float)b.x-sz,(float)b.y+sz,(float)b.z).color(c[0],c[1],c[2],0);
            hv=true;}
        if(hv)try{BufferRenderer.drawWithGlobalProgram(pb.end());}catch(Exception e){try{pb.end();}catch(Exception ignored){}}else try{pb.end();}catch(Exception ignored){}

        ms.pop(); RenderSystem.enableDepthTest(); RenderSystem.enableCull(); RenderSystem.disableBlend();
    }
    private void drawRing(Tessellator t,Matrix4f m,Vec3d p,float r,int[]c,int a){
        BufferBuilder buf=t.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
        for(int i=0;i<=48;i++){double ang=2*Math.PI*i/48;buf.vertex(m,(float)(p.x+r*Math.cos(ang)),(float)p.y,(float)(p.z+r*Math.sin(ang))).color(c[0],c[1],c[2],a);}
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }
    private int[] getBaseColor(int i){return switch(style.getCurrent()){case"Lightning"->new int[]{255,240,80};case"Nova"->hsv((globalHue+i*0.15f)%1f,0.9f,1f);case"Reaper"->new int[]{160,0,255};case"Explosion"->new int[]{255,(int)(100+i*30),0};default->hsv((globalHue+i*0.12f)%1f,0.85f,1f);};}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
