package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.settings.BooleanSetting;

/**
 * ArmorAlert — предупреждение когда броня близка к поломке.
 * Отображается как HUD сообщение + мигание.
 */
public class ArmorAlertModule extends Module {
    private static ArmorAlertModule instance;

    public final NumberSetting  threshold = new NumberSetting("Alert %", 10, 1, 40, 1);
    public final BooleanSetting blink     = new BooleanSetting("Blink", true);

    public ArmorAlertModule() {
        super("Armor Alert", "Warn when armor is breaking", Category.MISC);
        addSettings(threshold, blink);
        instance = this;
    }

    public static ArmorAlertModule getInstance() { return instance; }

    /** Вызывается из HUD рендера */
    public void renderAlert(DrawContext ctx, int sw, int sh) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        long t = System.currentTimeMillis();
        boolean visible = !blink.isEnabled() || (t/350)%2 == 0;

        int alertY = sh - 80;
        boolean anyAlert = false;

        String[] slots = {"Шлем", "Нагрудник", "Поножи", "Ботинки"};
        ItemStack[] armor = {
                mc.player.getInventory().getArmorStack(3),
                mc.player.getInventory().getArmorStack(2),
                mc.player.getInventory().getArmorStack(1),
                mc.player.getInventory().getArmorStack(0)
        };

        for (int i = 0; i < 4; i++) {
            ItemStack stack = armor[i];
            if (stack.isEmpty()) continue;
            if (!(stack.getItem() instanceof ArmorItem)) continue;

            int maxDur = stack.getMaxDamage();
            if (maxDur <= 0) continue;
            int durLeft = maxDur - stack.getDamage();
            float pct = durLeft / (float)maxDur * 100f;

            if (pct <= threshold.getValue().floatValue() && visible) {
                anyAlert = true;
                String msg = "⚠ " + slots[i] + " — " + (int)pct + "%";
                int tw = mc.textRenderer.getWidth(msg);
                ctx.fill(sw/2-tw/2-6, alertY-2, sw/2+tw/2+6, alertY+12, rgba(20,5,10,200));
                ctx.fill(sw/2-tw/2-6, alertY-2, sw/2+tw/2+6, alertY-1,  rgba(255,60,60,200));
                ctx.drawText(mc.textRenderer, Text.literal("§c"+msg), sw/2-tw/2, alertY, 0xFFFF4444, true);
                alertY -= 18;
            }
        }
    }

    private static int rgba(int r,int g,int b,int a) {
        return ((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
}