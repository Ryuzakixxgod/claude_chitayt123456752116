package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * 🚀 Smart FPS Limiter
 *
 * Когда Minecraft свёрнут — GPU рендерит 260 FPS вхолостую,
 * нагревая карту и сжирая электричество. Этот модуль:
 *
 * • Фон (tabbed out)  → 1–5 FPS (почти 0 нагрузки)
 * • Игра не в фокусе → пониженный FPS
 * • Активная игра    → максимальный FPS
 *
 * Сохраняет и восстанавливает оригинал при выключении.
 */
public class SmartFPSLimiter extends Module {
    private static SmartFPSLimiter instance;

    public final NumberSetting  backgroundFPS = new NumberSetting("Background FPS", 2,  1, 15,  1);
    public final NumberSetting  unfocusedFPS  = new NumberSetting("Unfocused FPS",  30, 10, 60, 5);
    public final NumberSetting  activeFPS     = new NumberSetting("Active FPS",    260, 60, 260, 10);
    public final BooleanSetting alwaysCap     = new BooleanSetting("Always Cap Active", false);

    private int origFps = -1;
    private int tickDelay = 0;

    public SmartFPSLimiter() {
        super("Smart FPS Limiter", "Auto FPS limit in background", Category.MISC);
        addSettings(backgroundFPS, unfocusedFPS, activeFPS, alwaysCap);
        instance = this;
    }

    public static SmartFPSLimiter getInstance() { return instance; }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        origFps = mc.options.getMaxFps().getValue();
    }

    @Override
    public void onDisable() {
        if (origFps < 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        mc.options.getMaxFps().setValue(origFps);
        mc.options.write();
    }

    @Override
    public void onUpdate() {
        // Проверяем раз в 20 тиков (1 секунда) — нет смысла чаще
        if (++tickDelay % 20 != 0) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null || mc.getWindow() == null) return;

        long windowHandle = mc.getWindow().getHandle();
        boolean isFocused = org.lwjgl.glfw.GLFW.glfwGetWindowAttrib(
            windowHandle, org.lwjgl.glfw.GLFW.GLFW_FOCUSED) == 1;
        boolean isIconified = org.lwjgl.glfw.GLFW.glfwGetWindowAttrib(
            windowHandle, org.lwjgl.glfw.GLFW.GLFW_ICONIFIED) == 1;

        int targetFPS;
        if (isIconified) {
            // Полностью свёрнут — минимум
            targetFPS = backgroundFPS.getValue().intValue();
        } else if (!isFocused) {
            // Окно есть но без фокуса
            targetFPS = unfocusedFPS.getValue().intValue();
        } else {
            // Активная игра
            targetFPS = alwaysCap.isEnabled()
                ? activeFPS.getValue().intValue()
                : (origFps > 0 ? origFps : 260);
        }

        mc.options.getMaxFps().setValue(targetFPS);
    }
}
