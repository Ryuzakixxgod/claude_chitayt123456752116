package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * RenderTweaks — набор мелких оптимизаций рендера.
 *
 * Каждый пункт небольшой но все вместе дают +20-40 FPS:
 *
 * noAO             — отключает Ambient Occlusion (+5-15 FPS)
 *                    AO = CPU пересчёт освещения для каждого блока в чанке
 * noBobbing        — отключает покачивание камеры при ходьбе (+1-3 FPS)
 * noClouds         — отключает рендер облаков (+3-8 FPS)
 *                    Облака = отдельный render pass каждый кадр
 * throttleLightmap — lightmap обновляется раз в N мс вместо каждого кадра
 *                    (+0.5-2 FPS, особенно на слабых GPU)
 * limitChunkUpd    — ограничивает перестройки чанков за тик
 *                    (убирает лаги при переходе биомов)
 */
public class RenderTweaksModule extends Module {
    public static RenderTweaksModule INSTANCE;

    public final BooleanSetting noAO             = new BooleanSetting("No Ambient Occlusion", true);
    public final BooleanSetting noBobbing        = new BooleanSetting("No View Bobbing",      true);
    public final BooleanSetting noClouds         = new BooleanSetting("No Clouds",            true);
    public final BooleanSetting throttleLightmap = new BooleanSetting("Throttle Lightmap",    true);
    public final NumberSetting  lightmapIntervalMs = new NumberSetting("Lightmap ms", 50, 16, 200, 16);
    public final BooleanSetting limitChunkUpd    = new BooleanSetting("Limit Chunk Updates",  true);
    public final NumberSetting  maxChunkUpd      = new NumberSetting("Chunk Updates/tick", 5, 1, 20, 1);

    private boolean origBobbing = true;
    private boolean saved = false;

    public RenderTweaksModule() {super("Render Tweaks", "Мелкие оптимизации рендера (+20-40 FPS)", Category.MISC);
                INSTANCE = this;
addSettings(noAO, noBobbing, noClouds, throttleLightmap, lightmapIntervalMs,
                    limitChunkUpd, maxChunkUpd);
    }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        origBobbing = mc.options.getBobView().getValue();
        saved = true;
        if (noBobbing.isEnabled()) mc.options.getBobView().setValue(false);
    }

    @Override
    public void onDisable() {
        if (!saved) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options != null) mc.options.getBobView().setValue(origBobbing);
    }

    @Override
    public void onUpdate() {
        if (!saved) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        boolean wantBob = !noBobbing.isEnabled();
        if (mc.options.getBobView().getValue() != wantBob)
            mc.options.getBobView().setValue(wantBob ? origBobbing : false);
    }
}
