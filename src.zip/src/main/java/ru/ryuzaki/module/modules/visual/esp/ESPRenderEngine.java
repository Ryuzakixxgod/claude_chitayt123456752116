package ru.ryuzaki.module.modules.visual.esp;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;

/**
 * ESPRenderEngine — Tessellator-based renderer.
 *
 * Uses Minecraft's Tessellator + BufferRenderer.drawWithGlobalProgram
 * (the same approach as NameTagsModule) instead of raw VAO/VBO.
 * This avoids GL INVALID_OPERATION conflicts on multiplayer servers.
 *
 * Old: N entities × 3 passes × Tessellator.begin/end = 3N draw calls
 * New: All entities batched into ONE Tessellator draw call per pass = 3 draw calls total
 */
public final class ESPRenderEngine {

    private static volatile ESPRenderEngine instance;
    public static ESPRenderEngine getInstance() {
        if (instance == null) synchronized(ESPRenderEngine.class) {
            if (instance == null) instance = new ESPRenderEngine();
        }
        return instance;
    }

    // Entity data – reused every frame (no alloc)
    private static final int MAX_ENTITIES = 256;

    private final double[] ex    = new double[MAX_ENTITIES];
    private final double[] ey    = new double[MAX_ENTITIES];
    private final double[] ez    = new double[MAX_ENTITIES];
    private final double[] ew    = new double[MAX_ENTITIES]; // half-width
    private final double[] eh    = new double[MAX_ENTITIES]; // height
    private final int[]    er    = new int[MAX_ENTITIES];
    private final int[]    eg    = new int[MAX_ENTITIES];
    private final int[]    eb    = new int[MAX_ENTITIES];
    private final float[]  ealpha= new float[MAX_ENTITIES];
    private final boolean[]efriend=new boolean[MAX_ENTITIES];
    private int count = 0;

    private double camX, camY, camZ;
    private boolean hasWork = false;

    public void beginFrame(Vec3d cam, Matrix4f projView, float maxDist) {
        count = 0;
        hasWork = false;
        camX = cam.x; camY = cam.y; camZ = cam.z;
    }

    public void submitEntity(LivingEntity e, int[]rgb, float hp, float pulse,
                              boolean friend, Vec3d lerp, int layers) {
        if (count >= MAX_ENTITIES) return;
        Box bb = e.getBoundingBox();
        ex[count]    = lerp.x - camX;
        ey[count]    = lerp.y - camY;
        ez[count]    = lerp.z - camZ;
        ew[count]    = (bb.maxX - bb.minX) / 2.0 + 0.05;
        eh[count]    = bb.maxY - bb.minY + 0.1;
        er[count]    = rgb[0];
        eg[count]    = rgb[1];
        eb[count]    = rgb[2];
        ealpha[count]= pulse * (friend ? 1.0f : 0.85f);
        efriend[count]= friend;
        count++;
        hasWork = true;
    }

    public boolean hasWork() { return hasWork; }

    // ── Tessellator helpers (mirrors NameTagsModule approach) ──────────

    private static void setStateForLines() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.lineWidth(1.5f);
    }

    private static void resetState() {
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(1f);
    }

    private static void flushPass(BufferBuilder bb) {
        try {
            BufferRenderer.drawWithGlobalProgram(bb.end());
        } catch (Exception ignored) {}
    }

    /**
     * Draws box outline edges into an open BufferBuilder (no begin/end) —
     * 12 edges, 24 vertices, same format as boxOutline() in NativeGL.
     */
    private static void bbEdges(BufferBuilder bb, Matrix4f mat,
                                  float x1, float y1, float z1,
                                  float x2, float y2, float z2,
                                  int r, int g, int b, int a) {
        // Bottom
        v(bb, mat, x1,y1,z1,r,g,b,a); v(bb, mat, x2,y1,z1,r,g,b,a);
        v(bb, mat, x2,y1,z1,r,g,b,a); v(bb, mat, x2,y1,z2,r,g,b,a);
        v(bb, mat, x2,y1,z2,r,g,b,a); v(bb, mat, x1,y1,z2,r,g,b,a);
        v(bb, mat, x1,y1,z2,r,g,b,a); v(bb, mat, x1,y1,z1,r,g,b,a);
        // Top
        v(bb, mat, x1,y2,z1,r,g,b,a); v(bb, mat, x2,y2,z1,r,g,b,a);
        v(bb, mat, x2,y2,z1,r,g,b,a); v(bb, mat, x2,y2,z2,r,g,b,a);
        v(bb, mat, x2,y2,z2,r,g,b,a); v(bb, mat, x1,y2,z2,r,g,b,a);
        v(bb, mat, x1,y2,z2,r,g,b,a); v(bb, mat, x1,y2,z1,r,g,b,a);
        // Pillars
        v(bb, mat, x1,y1,z1,r,g,b,a); v(bb, mat, x1,y2,z1,r,g,b,a);
        v(bb, mat, x2,y1,z1,r,g,b,a); v(bb, mat, x2,y2,z1,r,g,b,a);
        v(bb, mat, x2,y1,z2,r,g,b,a); v(bb, mat, x2,y2,z2,r,g,b,a);
        v(bb, mat, x1,y1,z2,r,g,b,a); v(bb, mat, x1,y2,z2,r,g,b,a);
    }

    /**
     * Draws L-bracket corners into an open BufferBuilder — 8 corners × 3 edges.
     */
    private static void bbCorners(BufferBuilder bb, Matrix4f mat,
                                   float x1, float y1, float z1,
                                   float x2, float y2, float z2,
                                   int r, int g, int b, int a) {
        float lx = Math.min((x2-x1)*.25f, .4f);
        float ly = Math.min((y2-y1)*.25f, .4f);
        float lz = Math.min((z2-z1)*.25f, .4f);
        // 8 corners: {x, y, z}, then 3 edge-end deltas
        v(bb,mat, x1,  y1,  z1,  r,g,b,a); v(bb,mat, x1+lx,y1,  z1,  r,g,b,a);
        v(bb,mat, x1,  y1,  z1,  r,g,b,a); v(bb,mat, x1,  y1+ly,z1,  r,g,b,a);
        v(bb,mat, x1,  y1,  z1,  r,g,b,a); v(bb,mat, x1,  y1,  z1+lz,r,g,b,a);

        v(bb,mat, x2,  y1,  z1,  r,g,b,a); v(bb,mat, x2-lx,y1,  z1,  r,g,b,a);
        v(bb,mat, x2,  y1,  z1,  r,g,b,a); v(bb,mat, x2,  y1+ly,z1,  r,g,b,a);
        v(bb,mat, x2,  y1,  z1,  r,g,b,a); v(bb,mat, x2,  y1,  z1+lz,r,g,b,a);

        v(bb,mat, x1,  y1,  z2,  r,g,b,a); v(bb,mat, x1+lx,y1,  z2,  r,g,b,a);
        v(bb,mat, x1,  y1,  z2,  r,g,b,a); v(bb,mat, x1,  y1+ly,z2,  r,g,b,a);
        v(bb,mat, x1,  y1,  z2,  r,g,b,a); v(bb,mat, x1,  y1,  z2-lz,r,g,b,a);

        v(bb,mat, x2,  y1,  z2,  r,g,b,a); v(bb,mat, x2-lx,y1,  z2,  r,g,b,a);
        v(bb,mat, x2,  y1,  z2,  r,g,b,a); v(bb,mat, x2,  y1+ly,z2,  r,g,b,a);
        v(bb,mat, x2,  y1,  z2,  r,g,b,a); v(bb,mat, x2,  y1,  z2-lz,r,g,b,a);

        v(bb,mat, x1,  y2,  z1,  r,g,b,a); v(bb,mat, x1+lx,y2,  z1,  r,g,b,a);
        v(bb,mat, x1,  y2,  z1,  r,g,b,a); v(bb,mat, x1,  y2-ly,z1,  r,g,b,a);
        v(bb,mat, x1,  y2,  z1,  r,g,b,a); v(bb,mat, x1,  y2,  z1+lz,r,g,b,a);

        v(bb,mat, x2,  y2,  z1,  r,g,b,a); v(bb,mat, x2-lx,y2,  z1,  r,g,b,a);
        v(bb,mat, x2,  y2,  z1,  r,g,b,a); v(bb,mat, x2,  y2-ly,z1,  r,g,b,a);
        v(bb,mat, x2,  y2,  z1,  r,g,b,a); v(bb,mat, x2,  y2,  z1+lz,r,g,b,a);

        v(bb,mat, x1,  y2,  z2,  r,g,b,a); v(bb,mat, x1+lx,y2,  z2,  r,g,b,a);
        v(bb,mat, x1,  y2,  z2,  r,g,b,a); v(bb,mat, x1,  y2-ly,z2,  r,g,b,a);
        v(bb,mat, x1,  y2,  z2,  r,g,b,a); v(bb,mat, x1,  y2,  z2-lz,r,g,b,a);

        v(bb,mat, x2,  y2,  z2,  r,g,b,a); v(bb,mat, x2-lx,y2,  z2,  r,g,b,a);
        v(bb,mat, x2,  y2,  z2,  r,g,b,a); v(bb,mat, x2,  y2-ly,z2,  r,g,b,a);
        v(bb,mat, x2,  y2,  z2,  r,g,b,a); v(bb,mat, x2,  y2,  z2-lz,r,g,b,a);
    }

    private static void v(BufferBuilder bb, Matrix4f mat, float x, float y, float z, int r, int g, int b, int a) {
        bb.vertex(mat, x, y, z).color(r, g, b, a);
    }

    /**
     * Flush: render ALL entities in ONE Tessellator draw call per pass.
     */
    public void flushFrame(MatrixStack ms, long now, float eyeX, float eyeY, float eyeZ,
                            float glowWidth, float glowLayers, boolean tracers,
                            boolean healthBars, int outlineIndex) {
        if (!hasWork || count == 0) return;

        Matrix4f mat = ms.peek().getPositionMatrix();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Tessellator tess = Tessellator.getInstance();

        // ── PASS 1: Glow (additive, wider) ──────────────────────────
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        setStateForLines();
        BufferBuilder glowBB = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < count; i++) {
            float expand = glowWidth * 2.5f;
            float x1=(float)(ex[i]-ew[i]-expand), y1=(float)(ey[i]-0.05f),       z1=(float)(ez[i]-ew[i]-expand);
            float x2=(float)(ex[i]+ew[i]+expand), y2=(float)(ey[i]+eh[i]+0.05f), z2=(float)(ez[i]+ew[i]+expand);
            int ga = (int)(ealpha[i] * 35);
            bbEdges(glowBB, mat, x1,y1,z1,x2,y2,z2, er[i],eg[i],eb[i],ga);
        }
        flushPass(glowBB);

        // ── PASS 2: Core corners or full outline ─────────────────────
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        setStateForLines();
        BufferBuilder coreBB = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < count; i++) {
            float x1=(float)(ex[i]-ew[i]), y1=(float)(ey[i]-0.05f),       z1=(float)(ez[i]-ew[i]);
            float x2=(float)(ex[i]+ew[i]), y2=(float)(ey[i]+eh[i]+0.05f), z2=(float)(ez[i]+ew[i]);
            int a = (int)(ealpha[i] * 220);
            if (outlineIndex >= 1) bbCorners(coreBB, mat, x1,y1,z1,x2,y2,z2, er[i],eg[i],eb[i],a);
            else                   bbEdges(coreBB, mat, x1,y1,z1,x2,y2,z2, er[i],eg[i],eb[i],a);
        }
        flushPass(coreBB);

        // ── PASS 3: Tracers ──────────────────────────────────────────
        if (tracers) {
            setStateForLines();
            BufferBuilder tracBB = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for (int i = 0; i < count; i++) {
                int a = (int)(ealpha[i] * 140);
                v(tracBB, mat, eyeX, eyeY, eyeZ, er[i],eg[i],eb[i],a);
                v(tracBB, mat, (float)ex[i], (float)(ey[i]+eh[i]*0.5f), (float)ez[i], er[i],eg[i],eb[i],0);
            }
            flushPass(tracBB);
        }

        resetState();
    }
}
