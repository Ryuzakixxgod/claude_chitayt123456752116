package ru.ryuzaki.module.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import ru.ryuzaki.hud.HudElement;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * ✨ Compass HUD
 *
 * Красивый анимированный компас с плавным скроллом.
 * Отображает: N S E W + градусы + координаты + биом.
 *
 * Рендерится как HUD элемент — перетаскивается в HUD Editor.
 * Стили: Bar (лента), Circle (окружность), Minimal (только Dir).
 */
public class CompassHudModule extends Module {
    private static CompassHudModule instance;

    public final ModeSetting   style    = new ModeSetting("Style","Bar","Bar","Minimal","Coords");
    public final BooleanSetting showCoords = new BooleanSetting("Show Coords", true);
    public final BooleanSetting showBiome  = new BooleanSetting("Show Biome",  false);
    public final NumberSetting  width      = new NumberSetting("Width", 180, 80, 300, 10);

    // HUD позиция
    private float hudX = -1, hudY = 4;

    public CompassHudModule() {
        super("Compass HUD", "Animated compass with direction", Category.VISUAL);
        addSettings(style, showCoords, showBiome, width);
        instance = this;
    }

    public static CompassHudModule getInstance() { return instance; }

    /** Вызывается из MixinInGameHud / HudManager */
    public void renderHud(DrawContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int sw = mc.getWindow().getScaledWidth();
        int w  = width.getValue().intValue();
        int x  = (hudX < 0) ? (sw/2 - w/2) : (int)hudX;
        int y  = (int)hudY;

        float yaw = mc.player.getYaw() % 360f;
        if (yaw < 0) yaw += 360f;
        String dir = getDirectionLabel(yaw);

        switch (style.getCurrent()) {
            case "Bar"     -> renderBar(ctx, mc, x, y, w, yaw, dir);
            case "Minimal" -> renderMinimal(ctx, mc, x, y, dir, yaw);
            case "Coords"  -> renderCoords(ctx, mc, x, y, w, yaw, dir);
        }
    }

    private void renderBar(DrawContext ctx, MinecraftClient mc, int x, int y, int w, float yaw, String dir) {
        int h = showCoords.isEnabled() ? 36 : 22;
        long t = System.currentTimeMillis();

        // Фон с градиентом
        ctx.fill(x, y, x+w, y+h, rgba(5,3,15,210));
        ctx.fill(x, y, x+w, y+1, rgba(130,50,220,200));  // верхний акцент

        // Тиклы компаса (скроллятся)
        int tickSpacing = 5; // пиксель на градус
        ctx.enableScissor(x+2, y+2, x+w-2, y+h-2);
        for (int deg = 0; deg < 360; deg += 5) {
            float offset = (deg - yaw + 540f) % 360f - 180f;
            int tx = x + w/2 + (int)(offset * (w / 180f));
            if (tx < x || tx > x+w) continue;

            boolean isCardinal = deg % 90 == 0;
            boolean isMajor    = deg % 45 == 0;
            int tickH = isCardinal ? 10 : isMajor ? 7 : 4;
            int tickA = isCardinal ? 255 : isMajor ? 180 : 100;
            int[] col = isCardinal ? (deg==0||deg==180 ? new int[]{255,60,60} : new int[]{180,180,255}) : new int[]{120,100,180};

            ctx.fill(tx, y+2, tx+1, y+2+tickH, rgba(col[0],col[1],col[2],tickA));

            // Подписи для кардинальных
            if (isCardinal) {
                String label = switch(deg){case 0->"N";case 90->"E";case 180->"S";default->"W";};
                int lw = mc.textRenderer.getWidth(label);
                ctx.drawText(mc.textRenderer, Text.literal(
                    (deg==0||deg==180?"§c":"§b") + label),
                    tx - lw/2, y+13, rgba(col[0],col[1],col[2],220), true);
            }
        }
        ctx.disableScissor();

        // Центральная стрелка
        ctx.fill(x+w/2-1, y+2, x+w/2+2, y+h-2, rgba(255,255,255,200));
        ctx.fill(x+w/2-3, y+2, x+w/2+4, y+3,    rgba(255,255,255,255));

        // Курс в градусах
        String deg = (int)yaw + "° " + dir;
        int dw = mc.textRenderer.getWidth(deg);
        ctx.drawText(mc.textRenderer, Text.literal("§f"+deg), x+w/2-dw/2, y+h-10, rgba(220,200,255,255), true);

        // Координаты
        if (showCoords.isEnabled()) {
            int px=(int)mc.player.getX(), py=(int)mc.player.getY(), pz=(int)mc.player.getZ();
            ctx.fill(x, y+h, x+w, y+h+12, rgba(3,2,10,200));
            String coords = "§8X:§7"+px+" §8Y:§7"+py+" §8Z:§7"+pz;
            ctx.drawText(mc.textRenderer, Text.literal(coords), x+4, y+h+2, rgba(200,180,240,200), false);
        }
        // Biome — real name from registry
        if (showBiome.isEnabled() && mc.world!=null && mc.player!=null) {
            String biome="";
            try{
                biome=mc.world.getBiome(mc.player.getBlockPos())
                    .getKey().map(k->k.getValue().getPath().replace("_"," ")).orElse("unknown");
                biome=Character.toUpperCase(biome.charAt(0))+biome.substring(1);
            }catch(Exception ignored){}
            int bOff=showCoords.isEnabled()?12:0;
            ctx.fill(x,y+h+bOff,x+w,y+h+bOff+12,rgba(3,2,10,185));
            ctx.drawText(mc.textRenderer,net.minecraft.text.Text.literal("§8Biome: §7"+biome),x+4,y+h+bOff+2,rgba(180,160,220,200),false);
        }
    }

    private void renderMinimal(DrawContext ctx, MinecraftClient mc, int x, int y, String dir, float yaw) {
        long t = System.currentTimeMillis();
        float pulse = 0.8f + 0.2f*(float)Math.abs(Math.sin(t/1000.0));
        int[] col = getDirColor(dir);

        ctx.fill(x, y, x+38, y+18, rgba(5,3,15,200));
        ctx.fill(x, y, x+38, y+1,  rgba(col[0],col[1],col[2],200));

        ctx.getMatrices().push();
        ctx.getMatrices().scale(1.5f,1.5f,1f);
        ctx.drawText(mc.textRenderer, Text.literal("§f"+dir),
            (int)((x+4)/1.5f), (int)((y+3)/1.5f), rgba(col[0],col[1],col[2],(int)(255*pulse)), true);
        ctx.getMatrices().pop();

        String d = (int)yaw+"°";
        ctx.drawText(mc.textRenderer, Text.literal("§8"+d), x+24, y+5, rgba(150,130,200,200), false);
    }

    private void renderCoords(DrawContext ctx, MinecraftClient mc, int x, int y, int w, float yaw, String dir) {
        if (mc.player == null) return;
        ctx.fill(x, y, x+w, y+28, rgba(5,3,15,215));
        ctx.fill(x, y, x+w, y+1,  rgba(130,50,220,200));
        int[] col = getDirColor(dir);
        ctx.drawText(mc.textRenderer, Text.literal("§f"+dir+" §8"+(int)yaw+"°"),x+4,y+4, rgba(col[0],col[1],col[2],255),true);
        int px=(int)mc.player.getX(),py=(int)mc.player.getY(),pz=(int)mc.player.getZ();
        ctx.drawText(mc.textRenderer, Text.literal("§8"+px+", "+py+", "+pz), x+4,y+15, rgba(190,170,230,200),false);
    }

    private String getDirectionLabel(float yaw) {
        int d = (int)((yaw + 22.5f) / 45f) % 8;
        return new String[]{"S","SW","W","NW","N","NE","E","SE"}[d];
    }

    private int[] getDirColor(String dir) {
        if (dir.contains("N")) return new int[]{100,180,255};
        if (dir.contains("S")) return new int[]{255,100,100};
        if (dir.contains("E")) return new int[]{100,255,150};
        return new int[]{255,200,100};
    }

    private static int rgba(int r,int g,int b,int a){return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
}
