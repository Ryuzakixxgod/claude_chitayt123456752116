package ru.ryuzaki.module.modules.player;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;

/**
 * Sprint — постоянный спринт без необходимости зажимать W дважды.
 *
 * Modes:
 *   Always    — спринтует всегда когда есть движение
 *   Omni      — спринтует в любую сторону (вперёд, назад, вбок)
 */
public class SprintModule extends Module {

    public final ModeSetting    режим   = new ModeSetting("Режим", "Всегда", "Всегда", "Омни");
    public final BooleanSetting стопВБою = new BooleanSetting("Стоп в Бою", false);

    public SprintModule() {
        super("Sprint", "Постоянный спринт", Category.PLAYER);
        addSettings(режим, стопВБою);
    }

    @Override
    public void onTick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;
        if (mc.player.isSneaking()) return;
        if (mc.player.getHungerManager().getFoodLevel() <= 6) return;

        boolean moving = mc.options.forwardKey.isPressed()
            || (режим.is("Омни") && (
                mc.options.backKey.isPressed() ||
                mc.options.leftKey.isPressed()  ||
                mc.options.rightKey.isPressed()
            ));

        if (moving) mc.player.setSprinting(true);
    }
}
