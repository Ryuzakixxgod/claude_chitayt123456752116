package ru.ryuzaki.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.Random;

/**
 * Velocity — уменьшает отдачу (knockback) при получении урона.
 *
 * ОБХОДЫ АНТИЧИТА:
 *  - Randomized delay: рандомные тики перед применением
 *  - Tick-based pattern: работает через N тиков, пауза
 *  - Ground check: не применяется на земле (реальный кнбк другой)
 *  - Damage threshold: не применяется при низком уроне (глайды и т.д.)
 *  - Momentum conservation: частично сохраняет импульс для реалистичности
 */
public class VelocityModule extends Module {

    public static VelocityModule INSTANCE;

    private final Random random = new Random();
    private long lastVelocityTime = 0;
    private int tickCounter = 0;
    private int activeTicks = 0;
    private boolean wasActive = false;

    // ── Основные настройки ─────────────────────────────────────────
    public final NumberSetting горизонтальная = new NumberSetting("Горизонтальная %", 0.0, 0.0, 100.0, 5.0);
    public final NumberSetting вертикальная   = new NumberSetting("Вертикальная %",  50.0, 0.0, 100.0, 5.0);

    // ── Обходы античита ────────────────────────────────────────────
    public final BooleanSetting рандомизировать = new BooleanSetting("Рандомизация", true);
    public final BooleanSetting проверкаЗемли = new BooleanSetting("Проверка Земли", true);
    public final NumberSetting минУрон = new NumberSetting("Мин Урон", 0.0, 0.0, 10.0, 0.5);
    public final BooleanSetting проверкаКрита = new BooleanSetting("Проверка Крита", true);
    public final NumberSetting паттернСоотношение = new NumberSetting("Паттерн", 8.0, 2.0, 20.0, 1.0);
    public final BooleanSetting сохранитьИмпульс = new BooleanSetting("Сохранить Импульс", false);

    // ── Внутреннее состояние для обходов ───────────────────────────
    private float pendingH = 0f;
    private float pendingV = 0f;
    private int pendingDelay = 0;

    public VelocityModule() {
        super("Velocity", "Уменьшает отдачу от ударов", Category.COMBAT);
        INSTANCE = this;
        addSettings(горизонтальная, вертикальная, рандомизировать, проверкаЗемли, минУрон,
                    проверкаКрита, паттернСоотношение, сохранитьИмпульс);
    }

    /**
     * Called from mixin to modify velocity components.
     * @param entity the entity being damaged (null-safe)
     * @param value original knockback value
     * @param isHorizontal true for X/Z, false for Y
     * @param damage damage received (can be used for threshold)
     * @return modified velocity
     */
    public double modify(LivingEntity entity, double value, boolean isHorizontal, float damage) {
        KnockbackMultipliers multipliers = getKnockbackMultipliers(entity, damage);
        return value * (isHorizontal ? multipliers.horizontal() : multipliers.vertical());
    }

    public KnockbackMultipliers getKnockbackMultipliers(LivingEntity entity, float damage) {
        if (!isEnabled()) return KnockbackMultipliers.VANILLA;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return KnockbackMultipliers.VANILLA;

        // ── Damage threshold: игнорируем если урон слишком мал (глайд, падение) ──
        if (минУрон.getValue() > 0 && damage < минУрон.getValue()) {
            return KnockbackMultipliers.VANILLA;
        }

        // ── Ground check: на земле отдача обычно меньше ─────────────────────────
        if (проверкаЗемли.isEnabled() && mc.player.isOnGround()) {
            // На земле применяем меньше (реалистичнее)
            return new KnockbackMultipliers(0.85, 0.9);
        }

        // ── Tick pattern: работает N тиков, потом пауза ──────────────────────────
        tickCounter++;
        double pattern = паттернСоотношение.getValue();
        if (tickCounter > pattern) {
            tickCounter = 0;
            wasActive = !wasActive;
        }
        if (!wasActive) return KnockbackMultipliers.VANILLA; // Пауза — отдача нормальная

        // ── Randomized delay: применяем не сразу ────────────────────────────────
        long now = System.currentTimeMillis();
        if (рандомизировать.isEnabled() && pendingDelay > 0) {
            if (now - lastVelocityTime < pendingDelay) {
                // Ещё не время — сохраняем часть импульса
                if (сохранитьИмпульс.isEnabled()) {
                    return new KnockbackMultipliers(0.5, 0.5); // 50% импульса
                }
                return KnockbackMultipliers.VANILLA;
            }
            pendingDelay = 0;
        }

        // ── Calculate final multiplier ─────────────────────────────────────────────
        double hMult = горизонтальная.getValue() / 100.0;
        double vMult = вертикальная.getValue() / 100.0;

        // ── Crit check: критические удары сложнее отменять ──────────────────────
        if (проверкаКрита.isEnabled() && !mc.player.isOnGround()) {
            // Критики — применяем меньше (сервер ожидает полную отдачу)
            hMult = Math.min(hMult, 0.3); // макс 30% для критов
        }

        // ── Randomize multiplier для обхода паттерн-детекта ────────────────────
        if (рандомизировать.isEnabled()) {
            // ±15% рандома
            double variance = 1.0 + (random.nextDouble() - 0.5) * 0.3;
            hMult *= variance;
            vMult *= variance;

            // Редко полностью отменяем (1 шанс из 20) — скрывает от "perfect velo" детекта
            if (random.nextInt(20) == 0) {
                hMult = 0;
                vMult = 0;
            }
        }

        lastVelocityTime = now;

        return new KnockbackMultipliers(Math.min(hMult, 1.0), Math.min(vMult, 1.0));
    }

    // Legacy method для обратной совместимости
    public double modifyH(double value) { return modify(null, value, true, 0); }
    public double modifyV(double value) { return modify(null, value, false, 0); }

    public record KnockbackMultipliers(double horizontal, double vertical) {
        private static final KnockbackMultipliers VANILLA = new KnockbackMultipliers(1.0, 1.0);

        public boolean isVanilla() {
            return horizontal == 1.0 && vertical == 1.0;
        }
    }

    @Override
    public void onDisable() {
        tickCounter = 0;
        wasActive = false;
        pendingDelay = 0;
    }
}
