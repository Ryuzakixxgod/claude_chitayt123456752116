package ru.ryuzaki.module.modules.world;

import net.minecraft.client.MinecraftClient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * DynamicLights — добавляет Night Vision если в руке факел/светящийся предмет.
 * Правила сервера: не нарушает — только визуальное освещение.
 */
public class DynamicLightsModule extends Module {
    private static final int[] LIGHT_ITEMS = {}; // список по itemId

    private final BooleanSetting torchLight  = new BooleanSetting("Torch Light", true);
    private final BooleanSetting glowLight   = new BooleanSetting("Glow Items",  true);
    private final NumberSetting  brightness  = new NumberSetting("Brightness", 5, 1, 15, 1);

    private int tickCounter = 0;

    public DynamicLightsModule() {
        super("Dynamic Lights", "Light from held items", Category.WORLD);
        addSettings(torchLight, glowLight, brightness);
    }

    public void onTick() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        tickCounter++;
        if (tickCounter % 5 != 0) return; // каждые 5 тиков

        ItemStack main = mc.player.getMainHandStack();
        ItemStack off  = mc.player.getOffHandStack();

        boolean hasLight = isLightSource(main) || isLightSource(off);

        if (hasLight) {
            // Применяем Night Vision эффект на короткое время
            mc.player.addStatusEffect(new net.minecraft.entity.effect.StatusEffectInstance(
                    net.minecraft.entity.effect.StatusEffects.NIGHT_VISION,
                    10, 0, false, false, false
            ));
        }
    }

    private boolean isLightSource(ItemStack stack) {
        if (stack.isEmpty()) return false;
        if (!torchLight.isEnabled() && !glowLight.isEnabled()) return false;
        var item = stack.getItem();
        if (torchLight.isEnabled() &&
                (item == Items.TORCH || item == Items.SOUL_TORCH ||
                        item == Items.LANTERN || item == Items.SOUL_LANTERN ||
                        item == Items.GLOWSTONE || item == Items.SEA_LANTERN)) return true;
        if (glowLight.isEnabled() &&
                (item == Items.GLOW_INK_SAC || item == Items.GLOWSTONE_DUST ||
                        item == Items.BLAZE_ROD || item == Items.MAGMA_CREAM)) return true;
        return false;
    }
}