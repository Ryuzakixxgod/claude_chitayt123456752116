// ════════════════════════════════════════════════════════════════════════
//  VISUAL MODULES — все рабочие реализации
//  Каждый класс — отдельный файл в modules/visual/
// ════════════════════════════════════════════════════════════════════════

// ── BloomModule.java ─────────────────────────────────────────────────────
package ru.ryuzaki.module.modules.visual;
// (файл BloomModule.java)
/*
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

public class BloomModule extends Module {
    public final NumberSetting intensity = new NumberSetting("Intensity", 1.0, 0.1, 3.0, 0.1);
    public final NumberSetting radius    = new NumberSetting("Radius",    8.0, 2.0, 20.0, 1.0);
    public final BooleanSetting pulse    = new BooleanSetting("Pulse", true);
    public final ColorSetting color      = new ColorSetting("Color", new ColorRGBA(140,80,255,160));

    public BloomModule(){super("Bloom","Свечение по краям экрана",Category.VISUAL);addSettings(intensity,radius,pulse,color);}

    public void render(DrawContext ctx, int sw, int sh) {
        if(!isEnabled()) return;
        ColorRGBA c=color.getColor(); if(c==null) return;
        int cr=c.getRed(),cg=c.getGreen(),cb=c.getBlue();
        int rad=(int)(radius.getValue()*4);
        double intens=intensity.getValue();
        long now=System.currentTimeMillis();
        float pulseMult=pulse.isEnabled()?0.65f+0.35f*(float)Math.sin(now*.002f):1f;

        for(int i=rad;i>=1;i-=Math.max(1,rad/20)){
            float f=(float)i/rad; f=f*f*f;
            int a=(int)(intens*55*pulseMult*(1f-f)); if(a<=0) continue;
            int col=rgba(cr,cg,cb,a);
            ctx.fill(0,0,sw,i,col); ctx.fill(0,sh-i,sw,sh,col);
            ctx.fill(0,i,i,sh-i,col); ctx.fill(sw-i,i,sw,sh-i,col);
        }
        // Угловые вспышки
        for(int i=rad*2;i>=1;i-=Math.max(1,rad/8)){
            float f=(float)i/(rad*2); int a=(int)(intens*38*pulseMult*(1f-f*f)); if(a<=0) continue;
            int col=rgba(cr,cg,cb,a);
            ctx.fill(0,0,i,i,col); ctx.fill(sw-i,0,sw,i,col);
            ctx.fill(0,sh-i,i,sh,col); ctx.fill(sw-i,sh-i,sw,sh,col);
        }
    }
    private static int rgba(int r,int g,int b,int a){return((Math.min(255,a)&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
}
*/
