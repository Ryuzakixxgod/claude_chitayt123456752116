package ru.ryuzaki.module.modules.particles;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.gui.style.ThemeManager;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * WorldParticleModule — золотые квадраты в воздухе (1:1 со скриншотом 3).
 * Квадратные частицы с акцентным цветом темы, летят вверх плавно.
 */
public class WorldParticleModule extends Module {

    public final ModeSetting type = new ModeSetting("Type",
        "Square", "Square", "Star", "Diamond", "Trail");
    public final NumberSetting count   = new NumberSetting("Count",  60, 10, 200, 5);
    public final NumberSetting area    = new NumberSetting("Area",   12, 4,  30,  1);
    public final NumberSetting speed   = new NumberSetting("Speed",  0.6, 0.1, 3.0, 0.1);
    public final NumberSetting size    = new NumberSetting("Size",   0.06, 0.01, 0.2, 0.01);

    private final List<Particle> particles = new ArrayList<>();
    private final Random rng = new Random();
    private boolean init = false;

    public WorldParticleModule() {
        super("WorldParticle", "Золотые квадраты в воздухе как на скриншоте", Category.PARTICLES);
        addSettings(type, count, area, speed, size);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }

    @Override
    public void onEnable()  { particles.clear(); init = false; }
    @Override
    public void onDisable() { particles.clear(); }

    @Override
    public void onUpdate() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        int target = count.getValue().intValue();
        Vec3d pos = mc.player.getPos();
        float areaR = area.getValue().floatValue();

        // Spawn to target count
        while (particles.size() < target) {
            particles.add(spawnParticle(pos, areaR));
        }
        // Remove excess
        while (particles.size() > target) {
            particles.remove(particles.size() - 1);
        }

        // Update
        float spd = speed.getValue().floatValue() * 0.004f;
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.y += spd * p.speedMul;
            p.x += p.vx;
            p.z += p.vz;
            p.rot += p.rotSpeed;
            p.life += 0.003f;

            // Respawn when too high or too old
            if (p.life > 1f || p.y - pos.y > areaR * 1.5f) {
                particles.set(i, spawnParticle(pos, areaR));
            }
        }
    }

    private Particle spawnParticle(Vec3d center, float areaR) {
        Particle p = new Particle();
        p.x = center.x + (rng.nextFloat() - 0.5f) * areaR * 2;
        p.y = center.y + (rng.nextFloat() - 0.5f) * areaR;
        p.z = center.z + (rng.nextFloat() - 0.5f) * areaR * 2;
        p.vx = (rng.nextFloat() - 0.5f) * 0.001f;
        p.vz = (rng.nextFloat() - 0.5f) * 0.001f;
        p.speedMul = 0.5f + rng.nextFloat() * 1.5f;
        p.rot = rng.nextFloat() * 360f;
        p.rotSpeed = (rng.nextFloat() - 0.5f) * 2f;
        p.life = rng.nextFloat() * 0.5f; // stagger
        p.scale = 0.5f + rng.nextFloat() * 1.5f;
        return p;
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled() || particles.isEmpty()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.gameRenderer == null) return;

        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        Camera cam = mc.gameRenderer.getCamera();
        Vec3d camPos = cam.getPos();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Color accent = ThemeManager.get().getAccent();
        float baseSize = size.getValue().floatValue();
        String shape = type.getCurrent();

        for (Particle p : particles) {
            float fade = p.life < 0.15f ? p.life / 0.15f : p.life > 0.75f ? (1 - p.life) / 0.25f : 1f;
            int alpha = (int)(fade * 200);
            if (alpha <= 0) continue;

            float s = baseSize * p.scale;

            ms.push();
            ms.translate(p.x - camPos.x, p.y - camPos.y, p.z - camPos.z);

            // Billboard
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-cam.getYaw()));
            ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(cam.getPitch()));
            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(p.rot));

            Matrix4f mat = ms.peek().getPositionMatrix();

            // Glow
            drawGlow(mat, s * 2.5f, accent, alpha / 3);

            // Main shape
            if (shape.equals("Square")) {
                drawSquare(mat, s, accent, alpha);
            } else if (shape.equals("Diamond")) {
                drawDiamond(mat, s, accent, alpha);
            } else {
                drawSquare(mat, s, accent, alpha);
            }

            ms.pop();
        }

        RenderSystem.enableCull();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableBlend();
        RenderSystem.setShaderColor(1, 1, 1, 1);
    }

    private void drawSquare(Matrix4f mat, float s, Color col, int alpha) {
        int r = col.getRed(), g = col.getGreen(), b = col.getBlue();
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(mat, -s,  s, 0).color(r, g, b, alpha);
        buf.vertex(mat,  s,  s, 0).color(r, g, b, alpha);
        buf.vertex(mat,  s, -s, 0).color(r, g, b, alpha);
        buf.vertex(mat, -s, -s, 0).color(r, g, b, alpha);
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception ignored) {}
    }

    private void drawDiamond(Matrix4f mat, float s, Color col, int alpha) {
        int r = col.getRed(), g = col.getGreen(), b = col.getBlue();
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(mat, 0,  s, 0).color(r, g, b, alpha);
        buf.vertex(mat, s,  0, 0).color(r, g, b, alpha);
        buf.vertex(mat, 0, -s, 0).color(r, g, b, alpha);
        buf.vertex(mat,-s,  0, 0).color(r, g, b, alpha);
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception ignored) {}
    }

    private void drawGlow(Matrix4f mat, float s, Color col, int alpha) {
        int r = col.getRed(), g = col.getGreen(), b = col.getBlue();
        BufferBuilder buf = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(mat, -s,  s, 0).color(r, g, b, alpha);
        buf.vertex(mat,  s,  s, 0).color(r, g, b, alpha);
        buf.vertex(mat,  s, -s, 0).color(r, g, b, alpha);
        buf.vertex(mat, -s, -s, 0).color(r, g, b, alpha);
        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception ignored) {}
    }

    private static class Particle {
        double x, y, z;
        float vx, vz, speedMul;
        float rot, rotSpeed, life, scale;
    }
}
