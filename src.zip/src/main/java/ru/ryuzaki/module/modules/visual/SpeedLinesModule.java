package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/SpeedLinesModule.java
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.Vec3d;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class SpeedLinesModule extends Module {
    public final ModeSetting   style     = new ModeSetting("Style","Cosmic","Cosmic","Anime","Neon","Elytra","Void","Warp","Fire");
    public final NumberSetting threshold = new NumberSetting("Threshold", 0.18, 0.02, 1.0, 0.02);
    public final NumberSetting density   = new NumberSetting("Density",   35, 5, 100, 5);
    public final NumberSetting thickness = new NumberSetting("Thickness",  1.5, 0.5, 4.0, 0.5);
    public final BooleanSetting always   = new BooleanSetting("Always",   false);
    public final BooleanSetting flash    = new BooleanSetting("Speed Flash",true);
    public final BooleanSetting warp     = new BooleanSetting("Warp Tunnel",false);

    private static class SpeedLine {
        float dx,dy, dist, len, life, hue;
        int r,g,b;
        SpeedLine(float dx,float dy,float dist,float len,float hue){this.dx=dx;this.dy=dy;this.dist=dist;this.len=len;this.life=1f;this.hue=hue;}
    }
    private final List<SpeedLine> lines = new ArrayList<>();
    private final Random rng = new Random();
    private float globalHue = 0f;
    private float screenFlash = 0f;
    private int cooldown = 0;

    public SpeedLinesModule() {
        super("Speed Lines", "Аниме-стиль линии скорости", Category.VISUAL);
        addSettings(style, threshold, density, thickness, always, flash, warp);
    }

    @Override public void onDisable() { lines.clear(); screenFlash=0f; }

    public void renderHud(DrawContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int sw=mc.getWindow().getScaledWidth(), sh=mc.getWindow().getScaledHeight();
        int cx=sw/2, cy=sh/2;

        Vec3d vel = mc.player.getVelocity();
        double horizSpd = Math.sqrt(vel.x*vel.x+vel.z*vel.z);
        double totalSpd = vel.length();
        boolean elytra  = mc.player.isGliding();
        boolean active  = always.isEnabled() || horizSpd>threshold.getValue() || (elytra&&totalSpd>0.3);

        globalHue = (globalHue + 0.002f) % 1f;

        // ── Обновляем линии ──────────────────────────────────────────────
        Iterator<SpeedLine> it = lines.iterator();
        while (it.hasNext()) {
            SpeedLine l = it.next();
            l.life -= 0.05f + (float)horizSpd*0.08f;
            if (l.life <= 0) { it.remove(); continue; }
            float t  = 1f - l.life;
            int   th = Math.max(1,(int)thickness.getValue().intValue());
            float len= l.len * Math.min(1f, t*3);
            int   lx1= (int)(cx + l.dx*l.dist*t);
            int   ly1= (int)(cy + l.dy*l.dist*t);
            int   lx2= (int)(cx + l.dx*l.dist*(t+len));
            int   ly2= (int)(cy + l.dy*l.dist*(t+len));
            int[] col= getColor(l, horizSpd, totalSpd, elytra);
            int   a  = (int)(200*l.life);
            // Glow (2 слоя)
            drawLine(ctx,lx1,ly1,lx2,ly2,rgba(col[0],col[1],col[2],a/4),th+2);
            drawLine(ctx,lx1,ly1,lx2,ly2,rgba(col[0],col[1],col[2],a/8),th+4);
            // Основная
            drawLine(ctx,lx1,ly1,lx2,ly2,rgba(col[0],col[1],col[2],a),th);
        }

        // ── Спауним новые ───────────────────────────────────────────────
        if (active && ++cooldown % 2 == 0) {
            int max = density.getValue().intValue();
            int toAdd = Math.min(4, max - lines.size());
            for (int i=0;i<toAdd;i++) {
                float ang  = rng.nextFloat()*(float)(Math.PI*2);
                float dist = 150+rng.nextFloat()*Math.max(sw,sh)*0.7f;
                lines.add(new SpeedLine((float)Math.cos(ang),(float)Math.sin(ang),dist,0.12f+rng.nextFloat()*0.25f,rng.nextFloat()));
            }
        }

        // ── Warp Tunnel ─────────────────────────────────────────────────
        if (warp.isEnabled() && (active || always.isEnabled())) {
            float warpSpeed = (float)Math.min(1.0, horizSpd/0.5);
            int RINGS = 5;
            for (int ring=0;ring<RINGS;ring++) {
                float progress = ((globalHue*3+ring/(float)RINGS) % 1f);
                float rr = sw*0.08f + sw*0.4f*progress;
                float alpha = warpSpeed*(0.5f-progress*0.4f);
                if (alpha<=0) continue;
                int[] wc = hsv((globalHue+ring*0.12f)%1f, 0.8f, 1f);
                int wa = (int)(alpha*180);
                for (int s=0;s<32;s++) {
                    double a=(2*Math.PI*s)/32;
                    int px=(int)(cx+rr*Math.cos(a)), py=(int)(cy+rr*0.55f*Math.sin(a));
                    ctx.fill(px,py,px+2,py+2,rgba(wc[0],wc[1],wc[2],wa));
                }
            }
        }

        // ── Speed Flash ──────────────────────────────────────────────────
        if (flash.isEnabled()) {
            float targetFlash = (float)Math.min(0.35, (horizSpd-threshold.getValue())*2);
            if (targetFlash < 0) targetFlash = 0;
            screenFlash = lerp(screenFlash, targetFlash, 0.15f);
            if (screenFlash > 0.01f) {
                int[] fc = hsv(globalHue, 0.6f, 1f);
                ctx.fill(0,0,sw,sh, rgba(fc[0],fc[1],fc[2],(int)(screenFlash*60)));
                // Белая вспышка по краям
                int fRad = (int)(screenFlash*50);
                for (int i=fRad;i>=1;i--) {
                    float ff=(float)i/fRad;
                    int fa=(int)(screenFlash*40*(1-ff));
                    ctx.fill(0,0,sw,i,rgba(fc[0],fc[1],fc[2],fa));
                    ctx.fill(0,sh-i,sw,sh,rgba(fc[0],fc[1],fc[2],fa));
                    ctx.fill(0,i,i,sh-i,rgba(fc[0],fc[1],fc[2],fa));
                    ctx.fill(sw-i,i,sw,sh-i,rgba(fc[0],fc[1],fc[2],fa));
                }
            }
        }
    }

    private int[] getColor(SpeedLine l, double hSpd, double tSpd, boolean elytra) {
        return switch (style.getCurrent()) {
            case "Anime" -> new int[]{240,240,255};
            case "Neon"  -> hsv(l.hue, 1f, 1f);
            case "Elytra"-> hsv(0.56f+(float)tSpd*0.05f, 0.7f, 1f);
            case "Void"  -> new int[]{(int)(60+l.hue*30),(int)(0+l.hue*10),(int)(120+l.hue*80)};
            case "Warp"  -> hsv((globalHue+l.hue*0.3f)%1f, 0.9f, 1f);
            case "Fire"  -> hsv(0.06f-l.hue*0.06f, 1f, 1f);
            default      -> hsv((globalHue+l.hue*0.2f)%1f, 0.85f, 1f);
        };
    }

    private void drawLine(DrawContext ctx, int x1, int y1, int x2, int y2, int color, int th) {
        // Fast approximation: draw fewer segments (every 4px instead of every px)
        int dx=x2-x1, dy=y2-y1;
        int steps=Math.max(1,Math.max(Math.abs(dx),Math.abs(dy))/4);
        float sx=(float)dx/steps, sy=(float)dy/steps;
        for(int i=0;i<=steps;i++) {
            int px=x1+(int)(sx*i), py=y1+(int)(sy*i);
            ctx.fill(px-th/2,py-th/2,px+th/2+1,py+th/2+1,color);
        }
    }
    private static float lerp(float a,float b,float t){return a+(b-a)*t;}
    private static int rgba(int r,int g,int b,int a){a=Math.min(255,Math.max(0,a));return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}