package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.opengl.GL11;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.FriendManager;
import ru.ryuzaki.util.RyuzakiRenderCache;
import ru.ryuzaki.util.TargetManager;

import java.awt.Color;
import java.util.*;

/**
 * TargetESP — 6 режимов ESP для ближайшей цели.
 *
 * Режимы:
 *  JELLO        — анимированный желеобразный цилиндр [3D]
 *  BRACKETS     — вращающиеся угловые скобки          [2D]
 *  BRACKETARROW — скобки + стрелки-указатели          [2D]
 *  DIAMONDRING  — вращающиеся ромбы по углам          [2D]
 *  PICKAXES     — кирки по уровню HP                  [2D]
 *  SOULSTARS    — орбы + звёзды                       [2D]
 *
 * Квадратное соотношение: eBounds использует w = h * 0.42f.
 * Невидимые сущности: скрываются, если нет видимой брони ни в одном слоте.
 * Друзья: зелёный цвет + метка ♥.
 */
public class TargetESP extends Module {

    public final ModeSetting mode = new ModeSetting(
            "Mode", "Jello",
            "Jello", "Brackets", "BracketArrow", "DiamondRing", "Pickaxes", "SoulStars");
    private final BooleanSetting onlyPlayers = new BooleanSetting("Only Players", false);
    private final NumberSetting  range       = new NumberSetting("Range", 64, 8, 128, 8);

    // ── Анимация появления ───────────────────────────────────────────
    private final Map<Entity, Float> spawnA = new WeakHashMap<>();

    // ── Кэш матриц 3D → 2D проекции ─────────────────────────────────
    private Matrix4f lastProj = new Matrix4f();
    private Matrix4f lastMV   = new Matrix4f();
    private int      lastSW   = 1, lastSH = 1;

    // ── SoulStars hue ────────────────────────────────────────────────
    private float ssHue = 0f;

    // ── Marker/pendulum state ────────────────────────────────────────
    private float markerAngle = 0f;
    private float markerSpd   = 0f;
    private boolean markerRev = false;

    public TargetESP() {
        super("TargetESP", "Стильный ESP — 6 режимов", Category.VISUAL);
        addSettings(mode, onlyPlayers, range);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  3D RENDER (вызывается из WorldRenderEvents.AFTER_ENTITIES)
    // ═══════════════════════════════════════════════════════════════════
    public void render3D(MatrixStack ms, float pt) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;

        // Захватываем 3D-матрицы здесь — они ещё корректны в этой фазе рендера
        try {
            lastProj = new Matrix4f(RenderSystem.getProjectionMatrix());
            lastMV   = new Matrix4f(RenderSystem.getModelViewMatrix());
        } catch (Exception ignored) {}

        if (!mode.getCurrent().equals("Jello")) return; // остальные режимы — 2D

        List<LivingEntity> tgts = getTargets();
        if (tgts.isEmpty()) return;

        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        jelloRender(ms, tgts, pt, RyuzakiRenderCache.now);

        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    // ═══════════════════════════════════════════════════════════════════
    //  HUD RENDER (вызывается из MixinInGameHud)
    // ═══════════════════════════════════════════════════════════════════
    public void renderHud(DrawContext ctx, int sw, int sh, float pt) {
        if (!isEnabled() || mc.world == null || mc.player == null) return;
        lastSW = sw;
        lastSH = sh;

        List<LivingEntity> tgts = getTargets();

        // Прогреваем анимацию появления для 2D-режимов
        float dt = Math.min(RyuzakiRenderCache.deltaTime, 0.05f);
        for (LivingEntity t : tgts) {
            float v = spawnA.getOrDefault(t, 0f);
            spawnA.put(t, Math.min(1f, v + dt * 2.5f));
        }

        // Лейблы (имя + HP) — для всех режимов
        renderLabels(ctx, tgts, sw, sh, pt);

        switch (mode.getCurrent()) {
            case "Brackets"     -> bracketsHud    (ctx, tgts, sw, sh, pt);
            case "BracketArrow" -> bracketArrowHud(ctx, tgts, sw, sh, pt);
            case "DiamondRing"  -> diamondRingHud (ctx, tgts, sw, sh, pt);
            case "Pickaxes"     -> pickaxesHud    (ctx, tgts, sw, sh, pt);
            case "SoulStars"    -> soulStarsHud   (ctx, tgts, sw, sh, pt);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  JELLO — анимированный желеобразный цилиндр [3D]
    // ═══════════════════════════════════════════════════════════════════
    private void jelloRender(MatrixStack ms, List<LivingEntity> tgts, float pt, long now) {
        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        for (LivingEntity t : tgts) {
            float anim = ease(t, RyuzakiRenderCache.deltaTime);
            if (anim < .01f) continue;
            int[] cl = getColor(t);

            double ix = lerp(t.lastRenderX, t.getX(), pt) - cam.x;
            double iy = lerp(t.lastRenderY, t.getY(), pt) - cam.y;
            double iz = lerp(t.lastRenderZ, t.getZ(), pt) - cam.z;

            float height = t.getHeight() + 0.1f;
            float w      = (t.getWidth() / 2f) + 0.05f;

            double dur     = 2500.0;
            double elapsed = now % dur;
            boolean side   = elapsed > dur / 2.0;
            double progress = elapsed / (dur / 2.0);
            if (side) --progress; else progress = 1 - progress;
            // ease in-out quad
            progress = progress < 0.5
                    ? 2.0 * progress * progress
                    : 1.0 - Math.pow(-2.0 * progress + 2.0, 2.0) / 2.0;
            double eased = (height / 1.5f) * (progress > 0.5 ? 1.0 - progress : progress) * (side ? -1 : 1);

            ms.push();
            ms.translate(ix, iy, iz);

            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
            RenderSystem.disableCull();
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

            final int SEGS = 64;
            Matrix4f mat  = ms.peek().getPositionMatrix();
            int coreA  = (int)(5   * anim);
            int bloomA = (int)(200 * anim);

            // Цилиндр
            BufferBuilder buf = Tessellator.getInstance()
                    .begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
            for (int ii = 0; ii <= SEGS; ii++) {
                double ang = Math.toRadians(ii * (360.0 / SEGS));
                float  xc  = (float)(Math.cos(ang) * w);
                float  zc  = (float)(Math.sin(ang) * w);
                buf.vertex(mat, xc, (float)(height * progress + eased), zc).color(cl[0], cl[1], cl[2], coreA);
                buf.vertex(mat, xc, (float)(height * progress),         zc).color(cl[0], cl[1], cl[2], bloomA);
            }
            try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception ex) {}

            // Контурное кольцо
            BufferBuilder ring = Tessellator.getInstance()
                    .begin(VertexFormat.DrawMode.LINE_STRIP, VertexFormats.POSITION_COLOR);
            for (int ii = 0; ii <= SEGS; ii++) {
                double ang = Math.toRadians(ii * (360.0 / SEGS));
                ring.vertex(mat, (float)(Math.cos(ang) * w), (float)(height * progress), (float)(Math.sin(ang) * w))
                        .color(cl[0], cl[1], cl[2], bloomA);
            }
            try { BufferRenderer.drawWithGlobalProgram(ring.end()); } catch (Exception ex) {}

            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.disableBlend();
            RenderSystem.defaultBlendFunc();
            ms.pop();
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  ОБЩИЙ HUD — имена + полоска HP над головой
    // ═══════════════════════════════════════════════════════════════════
    private void renderLabels(DrawContext ctx, List<LivingEntity> tgts, int sw, int sh, float pt) {
        for (LivingEntity t : tgts) {
            float anim = spawnA.getOrDefault(t, 0f);
            if (anim < .05f) continue;

            double ix = lerp(t.lastRenderX, t.getX(), pt);
            double iy = lerp(t.lastRenderY, t.getY(), pt);
            double iz = lerp(t.lastRenderZ, t.getZ(), pt);

            float[] scr = projectToScreen(ix, iy + t.getHeight() + 0.35, iz, sw, sh);
            if (scr == null) continue;

            int[]  c    = getColor(t);
            int    a    = (int)(210 * anim);
            boolean friend = isFriend(t);

            String name = friend ? "♥ " + t.getName().getString() : t.getName().getString();
            Color  nc   = friend ? new Color(34, 197, 94, a) : new Color(237, 232, 255, a);
            drawText(ctx, name, scr[0] - textW(name, 9f) / 2f, scr[1] - 2, nc, 9f, true);

            // HP bar
            float hp  = t.getHealth() / Math.max(1f, t.getMaxHealth());
            float bw  = textW(name, 9f) + 8;
            float bx  = scr[0] - bw / 2f;
            float by  = scr[1] + 5;
            // подложка
            ctx.fill((int)bx, (int)by, (int)(bx + bw), (int)(by + 3), ((a / 4) << 24));
            // заполнение
            int hpR = hp > 0.6f ? 0          : (int)((1 - hp * 1.67f) * 255);
            int hpG = hp < 0.4f ? 0          : (int)(Math.min(1f, (hp - 0.4f) * 1.67f) * 200 + 55);
            ctx.fill((int)bx, (int)by, (int)(bx + bw * hp), (int)(by + 3),
                    ((int)(180 * anim) << 24) | (hpR << 16) | (hpG << 8));
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  BRACKETS — вращающиеся угловые скобки [2D]
    // ═══════════════════════════════════════════════════════════════════
    private void bracketsHud(DrawContext ctx, List<LivingEntity> tgts, int sw, int sh, float pt) {
        float ang = pendulum(RyuzakiRenderCache.now);
        float cos = (float)Math.cos(Math.toRadians(ang));
        float sin = (float)Math.sin(Math.toRadians(ang));
        float[] p = new float[2], q = new float[2];
        float[][] dirs = {{-1,-1, 1, 1},{1,-1,-1, 1},{1, 1,-1,-1},{-1, 1, 1,-1}};

        for (LivingEntity t : tgts) {
            float anim = spawnA.getOrDefault(t, 0f);
            if (anim < .05f) continue;
            float[][] b = eBounds(t, pt, sw, sh);
            if (b == null) continue;

            float cx  = b[0][0], cy = b[0][1];
            float h   = Math.abs(b[2][1] - b[1][1]) / 2f;
            float w   = h * 0.42f;  // квадрат: 0.42 вместо 0.55
            float L   = h * 0.30f;
            int[] c   = getColor(t);
            int   col = ((int)(210 * anim) << 24) | (c[0] << 16) | (c[1] << 8) | c[2];

            for (float[] di : dirs) {
                float px = di[0] * w, py = di[1] * h;
                rotatePt(px, py, cos, sin, cx, cy, p);
                rotatePt(px + di[2] * L, py, cos, sin, cx, cy, q);
                line2D(ctx, p[0], p[1], q[0], q[1], col, 3);
                rotatePt(px, py + di[3] * L, cos, sin, cx, cy, q);
                line2D(ctx, p[0], p[1], q[0], q[1], col, 3);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  BRACKET + ARROWS — скобки + угловые стрелки [2D]
    // ═══════════════════════════════════════════════════════════════════
    private void bracketArrowHud(DrawContext ctx, List<LivingEntity> tgts, int sw, int sh, float pt) {
        // Рисуем базовые скобки
        bracketsHud(ctx, tgts, sw, sh, pt);

        float ang = pendulum(RyuzakiRenderCache.now);
        float cos = (float)Math.cos(Math.toRadians(ang));
        float sin = (float)Math.sin(Math.toRadians(ang));
        float[] p = new float[2], q = new float[2], r2 = new float[2];

        for (LivingEntity t : tgts) {
            float anim = spawnA.getOrDefault(t, 0f);
            if (anim < .05f) continue;
            float[][] b = eBounds(t, pt, sw, sh);
            if (b == null) continue;

            float cx = b[0][0], cy = b[0][1];
            float h  = Math.abs(b[2][1] - b[1][1]) / 2f;
            float w  = h * 0.42f;
            float cs = h * 0.18f, gap = h * 0.15f;
            int[] c  = getColor(t);
            int col  = ((int)(210 * anim) << 24) | (c[0] << 16) | (c[1] << 8) | c[2];

            // 4 стрелки по сторонам (верх, право, низ, лево)
            float[][] chevrons = {
                    { 0,  -(h + gap),  -cs,  cs,   0, -cs,   cs,  cs},
                    { w + gap,   0,    -cs, -cs,   cs,   0,  -cs,  cs},
                    { 0,   h + gap,   -cs, -cs,    0,  cs,   cs, -cs},
                    {-(w + gap), 0,    cs,  -cs,  -cs,   0,   cs,  cs}
            };
            for (float[] ch : chevrons) {
                float cpx = ch[0], cpy = ch[1];
                rotatePt(cpx + ch[2], cpy + ch[3], cos, sin, cx, cy, p);
                rotatePt(cpx + ch[4], cpy + ch[5], cos, sin, cx, cy, q);
                rotatePt(cpx + ch[6], cpy + ch[7], cos, sin, cx, cy, r2);
                line2D(ctx, p[0], p[1], q[0],  q[1],  col, 3);
                line2D(ctx, q[0], q[1], r2[0], r2[1], col, 3);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  DIAMOND RING — вращающиеся ромбы [2D]
    // ═══════════════════════════════════════════════════════════════════
    private void diamondRingHud(DrawContext ctx, List<LivingEntity> tgts, int sw, int sh, float pt) {
        float ang = pendulum(RyuzakiRenderCache.now);
        float cos = (float)Math.cos(Math.toRadians(ang));
        float sin = (float)Math.sin(Math.toRadians(ang));

        for (LivingEntity t : tgts) {
            float anim = spawnA.getOrDefault(t, 0f);
            if (anim < .05f) continue;
            float[][] b = eBounds(t, pt, sw, sh);
            if (b == null) continue;

            float cx  = b[0][0], cy = b[0][1];
            float h   = Math.abs(b[2][1] - b[1][1]) / 2f;
            float w   = h * 0.42f;
            float bsz = h * 0.14f;
            int[] c   = getColor(t);
            int   col = ((int)(210 * anim) << 24) | (c[0] << 16) | (c[1] << 8) | c[2];

            // Ромбы в 4 углах
            for (float[] cn : new float[][]{{-w, -h},{w, -h},{w, h},{-w, h}}) {
                hollowSquare(ctx, cn[0], cn[1], bsz, cos, sin, cx, cy, col, 3);
            }
            // Центральный ромб
            hollowDiamond(ctx, 0, 0, bsz * 1.4f, cos, sin, cx, cy, col, 3);
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  PICKAXES — кирки по уровню HP [2D]
    // ═══════════════════════════════════════════════════════════════════
    private void pickaxesHud(DrawContext ctx, List<LivingEntity> tgts, int sw, int sh, float pt) {
        float bob = (float)Math.sin(RyuzakiRenderCache.now * 0.003f) * 5f;

        for (LivingEntity t : tgts) {
            float anim = spawnA.getOrDefault(t, 0f);
            if (anim < .05f) continue;
            float[][] b = eBounds(t, pt, sw, sh);
            if (b == null) continue;

            float cx   = b[0][0], cy = b[0][1];
            float h    = Math.abs(b[2][1] - b[1][1]);
            float sz   = Math.min(48f, Math.max(16f, h * 0.55f)) * anim;
            float sc   = sz / 16f;
            float offX = h * 0.45f;

            float hpPct = t.getMaxHealth() > 0 ? t.getHealth() / t.getMaxHealth() : 1f;
            var   pick  = new ItemStack(pickaxeForHp(hpPct));

            for (int side = 0; side < 2; side++) {
                float sx = cx + (side == 0 ? -offX : offX) - sz / 2f;
                float sy = cy - sz / 2f + bob;

                ctx.getMatrices().push();
                ctx.getMatrices().translate(sx + sz / 2f, sy + sz / 2f, 0);
                ctx.getMatrices().scale(side == 0 ? -sc : sc, sc, 1f);
                ctx.drawItem(pick, -8, -8);
                ctx.getMatrices().pop();
            }
        }
    }

    private static net.minecraft.item.Item pickaxeForHp(float pct) {
        if (pct > 0.80f) return Items.NETHERITE_PICKAXE;
        if (pct > 0.60f) return Items.DIAMOND_PICKAXE;
        if (pct > 0.40f) return Items.IRON_PICKAXE;
        if (pct > 0.20f) return Items.STONE_PICKAXE;
        return Items.WOODEN_PICKAXE;
    }

    // ═══════════════════════════════════════════════════════════════════
    //  SOUL STARS — орбы-змейки + дрейфующие звёзды [2D]
    // ═══════════════════════════════════════════════════════════════════
    private void soulStarsHud(DrawContext ctx, List<LivingEntity> tgts, int sw, int sh, float pt) {
        long now = RyuzakiRenderCache.now;
        ssHue = (ssHue + 0.001f) % 1f;

        for (LivingEntity t : tgts) {
            float anim = spawnA.getOrDefault(t, 0f);
            if (anim < .05f) continue;
            float[][] b = eBounds(t, pt, sw, sh);
            if (b == null) continue;

            float cx = b[0][0], cy = b[0][1];
            float h  = Math.abs(b[2][1] - b[1][1]) / 2f;
            float wr = h * 0.25f;  // горизонтальный радиус орбиты
            int   a  = (int)(220 * anim);

            // ── 2 орба с хвостами ────────────────────────────────────
            final int TAIL = 28;
            for (int i = 0; i < 2; i++) {
                float baseAng = (float)(now * 0.0012 + i * Math.PI);
                // Хвост
                for (int j = 1; j <= TAIL; j++) {
                    float tang = (float)(now * 0.0012 - j * 0.13f + i * Math.PI);
                    float tx   = (float)Math.cos(tang) * wr + cx;
                    float ty   = (float)Math.sin(tang) * h  + cy;
                    float tp   = 1f - j / (float)TAIL;
                    int   ta   = (int)(140 * tp * anim);

                    // Шёрстка
                    for (int f = 0; f < 8; f++) {
                        float fa = (float)(f * Math.PI * 0.25 + tang * 1.5);
                        float fl = 9 * tp;
                        ctx.fill((int)(tx + Math.cos(fa) * fl),     (int)(ty + Math.sin(fa) * fl),
                                (int)(tx + Math.cos(fa) * fl) + 1, (int)(ty + Math.sin(fa) * fl) + 1,
                                ((ta / 4) << 24) | 0x0000C8);
                    }
                    ctx.fill((int)tx - 1, (int)ty - 1, (int)tx + 2, (int)ty + 2, (ta << 24) | 0x000ADC);
                }
                // Голова орба
                float headX = (float)Math.cos(baseAng) * wr + cx;
                float headY = (float)Math.sin(baseAng) * h  + cy;
                fillCircle(ctx, (int)headX, (int)headY, 10, (a << 24) | 0x0014B4);
                fillCircle(ctx, (int)headX, (int)headY,  6, (a << 24) | 0x3250FF);
                fillCircle(ctx, (int)headX, (int)headY,  3, 0xFFFFFFFF);
            }

            // ── 4 дрейфующие звезды ──────────────────────────────────
            for (int i = 0; i < 4; i++) {
                float sang = (float)(now * 3e-4 + i * Math.PI / 2);
                float sr   = h * 1.65f + (float)Math.sin(now * 7e-4 + i * 1.3f) * h * 0.1f;
                float sx   = (float)Math.cos(sang) * sr + cx;
                float sy   = (float)Math.sin(sang) * sr * 0.4f + cy;
                star5(ctx, (int)sx, (int)sy, 7 + (i % 2) * 4, ((int)(190 * anim) << 24) | 0x0000C8);
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  УТИЛИТЫ — цели, проекция, анимация
    // ═══════════════════════════════════════════════════════════════════

    /** Список целей — только ближайший по кросхейру (или ближайший ≤ 4 блоков) */
    private List<LivingEntity> getTargets() {
        if (mc.world == null || mc.player == null) return Collections.emptyList();
        LivingEntity best = getCrosshairTarget();
        return best != null ? List.of(best) : Collections.emptyList();
    }

    private LivingEntity getCrosshairTarget() {
        if (mc.world == null || mc.player == null) return null;
        Vec3d eye   = mc.player.getEyePos();
        Vec3d look  = mc.player.getRotationVec(1f);
        double maxR = range.getValue();
        Vec3d end   = eye.add(look.multiply(maxR));

        LivingEntity bestRay   = null; double bestRayD   = Double.MAX_VALUE;
        LivingEntity bestClose = null; double bestCloseD = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || e == mc.player) continue;
            if (onlyPlayers.isEnabled() && !(e instanceof PlayerEntity)) continue;
            if (!le.isAlive()) continue;

            // Невидимые без брони — пропускаем
            if (le.isInvisible() && !hasVisibleArmor(le)) continue;

            double dist = mc.player.distanceTo(e);
            if (dist > maxR) continue;

            // Проверяем попадание луча в расширенный хитбокс
            var hit = le.getBoundingBox().expand(0.3).raycast(eye, end);
            if (hit.isPresent()) {
                double d = eye.distanceTo(hit.get());
                if (d < bestRayD) { bestRayD = d; bestRay = le; }
            }
            if (dist < bestCloseD) { bestCloseD = dist; bestClose = le; }
        }

        if (bestRay   != null) return bestRay;
        if (bestClose != null && bestCloseD < 4.0) return bestClose;
        return null;
    }

    /** Возвращает true если на сущности есть хоть один видимый предмет брони */
    private boolean hasVisibleArmor(LivingEntity le) {
        for (ItemStack s : le.getArmorItems())
            if (!s.isEmpty() && s.getItem() != Items.AIR) return true;
        return false;
    }

    private boolean isFriend(LivingEntity e) {
        return (e instanceof PlayerEntity) && FriendManager.isFriend(e.getName().getString());
    }

    private int[] getColor(LivingEntity e) {
        if (isFriend(e)) return new int[]{34, 197, 94};
        return RyuzakiRenderCache.rgb1;
    }

    /**
     * Проецирует мировую координату на экран.
     * Использует матрицы захваченные в render3D() — они корректны для 3D фазы.
     */
    private float[] projectToScreen(double wx, double wy, double wz, int sw, int sh) {
        try {
            Vec3d cam = mc.gameRenderer.getCamera().getPos();
            org.joml.Vector4f v = new org.joml.Vector4f(
                    (float)(wx - cam.x), (float)(wy - cam.y), (float)(wz - cam.z), 1f);
            lastMV.transform(v);
            lastProj.transform(v);
            if (v.w <= 0) return null;
            float ndcX = v.x / v.w, ndcY = v.y / v.w;
            return new float[]{(ndcX * 0.5f + 0.5f) * sw, (1f - (ndcY * 0.5f + 0.5f)) * sh};
        } catch (Exception ex) { return null; }
    }

    /**
     * Экранные границы сущности.
     * @return [[cx,cy], [topX,topY], [botX,botY]] или null если за экраном
     */
    private float[][] eBounds(LivingEntity t, float pt, int sw, int sh) {
        double ex = lerp(t.lastRenderX, t.getX(), pt);
        double ey = lerp(t.lastRenderY, t.getY(), pt);
        double ez = lerp(t.lastRenderZ, t.getZ(), pt);
        float[] top = projectToScreen(ex, ey + t.getHeight() + 0.05, ez, sw, sh);
        float[] bot = projectToScreen(ex, ey - 0.05,                  ez, sw, sh);
        if (top == null || bot == null) return null;
        return new float[][]{
                {(top[0] + bot[0]) / 2f, (top[1] + bot[1]) / 2f},
                top, bot
        };
    }

    /** Ease-out cubic (BackEase) для плавного появления */
    private float ease(Entity e, float dt) {
        float v = spawnA.getOrDefault(e, 0f);
        v = Math.min(1f, v + dt * 2.5f);
        spawnA.put(e, v);
        float c2 = 1.70158f, c3 = c2 + 1;
        return Math.max(0f, Math.min(1f, 1f + c3 * (float)Math.pow(v - 1, 3) + c2 * (float)Math.pow(v - 1, 2)));
    }

    /** Маятникообразное вращение для 2D-режимов */
    private static float pendulum(long t) {
        return (float)(Math.sin(t * 7.5e-4) * 720);
    }

    private double lerp(double a, double b, float t) { return a + (b - a) * t; }

    // ═══════════════════════════════════════════════════════════════════
    //  ПРИМИТИВЫ РИСОВАНИЯ (2D)
    // ═══════════════════════════════════════════════════════════════════

    /** Горизонтально-антиалиасированная линия пикселями */
    private static void line2D(DrawContext ctx, float x1, float y1, float x2, float y2, int col, int t) {
        float dx = x2 - x1, dy = y2 - y1;
        int   n  = Math.max(1, (int)Math.hypot(dx, dy));
        for (int i = 0; i <= n; i++) {
            float s  = i / (float)n;
            int   px = (int)(x1 + dx * s), py = (int)(y1 + dy * s);
            ctx.fill(px - t / 2, py - t / 2, px + (t + 1) / 2, py + (t + 1) / 2, col);
        }
    }

    /** Поворот точки (px,py) вокруг (cx,cy) */
    private static void rotatePt(float px, float py, float cos, float sin, float cx, float cy, float[] out) {
        out[0] = px * cos - py * sin + cx;
        out[1] = px * sin + py * cos + cy;
    }

    /** Полый квадрат с вращением */
    private static void hollowSquare(DrawContext ctx, float px, float py, float sz,
                                     float cos, float sin, float cx, float cy, int col, int t) {
        float[][] v  = {{px - sz, py - sz},{px + sz, py - sz},{px + sz, py + sz},{px - sz, py + sz}};
        float[][] rv = new float[4][2];
        for (int i = 0; i < 4; i++) rotatePt(v[i][0], v[i][1], cos, sin, cx, cy, rv[i]);
        for (int i = 0; i < 4; i++) line2D(ctx, rv[i][0], rv[i][1], rv[(i + 1) % 4][0], rv[(i + 1) % 4][1], col, t);
    }

    /** Полый ромб с вращением */
    private static void hollowDiamond(DrawContext ctx, float px, float py, float sz,
                                      float cos, float sin, float cx, float cy, int col, int t) {
        float[][] v  = {{px + sz, py},{px, py + sz},{px - sz, py},{px, py - sz}};
        float[][] rv = new float[4][2];
        for (int i = 0; i < 4; i++) rotatePt(v[i][0], v[i][1], cos, sin, cx, cy, rv[i]);
        for (int i = 0; i < 4; i++) line2D(ctx, rv[i][0], rv[i][1], rv[(i + 1) % 4][0], rv[(i + 1) % 4][1], col, t);
    }

    /** Закрашенный круг */
    private static void fillCircle(DrawContext ctx, int cx, int cy, int r, int col) {
        for (int dy = -r; dy <= r; dy++) {
            int dx = (int)Math.sqrt(Math.max(0.0, (double)r * r - (double)dy * dy));
            ctx.fill(cx - dx, cy + dy, cx + dx + 1, cy + dy + 1, col);
        }
    }

    /** 5-угольная звезда */
    private static void star5(DrawContext ctx, int cx, int cy, int r, int col) {
        float ir = r * 0.4f;
        float[] sx = new float[10], sy = new float[10];
        for (int i = 0; i < 10; i++) {
            float a  = (float)(i * Math.PI / 5 - Math.PI / 2);
            float rr = i % 2 == 0 ? r : ir;
            sx[i] = (float)Math.cos(a) * rr + cx;
            sy[i] = (float)Math.sin(a) * rr + cy;
        }
        for (int i = 0; i < 10; i++)
            line2D(ctx, sx[i], sy[i], sx[(i + 1) % 10], sy[(i + 1) % 10], col, 2);
    }

    // ── Рендер текста через MSDF / MC fallback ───────────────────────
    private void drawText(DrawContext ctx, String text, float x, float y, Color col, float size, boolean bold) {
        var f = bold ? Fonts.BOLD : Fonts.MEDIUM;
        if (f != null) {
            try {
                DrawHelper.drawText(ctx.getMatrices().peek().getPositionMatrix(), f.getFont(size), text, x, y, col);
                return;
            } catch (Exception ignored) {}
        }
        int argb = (col.getAlpha() << 24) | (col.getRed() << 16) | (col.getGreen() << 8) | col.getBlue();
        ctx.drawText(mc.textRenderer, text, (int)x, (int)(y - 7), argb, false);
    }

    private float textW(String s, float size) {
        if (Fonts.BOLD != null) return Fonts.BOLD.getWidth(s, size);
        return mc.textRenderer.getWidth(s);
    }

    @Override
    public void onDisable() {
        spawnA.clear();
    }
}