package ru.ryuzaki.module.modules.world;
// src/main/java/ru/ryuzaki/module/modules/world/TimeChangerModule.java

import net.minecraft.client.MinecraftClient;
import net.minecraft.world.World;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

public class TimeChangerModule extends Module {
    public static TimeChangerModule INSTANCE;
    public final NumberSetting  time   = new NumberSetting("Time",        6000.0, 0.0, 24000.0, 100.0);
    public final BooleanSetting freeze = new BooleanSetting("Freeze Time", true);

    public TimeChangerModule() {
        super("TimeChanger", "Визуальная смена времени суток", Category.WORLD);
        INSTANCE = this;
        addSettings(time, freeze);
    }

    // getSkyAngle теперь доступен через AccessWidener
    public float getSkyAngle(float tickDelta) {
        return (float)(time.getValue() / 24000.0);
    }
}