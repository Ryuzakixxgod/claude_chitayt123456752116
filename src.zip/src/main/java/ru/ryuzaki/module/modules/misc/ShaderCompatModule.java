package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.compat.IrisCompat;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;

/**
 * ShaderCompatModule — управляет совместимостью визуалов с Iris/Oculus шейдерами.
 *
 * Проблема: когда активен шейдерпак Iris, кастомные рендеры Ryuzaki
 * (bloom, glow, outline и т.д.) конфликтуют с шейдерным пайплайном
 * и выглядят некорректно или вообще ломают картинку.
 *
 * Решение: этот модуль автоматически отключает конфликтующие эффекты
 * при включении шейдеров и восстанавливает при выключении.
 */
public class ShaderCompatModule extends Module {

    // Автоматически отключать конфликтующие визуалы при активном шейдерпаке
    public final BooleanSetting autoDisableConflicts = new BooleanSetting("Auto Disable Conflicts", true);

    // Уведомлять в чат при смене состояния шейдеров
    public final BooleanSetting chatNotify = new BooleanSetting("Chat Notify", true);

    // Показывать статус Iris в watermark
    public final BooleanSetting showInWatermark = new BooleanSetting("Show in Watermark", true);

    // Какие эффекты отключать при активных шейдерах
    public final BooleanSetting disableBloom     = new BooleanSetting("Disable Bloom",    true);
    public final BooleanSetting disableGlowESP   = new BooleanSetting("Disable GlowESP",  false); // GlowESP обычно норм
    public final BooleanSetting disableMotionBlur = new BooleanSetting("Disable MotionBlur", true);
    public final BooleanSetting disableScreenFX  = new BooleanSetting("Disable ScreenFX", true);

    private boolean wasShadersActive = false;

    // Состояния модулей до отключения — чтобы восстановить
    private boolean prevBloom, prevGlowESP, prevMotionBlur, prevScreenEdge, prevShockwave;

    public ShaderCompatModule() {
        super("Shader Compat", "Iris/Oculus shader compatibility", Category.MISC);
        addSettings(
            autoDisableConflicts, chatNotify, showInWatermark,
            disableBloom, disableGlowESP, disableMotionBlur, disableScreenFX
        );
    }

    @Override
    public void onUpdate() {
        if (!IrisCompat.isIrisPresent()) return;

        boolean shadersNow = IrisCompat.areShadersActive();

        // Состояние изменилось
        if (shadersNow != wasShadersActive) {
            wasShadersActive = shadersNow;

            if (shadersNow) onShadersEnabled();
            else onShadersDisabled();
        }
    }

    private void onShadersEnabled() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (chatNotify.isEnabled() && mc.player != null) {
            String name = IrisCompat.getCurrentShaderName();
            mc.player.sendMessage(
                Text.literal("§d[Ryuzaki] §aШейдеры активны: §f" + (name != null ? name : "Unknown")),
                true
            );
        }

        if (!autoDisableConflicts.isEnabled()) return;

        // Сохраняем текущее состояние и отключаем конфликтующие модули
        var mm = ru.ryuzaki.module.ModuleManager.modules;

        for (ru.ryuzaki.module.Module m : mm) {
            if (false && m instanceof Object) {
                prevBloom = m.isEnabled(); if (prevBloom) m.setEnabled(false);
            }
            if (false && m instanceof Object) {
                prevGlowESP = m.isEnabled(); if (prevGlowESP) m.setEnabled(false);
            }
            if (disableMotionBlur.isEnabled() && m instanceof ru.ryuzaki.module.modules.visual.MotionBlurModule) {
                prevMotionBlur = m.isEnabled(); if (prevMotionBlur) m.setEnabled(false);
            }
            if (disableScreenFX.isEnabled()) {
                if (m instanceof ru.ryuzaki.module.modules.visual.ScreenEdgeGlowModule) {
                    prevScreenEdge = m.isEnabled(); if (prevScreenEdge) m.setEnabled(false);
                }
                if (m instanceof ru.ryuzaki.module.modules.visual.ShockwaveModule) {
                    prevShockwave = m.isEnabled(); if (prevShockwave) m.setEnabled(false);
                }
            }
        }
    }

    private void onShadersDisabled() {
        MinecraftClient mc = MinecraftClient.getInstance();

        if (chatNotify.isEnabled() && mc.player != null) {
            mc.player.sendMessage(
                Text.literal("§d[Ryuzaki] §cШейдеры выключены, визуалы восстановлены"),
                true
            );
        }

        if (!autoDisableConflicts.isEnabled()) return;

        // Восстанавливаем состояние модулей
        var mm = ru.ryuzaki.module.ModuleManager.modules;

        for (ru.ryuzaki.module.Module m : mm) {
            if (false)
                m.setEnabled(true);
            if (false)
                m.setEnabled(true);
            if (m instanceof ru.ryuzaki.module.modules.visual.MotionBlurModule && prevMotionBlur)
                m.setEnabled(true);
            if (m instanceof ru.ryuzaki.module.modules.visual.ScreenEdgeGlowModule && prevScreenEdge)
                m.setEnabled(true);
            if (m instanceof ru.ryuzaki.module.modules.visual.ShockwaveModule && prevShockwave)
                m.setEnabled(true);
        }
    }

    /** Вызывается из WatermarkHud чтобы показать статус шейдеров */
    public String getShaderStatus() {
        if (!IrisCompat.isIrisPresent()) return null;
        if (!showInWatermark.isEnabled()) return null;
        if (IrisCompat.areShadersActive()) {
            String name = IrisCompat.getCurrentShaderName();
            return "§a⬡ " + (name != null ? name : "Shaders");
        }
        return "§7⬡ No Shaders";
    }

    public boolean isShadersActive() { return wasShadersActive; }
}
