package ru.ryuzaki.module.modules.visual;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.settings.BooleanSetting;

/**
 * CapeModule — кастомный плащ.
 * Рендерится через MixinCapeFeatureRenderer, который модифицирует
 * vanilla cape renderer (уже правильно позиционирован на спине).
 * 
 * ВАЖНО: не использует WorldRenderEvents (было неправильное позиционирование).
 */
public class CapeModule extends Module {

    public static CapeModule INSTANCE;

    public final ModeSetting style   = new ModeSetting("Style","Ryuzaki","Ryuzaki","Wavy","Elytra","Static");
    public final ModeSetting physics = new ModeSetting("Physics","Smooth","Smooth","Realistic","Wavy","None");
    public final NumberSetting intensity = new NumberSetting("Intensity",1.0,0.1,2.0,0.1);
    public final BooleanSetting customColor = new BooleanSetting("Custom Color",false);

    // Physics state
    public float capeAngle = 8f;
    public float capeVel   = 0f;

    public CapeModule() {
        super("Cape","Кастомный плащ с физикой (через vanilla renderer)",Category.VISUAL);
        addSettings(style, physics, intensity, customColor);
        INSTANCE = this;
    }
}
