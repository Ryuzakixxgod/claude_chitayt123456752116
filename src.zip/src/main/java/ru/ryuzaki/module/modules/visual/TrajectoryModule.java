package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/TrajectoryModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.*;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;
import java.util.ArrayList;
import java.util.List;

public class TrajectoryModule extends Module {
    public final ModeSetting   style      = new ModeSetting("Style","Gradient","Gradient","Pulse","Neon","Solid");
    public final BooleanSetting showGlow  = new BooleanSetting("Glow",     true);
    public final BooleanSetting showLand  = new BooleanSetting("Landing",  true);
    public final BooleanSetting showDot   = new BooleanSetting("Dot Trail",true);
    public final NumberSetting  lineWidth = new NumberSetting("Width", 2.0, 0.5, 4.0, 0.5);
    public final ColorSetting   color     = new ColorSetting("Color", new ColorRGBA(100,220,255,200));

    private float hue = 0f;

    public TrajectoryModule(){
        super("Trajectory","Траектория снаряда с эффектами",Category.VISUAL);
        addSettings(style,showGlow,showLand,showDot,lineWidth,color);
    }

    @Override public void onUpdate(){ hue=(hue+0.003f)%1f; }

    public void render3D(MatrixStack ms, float td){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(!isEnabled()||mc.player==null||mc.world==null) return;
        ItemStack held=mc.player.getMainHandStack();
        if(!isProjectile(held)) return;

        List<Vec3d> pts = calcTrajectory(held,td);
        if(pts.size()<2) return;
        Vec3d land = pts.get(pts.size()-1);
        boolean hitBlock = land!=null && isBlockHit(land,mc);

        Vec3d cam=mc.gameRenderer.getCamera().getPos();
        ms.push(); ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.enableBlend(); RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest(); RenderSystem.disableCull();
        RenderSystem.lineWidth(lineWidth.getValue().floatValue());
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();
        long now=System.currentTimeMillis();
        float pulse=0.65f+0.35f*(float)Math.sin(now*0.004f);

        // ── 1. GLOW ───────────────────────────────────────────────────────
        if(showGlow.isEnabled()){
            for(int gl=4;gl>=1;gl--){
                drawTrajectoryLine(tess,mat,pts,gl*0.015f,(int)(40*pulse/gl),true);
            }
        }

        // ── 2. ОСНОВНАЯ ЛИНИЯ ─────────────────────────────────────────────
        drawTrajectoryLine(tess,mat,pts,0,220,false);

        // ── 3. ТОЧКИ (dot trail) ──────────────────────────────────────────
        if(showDot.isEnabled()){
            int[]c=getColor(0);
            BufferBuilder db=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            for(int i=0;i<pts.size();i+=3){
                Vec3d p=pts.get(i);float pct=1f-(float)i/pts.size();
                float sz=0.04f*pct; int da=(int)(200*pct);
                db.vertex(mat,(float)p.x-sz,(float)p.y-sz,(float)p.z).color(c[0],c[1],c[2],da);
                db.vertex(mat,(float)p.x+sz,(float)p.y-sz,(float)p.z).color(c[0],c[1],c[2],da);
                db.vertex(mat,(float)p.x+sz,(float)p.y+sz,(float)p.z).color(c[0],c[1],c[2],0);
                db.vertex(mat,(float)p.x-sz,(float)p.y+sz,(float)p.z).color(c[0],c[1],c[2],0);
            }
            try{BufferRenderer.drawWithGlobalProgram(db.end());}catch(Exception ignored){}
        }

        // ── 4. LANDING ZONE ───────────────────────────────────────────────
        if(showLand.isEnabled()&&land!=null){
            // Expanding ripple rings
            float rippleT = (now % 1200) / 1200f;
            for(int r2=0;r2<3;r2++){
                float rT = (rippleT + r2*0.33f) % 1f;
                float rRad = 0.2f + rT * 1.8f;
                int rA = (int)(180*(1f-rT));
                if(rA>4){ int[]lc2=hitBlock?new int[]{255,80,80}:getColor(0); drawRing(tess,mat,land,rRad,lc2[0],lc2[1],lc2[2],rA,32); }
            }
            int[]lc=hitBlock?new int[]{220,80,80}:getColor(0);
            float lPulse=0.5f+0.5f*(float)Math.sin(now*0.006f);
            // Кольца приземления
            for(int gl=5;gl>=1;gl--){
                float gr=0.6f+gl*0.12f; int la=(int)(120*lPulse*0.2f/gl);
                drawRing(tess,mat,land,gr,lc[0],lc[1],lc[2],la,24);
            }
            drawRing(tess,mat,land,0.6f,lc[0],lc[1],lc[2],(int)(220*lPulse),32);
            drawRing(tess,mat,land,0.3f,lc[0],lc[1],lc[2],(int)(180*lPulse),24);
            // Крест в центре
            float cx=(float)land.x,cy=(float)land.y+0.02f,cz=(float)land.z;
            BufferBuilder xb=tess.begin(VertexFormat.DrawMode.DEBUG_LINES,VertexFormats.POSITION_COLOR);
            int xa=(int)(220*lPulse);
            xb.vertex(mat,cx-0.5f,cy,cz).color(lc[0],lc[1],lc[2],xa); xb.vertex(mat,cx+0.5f,cy,cz).color(lc[0],lc[1],lc[2],xa);
            xb.vertex(mat,cx,cy,cz-0.5f).color(lc[0],lc[1],lc[2],xa); xb.vertex(mat,cx,cy,cz+0.5f).color(lc[0],lc[1],lc[2],xa);
            try{BufferRenderer.drawWithGlobalProgram(xb.end());}catch(Exception ignored){}
        }

        ms.pop();
        RenderSystem.lineWidth(1f);
        RenderSystem.enableDepthTest(); RenderSystem.enableCull(); RenderSystem.disableBlend();
    }

    private void drawTrajectoryLine(Tessellator tess,Matrix4f mat,List<Vec3d>pts,float exp,int baseA,boolean isGlow){
        if(pts.size()<2) return;
        BufferBuilder buf=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
        int total=pts.size();
        for(int i=0;i<total;i++){
            float pct=1f-(float)i/total;
            int[]c=getColor(i);
            int a=(int)(baseA*pct*(isGlow?0.3f:1f));
            Vec3d p=pts.get(i);
            buf.vertex(mat,(float)p.x,(float)p.y+exp,(float)p.z).color(c[0],c[1],c[2],a);
        }
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }
    private void drawRing(Tessellator t,Matrix4f m,Vec3d pos,float r,int rc,int g,int b,int a,int segs){
        BufferBuilder buf=t.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
        for(int i=0;i<=segs;i++){double ang=2*Math.PI*i/segs;buf.vertex(m,(float)(pos.x+r*Math.cos(ang)),(float)pos.y+0.02f,(float)(pos.z+r*Math.sin(ang))).color(rc,g,b,a);}
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private int[] getColor(int idx){
        long now=System.currentTimeMillis();
        return switch(style.getCurrent()){
            case"Pulse" ->hsv((hue+idx*0.005f)%1f,0.7f,0.6f+0.4f*(float)Math.sin(now*0.004f+idx*0.1f));
            case"Neon"  ->{ColorRGBA c=color.getColor();yield c!=null?new int[]{c.getRed(),c.getGreen(),c.getBlue()}:new int[]{100,220,255};}
            case"Solid" ->{ColorRGBA c=color.getColor();yield c!=null?new int[]{c.getRed(),c.getGreen(),c.getBlue()}:new int[]{100,220,255};}
            default     ->hsv((hue+idx*0.008f)%1f,0.85f,1f);
        };
    }
    private boolean isBlockHit(Vec3d pos,MinecraftClient mc){return mc.world!=null&&!mc.world.getBlockState(new net.minecraft.util.math.BlockPos((int)pos.x,(int)pos.y,(int)pos.z)).isAir();}
    private boolean isProjectile(ItemStack s){Item i=s.getItem();return i instanceof BowItem||i instanceof CrossbowItem||i instanceof TridentItem||i instanceof EnderPearlItem||i instanceof SnowballItem||i instanceof EggItem||i instanceof ExperienceBottleItem;}
    private List<Vec3d> calcTrajectory(ItemStack s,float td){
        Vec3d pos=MinecraftClient.getInstance().player.getCameraPosVec(td);
        Vec3d vel=MinecraftClient.getInstance().player.getRotationVec(td).multiply(getVel(s));
        float g=getGrav(s);
        List<Vec3d>pts=new ArrayList<>();
        MinecraftClient mc=MinecraftClient.getInstance();
        for(int i=0;i<250;i++){
            if(i%2==0)pts.add(pos);
            Vec3d next=pos.add(vel);
            BlockHitResult hit=mc.world.raycast(new RaycastContext(pos,next,RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,mc.player));
            if(hit.getType()==HitResult.Type.BLOCK){pts.add(hit.getPos());break;}
            pos=next;vel=vel.add(0,-g,0).multiply(0.99);
            if(pos.y<mc.player.getY()-80||pos.distanceTo(mc.player.getEyePos())>160)break;
        }
        return pts;
    }
    private float getVel(ItemStack s){Item i=s.getItem();if(i instanceof CrossbowItem)return 3.15f;if(i instanceof BowItem)return 3f;if(i instanceof TridentItem)return 2.5f;return 1.5f;}
    private float getGrav(ItemStack s){return(s.getItem()instanceof EnderPearlItem||s.getItem()instanceof EggItem||s.getItem()instanceof SnowballItem)?0.03f:0.05f;}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
