package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.waypoints.Waypoint;
import ru.ryuzaki.waypoints.WaypointManager;

import java.awt.Color;
import java.util.Random;

/**
 * CoordSaver — сохраняет текущие координаты нажатием кнопки.
 * Создаёт waypoint с рандомным цветом и меткой времени.
 * Привязывается к биндингу модуля.
 */
public class CoordSaverModule extends Module {
    private static CoordSaverModule instance;

    public final BooleanSetting chatNotify = new BooleanSetting("Chat Notify", true);
    public final NumberSetting  maxSaved   = new NumberSetting("Max Saved", 20, 5, 100, 5);

    private static final Random rng = new Random();
    private long lastSave = 0;

    public CoordSaverModule(){
        super("CoordSaver","Сохранить координаты кнопкой биндинга",Category.MISC);
        addSettings(chatNotify, maxSaved);
        instance = this;
    }

    public static CoordSaverModule getInstance(){ return instance; }

    @Override
    public void onEnable(){
        // Toggle mode: fires once on enable, then disables itself
        saveCurrentCoords();
        setEnabled(false);
    }

    private void saveCurrentCoords(){
        MinecraftClient mc = MinecraftClient.getInstance();
        if(mc.player == null || mc.world == null) return;

        long now = System.currentTimeMillis();
        if(now - lastSave < 500) return; // debounce
        lastSave = now;

        int x = (int)mc.player.getX();
        int y = (int)mc.player.getY();
        int z = (int)mc.player.getZ();

        // Random accent color
        float hue = rng.nextFloat();
        Color c = Color.getHSBColor(hue, 0.7f, 1f);
        int argb = 0xFF000000 | c.getRGB();

        String label = String.format("Point %d,%d,%d", x,y,z);
        Waypoint wp = new Waypoint(label, x, y, z, argb);
        WaypointManager.getInstance().addWaypoint(wp);

        // Trim to max
        var wps = WaypointManager.getInstance().getWaypoints();
        int max = maxSaved.getValue().intValue();
        while(wps.size() > max) wps.remove(0);

        if(chatNotify.isEnabled() && mc.player != null){
            mc.player.sendMessage(Text.literal(
                "§a[CoordSaver] §fSaved §7" + label), false);
        }
    }
}
