package ru.ryuzaki.module.modules.world;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * FogControlModule — плавный кастомный туман.
 * Smooth lerp при включении/изменении дистанции.
 */
public class FogControlModule extends Module {
    public static FogControlModule INSTANCE;

    public final NumberSetting  distance = new NumberSetting("Distance", 24.0, 2.0, 96.0, 1.0);
    public final BooleanSetting noFog    = new BooleanSetting("No Fog",  false);
    public final BooleanSetting colored  = new BooleanSetting("Custom Color", false);
    public final NumberSetting  fogR     = new NumberSetting("Fog R", 0.5, 0.0, 1.0, 0.05);
    public final NumberSetting  fogG     = new NumberSetting("Fog G", 0.5, 0.0, 1.0, 0.05);
    public final NumberSetting  fogB     = new NumberSetting("Fog B", 0.8, 0.0, 1.0, 0.05);

    // Smooth transition state
    private float currentStart = -1f;
    private float currentEnd   = -1f;
    private float currentR = -1f, currentG = -1f, currentB = -1f;

    public FogControlModule() {
        super("FogControl","Кастомный туман с плавным переходом",Category.WORLD);
        INSTANCE = this;
        addSettings(distance, noFog, colored, fogR, fogG, fogB);
    }

    @Override public void onEnable()  { currentStart=-1; currentEnd=-1; currentR=-1; }
    @Override public void onDisable() { currentStart=-1; currentEnd=-1; }

    // Called from mixin every frame — smooth interpolation
    public float[] getSmoothedFog(float vanillaStart, float vanillaEnd,
                                   float vanillaR, float vanillaG, float vanillaB) {
        float targetEnd   = noFog.isEnabled() ? 999999f : distance.getValue().floatValue()*16f;
        float targetStart = noFog.isEnabled() ? 1000000f : targetEnd*0.75f;
        float tr = colored.isEnabled() ? fogR.getValue().floatValue() : vanillaR;
        float tg = colored.isEnabled() ? fogG.getValue().floatValue() : vanillaG;
        float tb = colored.isEnabled() ? fogB.getValue().floatValue() : vanillaB;

        float spd = 0.06f; // lerp speed per frame
        if (currentStart < 0) { currentStart=vanillaStart; currentEnd=vanillaEnd; }
        if (currentR    < 0) { currentR=vanillaR; currentG=vanillaG; currentB=vanillaB; }
        currentStart = lerp(currentStart, targetStart, spd);
        currentEnd   = lerp(currentEnd,   targetEnd,   spd);
        currentR     = lerp(currentR, tr, spd);
        currentG     = lerp(currentG, tg, spd);
        currentB     = lerp(currentB, tb, spd);
        return new float[]{currentStart, currentEnd, currentR, currentG, currentB};
    }

    private static float lerp(float a, float b, float t){ return a+(b-a)*t; }
    public float getR(){ return currentR<0?fogR.getValue().floatValue():currentR; }
    public float getG(){ return currentG<0?fogG.getValue().floatValue():currentG; }
    public float getB(){ return currentB<0?fogB.getValue().floatValue():currentB; }
}
