package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

public class HitSoundModule extends Module {
    private static HitSoundModule instance;

    public final ModeSetting   sound  = new ModeSetting("Sound","UwU","UwU","Oof","Pop","VineBoom","Kick");
    public final NumberSetting volume = new NumberSetting("Volume", 1.0, 0.1, 2.0, 0.1);
    public final NumberSetting pitch  = new NumberSetting("Pitch",  1.0, 0.5, 2.0, 0.05);

    public HitSoundModule() {
        super("HitSound", "Custom hit sound effect", Category.MISC);
        addSettings(sound, volume, pitch);
        instance = this;
    }

    public static HitSoundModule getInstance() { return instance; }

    public void playHit() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.getSoundManager() == null) return;

        String soundId = switch (sound.getCurrent()) {
            case "Oof"      -> "ryuzaki:hitsound_oof";
            case "Pop"      -> "ryuzaki:hitsound_pop";
            case "VineBoom" -> "ryuzaki:hitsound_vine";
            case "Kick"     -> "ryuzaki:hitsound_kick";
            default         -> "ryuzaki:hitsound_uwu";
        };

        // Берём звук из реестра — Fabric заполнил его из sounds.json
        SoundEvent event = net.minecraft.registry.Registries.SOUND_EVENT
                .get(Identifier.of(soundId));

        if (event == null) {
            System.err.println("[Ryuzaki] HitSound: " + soundId + " not found in registry");
            return;
        }

        mc.getSoundManager().play(PositionedSoundInstance.master(
                event,
                pitch.getValue().floatValue(),
                volume.getValue().floatValue()
        ));
    }
}