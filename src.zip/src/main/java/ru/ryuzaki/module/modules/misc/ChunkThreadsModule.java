package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.NumberSetting;

/**
 * ChunkThreads — увеличивает число потоков сборки чанков.
 *
 * Vanilla: max(1, cores/8) — на 8 ядрах = 1 поток!
 * Sodium:  max(1, cores/2) — на 8 ядрах = 4 потока.
 * Мы:      настраиваемо, рекомендуется cores/2.
 *
 * Применяется при СОЗДАНИИ ChunkBuilder (старт игры/мир).
 * Изменение вступает в силу после перезахода в мир.
 *
 * Эффект: чанки при быстром движении грузятся в 2-4x быстрее.
 * На слабых ЦП не ставить выше cores/2 — перегрузит.
 */
public class ChunkThreadsModule extends Module {
    public static ChunkThreadsModule INSTANCE;

    public final NumberSetting threads = new NumberSetting(
        "Threads",
        (double) Math.max(2, Runtime.getRuntime().availableProcessors() / 2),
        1,
        (double) Runtime.getRuntime().availableProcessors(),
        1
    );

    public ChunkThreadsModule() {
        super("Chunk Threads", "More chunk build threads (+load speed)", Category.MISC);
        INSTANCE = this;
        addSettings(threads);
    }
}
