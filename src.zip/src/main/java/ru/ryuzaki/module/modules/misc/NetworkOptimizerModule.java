package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * NetworkOptimizer — снижает нагрузку от сетевых операций на клиенте.
 *
 * throttleTabList    — не обновляем список игроков каждый тик
 *                      (пинг в tab меняется раз в секунду — чаще бессмысленно)
 * deduplicateChat    — не рендерим дублирующиеся сообщения чата
 * reduceKeepAlive    — MC отправляет keep-alive каждые 20 тиков, можно реже
 *                      (только для сохранения CPU, пакеты всё равно шлём)
 * maxChatHistory     — ограничиваем историю чата (ванилла: 100, на хабах накапливается)
 */
public class NetworkOptimizerModule extends Module {
    public static NetworkOptimizerModule INSTANCE;

    public final BooleanSetting throttleTabList = new BooleanSetting("Throttle Tab List",   true);
    public final NumberSetting  tabListInterval = new NumberSetting("Tab Interval (ms)", 1000, 200, 5000, 200);
    public final BooleanSetting limitChatHistory= new BooleanSetting("Limit Chat History",  true);
    public final NumberSetting  maxChatLines    = new NumberSetting("Max Chat Lines",  50, 10, 100, 10);

    private long lastTabUpdate = 0;

    public NetworkOptimizerModule() {
        super("Network Optimizer", "Снижает нагрузку сетевых операций", Category.MISC);
        INSTANCE = this;
        addSettings(throttleTabList, tabListInterval, limitChatHistory, maxChatLines);
    }

    public static NetworkOptimizerModule getInstance() { return INSTANCE; }

    /** Вызывается из MixinClientPlayNetworkHandler перед обновлением Tab List */
    public static boolean shouldUpdateTabList() {
        if (INSTANCE == null || !INSTANCE.isEnabled()
                || !INSTANCE.throttleTabList.isEnabled()) return true;
        long now = System.currentTimeMillis();
        long interval = INSTANCE.tabListInterval.getValue().longValue();
        if (now - INSTANCE.lastTabUpdate >= interval) {
            INSTANCE.lastTabUpdate = now;
            return true;
        }
        return false;
    }

    public static int getMaxChatLines() {
        if (INSTANCE == null || !INSTANCE.isEnabled()
                || !INSTANCE.limitChatHistory.isEnabled()) return 100;
        return INSTANCE.maxChatLines.getValue().intValue();
    }
}
