package ru.ryuzaki.module.modules.world;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * BetterWaterModule — улучшенная вода.
 *
 * Функции:
 * - No Overlay: убирает синий оверлей под водой (через MixinClientWorld fog)
 * - Fullbright Water: полная яркость под водой (Night Vision эффект)
 * - No Fog: убирает туман под водой (через FogControl логику)
 * - Transparency: управляет прозрачностью воды
 *
 * Микс-ин: MixinClientWorld.getRainGradient переиспользован,
 * вода без оверлея через MixinInGameHud (noWater setting в NoOverlay).
 */
public class BetterWaterModule extends Module {
    public static BetterWaterModule INSTANCE;

    public final BooleanSetting noOverlay   = new BooleanSetting("No Overlay",    true);   // убрать синий тинт
    public final BooleanSetting noFog       = new BooleanSetting("No Water Fog",  true);   // убрать туман под водой
    public final BooleanSetting fullbright  = new BooleanSetting("Fullbright",    true);   // ночное зрение под водой
    public final NumberSetting  fogDist     = new NumberSetting("Fog Distance", 16.0, 2.0, 64.0, 2.0);

    public BetterWaterModule(){
        super("Better Water","Улучшенная вода — нет тумана и оверлея",Category.WORLD);
        INSTANCE = this;
        addSettings(noOverlay, noFog, fullbright, fogDist);
    }

    public static BetterWaterModule getInstance(){ return INSTANCE; }

    /** Called from MixinBackgroundRenderer when player is submerged */
    public boolean shouldRemoveWaterFog(){
        return isEnabled() && noFog.isEnabled();
    }
    public float getWaterFogDist(){
        return fogDist.getValue().floatValue();
    }
    public boolean shouldFullbright(){
        return isEnabled() && fullbright.isEnabled();
    }
    public boolean shouldRemoveOverlay(){
        return isEnabled() && noOverlay.isEnabled();
    }
}
