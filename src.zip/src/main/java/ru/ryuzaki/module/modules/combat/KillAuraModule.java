package ru.ryuzaki.module.modules.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

public final class KillAuraModule extends Module {
    public static KillAuraModule INSTANCE;
    private final Random random = new Random();

    // Range
    public final NumberSetting минДистанция = new NumberSetting("Мин Дистанция", 0.0, 0.0, 6.0, 0.1);
    public final NumberSetting дальность = new NumberSetting("Дальность", 3.5, 0.0, 6.0, 0.1);

    // Target
    public final ModeSetting режимЦели = new ModeSetting("Режим Цели", "Ближайший", "Ближайший", "Наименее HP", "Crosshair");
    public final ModeSetting типЦели = new ModeSetting("Тип Цели", "Игроки", "Игроки", "Мобы", "Все");
    public final BooleanSetting игнорироватьДрузей = new BooleanSetting("Игнорировать Друзей", true);

    // Rotation
    public final NumberSetting скоростьПоворота = new NumberSetting("Скорость Поворота", 180.0, 1.0, 360.0, 1.0);
    public final NumberSetting скоростьLerp = new NumberSetting("Скорость Lerp", 0.15, 0.01, 1.0, 0.01);
    public final BooleanSetting использоватьGCD = new BooleanSetting("Использовать GCD", true);
    public final NumberSetting мертваяЗона = new NumberSetting("Мертвая Зона", 0.5, 0.0, 10.0, 0.1);

    // Prediction
    public final BooleanSetting предсказаниеЦели = new BooleanSetting("Предсказание Цели", true);
    public final NumberSetting силаПредсказания = new NumberSetting("Сила Предсказания", 1.0, 0.0, 2.0, 0.1);

    // Accuracy
    public final NumberSetting расширениеХитбокса = new NumberSetting("Расширение Хитбокса", 0.0, 0.0, 0.5, 0.01);
    public final BooleanSetting случайнаяТочка = new BooleanSetting("Случайная Точка", true);
    public final NumberSetting точность = new NumberSetting("Точность", 100.0, 0.0, 100.0, 1.0);

    // Raytrace
    public final BooleanSetting проверкаЛуча = new BooleanSetting("Проверка Луча", true);
    public final NumberSetting минУголЛуча = new NumberSetting("Мин Угол Луча", 0.85, 0.0, 1.0, 0.01);

    // Attack
    public final NumberSetting задержка = new NumberSetting("Задержка (мс)", 100.0, 0.0, 500.0, 10.0);
    public final NumberSetting рандомЗадержки = new NumberSetting("Рандом Задержки", 0.0, 0.0, 100.0, 5.0);
    public final BooleanSetting требоватьОружие = new BooleanSetting("Требовать Оружие", false);

    // Rate Limit
    public final BooleanSetting ограничениеСкорости = new BooleanSetting("Ограничение Скорости", true);
    public final NumberSetting максХитовВСекунду = new NumberSetting("Макс Хитов/сек", 15.0, 1.0, 30.0, 1.0);

    // Target Lock
    public final BooleanSetting захватЦели = new BooleanSetting("Захват Цели", true);
    public final NumberSetting времяЗахвата = new NumberSetting("Время Захвата (мс)", 2000.0, 0.0, 5000.0, 100.0);

    // Camera Freedom (Separate Rotation)
    public final BooleanSetting свободаКамеры = new BooleanSetting("Свобода Камеры", true);
    public final NumberSetting порогКамеры = new NumberSetting("Порог Камеры", 8.0, 1.0, 30.0, 1.0);

    // Grim Mode
    public final BooleanSetting режимGrim = new BooleanSetting("Режим Grim", true);

    // Static rotation state
    private static volatile float targetYaw = 0f;
    private static volatile float targetPitch = 0f;
    private static volatile boolean isRotating = false;

    private LivingEntity currentTarget = null;
    private long targetLockTime = 0;
    private long lastAttackTime = 0;
    private long currentDelay = 100;
    private int consecutiveHits = 0;
    private int hitsThisSecond = 0;
    private long secondStartTime = 0;
    private double lastMouseX = 0;
    private double lastMouseY = 0;
    private long lastPlayerInputTime = 0;

    public KillAuraModule() {
        super("KillAura", "Автоматическая атака целей", Category.COMBAT);
        INSTANCE = this;
        addSettings(минДистанция, дальность, режимЦели, типЦели, игнорироватьДрузей,
            скоростьПоворота, скоростьLerp, использоватьGCD, мертваяЗона,
            предсказаниеЦели, силаПредсказания,
            расширениеХитбокса, случайнаяТочка, точность,
            проверкаЛуча, минУголЛуча,
            задержка, рандомЗадержки, требоватьОружие,
            ограничениеСкорости, максХитовВСекунду,
            захватЦели, времяЗахвата,
            свободаКамеры, порогКамеры, режимGrim);
    }

    @Override
    public void onEnable() {
        isRotating = false;
        currentTarget = null;
        lastAttackTime = 0;
        consecutiveHits = 0;
        hitsThisSecond = 0;
        currentDelay = задержка.getValue().longValue();
        if (режимGrim.isEnabled()) {
            использоватьGCD.setValue(true);
            проверкаЛуча.setValue(true);
            ограничениеСкорости.setValue(true);
        }
    }

    @Override
    public void onDisable() {
        isRotating = false;
        currentTarget = null;
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (mc.currentScreen != null) return;

        if (требоватьОружие.isEnabled()) {
            var mainHand = mc.player.getMainHandStack();
            var offHand = mc.player.getOffHandStack();
            if (!(mainHand.getItem() instanceof SwordItem) && !(offHand.getItem() instanceof SwordItem)) return;
        }

        long now = System.currentTimeMillis();

        // Camera freedom check
        if (свободаКамеры.isEnabled()) {
            double[] mx = new double[1], my = new double[1];
            GLFW.glfwGetCursorPos(mc.getWindow().getHandle(), mx, my);
            double dx = mx[0] - lastMouseX;
            double dy = my[0] - lastMouseY;
            if (Math.sqrt(dx * dx + dy * dy) > порогКамеры.getValue()) {
                lastPlayerInputTime = now;
                isRotating = false;
                currentTarget = null;
            } else if (now - lastPlayerInputTime < 150) {
                return;
            }
            lastMouseX = mx[0];
            lastMouseY = my[0];
        }

        // Find targets
        List<LivingEntity> targets = findTargets(mc.player, mc.world);
        if (targets.isEmpty()) {
            currentTarget = null;
            isRotating = false;
            return;
        }

        // Select target
        LivingEntity target = selectTarget(targets, mc);
        if (target == null) {
            isRotating = false;
            return;
        }

        currentTarget = target;
        targetLockTime = now;

        // Check cooldown
        if (!isCooldownComplete(now)) return;

        // Calculate and apply rotation
        float[] rotations = calculateAim(mc.player, target);
        applyRotation(mc.player, rotations[0], rotations[1], mc);

        // Attack if aimed
        if (canAttack(mc.player, target, now)) {
            performAttack(mc.player, target, now);
        }
    }

    private List<LivingEntity> findTargets(ClientPlayerEntity player, ClientWorld world) {
        List<LivingEntity> targets = new ArrayList<>();
        double minRange = минДистанция.getValue();
        double maxRange = дальность.getValue();
        String targetType = типЦели.getCurrent();

        for (Entity e : world.getEntities()) {
            if (!(e instanceof LivingEntity le)) continue;
            if (e == player || !le.isAlive()) continue;

            if (targetType.equals("Игроки") && !(e instanceof PlayerEntity)) continue;
            if (targetType.equals("Мобы") && e instanceof PlayerEntity) continue;

            double dist = player.distanceTo(e);
            if (dist < minRange || dist > maxRange) continue;

            targets.add(le);
        }
        return targets;
    }

    private LivingEntity selectTarget(List<LivingEntity> targets, MinecraftClient mc) {
        if (targets.isEmpty()) return null;
        String mode = режимЦели.getCurrent();

        switch (mode) {
            case "Наименее HP":
                return targets.stream().min(Comparator.comparingDouble(LivingEntity::getHealth)).orElse(targets.get(0));
            case "Crosshair":
                Vec3d eyePos = mc.player.getEyePos();
                Vec3d lookDir = mc.player.getRotationVec(1.0f);
                return targets.stream().min(Comparator.comparingDouble(e -> {
                    Vec3d toEntity = e.getPos().subtract(eyePos).normalize();
                    return -lookDir.dotProduct(toEntity);
                })).orElse(targets.get(0));
            default:
                return targets.stream().min(Comparator.comparingDouble(e -> mc.player.distanceTo(e))).orElse(targets.get(0));
        }
    }

    private float[] calculateAim(ClientPlayerEntity player, LivingEntity target) {
        Vec3d eyePos = player.getEyePos();
        Box targetBox = target.getBoundingBox();

        // Expand hitbox
        float expand = расширениеХитбокса.getValue().floatValue();
        if (expand > 0) {
            targetBox = targetBox.expand(expand, expand, expand);
        }

        // Get hit point
        Vec3d targetPos = случайнаяТочка.isEnabled() ? getRandomHitpoint(targetBox) : targetBox.getCenter();

        // Prediction
        if (предсказаниеЦели.isEnabled()) {
            targetPos = predictPosition(target, targetPos);
        }

        // Accuracy offset
        if (точность.getValue() < 100) {
            float inaccuracy = (float) (100 - точность.getValue()) / 100f;
            targetPos = targetPos.add(
                (random.nextDouble() - 0.5) * inaccuracy * 2,
                (random.nextDouble() - 0.5) * inaccuracy * 2,
                (random.nextDouble() - 0.5) * inaccuracy * 2
            );
        }

        // Calculate rotation
        double dx = targetPos.x - eyePos.x;
        double dy = targetPos.y - eyePos.y;
        double dz = targetPos.z - eyePos.z;
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < 0.01) return new float[]{player.getYaw(), player.getPitch()};

        float targetYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
        float targetPitch = (float) Math.toDegrees(Math.atan2(-dy, Math.sqrt(dx * dx + dz * dz)));

        // Deadzone check
        float yawDiff = MathHelper.wrapDegrees(targetYaw - player.getYaw());
        float pitchDiff = targetPitch - player.getPitch();
        double dzVal = мертваяЗона.getValue();

        if (Math.abs(yawDiff) <= dzVal && Math.abs(pitchDiff) <= dzVal) {
            return new float[]{player.getYaw(), player.getPitch()};
        }

        return new float[]{MathHelper.wrapDegrees(targetYaw), MathHelper.clamp(targetPitch, -90f, 90f)};
    }

    private void applyRotation(ClientPlayerEntity player, float targetYaw, float targetPitch, MinecraftClient mc) {
        float curYaw = player.getYaw();
        float curPitch = player.getPitch();

        float yawDiff = MathHelper.wrapDegrees(targetYaw - curYaw);
        float pitchDiff = targetPitch - curPitch;

        // Deadzone
        if (Math.abs(yawDiff) <= мертваяЗона.getValue() && Math.abs(pitchDiff) <= мертваяЗона.getValue()) {
            isRotating = false;
            return;
        }

        float lerpSpeed = скоростьLerp.getValue().floatValue();
        float newYaw = curYaw;
        float newPitch = curPitch;

        // Smooth rotation with speed limit
        float maxSpeed = скоростьПоворота.getValue().floatValue();
        yawDiff = Math.max(-maxSpeed, Math.min(maxSpeed, yawDiff));
        pitchDiff = Math.max(-maxSpeed, Math.min(maxSpeed, pitchDiff));
        newYaw = MathHelper.wrapDegrees(curYaw + yawDiff * lerpSpeed);
        newPitch = MathHelper.clamp(curPitch + pitchDiff * lerpSpeed, -90f, 90f);

        // GCD quantization for Grim bypass
        if (использоватьGCD.isEnabled()) {
            double sensitivity = mc.options.getMouseSensitivity().getValue();
            double gcd = calculateGCD(sensitivity);
            newYaw = (float) (Math.round(newYaw / gcd) * gcd);
            newPitch = (float) (Math.round(newPitch / gcd) * gcd);
        }

        // Apply to player (this affects visual)
        player.setYaw(newYaw);
        player.setPitch(newPitch);

        // Store for mixin (sends to server)
        targetYaw = newYaw;
        targetPitch = newPitch;
        isRotating = true;
    }

    private boolean canAttack(ClientPlayerEntity player, LivingEntity target, long now) {
        // Raytrace check
        if (проверкаЛуча.isEnabled() && !isLookingAtTarget(player, target)) {
            return false;
        }

        // Rate limiting
        if (ограничениеСкорости.isEnabled()) {
            if (now - secondStartTime >= 1000) {
                hitsThisSecond = 0;
                secondStartTime = now;
            }
            if (hitsThisSecond >= максХитовВСекунду.getValue()) {
                return false;
            }
        }

        return isCooldownComplete(now);
    }

    private boolean isLookingAtTarget(ClientPlayerEntity player, LivingEntity target) {
        Vec3d eyePos = player.getEyePos();
        float yawRad = (float) Math.toRadians(player.getYaw());
        float pitchRad = (float) Math.toRadians(player.getPitch());

        Vec3d lookDir = new Vec3d(
            -MathHelper.sin(yawRad) * MathHelper.cos(pitchRad),
            -MathHelper.sin(pitchRad),
            MathHelper.cos(yawRad) * MathHelper.cos(pitchRad)
        ).normalize();

        Vec3d targetCenter = target.getBoundingBox().getCenter();
        double dot = lookDir.dotProduct(targetCenter.subtract(eyePos).normalize());
        return dot > минУголЛуча.getValue();
    }

    private void performAttack(ClientPlayerEntity player, LivingEntity target, long now) {
        // Send attack packet
        player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(target, player.isSneaking()));
        player.swingHand(Hand.MAIN_HAND);

        lastAttackTime = now;
        consecutiveHits++;
        hitsThisSecond++;

        // Randomize delay
        double randomFactor = рандомЗадержки.getValue() / 100.0;
        long baseDelay = задержка.getValue().longValue();
        currentDelay = baseDelay + (long) (random.nextDouble() * baseDelay * randomFactor);

        if (consecutiveHits > 20) consecutiveHits = 0;
    }

    private boolean isCooldownComplete(long now) {
        return now - lastAttackTime >= currentDelay;
    }

    private Vec3d getRandomHitpoint(Box box) {
        return new Vec3d(
            box.minX + (box.maxX - box.minX) * (0.3 + random.nextDouble() * 0.4),
            box.minY + (box.maxY - box.minY) * (0.3 + random.nextDouble() * 0.4),
            box.minZ + (box.maxZ - box.minZ) * (0.3 + random.nextDouble() * 0.4)
        );
    }

    private Vec3d predictPosition(LivingEntity target, Vec3d currentPos) {
        long ping = getPing();
        double pf = ping / 1000.0 * 20.0 * силаПредсказания.getValue();
        Vec3d predicted = currentPos.add(target.getVelocity().multiply(pf));
        if (!target.isOnGround()) {
            predicted = predicted.add(0, -0.08 * pf * (pf + 1) / 2, 0);
        }
        return predicted;
    }

    private long getPing() {
        try {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.getNetworkHandler() == null || mc.player == null) return 50;
            var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
            return entry != null ? entry.getLatency() : 50;
        } catch (Exception e) { return 50; }
    }

    private double calculateGCD(double sensitivity) {
        double f = sensitivity * 0.6 + 0.2;
        return Math.max(Math.pow(f, 3) * 8.0, 0.001);
    }

    // Static methods for mixin
    public static boolean isRotating() { return isRotating; }
    public static float getTargetYaw() { return targetYaw; }
    public static float getTargetPitch() { return targetPitch; }
}