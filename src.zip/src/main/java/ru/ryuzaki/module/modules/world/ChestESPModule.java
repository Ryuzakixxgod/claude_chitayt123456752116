package ru.ryuzaki.module.modules.world;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.entity.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

import java.util.ArrayList;
import java.util.List;

/**
 * ChestESP — подсвечивает сундуки, шалкеры, бочки и другие контейнеры
 * сквозь стены с цветным glow.
 */
public class ChestESPModule extends Module {

    public final NumberSetting range    = new NumberSetting("Range", 32.0, 8.0, 64.0, 4.0);
    public final BooleanSetting chests  = new BooleanSetting("Chests",       true);
    public final BooleanSetting shulker = new BooleanSetting("Shulker Boxes",true);
    public final BooleanSetting barrels = new BooleanSetting("Barrels",      true);
    public final BooleanSetting enders  = new BooleanSetting("Ender Chests", true);
    public final NumberSetting  glow    = new NumberSetting("Glow Layers", 4.0, 1.0, 8.0, 1.0);

    // Colour per type (ARGB)
    private static final int COL_CHEST   = 0xFFFFAA00; // gold
    private static final int COL_SHULKER = 0xFFAA00FF; // purple
    private static final int COL_BARREL  = 0xFF00AAFF; // blue
    private static final int COL_ENDER   = 0xFF00FFAA; // cyan

    public ChestESPModule() {
        super("ChestESP", "Подсвечивает сундуки сквозь стены", Category.WORLD);
        addSettings(range, chests, shulker, barrels, enders, glow);
    }

    public void render3D(MatrixStack ms, float tickDelta) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!isEnabled() || mc.world == null || mc.player == null) return;

        Vec3d cam    = mc.gameRenderer.getCamera().getPos();
        double maxSq = range.getValue() * range.getValue();

        List<int[]> toRender = new ArrayList<>(); // {x,y,z,color}

        int playerCX = mc.player.getBlockPos().getX() >> 4;
        int playerCZ = mc.player.getBlockPos().getZ() >> 4;
        int chunkRadius = (int)(range.getValue() / 16) + 1;

        for (int cx = playerCX - chunkRadius; cx <= playerCX + chunkRadius; cx++) {
            for (int cz = playerCZ - chunkRadius; cz <= playerCZ + chunkRadius; cz++) {
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    BlockPos pos = be.getPos();
                    double dSq = mc.player.squaredDistanceTo(pos.getX()+.5, pos.getY()+.5, pos.getZ()+.5);
                    if (dSq > maxSq) continue;

                    int color = -1;
                    if (be instanceof ChestBlockEntity && chests.isEnabled())   color = COL_CHEST;
                    else if (be instanceof ShulkerBoxBlockEntity && shulker.isEnabled()) color = COL_SHULKER;
                    else if (be instanceof BarrelBlockEntity && barrels.isEnabled())     color = COL_BARREL;
                    else if (be instanceof EnderChestBlockEntity && enders.isEnabled())  color = COL_ENDER;
                    if (color == -1) continue;

                    toRender.add(new int[]{pos.getX(), pos.getY(), pos.getZ(), color});
                }
            }
        }

        if (toRender.isEmpty()) return;

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);

        RenderSystem.enableBlend();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Tessellator tess = Tessellator.getInstance();
        int layers = glow.getValue().intValue();

        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        Matrix4f mat = ms.peek().getPositionMatrix();

        for (int[] d : toRender) {
            int r=(d[3]>>16)&0xFF, g=(d[3]>>8)&0xFF, b=d[3]&0xFF;
            for (int gl = layers; gl >= 1; gl--) {
                float exp = gl * 0.04f;
                int a = Math.max(1, (int)(40f / gl));
                Box box = new Box(d[0]-exp, d[1]-exp, d[2]-exp,
                                  d[0]+1+exp, d[1]+1+exp, d[2]+1+exp);
                appendBox(buf, mat, box, r, g, b, a);
            }
        }

        try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception ignored) {}

        ms.pop();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private static void appendBox(BufferBuilder b, Matrix4f m, Box box, int r, int g, int c, int a) {
        float x1=(float)box.minX,y1=(float)box.minY,z1=(float)box.minZ;
        float x2=(float)box.maxX,y2=(float)box.maxY,z2=(float)box.maxZ;
        b.vertex(m,x1,y1,z1).color(r,g,c,a);b.vertex(m,x2,y1,z1).color(r,g,c,a);b.vertex(m,x2,y1,z2).color(r,g,c,a);b.vertex(m,x1,y1,z2).color(r,g,c,a);
        b.vertex(m,x1,y2,z2).color(r,g,c,a);b.vertex(m,x2,y2,z2).color(r,g,c,a);b.vertex(m,x2,y2,z1).color(r,g,c,a);b.vertex(m,x1,y2,z1).color(r,g,c,a);
        b.vertex(m,x1,y1,z1).color(r,g,c,a);b.vertex(m,x1,y2,z1).color(r,g,c,a);b.vertex(m,x2,y2,z1).color(r,g,c,a);b.vertex(m,x2,y1,z1).color(r,g,c,a);
        b.vertex(m,x2,y1,z2).color(r,g,c,a);b.vertex(m,x2,y2,z2).color(r,g,c,a);b.vertex(m,x1,y2,z2).color(r,g,c,a);b.vertex(m,x1,y1,z2).color(r,g,c,a);
        b.vertex(m,x1,y1,z2).color(r,g,c,a);b.vertex(m,x1,y2,z2).color(r,g,c,a);b.vertex(m,x1,y2,z1).color(r,g,c,a);b.vertex(m,x1,y1,z1).color(r,g,c,a);
        b.vertex(m,x2,y1,z1).color(r,g,c,a);b.vertex(m,x2,y2,z1).color(r,g,c,a);b.vertex(m,x2,y2,z2).color(r,g,c,a);b.vertex(m,x2,y1,z2).color(r,g,c,a);
    }
}
