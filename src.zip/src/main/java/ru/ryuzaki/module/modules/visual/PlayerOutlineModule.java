package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/PlayerOutlineModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

public class PlayerOutlineModule extends Module {
    private static PlayerOutlineModule instance;
    public final ModeSetting   mode   = new ModeSetting("Mode","Cosmic","Cosmic","Rainbow","HP","Static","Pulse","Friend");
    public final ColorSetting  color  = new ColorSetting("Color",new ColorRGBA(130,50,255,255));
    public final NumberSetting thick  = new NumberSetting("Thickness",2.0,1.0,5.0,0.5);
    public final BooleanSetting glow  = new BooleanSetting("Glow Layers",true);

    private float hue=0f, pulsePhase=0f;

    public PlayerOutlineModule(){
        super("PlayerOutline","Цветной контур своей модели (3rd person)",Category.VISUAL);
        addSettings(mode,color,thick,glow);
        instance=this;
    }
    public static PlayerOutlineModule getInstance(){return instance;}

    @Override public void onUpdate(){
        hue=(hue+0.003f)%1f;
        pulsePhase+=0.06f;
    }

    // Возвращает ARGB цвет для EntityOutlineShader
    public int getColor(){
        if(!isEnabled()) return -1;
        MinecraftClient mc=MinecraftClient.getInstance();
        long now=System.currentTimeMillis();
        return switch(mode.getCurrent()){
            case"HP" -> {
                if(mc.player==null) yield 0xFFFF4444;
                float hp=mc.player.getHealth()/mc.player.getMaxHealth();
                int[]c=hsv(hp*0.33f,0.9f,1f);
                yield rgba(c[0],c[1],c[2],255);
            }
            case"Rainbow" -> {
                int[]c=hsv(hue,0.9f,1f);
                yield rgba(c[0],c[1],c[2],255);
            }
            case"Cosmic" -> {
                int[]c=hsv((hue+0.7f)%1f,0.8f,1f);
                yield rgba(c[0],c[1],c[2],255);
            }
            case"Pulse" -> {
                float p=0.5f+0.5f*(float)Math.sin(pulsePhase);
                int[]c=hsv(hue,0.9f,p*0.5f+0.5f);
                yield rgba(c[0],c[1],c[2],255);
            }
            case"Friend" -> rgba(50,255,100,255);
            default -> {
                ColorRGBA c=color.getColor();
                yield c!=null?rgba(c.getRed(),c.getGreen(),c.getBlue(),255):rgba(130,50,255,255);
            }
        };
    }

    // Возвращает дополнительный цвет для слоёв glow
    public int getGlowColor(int layer){
        if(!glow.isEnabled()) return -1;
        int base=getColor();
        if(base==-1) return -1;
        int a=Math.max(0,(int)(40.0/layer));
        return (base&0x00FFFFFF)|((a&0xFF)<<24);
    }

    public float getThickness(){return thick.getValue().floatValue();}

    private static int rgba(int r,int g,int b,int a){return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
    private void flushBB(BufferBuilder bb) {
        try { BufferRenderer.drawWithGlobalProgram(bb.end()); } catch (Exception ignored) {}
    }

    private static void bbEdges(BufferBuilder bb, Matrix4f mat,
                                float x1,float y1,float z1,
                                float x2,float y2,float z2,
                                int r,int g,int b,int a) {
        // Bottom
        v(bb,mat,x1,y1,z1,r,g,b,a); v(bb,mat,x2,y1,z1,r,g,b,a);
        v(bb,mat,x2,y1,z1,r,g,b,a); v(bb,mat,x2,y1,z2,r,g,b,a);
        v(bb,mat,x2,y1,z2,r,g,b,a); v(bb,mat,x1,y1,z2,r,g,b,a);
        v(bb,mat,x1,y1,z2,r,g,b,a); v(bb,mat,x1,y1,z1,r,g,b,a);
        // Top
        v(bb,mat,x1,y2,z1,r,g,b,a); v(bb,mat,x2,y2,z1,r,g,b,a);
        v(bb,mat,x2,y2,z1,r,g,b,a); v(bb,mat,x2,y2,z2,r,g,b,a);
        v(bb,mat,x2,y2,z2,r,g,b,a); v(bb,mat,x1,y2,z2,r,g,b,a);
        v(bb,mat,x1,y2,z2,r,g,b,a); v(bb,mat,x1,y2,z1,r,g,b,a);
        // Pillars
        v(bb,mat,x1,y1,z1,r,g,b,a); v(bb,mat,x1,y2,z1,r,g,b,a);
        v(bb,mat,x2,y1,z1,r,g,b,a); v(bb,mat,x2,y2,z1,r,g,b,a);
        v(bb,mat,x2,y1,z2,r,g,b,a); v(bb,mat,x2,y2,z2,r,g,b,a);
        v(bb,mat,x1,y1,z2,r,g,b,a); v(bb,mat,x1,y2,z2,r,g,b,a);
    }

    private static void v(BufferBuilder bb, Matrix4f mat, float x,float y,float z, int r,int g,int b,int a) {
        bb.vertex(mat,x,y,z).color(r,g,b,a);
    }

    public void render3D(MatrixStack ms, float td){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.options.getPerspective().isFirstPerson()) return;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.lineWidth(2f);
        Vec3d cam=mc.gameRenderer.getCamera().getPos();
        double expand=thick.getValue()*0.04;
        Box bb=mc.player.getBoundingBox().expand(expand);
        int col=getColor(); if(col==-1){resetGL();return;}
        int cr=(col>>16)&0xFF,cg=(col>>8)&0xFF,cb=col&0xFF;
        float x1=(float)(bb.minX-cam.x),y1=(float)(bb.minY-cam.y),z1=(float)(bb.minZ-cam.z);
        float x2=(float)(bb.maxX-cam.x),y2=(float)(bb.maxY-cam.y),z2=(float)(bb.maxZ-cam.z);
        Matrix4f mat=ms.peek().getPositionMatrix();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Tessellator tess = Tessellator.getInstance();
        if(glow.isEnabled()){
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
            BufferBuilder glowBB = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
            for(int gl=4;gl>=1;gl--){
                float ex2=(float)(gl*0.028);
                bbEdges(glowBB, mat, x1-ex2,y1-ex2,z1-ex2,x2+ex2,y2+ex2,z2+ex2, cr,cg,cb, Math.max(0,(int)(25.0/gl)));
            }
            flushBB(glowBB);
        }
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);
        BufferBuilder coreBB = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);
        bbEdges(coreBB, mat, x1,y1,z1,x2,y2,z2, cr,cg,cb,190);
        flushBB(coreBB);
        resetGL();
    }

    private void resetGL(){
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.lineWidth(1f);
    }

    private void drawOutlineBox(BufferBuilder bb, Matrix4f mat, Box b, int r, int g, int bl, int a){
        float x1=(float)b.minX,y1=(float)b.minY,z1=(float)b.minZ,x2=(float)b.maxX,y2=(float)b.maxY,z2=(float)b.maxZ;
        bb.vertex(mat,x1,y1,z1).color(r,g,bl,a); bb.vertex(mat,x2,y1,z1).color(r,g,bl,a);
        bb.vertex(mat,x2,y1,z1).color(r,g,bl,a); bb.vertex(mat,x2,y1,z2).color(r,g,bl,a);
        bb.vertex(mat,x2,y1,z2).color(r,g,bl,a); bb.vertex(mat,x1,y1,z2).color(r,g,bl,a);
        bb.vertex(mat,x1,y1,z2).color(r,g,bl,a); bb.vertex(mat,x1,y1,z1).color(r,g,bl,a);
        bb.vertex(mat,x1,y2,z1).color(r,g,bl,a); bb.vertex(mat,x2,y2,z1).color(r,g,bl,a);
        bb.vertex(mat,x2,y2,z1).color(r,g,bl,a); bb.vertex(mat,x2,y2,z2).color(r,g,bl,a);
        bb.vertex(mat,x2,y2,z2).color(r,g,bl,a); bb.vertex(mat,x1,y2,z2).color(r,g,bl,a);
        bb.vertex(mat,x1,y2,z2).color(r,g,bl,a); bb.vertex(mat,x1,y2,z1).color(r,g,bl,a);
        bb.vertex(mat,x1,y1,z1).color(r,g,bl,a); bb.vertex(mat,x1,y2,z1).color(r,g,bl,a);
        bb.vertex(mat,x2,y1,z1).color(r,g,bl,a); bb.vertex(mat,x2,y2,z1).color(r,g,bl,a);
        bb.vertex(mat,x2,y1,z2).color(r,g,bl,a); bb.vertex(mat,x2,y2,z2).color(r,g,bl,a);
        bb.vertex(mat,x1,y1,z2).color(r,g,bl,a); bb.vertex(mat,x1,y2,z2).color(r,g,bl,a);
    }

}