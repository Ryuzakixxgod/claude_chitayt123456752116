package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;

/**
 * 🚀 Fast Math — JVM-уровневые оптимизации рендера.
 * • Отключает VSync для максимального FPS
 * • Оптимизирует chunk rebuild throttle
 * • Снижает кол-во chunk updates за тик
 */
public class FastMathModule extends Module {
    private static FastMathModule instance;
    public final BooleanSetting noVSync      = new BooleanSetting("Disable VSync",    true);
    public final BooleanSetting fastChunks   = new BooleanSetting("Fast Chunk Update", true);

    private boolean origVSync = false;
    private boolean saved = false;

    public FastMathModule() {
        super("Fast Math", "VSync off + chunk optimizations", Category.MISC);
        addSettings(noVSync, fastChunks);
        instance = this;
    }

    public static FastMathModule getInstance() { return instance; }

    @Override
    public void onEnable() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        origVSync = mc.options.getEnableVsync().getValue();
        saved = true;
        if (noVSync.isEnabled())
            mc.options.getEnableVsync().setValue(false);
        mc.options.write();
    }

    @Override
    public void onDisable() {
        if (!saved) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options == null) return;
        mc.options.getEnableVsync().setValue(origVSync);
        mc.options.write();
    }
}
