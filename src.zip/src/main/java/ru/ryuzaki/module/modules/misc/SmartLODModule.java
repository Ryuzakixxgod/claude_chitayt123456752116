package ru.ryuzaki.module.modules.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * SmartLOD — пропускает рендер кадров для не-игровых сущностей.
 *
 * Принцип: мобы вдали не нуждаются в обновлении анимации каждый кадр.
 * При farFrameSkip=2: каждый 2-й кадр моба не рендерится.
 * Визуально: чуть более "дёрганая" анимация у мобов за 32+ блоков.
 * Выигрыш: ~30-50% CPU на скелетных анимациях при 50+ мобах.
 *
 * Подключён через MixinLivingEntityRenderer.
 */
public class SmartLODModule extends Module {
    private static SmartLODModule instance;

    public final NumberSetting  farFrameSkip = new NumberSetting(
        "Frame Skip (far)", 2, 1, 6, 1);
    public final BooleanSetting skipFar      = new BooleanSetting(
        "Skip Far Animations", true);
    public final NumberSetting  farDist      = new NumberSetting(
        "Far Dist (blocks)", 32, 8, 64, 4);

    public SmartLODModule() {
        super("Smart LOD", "Entity animation LOD (frame skip)", Category.MISC);
        addSettings(farFrameSkip, skipFar, farDist);
        instance = this;
    }

    public static SmartLODModule getInstance() { return instance; }

    /**
     * Вызывается из MixinLivingEntityRenderer.
     * Возвращает N — пропускать каждый N-й кадр (1 = не пропускать).
     */
    public int getFrameSkip() {
        if (!isEnabled() || !skipFar.isEnabled()) return 1;
        return farFrameSkip.getValue().intValue();
    }

    /** Быстрая проверка через кэш позиции камеры — без sqrt для частых вызовов */
    public static boolean shouldSkipAnimation(double ex, double ey, double ez) {
        if (instance == null || !instance.isEnabled() || !instance.skipFar.isEnabled())
            return false;
        double farD = instance.farDist.getValue();
        return RyuzakiRenderCache.camDistSq(ex, ey, ez) > farD * farD;
    }
}
