package ru.ryuzaki.module.modules.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.math.BlockPos;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.settings.BooleanSetting;

public class NoSlowModule extends Module {

    public static NoSlowModule INSTANCE;

    private final ModeSetting режим = new ModeSetting("Режим", "Ванильный", "Ванильный", "Grim", "Sloth", "Vulcan");
    private final NumberSetting множитель = new NumberSetting("Множитель", 100.0, 10.0, 100.0, 5.0);
    private final BooleanSetting проверкаПотребления = new BooleanSetting("Проверка Потребления", true);

    private int slowTicks = 0;

    public NoSlowModule() {
        super("NoSlow", "Убирает замедление", Category.MOVEMENT);
        INSTANCE = this;
        addSettings(режим, множитель, проверкаПотребления);
    }

    @Override
    public void onUpdate() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        String currentMode = режим.getCurrent();

        if (!currentMode.equals("Ванильный")) {
            if (currentMode.equals("Grim")) {
                handleGrimNoSlow(mc);
            } else if (currentMode.equals("Sloth")) {
                handleSlothNoSlow(mc);
            } else if (currentMode.equals("Vulcan")) {
                handleVulcanNoSlow(mc);
            }
        }

        slowTicks++;
    }

    private void handleGrimNoSlow(MinecraftClient mc) {
        if (mc.player.isUsingItem()) {
            if (slowTicks % 8 == 0) {
                mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.RELEASE_USE_ITEM,
                    BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
            }
        }
    }

    private void handleSlothNoSlow(MinecraftClient mc) {
        if (mc.player.isUsingItem()) {
            int interval = (int)(6 + Math.random() * 6);
            if (slowTicks % interval == 0) {
                mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.RELEASE_USE_ITEM,
                    BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
            }
        }
    }

    private void handleVulcanNoSlow(MinecraftClient mc) {
        if (mc.player.isUsingItem()) {
            int baseInterval = 5;
            int variance = (int)(Math.random() * 3);
            if (slowTicks % (baseInterval + variance) == 0) {
                mc.player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.RELEASE_USE_ITEM,
                    BlockPos.ORIGIN, mc.player.getHorizontalFacing()));
            }
        }
    }
}
