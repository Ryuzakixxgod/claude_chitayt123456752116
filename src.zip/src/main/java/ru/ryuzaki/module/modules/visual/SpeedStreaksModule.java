package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/SpeedStreaksModule.java
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import java.util.*;

public class SpeedStreaksModule extends Module {
    public final ModeSetting   style    = new ModeSetting("Style","Plasma","Plasma","Fire","Ice","Rainbow","Void","Electric","Cosmic");
    public final NumberSetting threshold= new NumberSetting("Threshold",0.12,0.03,0.5,0.01);
    public final NumberSetting count    = new NumberSetting("Streaks",   8,   2,  20,  1);
    public final NumberSetting length   = new NumberSetting("Length",    2.5, 0.5, 6.0, 0.25);
    public final BooleanSetting glow    = new BooleanSetting("Glow",     true);
    public final BooleanSetting elytra  = new BooleanSetting("Elytra+",  true);

    private static class Streak {
        double x,y,z; // начало
        double ex,ey,ez; // конец (позиция назад)
        float life,maxLife,hue;
        Streak(double x,double y,double z,double ex,double ey,double ez,float life,float hue){
            this.x=x;this.y=y;this.z=z;this.ex=ex;this.ey=ey;this.ez=ez;
            this.life=this.maxLife=life;this.hue=hue;
        }
        void update(){life--;}
    }

    private final List<Streak> streaks=new ArrayList<>();
    private final java.util.Deque<Vec3d> posHistory=new ArrayDeque<>();
    private float globalHue=0f;
    private final java.util.Random rng=new java.util.Random();
    private static final int[] C_ELECTRIC={200,240,255};
    private final int[] streakColorBuf=new int[3];

    public SpeedStreaksModule(){
        super("SpeedStreaks","Световые полосы при движении",Category.VISUAL);
        addSettings(style,threshold,count,length,glow,elytra);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }

    @Override public void onDisable(){streaks.clear();posHistory.clear();}

    @Override
    public void onUpdate(){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null) return;
        globalHue=(globalHue+0.002f)%1f;

        Vec3d vel=mc.player.getVelocity();
        double speed=Math.sqrt(vel.x*vel.x+vel.z*vel.z+vel.y*vel.y*(elytra.isEnabled()&&mc.player.isGliding()?1:0.2));
        Vec3d pos=mc.player.getPos().add(0,mc.player.getHeight()*0.5,0);

        posHistory.addFirst(pos);
        int histLen=(int)(length.getValue()*10)+5;
        while(posHistory.size()>histLen) posHistory.removeLast();

        // Обновляем и удаляем мёртвые
        streaks.removeIf(s->{s.update();return s.life<=0;});

        if(speed>threshold.getValue()&&posHistory.size()>3){
            int maxStr=count.getValue().intValue();
            if(streaks.size()<maxStr&&rng.nextInt(3)==0){
                // Конец полосы — позиция назад по истории
                Vec3d backPos=posHistory.size()>2?(Vec3d)posHistory.toArray()[Math.min(posHistory.size()-1,4)]:pos;
                // Рандомный оффсет для разброса
                double offX=rng.nextGaussian()*0.3, offY=rng.nextGaussian()*0.15, offZ=rng.nextGaussian()*0.3;
                streaks.add(new Streak(
                    pos.x+offX,pos.y+offY,pos.z+offZ,
                    backPos.x+offX,backPos.y+offY,backPos.z+offZ,
                    8+rng.nextInt(6), rng.nextFloat()
                ));
            }
        }
    }

    private void render(WorldRenderContext ctx){
        if(!isEnabled()||streaks.isEmpty()) return;
        Vec3d cam=ctx.camera().getPos();
        MatrixStack ms=ctx.matrixStack();if(ms==null)return;
        ms.push();ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.disableDepthTest();RenderSystem.enableBlend();RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();
        float thick=0.022f;

        for(Streak s:streaks){
            float pct=s.life/s.maxLife;
            int[]c=getColor(s);
            int a=(int)(220*pct*(0.3f+0.7f*(float)Math.sin(pct*Math.PI)));

            // Вектор перпендикулярный направлению полосы
            double dx=s.x-s.ex, dy=s.y-s.ey, dz=s.z-s.ez;
            double len2=Math.sqrt(dx*dx+dz*dz);
            float tx=len2>0.0001?(float)(-dz/len2*thick):thick, tz=len2>0.0001?(float)(dx/len2*thick):0;

            // Glow слои
            if(glow.isEnabled()){
                for(int gl=3;gl>=1;gl--){
                    float gt=thick*(1+gl*0.5f);
                    int ga=(int)(a*0.12f/gl);
                    drawStreak(tess,mat,(float)s.x,(float)s.y,(float)s.z,(float)s.ex,(float)s.ey,(float)s.ez,c[0],c[1],c[2],ga,gt*10);
                }
            }
            // Основная полоса (лента)
            drawStreak(tess,mat,(float)s.x,(float)s.y,(float)s.z,(float)s.ex,(float)s.ey,(float)s.ez,c[0],c[1],c[2],a,thick*8);
            // Яркая тонкая центральная линия
            drawStreak(tess,mat,(float)s.x,(float)s.y,(float)s.z,(float)s.ex,(float)s.ey,(float)s.ez,255,255,255,(int)(a*0.4f),thick*2);
        }

        ms.pop();RenderSystem.enableDepthTest();RenderSystem.enableCull();RenderSystem.disableBlend();
    }

    private void drawStreak(Tessellator t,Matrix4f m,float x1,float y1,float z1,float x2,float y2,float z2,int r,int g,int b,int a,float w){
        double dx=x2-x1,dz=z2-z1,len=Math.sqrt(dx*dx+dz*dz);
        if(len<0.0001)return;
        float tx=(float)(-dz/len*w),tz=(float)(dx/len*w);
        BufferBuilder buf=t.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
        buf.vertex(m,x1+tx,y1+w,z1+tz).color(r,g,b,a);
        buf.vertex(m,x1-tx,y1-w,z1-tz).color(r,g,b,0);
        buf.vertex(m,x2+tx,y2+w,z2+tz).color(r,g,b,0);
        buf.vertex(m,x2-tx,y2-w,z2-tz).color(r,g,b,0);
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private int[]getColor(Streak s){
        switch(style.getCurrent()){
            case"Electric" -> { return C_ELECTRIC; }
            case"Fire"     -> ru.ryuzaki.util.RyuzakiRenderCache.hsvFill(0.06f-s.hue*0.05f,1f,1f,streakColorBuf);
            case"Ice"      -> ru.ryuzaki.util.RyuzakiRenderCache.hsvFill(0.56f+s.hue*0.04f,0.7f,1f,streakColorBuf);
            case"Rainbow"  -> ru.ryuzaki.util.RyuzakiRenderCache.hsvFill(s.hue,1f,1f,streakColorBuf);
            case"Void"     -> ru.ryuzaki.util.RyuzakiRenderCache.hsvFill(0.75f+s.hue*0.08f,0.9f,0.7f,streakColorBuf);
            case"Cosmic"   -> ru.ryuzaki.util.RyuzakiRenderCache.hsvFill((globalHue+s.hue*0.2f)%1f,0.85f,1f,streakColorBuf);
            default        -> ru.ryuzaki.util.RyuzakiRenderCache.hsvFill((globalHue+s.hue*0.15f)%1f,0.8f,1f,streakColorBuf);
        }
        return streakColorBuf;
    }
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
