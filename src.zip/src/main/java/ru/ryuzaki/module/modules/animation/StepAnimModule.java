package ru.ryuzaki.module.modules.animation;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.NumberSetting;

/**
 * StepAnim — подъём на блоки без прыжка.
 * getStepHeight() переопределяется в MixinLivingEntity — здесь только хранится настройка.
 */
public class StepAnimModule extends Module {
    public static StepAnimModule INSTANCE;

    public final NumberSetting height = new NumberSetting("Step Height", 1.0, 0.6, 2.0, 0.1);

    public StepAnimModule() {
        super("StepAnim", "Плавный подъём на блоки", Category.ANIMATION);
        INSTANCE = this;
        addSettings(height);
    }
}
