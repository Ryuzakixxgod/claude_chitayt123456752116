package ru.ryuzaki.module.modules.particles;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import java.util.*;

/**
 * CosmicCritModule — переработанные крит-частицы.
 * 6 стилей: Cosmic (rainbow orbs), Stars (gold stars), Rings (blue shock rings),
 * Burst (orange sparks), Sakura (pink petals), Spiral (rainbow spiral).
 *
 * Исправления:
 * - BufferBuilder корректно закрывается при пустом батче
 * - Частицы billboard-ориентированы (вращаются к камере)
 * - Impact rings плавно расширяются с fade
 */
public class CosmicCritModule extends Module {
    public static CosmicCritModule INSTANCE;

    public final ModeSetting   style = new ModeSetting("Style","Cosmic","Cosmic","Stars","Rings","Burst","Sakura","Spiral");
    public final NumberSetting count = new NumberSetting("Count", 18, 5, 60, 5);
    public final BooleanSetting impactRing = new BooleanSetting("Impact Ring", true);
    public final BooleanSetting glow       = new BooleanSetting("Glow",        true);

    private static class CP {
        double x,y,z; float vx,vy,vz,life,maxLife,size,hue,rot,rv;
        boolean star;
        CP(double x,double y,double z,float vx,float vy,float vz,float life,float size,float hue,boolean star,float rot,float rv){
            this.x=x;this.y=y;this.z=z;this.vx=vx;this.vy=vy;this.vz=vz;
            this.life=this.maxLife=life;this.size=size;this.hue=hue;this.star=star;this.rot=rot;this.rv=rv;
        }
        void update(){x+=vx;y+=vy;z+=vz;vy-=0.0035f;life--;vx*=0.95f;vz*=0.95f;rot+=rv;}
    }
    private static class IR {
        Vec3d pos; float radius,maxR,life,maxLife,hue;
        IR(Vec3d p,float maxR,float life,float hue){pos=p;radius=0;this.maxR=maxR;this.life=this.maxLife=life;this.hue=hue;}
        void update(){radius=maxR*(1f-life/maxLife);life--;}
    }

    private final List<CP> particles   = new ArrayList<>();
    private final List<IR> impactRings = new ArrayList<>();
    private final Random   rng         = new Random();
    private float globalHue = 0f;

    public CosmicCritModule(){
        super("CosmicCrit","Крит-частицы с 6 стилями",Category.PARTICLES);
        INSTANCE = this;
        addSettings(style,count,impactRing,glow);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
    }
    public static CosmicCritModule getInstance(){return INSTANCE;}

    public void spawnCrit(Vec3d pos){
        if(!isEnabled()) return;
        globalHue=(globalHue+0.08f)%1f;
        int n=count.getValue().intValue();

        if(impactRing.isEnabled()){
            impactRings.add(new IR(pos,1.6f,20,globalHue));
            impactRings.add(new IR(pos,0.9f,14,(globalHue+0.2f)%1f));
        }

        for(int i=0;i<n;i++){
            float ang=(float)(Math.PI*2*rng.nextFloat());
            float up=0.035f+rng.nextFloat()*0.10f;
            float hz=rng.nextFloat()*0.045f;
            float hue = switch(style.getCurrent()){
                case "Stars"  -> 0.11f+rng.nextFloat()*0.05f;
                case "Rings"  -> 0.55f+rng.nextFloat()*0.12f;
                case "Burst"  -> 0.05f+rng.nextFloat()*0.10f;
                case "Sakura" -> 0.90f+rng.nextFloat()*0.07f;
                case "Spiral" -> (float)i/n;
                default       -> (globalHue+rng.nextFloat()*0.35f)%1f;
            };
            boolean isStar = style.getCurrent().equals("Stars") && rng.nextFloat() > 0.4f;
            float rv = (rng.nextFloat()-0.5f) * (isStar ? 8f : 4f);

            // Spiral — закрученный spawn
            if(style.getCurrent().equals("Spiral")){
                float spiralAng = (float)i/n * (float)(Math.PI*4);
                ang = spiralAng;
                hz = 0.03f + (float)i/n * 0.04f;
            }

            particles.add(new CP(
                pos.x + rng.nextGaussian()*0.07,
                pos.y + 0.4 + rng.nextDouble()*0.6,
                pos.z + rng.nextGaussian()*0.07,
                (float)Math.cos(ang)*hz, up, (float)Math.sin(ang)*hz,
                14+rng.nextInt(16), 0.04f+rng.nextFloat()*0.07f,
                hue, isStar, rng.nextFloat()*360f, rv
            ));
        }
        while(particles.size()>500) particles.remove(0);
    }

    private void render(WorldRenderContext ctx){
        if(!isEnabled()||(particles.isEmpty()&&impactRings.isEmpty())) return;
        Vec3d cam=ctx.camera().getPos();
        MatrixStack ms=ctx.matrixStack(); if(ms==null)return;
        ms.push(); ms.translate(-cam.x,-cam.y,-cam.z);
        RenderSystem.disableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();
        Matrix4f mat=ms.peek().getPositionMatrix();

        // ── Кольца ──────────────────────────────────────────────────
        Iterator<IR> ri=impactRings.iterator();
        while(ri.hasNext()){
            IR r=ri.next(); r.update(); if(r.life<=0){ri.remove();continue;}
            float pct=r.life/r.maxLife; float bright=(float)Math.sin(pct*Math.PI);
            int[]c=hsv(r.hue,0.85f,1f);
            // Glow ring — additive
            if(glow.isEnabled()){
                RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
                BufferBuilder gb=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
                for(int i=0;i<=40;i++){double a=2*Math.PI*i/40;float re=r.radius+0.06f,ri2=r.radius-0.06f;gb.vertex(mat,(float)(r.pos.x+ri2*Math.cos(a)),(float)r.pos.y,(float)(r.pos.z+ri2*Math.sin(a))).color(c[0],c[1],c[2],0);gb.vertex(mat,(float)(r.pos.x+re*Math.cos(a)),(float)r.pos.y,(float)(r.pos.z+re*Math.sin(a))).color(c[0],c[1],c[2],(int)(180*bright));}
                try{BufferRenderer.drawWithGlobalProgram(gb.end());}catch(Exception ignored){}
            }
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);
            BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
            for(int i=0;i<=32;i++){double a=2*Math.PI*i/32;rb.vertex(mat,(float)(r.pos.x+r.radius*Math.cos(a)),(float)r.pos.y,(float)(r.pos.z+r.radius*Math.sin(a))).color(c[0],c[1],c[2],(int)(230*bright));}
            try{BufferRenderer.drawWithGlobalProgram(rb.end());}catch(Exception ignored){}
        }

        // ── Частицы ──────────────────────────────────────────────────
        // Получаем направление камеры для billboard
        float camYaw   = ctx.camera().getYaw();
        float camPitch = ctx.camera().getPitch();

        Iterator<CP> pi=particles.iterator();
        while(pi.hasNext()){
            CP p=pi.next(); p.update(); if(p.life<=0){pi.remove();continue;}
            float pct=p.life/p.maxLife;
            int pa=(int)(200*pct*(0.4f+0.6f*(float)Math.sin(pct*Math.PI)));
            if(pa<=0) continue;
            int[]c=hsv(p.hue,0.85f,1f);
            float sz=p.size*(0.3f+0.7f*pct);

            ms.push();
            ms.translate(p.x,p.y,p.z);
            // Billboard
            ms.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Y.rotationDegrees(-(camYaw)));
            ms.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_X.rotationDegrees(camPitch));
            ms.multiply(net.minecraft.util.math.RotationAxis.POSITIVE_Z.rotationDegrees(p.rot));
            Matrix4f pm=ms.peek().getPositionMatrix();

            if(glow.isEnabled()){
                RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE);
                float gs=sz*2.5f;
                BufferBuilder gl2=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
                gl2.vertex(pm,-gs,gs,0).color(c[0],c[1],c[2],pa/5);
                gl2.vertex(pm, gs,gs,0).color(c[0],c[1],c[2],pa/5);
                gl2.vertex(pm, gs,-gs,0).color(c[0],c[1],c[2],pa/5);
                gl2.vertex(pm,-gs,-gs,0).color(c[0],c[1],c[2],pa/5);
                try{BufferRenderer.drawWithGlobalProgram(gl2.end());}catch(Exception ignored){}
            }
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);

            if(p.star){
                // 8-point star
                BufferBuilder stb=tess.begin(VertexFormat.DrawMode.TRIANGLES,VertexFormats.POSITION_COLOR);
                for(int i=0;i<8;i++){
                    float a1=(float)(i*Math.PI/4), a2=(float)((i+0.5f)*Math.PI/4), a3=(float)((i+1)*Math.PI/4);
                    stb.vertex(pm,0,0,0).color(c[0],c[1],c[2],pa);
                    stb.vertex(pm,(float)Math.cos(a1)*sz,(float)Math.sin(a1)*sz,0).color(255,255,255,pa);
                    stb.vertex(pm,(float)Math.cos(a2)*sz*0.4f,(float)Math.sin(a2)*sz*0.4f,0).color(c[0],c[1],c[2],pa/2);
                }
                try{BufferRenderer.drawWithGlobalProgram(stb.end());}catch(Exception ignored){}
            } else {
                BufferBuilder sq=tess.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
                sq.vertex(pm,-sz, sz,0).color(c[0],c[1],c[2],pa);
                sq.vertex(pm, sz, sz,0).color(c[0],c[1],c[2],pa);
                sq.vertex(pm, sz,-sz,0).color(c[0],c[1],c[2],0);
                sq.vertex(pm,-sz,-sz,0).color(c[0],c[1],c[2],0);
                try{BufferRenderer.drawWithGlobalProgram(sq.end());}catch(Exception ignored){}
            }
            ms.pop();
        }

        ms.pop();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA,org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);
        RenderSystem.disableBlend();
    }

    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t2=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t2;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t2;}case 3->{r=p;g=q;b=v;}case 4->{r=t2;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
