package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.lwjgl.opengl.GL11;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;

import java.util.Random;

/**
 * Питомец-спутник: Wolf / Fox / Fairy / MiniWarden
 * - Ванильная скорость, масштабируется с игроком
 * - Не проваливается сквозь блоки
 * - Только Fairy летит, остальные ходят
 * - Hyper-детализированные модели (~100-150 боксов каждая)
 * - Характерные звуки через реестр
 */
public class PetModule extends Module {

    public final ModeSetting type = new ModeSetting("Type", "Wolf",
            "Wolf", "Fox", "Fairy", "MiniWarden");

    // ── Скорость — ванильная ────────────────────────────────────────
    // Ванильный волк идёт ~1.5 б/с = 0.025 б/кадр при 60fps
    private static final double BASE_SPEED    = 0.008; // ~0.5 блока/сек — ванильная скорость волка
    private static final double RUN_SPEED     = 0.016; // ~1 блок/сек — лёгкий бег
    private static final double FOLLOW_DIST   = 2.0;
    private static final double MAX_DIST      = 5.5;
    private static final double TELEPORT_DIST = 30.0;
    private static final double WANDER_RADIUS = 3.2;
    private static final float  IDLE_TICKS    = 95f;

    // ── Состояние ───────────────────────────────────────────────────
    private double petX, petY, petZ, petYaw;
    private double prevX, prevZ;
    private double wTargetX, wTargetZ;
    private float  wTimer, animFrame, moveSpeed, idleTimer, sitAmount, tailPitch, soundTimer;
    private boolean initialized;
    private final Random rng = new Random();

    // ═══ ПАЛИТРЫ ════════════════════════════════════════════════════

    // Wolf
    private static final int[]
            WF1={172,164,152}, WF2={158,150,138}, WF3={142,134,122}, // мех 3 тона
            WD1={108, 98, 86}, WD2={ 90, 80, 70},                    // тёмные
            WB1={224,218,206}, WB2={235,230,220},                    // живот
            WS1={192,182,168}, WS2={178,168,154},                    // морда
            WN ={ 22, 16, 14}, WNS={ 46, 36, 34},                   // нос / ноздри
            WE1={222,150, 28}, WE2={200,128, 18},                   // глаза янтарь
            WPU={ 10,  8,  8}, WHI={255,255,255},                   // зрачок / блик
            WI1={205,132,118}, WI2={180,108, 95},                   // ухо внутри
            WCL={ 30, 24, 20};                                       // когти

    // Fox
    private static final int[]
            FO1={238,128, 38}, FO2={222,110, 22}, FO3={200, 90, 12},
            FK1={195, 90, 22}, FK2={165, 68, 10},
            FW1={248,244,230}, FW2={232,228,212},
            FN ={ 22, 14, 14}, FNS={ 48, 34, 34},
            FE1={ 52,188, 52}, FE2={ 35,155, 35},
            FPI={  8,  8,  8}, FIE={ 88, 28, 28};

    // Fairy
    private static final int[]
            SK1={255,222,196}, SK2={242,205,178}, SK3={228,188,162},
            LIP={215, 72, 72}, SKHI={255,240,228};

    // Warden
    private static final int[]
            MB1={ 14, 36, 52}, MB2={ 20, 48, 68}, MB3={ 28, 60, 84},
            MR1={ 24, 58, 78}, MR2={ 18, 44, 62},
            MG1={ 50,195,238}, MG2={ 38,168,212},
            MS1={188, 48,218}, MS2={155, 32,182}, MS3={120, 18,148},
            MD1={  8, 20, 32};

    public PetModule() {
        super("Pet", "Питомец-спутник", Category.VISUAL);
        addSettings(type);
        WorldRenderEvents.AFTER_TRANSLUCENT.register(this::onRender);
    }

    @Override public void onEnable()  { reset(); }
    @Override public void onDisable() { reset(); }

    private void reset() {
        initialized = false;
        animFrame = moveSpeed = idleTimer = sitAmount = tailPitch = soundTimer = wTimer = 0;
    }

    // ═══════════════════════════════════════════════════════════════════
    private void onRender(WorldRenderContext ctx) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        PlayerEntity player = mc.player;
        Vec3d cam = ctx.camera().getPos();
        boolean isFairy = type.getCurrent().equals("Fairy");

        // ── Инициализация ────────────────────────────────────────────
        if (!initialized) {
            double a = Math.toRadians(player.bodyYaw + 130);
            petX = player.getX() + Math.cos(a) * 1.8;
            petZ = player.getZ() + Math.sin(a) * 1.8;
            petY = groundY(mc, petX, player.getY(), petZ, isFairy);
            petYaw = player.bodyYaw; prevX = petX; prevZ = petZ;
            wTargetX = petX; wTargetZ = petZ;
            initialized = true;
        }

        // ── Телепорт ─────────────────────────────────────────────────
        if (dist2D(petX, petZ, player.getX(), player.getZ()) > TELEPORT_DIST) {
            double a = Math.toRadians(player.bodyYaw + 130);
            petX = player.getX() + Math.cos(a) * 1.8;
            petZ = player.getZ() + Math.sin(a) * 1.8;
            petY = player.getY(); // on teleport start at player Y, groundY will correct next frame
            wTargetX = petX; wTargetZ = petZ;
        }

        // ── Скорость = ванильная + масштаб скорости игрока ──────────
        // pSpd ≈ 0.0 стоим, ≈ 0.04 идём, ≈ 0.07 бежим (per frame при 60fps)
        Vec3d vel  = player.getVelocity();
        double pSpd = Math.sqrt(vel.x * vel.x + vel.z * vel.z);
        // Наша скорость ≈ базовая + небольшой буст если игрок быстрее идёт
        double mySpeed = BASE_SPEED + pSpd * 0.65;
        mySpeed = Math.min(mySpeed, RUN_SPEED);

        // ── Вандеринг-ИИ ─────────────────────────────────────────────
        double distPlayer = dist2D(petX, petZ, player.getX(), player.getZ());
        wTimer--;
        if (wTimer <= 0 || distPlayer > MAX_DIST) wanderChoose(player, distPlayer);

        prevX = petX; prevZ = petZ;
        double dx = wTargetX - petX, dz = wTargetZ - petZ;
        double distTarget = Math.sqrt(dx*dx + dz*dz);
        double actual = 0;

        if (distTarget > 0.04) {
            boolean sprint = distPlayer > MAX_DIST - 1.0;
            double step = Math.min(distTarget, sprint ? RUN_SPEED : mySpeed);
            petX += (dx / distTarget) * step;
            petZ += (dz / distTarget) * step;
            actual = step;

            double tYaw = Math.toDegrees(Math.atan2(-dx, dz)); // MC yaw: 0=South,90=West,270=East
            double dy   = tYaw - petYaw;
            while (dy >  180) dy -= 360;
            while (dy < -180) dy += 360;
            petYaw += dy * 0.12;
        }

        // Ground Y — scans relative to petY (not player), capped at 0.25 blocks/frame to prevent jumping
        double targetGroundY = groundY(mc, petX, petY, petZ, isFairy);
        double yDelta = (targetGroundY - petY) * (isFairy ? 0.05 : 0.22);
        yDelta = Math.max(-0.25, Math.min(0.25, yDelta));  // cap vertical speed
        petY += yDelta;

        // ── Анимация ─────────────────────────────────────────────────
        boolean moving = actual > 0.004;
        float raw = (float) actual;
        moveSpeed += (raw - moveSpeed) * 0.30f;

        if (moving) idleTimer = 0; else idleTimer++;
        boolean canSit = !isFairy && !type.getCurrent().equals("MiniWarden");
        sitAmount += ((canSit && idleTimer > IDLE_TICKS ? 1f : 0f) - sitAmount) * 0.035f;

        // Скорость анимации пропорциональна moveSpeed
        float aspd = moving ? (0.04f + moveSpeed * 55f) : 0.018f;
        animFrame += aspd;

        // Хвост: высокий угол вверх
        float tTgt = moving
                ? (float) Math.sin(animFrame * 4.5f) * 0.28f + 0.62f
                : (float) Math.sin(animFrame * 2.0f) * 0.12f + 0.50f;
        tailPitch += (tTgt - tailPitch) * 0.14f;

        // ── Звук ─────────────────────────────────────────────────────
        soundTimer--;
        if (soundTimer <= 0) { sound(mc); soundTimer = 220 + rng.nextFloat() * 280; }

        // ── Рендер ───────────────────────────────────────────────────
        float bob      = moving ? (float) Math.sin(animFrame * 2) * 0.014f * Math.min(1f, moveSpeed * 80f) : 0f;
        float hover    = isFairy ? (float) Math.sin(animFrame * 1.5f) * 0.08f : 0f;
        float scale    = switch (type.getCurrent()) { case "Fox" -> 0.54f; case "Fairy" -> 0.30f;
            case "MiniWarden" -> 0.46f; default -> 0.62f; };

        ms.push();
        ms.translate(petX - cam.x, petY - cam.y + bob + hover, petZ - cam.z);
        ms.scale(scale, scale, scale);
        ms.multiply(new Quaternionf().rotateY((float) Math.toRadians(-petYaw + 180)));

        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        switch (type.getCurrent()) {
            case "Wolf"      -> wolf(ms);
            case "Fox"       -> fox(ms);
            case "Fairy"     -> fairy(ms);
            case "MiniWarden"-> warden(ms);
        }

        ms.pop();
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    // ── Вандеринг ────────────────────────────────────────────────────
    private void wanderChoose(PlayerEntity pl, double dp) {
        double px = pl.getX(), pz = pl.getZ();
        if (dp > MAX_DIST - 0.5) {
            double a = Math.atan2(pz - petZ, px - petX);
            double spread = (rng.nextDouble() - 0.5) * 0.7;
            double near   = 0.8 + rng.nextDouble() * (FOLLOW_DIST - 0.4);
            wTargetX = px + Math.cos(a + Math.PI + spread) * near;
            wTargetZ = pz + Math.sin(a + Math.PI + spread) * near;
            wTimer = 18 + rng.nextInt(12);
        } else {
            double a = rng.nextDouble() * Math.PI * 2;
            double d = 0.3 + rng.nextDouble() * WANDER_RADIUS;
            double nx = px + Math.cos(a) * d, nz = pz + Math.sin(a) * d;
            double ddx = nx-px, ddz = nz-pz, dd = Math.sqrt(ddx*ddx+ddz*ddz);
            if (dd > MAX_DIST-0.6) { nx = px+ddx/dd*(MAX_DIST-0.6); nz = pz+ddz/dd*(MAX_DIST-0.6); }
            wTargetX = nx; wTargetZ = nz;
            wTimer = 50 + rng.nextInt(100);
        }
    }

    // ── Y земли ──────────────────────────────────────────────────────
    private double groundY(MinecraftClient mc, double x, double currentY, double z, boolean fly) {
        if (fly) return mc.player != null ? mc.player.getY() + 1.0 : currentY + 1.0;
        int ix = (int) Math.floor(x), iz = (int) Math.floor(z);
        // Сканируем вниз от refY+1 до -5 относительно текущей позиции
        int startY = (int) Math.ceil(currentY) + 1;
        int endY   = startY - 16;
        for (int iy = startY; iy >= endY; iy--) {
            BlockState bs = mc.world.getBlockState(new BlockPos(ix, iy, iz));
            if (!bs.isAir() && !bs.isOf(net.minecraft.block.Blocks.WATER)
                    && !bs.isOf(net.minecraft.block.Blocks.LAVA)
                    && !bs.isOf(net.minecraft.block.Blocks.VOID_AIR)) return iy + 1.0;
        }
        // Если ничего не нашли — используем высоту игрока как fallback
        return mc.player != null ? mc.player.getY() : currentY;
    }

    // ── Звук ─────────────────────────────────────────────────────────
    private void sound(MinecraftClient mc) {
        if (mc.world == null) return;
        float v = 0.32f;
        switch (type.getCurrent()) {
            case "Wolf"      -> snd(mc, rng.nextBoolean() ? "entity.wolf.ambient" : "entity.wolf.pant",
                    v, 0.85f + rng.nextFloat() * 0.3f);
            case "Fox"       -> snd(mc, "entity.fox.ambient",       v,       0.9f  + rng.nextFloat() * 0.35f);
            case "Fairy"     -> snd(mc, "entity.bat.ambient",       v*0.5f,  1.45f + rng.nextFloat() * 0.55f);
            case "MiniWarden"-> { snd(mc, "entity.warden.heartbeat", v*0.8f, 1.0f + rng.nextFloat()*0.08f);
                if (rng.nextFloat()<0.3f) snd(mc,"entity.warden.ambient",v*0.5f,1.1f); }
        }
    }
    private void snd(MinecraftClient mc, String id, float vol, float pitch) {
        SoundEvent e = Registries.SOUND_EVENT.get(Identifier.of("minecraft", id));
        if (e != null && mc.world != null)
            mc.world.playSound(petX, petY, petZ, e, SoundCategory.NEUTRAL, vol, pitch, false);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  WOLF  — ~150 деталей
    // ═══════════════════════════════════════════════════════════════════
    private void wolf(MatrixStack ms) {
        Tessellator T = Tessellator.getInstance();
        float sit = sitAmount;
        float run = Math.min(1f, moveSpeed * 140f);
        float ph  = (float) Math.sin(animFrame * 3.2f);

        // ══ ХВОСТ — 5 сегментов, изогнут вверх ══════════════════════
        ms.push();
        ms.translate(0, 0.54f, 0.36f);
        // Сегмент 1 — основание
        ms.multiply(new Quaternionf().rotateX(-(tailPitch * 0.9f + 0.3f)));
        b(ms,T,-0.08f,0,-0.072f, 0.08f,0.20f,0.072f, WF2,255);
        b(ms,T,-0.07f,0,-0.063f, 0.07f,0.20f,0.063f, WF1,200); // подшёрсток
        // Сегмент 2
        ms.translate(0,0.18f,0); ms.multiply(new Quaternionf().rotateX(-0.30f));
        b(ms,T,-0.074f,0,-0.066f, 0.074f,0.19f,0.066f, WF2,255);
        // Сегмент 3
        ms.translate(0,0.17f,0); ms.multiply(new Quaternionf().rotateX(-0.22f));
        b(ms,T,-0.068f,0,-0.060f, 0.068f,0.18f,0.060f, WF1,255);
        // Сегмент 4
        ms.translate(0,0.16f,0); ms.multiply(new Quaternionf().rotateX(-0.15f));
        b(ms,T,-0.058f,0,-0.050f, 0.058f,0.16f,0.050f, WF2,255);
        // Кончик (светлый)
        ms.translate(0,0.14f,0); ms.multiply(new Quaternionf().rotateX(-0.10f));
        b(ms,T,-0.044f,0,-0.038f, 0.044f,0.13f,0.038f, WB1,255);
        ms.pop();

        // ══ ТЕЛО ══════════════════════════════════════════════════════
        float by = -0.042f * sit;
        Matrix4f m = ms.peek().getPositionMatrix();

        // Основной торс (3 слоя — создаёт ощущение объёма)
        b(m,T,-0.315f,0.22f+by,-0.445f, 0.315f,0.720f+by, 0.370f, WF2,255);
        b(m,T,-0.305f,0.25f+by,-0.435f, 0.305f,0.715f+by, 0.360f, WF1,255);

        // Спина — тёмная полоса
        b(m,T,-0.190f,0.670f+by,-0.420f, 0.190f,0.722f+by, 0.340f, WD1,255);
        b(m,T,-0.120f,0.695f+by,-0.400f, 0.120f,0.724f+by, 0.310f, WD2,255);

        // Лопатки (выпуклость за передними ногами)
        b(m,T,-0.318f,0.480f+by,-0.320f,-0.290f,0.620f+by,-0.130f, WD1,255);
        b(m,T, 0.290f,0.480f+by,-0.320f, 0.318f,0.620f+by,-0.130f, WD1,255);

        // Бёдра (выпуклость у задних ног)
        b(m,T,-0.318f,0.360f+by, 0.080f,-0.290f,0.520f+by, 0.280f, WD1,255);
        b(m,T, 0.290f,0.360f+by, 0.080f, 0.318f,0.520f+by, 0.280f, WD1,255);

        // Живот (3 тона — светлее)
        b(m,T,-0.215f,0.220f+by,-0.400f, 0.215f,0.560f+by, 0.330f, WB1,255);
        b(m,T,-0.165f,0.235f+by,-0.380f, 0.165f,0.510f+by, 0.310f, WB2,255);

        // Грудь
        b(m,T,-0.185f,0.340f+by,-0.450f, 0.185f,0.650f+by,-0.375f, WB1,255);
        b(m,T,-0.140f,0.380f+by,-0.452f, 0.140f,0.620f+by,-0.380f, WB2,255);

        // Рёбра (тонкие тёмные полосы сбоку)
        for (int i=0;i<4;i++) {
            float ry=0.280f+i*0.105f+by;
            b(m,T,-0.317f,ry,-0.380f,-0.306f,ry+0.055f, 0.240f, WD2,170);
            b(m,T, 0.306f,ry,-0.380f, 0.317f,ry+0.055f, 0.240f, WD2,170);
        }

        // ══ ШЕЯ ═══════════════════════════════════════════════════════
        b(m,T,-0.175f,0.615f+by,-0.560f, 0.175f,0.850f+by,-0.320f, WF2,255);
        b(m,T,-0.155f,0.630f+by,-0.545f, 0.155f,0.840f+by,-0.335f, WF1,255);
        // Горло
        b(m,T,-0.130f,0.640f+by,-0.540f, 0.130f,0.825f+by,-0.345f, WB1,255);
        b(m,T,-0.105f,0.655f+by,-0.525f, 0.105f,0.810f+by,-0.360f, WB2,255);
        // Загривок (темнее)
        b(m,T,-0.105f,0.800f+by,-0.430f, 0.105f,0.870f+by,-0.300f, WD1,255);

        // ══ ГОЛОВА ════════════════════════════════════════════════════
        float hy = 0.810f + by;

        // Череп — основной объём
        b(m,T,-0.250f,hy,       -0.638f, 0.250f,hy+0.302f,-0.262f, WF2,255);
        b(m,T,-0.238f,hy+0.010f,-0.625f, 0.238f,hy+0.295f,-0.270f, WF1,255);

        // Темя (тёмное)
        b(m,T,-0.220f,hy+0.238f,-0.615f, 0.220f,hy+0.302f,-0.275f, WD1,255);
        b(m,T,-0.150f,hy+0.268f,-0.600f, 0.150f,hy+0.302f,-0.285f, WD2,255);

        // Затылок
        b(m,T,-0.215f,hy+0.095f,-0.262f, 0.215f,hy+0.285f,-0.195f, WF2,255);

        // Щёки (пышные)
        b(m,T,-0.302f,hy+0.038f,-0.605f,-0.235f,hy+0.235f,-0.305f, WF1,255);
        b(m,T, 0.235f,hy+0.038f,-0.605f, 0.302f,hy+0.235f,-0.305f, WF1,255);
        // Подщёчные мешки
        b(m,T,-0.318f,hy+0.055f,-0.572f,-0.295f,hy+0.198f,-0.325f, WF2,255);
        b(m,T, 0.295f,hy+0.055f,-0.572f, 0.318f,hy+0.198f,-0.325f, WF2,255);

        // ── Морда (верхняя часть) — 3 секции
        b(m,T,-0.148f,hy+0.052f,-0.848f, 0.148f,hy+0.182f,-0.688f, WS1,255);
        b(m,T,-0.136f,hy+0.062f,-0.835f, 0.136f,hy+0.175f,-0.700f, WS2,255);
        b(m,T,-0.132f,hy+0.038f,-0.688f, 0.132f,hy+0.168f,-0.630f, WS1,255);

        // ── Нижняя челюсть — 2 части
        b(m,T,-0.125f,hy-0.060f,-0.830f, 0.125f,hy+0.038f,-0.638f, WD1,255);
        b(m,T,-0.112f,hy-0.048f,-0.820f, 0.112f,hy+0.030f,-0.648f, WD2,255);
        // Подбородок
        b(m,T,-0.075f,hy-0.065f,-0.780f, 0.075f,hy-0.020f,-0.640f, WB1,200);

        // ── Нос — 4 части
        b(m,T,-0.075f,hy+0.118f,-0.872f, 0.075f,hy+0.182f,-0.812f, WN, 255);
        b(m,T,-0.070f,hy+0.122f,-0.868f, 0.070f,hy+0.178f,-0.816f, WD2,180);
        // Ноздри
        b(m,T,-0.060f,hy+0.118f,-0.876f,-0.024f,hy+0.145f,-0.858f, WNS,255);
        b(m,T, 0.024f,hy+0.118f,-0.876f, 0.060f,hy+0.145f,-0.858f, WNS,255);
        b(m,T,-0.055f,hy+0.120f,-0.878f,-0.030f,hy+0.142f,-0.860f, WD2,255);
        b(m,T, 0.030f,hy+0.120f,-0.878f, 0.055f,hy+0.142f,-0.860f, WD2,255);

        // Желобок (фильтрум)
        b(m,T,-0.008f,hy+0.040f,-0.850f, 0.008f,hy+0.118f,-0.840f, WD2,180);

        // Губы
        b(m,T,-0.122f,hy-0.062f,-0.842f,-0.018f,hy-0.045f,-0.835f, WD2,200);
        b(m,T, 0.018f,hy-0.062f,-0.842f, 0.122f,hy-0.045f,-0.835f, WD2,200);

        // ── Глаза — полная детализация ────────────────────────────────
        // Орбита (углубление)
        b(m,T,-0.240f,hy+0.118f,-0.660f,-0.132f,hy+0.208f,-0.638f, WD2,255);
        b(m,T, 0.132f,hy+0.118f,-0.660f, 0.240f,hy+0.208f,-0.638f, WD2,255);
        // Склера (белок, едва виден)
        b(m,T,-0.236f,hy+0.122f,-0.658f,-0.136f,hy+0.204f,-0.640f, WB2,240);
        b(m,T, 0.136f,hy+0.122f,-0.658f, 0.236f,hy+0.204f,-0.640f, WB2,240);
        // Радужка
        b(m,T,-0.232f,hy+0.126f,-0.660f,-0.140f,hy+0.200f,-0.642f, WE1,255);
        b(m,T, 0.140f,hy+0.126f,-0.660f, 0.232f,hy+0.200f,-0.642f, WE1,255);
        // Тёмный ободок радужки
        b(m,T,-0.230f,hy+0.128f,-0.661f,-0.142f,hy+0.198f,-0.643f, WE2,255);
        b(m,T, 0.142f,hy+0.128f,-0.661f, 0.230f,hy+0.198f,-0.643f, WE2,255);
        // Зрачок
        b(m,T,-0.218f,hy+0.136f,-0.662f,-0.156f,hy+0.192f,-0.644f, WPU,255);
        b(m,T, 0.156f,hy+0.136f,-0.662f, 0.218f,hy+0.192f,-0.644f, WPU,255);
        // Блик
        b(m,T,-0.205f,hy+0.172f,-0.663f,-0.190f,hy+0.186f,-0.647f, WHI,210);
        b(m,T, 0.190f,hy+0.172f,-0.663f, 0.205f,hy+0.186f,-0.647f, WHI,210);
        // Верхнее веко
        b(m,T,-0.238f,hy+0.198f,-0.660f,-0.134f,hy+0.212f,-0.639f, WD1,255);
        b(m,T, 0.134f,hy+0.198f,-0.660f, 0.238f,hy+0.212f,-0.639f, WD1,255);
        // Надбровные дуги (асимметрия)
        b(m,T,-0.235f,hy+0.210f,-0.650f,-0.138f,hy+0.252f,-0.630f, WD1,255);
        b(m,T, 0.138f,hy+0.210f,-0.650f, 0.235f,hy+0.252f,-0.630f, WD1,255);
        b(m,T,-0.228f,hy+0.245f,-0.648f,-0.145f,hy+0.260f,-0.632f, WD2,220);
        b(m,T, 0.145f,hy+0.245f,-0.648f, 0.228f,hy+0.260f,-0.632f, WD2,220);

        // Усы (тонкие горизонтальные полосы)
        b(m,T,-0.148f,hy+0.062f,-0.852f,-0.090f,hy+0.070f,-0.680f, WF2,130);
        b(m,T, 0.090f,hy+0.062f,-0.852f, 0.148f,hy+0.070f,-0.680f, WF2,130);
        b(m,T,-0.148f,hy+0.038f,-0.845f,-0.090f,hy+0.045f,-0.680f, WF3,100);
        b(m,T, 0.090f,hy+0.038f,-0.845f, 0.148f,hy+0.045f,-0.680f, WF3,100);

        // ── Уши — 5 слоёв каждое ────────────────────────────────────
        // Внешняя раковина
        b(m,T,-0.252f,hy+0.258f,-0.582f,-0.104f,hy+0.535f,-0.388f, WD1,255);
        b(m,T, 0.104f,hy+0.258f,-0.582f, 0.252f,hy+0.535f,-0.388f, WD1,255);
        // Средний слой
        b(m,T,-0.242f,hy+0.270f,-0.570f,-0.115f,hy+0.518f,-0.398f, WF2,255);
        b(m,T, 0.115f,hy+0.270f,-0.570f, 0.242f,hy+0.518f,-0.398f, WF2,255);
        // Внутренняя раковина
        b(m,T,-0.232f,hy+0.282f,-0.558f,-0.128f,hy+0.498f,-0.408f, WI1,255);
        b(m,T, 0.128f,hy+0.282f,-0.558f, 0.232f,hy+0.498f,-0.408f, WI1,255);
        // Центральный канал
        b(m,T,-0.218f,hy+0.296f,-0.545f,-0.145f,hy+0.472f,-0.418f, WI2,255);
        b(m,T, 0.145f,hy+0.296f,-0.545f, 0.218f,hy+0.472f,-0.418f, WI2,255);
        // Волоски внутри (тёмная точка)
        b(m,T,-0.198f,hy+0.312f,-0.540f,-0.162f,hy+0.440f,-0.422f, WD2,180);
        b(m,T, 0.162f,hy+0.312f,-0.540f, 0.198f,hy+0.440f,-0.422f, WD2,180);

        // ══ НОГИ — каждая из 4 частей (бедро/голень/лапа/когти) ══════
        float bs = sit * 0.23f;
        wolfLeg(ms,T,-0.238f,0.22f+by,-0.310f,  ph*0.195f*run, false,0f);
        wolfLeg(ms,T, 0.238f,0.22f+by,-0.310f, -ph*0.195f*run, false,0f);
        wolfLeg(ms,T,-0.218f,0.22f+by, 0.188f, -ph*0.195f*run, true, bs);
        wolfLeg(ms,T, 0.218f,0.22f+by, 0.188f,  ph*0.195f*run, true, bs);
    }

    private void wolfLeg(MatrixStack ms, Tessellator T,
                         float ox,float oy,float oz,float sw,boolean back,float sitF){
        ms.push();
        ms.translate(ox,oy,oz);
        float hw = back?0.092f:0.082f, hh = back?0.270f:0.230f;
        ms.multiply(new Quaternionf().rotateX(sw+sitF));
        // Бедро — 2 слоя (объём)
        b(ms,T,-hw,-hh,-hw, hw,0,hw, WF2,255);
        b(ms,T,-hw+0.008f,-hh+0.010f,-hw+0.005f, hw-0.008f,0,hw-0.005f, WF1,255);
        ms.translate(0,-hh,0);
        // Колено
        b(ms,T,-hw-0.012f,-0.028f,-hw-0.010f, hw+0.012f,0.012f,hw+0.010f, WD2,255);
        ms.multiply(new Quaternionf().rotateX(-sw*0.55f-sitF*0.75f));
        float lw=hw-0.010f, lh=back?0.228f:0.208f;
        // Голень — 2 слоя
        b(ms,T,-lw,-lh,-lw, lw,0,lw, WD1,255);
        b(ms,T,-lw+0.007f,-lh+0.008f,-lw+0.005f, lw-0.007f,0,lw-0.005f, WD2,255);
        ms.translate(0,-lh,0);
        // Лапа
        b(ms,T,-0.105f,-0.058f,-0.128f, 0.105f,0.010f,0.085f, WD1,255);
        b(ms,T,-0.098f,-0.050f,-0.120f, 0.098f,0.005f,0.078f, WF3,255);
        // Пальцы (3 выступа)
        b(ms,T,-0.095f,-0.068f,-0.138f,-0.058f,-0.048f,-0.118f, WD2,255);
        b(ms,T,-0.025f,-0.068f,-0.138f, 0.025f,-0.048f,-0.118f, WD2,255);
        b(ms,T, 0.058f,-0.068f,-0.138f, 0.095f,-0.048f,-0.118f, WD2,255);
        // Когти
        b(ms,T,-0.088f,-0.075f,-0.145f,-0.062f,-0.058f,-0.128f, WCL,255);
        b(ms,T,-0.018f,-0.075f,-0.145f, 0.018f,-0.058f,-0.128f, WCL,255);
        b(ms,T, 0.062f,-0.075f,-0.145f, 0.088f,-0.058f,-0.128f, WCL,255);
        ms.pop();
    }

    // ═══════════════════════════════════════════════════════════════════
    //  FOX  — ~140 деталей
    // ═══════════════════════════════════════════════════════════════════
    private void fox(MatrixStack ms) {
        Tessellator T = Tessellator.getInstance();
        float sit = sitAmount;
        float run = Math.min(1f, moveSpeed * 155f);
        float ph  = (float) Math.sin(animFrame * 3.4f);

        // ══ ХВОСТ — 6 сегментов, вверх ═══════════════════════════════
        ms.push();
        ms.translate(0, 0.38f, 0.28f);
        ms.multiply(new Quaternionf().rotateX(-(tailPitch * 0.85f + 0.35f)));
        b(ms,T,-0.100f,0,-0.093f, 0.100f,0.18f,0.093f, FO1,255);
        ms.translate(0,0.16f,0); ms.multiply(new Quaternionf().rotateX(-0.28f));
        b(ms,T,-0.112f,0,-0.105f, 0.112f,0.19f,0.105f, FO2,255);
        ms.translate(0,0.17f,0); ms.multiply(new Quaternionf().rotateX(-0.22f));
        b(ms,T,-0.115f,0,-0.108f, 0.115f,0.20f,0.108f, FO1,255);
        // Пушистое утолщение
        b(ms,T,-0.125f,-0.015f,-0.118f, 0.125f,0.15f,0.118f, FO2,200);
        ms.translate(0,0.18f,0); ms.multiply(new Quaternionf().rotateX(-0.18f));
        b(ms,T,-0.112f,0,-0.104f, 0.112f,0.18f,0.104f, FO1,255);
        ms.translate(0,0.16f,0); ms.multiply(new Quaternionf().rotateX(-0.12f));
        b(ms,T,-0.095f,0,-0.088f, 0.095f,0.17f,0.088f, FO2,255);
        // Белый кончик
        ms.translate(0,0.15f,0);
        b(ms,T,-0.080f,0,-0.072f, 0.080f,0.15f,0.072f, FW1,255);
        b(ms,T,-0.065f,0.03f,-0.058f, 0.065f,0.13f,0.058f, FW2,255);
        ms.pop();

        // ══ ТЕЛО ══════════════════════════════════════════════════════
        float by = -0.032f * sit;
        Matrix4f m = ms.peek().getPositionMatrix();

        b(m,T,-0.262f,0.14f+by,-0.415f, 0.262f,0.565f+by, 0.320f, FO2,255);
        b(m,T,-0.252f,0.16f+by,-0.405f, 0.252f,0.558f+by, 0.310f, FO1,255);
        // Спина тёмнее
        b(m,T,-0.195f,0.505f+by,-0.375f, 0.195f,0.562f+by, 0.265f, FK1,255);
        b(m,T,-0.125f,0.528f+by,-0.355f, 0.125f,0.565f+by, 0.245f, FK2,255);
        // Живот белый
        b(m,T,-0.182f,0.140f+by,-0.372f, 0.182f,0.408f+by, 0.272f, FW1,255);
        b(m,T,-0.148f,0.155f+by,-0.358f, 0.148f,0.385f+by, 0.255f, FW2,255);
        // Грудь
        b(m,T,-0.152f,0.285f+by,-0.422f, 0.152f,0.552f+by,-0.352f, FW1,255);
        b(m,T,-0.120f,0.312f+by,-0.425f, 0.120f,0.528f+by,-0.358f, FW2,255);
        // Бочок
        for (int i=0;i<3;i++) {
            float ry=0.185f+i*0.115f+by;
            b(m,T,-0.265f,ry,-0.362f,-0.255f,ry+0.055f, 0.225f, FK1,165);
            b(m,T, 0.255f,ry,-0.362f, 0.265f,ry+0.055f, 0.225f, FK1,165);
        }

        // ══ ШЕЯ ═══════════════════════════════════════════════════════
        b(m,T,-0.138f,0.502f+by,-0.518f, 0.138f,0.712f+by,-0.302f, FO1,255);
        b(m,T,-0.120f,0.518f+by,-0.502f, 0.120f,0.700f+by,-0.315f, FO2,255);
        b(m,T,-0.108f,0.532f+by,-0.490f, 0.108f,0.688f+by,-0.328f, FW1,255); // горло

        // ══ ГОЛОВА ════════════════════════════════════════════════════
        float hy = 0.688f + by;

        b(m,T,-0.212f,hy,       -0.582f, 0.212f,hy+0.252f,-0.272f, FO1,255);
        b(m,T,-0.200f,hy+0.010f,-0.568f, 0.200f,hy+0.245f,-0.280f, FO2,255);
        // Темя
        b(m,T,-0.190f,hy+0.205f,-0.560f, 0.190f,hy+0.252f,-0.285f, FK1,255);
        b(m,T,-0.130f,hy+0.228f,-0.545f, 0.130f,hy+0.252f,-0.295f, FK2,255);
        // Щёки пышные (лиса)
        b(m,T,-0.255f,hy+0.020f,-0.538f,-0.195f,hy+0.195f,-0.300f, FO1,255);
        b(m,T, 0.195f,hy+0.020f,-0.538f, 0.255f,hy+0.195f,-0.300f, FO1,255);
        b(m,T,-0.272f,hy+0.035f,-0.510f,-0.252f,hy+0.175f,-0.318f, FO2,255);
        b(m,T, 0.252f,hy+0.035f,-0.510f, 0.272f,hy+0.175f,-0.318f, FO2,255);

        // Острая длинная морда — 3 секции
        b(m,T,-0.115f,hy+0.042f,-0.862f, 0.115f,hy+0.158f,-0.695f, FO1,255);
        b(m,T,-0.105f,hy+0.050f,-0.848f, 0.105f,hy+0.152f,-0.705f, FO2,255);
        b(m,T,-0.108f,hy+0.030f,-0.695f, 0.108f,hy+0.148f,-0.578f, FO1,255);
        // Нижняя челюсть
        b(m,T,-0.094f,hy-0.048f,-0.842f, 0.094f,hy+0.032f,-0.575f, FW1,255);
        b(m,T,-0.082f,hy-0.038f,-0.828f, 0.082f,hy+0.028f,-0.582f, FW2,255);
        // Подбородок
        b(m,T,-0.060f,hy-0.052f,-0.802f, 0.060f,hy-0.012f,-0.585f, FW1,190);

        // Нос
        b(m,T,-0.062f,hy+0.108f,-0.878f, 0.062f,hy+0.162f,-0.822f, FN, 255);
        b(m,T,-0.057f,hy+0.112f,-0.874f, 0.057f,hy+0.158f,-0.826f, WD2,180);
        b(m,T,-0.050f,hy+0.108f,-0.882f,-0.020f,hy+0.138f,-0.862f, FNS,255);
        b(m,T, 0.020f,hy+0.108f,-0.882f, 0.050f,hy+0.138f,-0.862f, FNS,255);

        // Губы
        b(m,T,-0.112f,hy-0.050f,-0.856f,-0.022f,hy-0.034f,-0.848f, FW1,200);
        b(m,T, 0.022f,hy-0.050f,-0.856f, 0.112f,hy-0.034f,-0.848f, FW1,200);

        // Глаза зелёные
        b(m,T,-0.198f,hy+0.085f,-0.622f,-0.115f,hy+0.165f,-0.600f, WD2,255);
        b(m,T, 0.115f,hy+0.085f,-0.622f, 0.198f,hy+0.165f,-0.600f, WD2,255);
        b(m,T,-0.194f,hy+0.090f,-0.624f,-0.120f,hy+0.162f,-0.602f, FE1,255);
        b(m,T, 0.120f,hy+0.090f,-0.624f, 0.194f,hy+0.162f,-0.602f, FE1,255);
        b(m,T,-0.188f,hy+0.095f,-0.625f,-0.125f,hy+0.158f,-0.603f, FE2,255);
        b(m,T, 0.125f,hy+0.095f,-0.625f, 0.188f,hy+0.158f,-0.603f, FE2,255);
        b(m,T,-0.178f,hy+0.102f,-0.626f,-0.135f,hy+0.152f,-0.604f, FPI,255);
        b(m,T, 0.135f,hy+0.102f,-0.626f, 0.178f,hy+0.152f,-0.604f, FPI,255);
        // Блик
        b(m,T,-0.168f,hy+0.140f,-0.627f,-0.155f,hy+0.152f,-0.605f, WHI,200);
        b(m,T, 0.155f,hy+0.140f,-0.627f, 0.168f,hy+0.152f,-0.605f, WHI,200);
        // Веки
        b(m,T,-0.196f,hy+0.162f,-0.622f,-0.118f,hy+0.174f,-0.600f, FK1,255);
        b(m,T, 0.118f,hy+0.162f,-0.622f, 0.196f,hy+0.174f,-0.600f, FK1,255);

        // Усы лисы
        b(m,T,-0.115f,hy+0.048f,-0.865f,-0.075f,hy+0.055f,-0.698f, FW1,145);
        b(m,T, 0.075f,hy+0.048f,-0.865f, 0.115f,hy+0.055f,-0.698f, FW1,145);

        // Большие уши — 5 слоёв
        b(m,T,-0.222f,hy+0.228f,-0.545f,-0.090f,hy+0.588f,-0.368f, FK1,255);
        b(m,T, 0.090f,hy+0.228f,-0.545f, 0.222f,hy+0.588f,-0.368f, FK1,255);
        b(m,T,-0.210f,hy+0.242f,-0.530f,-0.105f,hy+0.568f,-0.380f, FK2,255);
        b(m,T, 0.105f,hy+0.242f,-0.530f, 0.210f,hy+0.568f,-0.380f, FK2,255);
        b(m,T,-0.198f,hy+0.258f,-0.515f,-0.118f,hy+0.545f,-0.392f, FIE,255);
        b(m,T, 0.118f,hy+0.258f,-0.515f, 0.198f,hy+0.545f,-0.392f, FIE,255);
        b(m,T,-0.184f,hy+0.275f,-0.500f,-0.132f,hy+0.520f,-0.405f, FO2,230);
        b(m,T, 0.132f,hy+0.275f,-0.500f, 0.184f,hy+0.520f,-0.405f, FO2,230);
        b(m,T,-0.168f,hy+0.292f,-0.485f,-0.148f,hy+0.492f,-0.415f, FK1,180);
        b(m,T, 0.148f,hy+0.292f,-0.485f, 0.168f,hy+0.492f,-0.415f, FK1,180);

        // ══ НОГИ ══════════════════════════════════════════════════════
        float bs = sit * 0.21f;
        foxLeg(ms,T,-0.200f,0.14f+by,-0.280f,  ph*0.185f*run, false,0f);
        foxLeg(ms,T, 0.200f,0.14f+by,-0.280f, -ph*0.185f*run, false,0f);
        foxLeg(ms,T,-0.182f,0.14f+by, 0.170f, -ph*0.185f*run, true, bs);
        foxLeg(ms,T, 0.182f,0.14f+by, 0.170f,  ph*0.185f*run, true, bs);
    }

    private void foxLeg(MatrixStack ms,Tessellator T,
                        float ox,float oy,float oz,float sw,boolean back,float sitF){
        ms.push();
        ms.translate(ox,oy,oz);
        float hw=back?0.082f:0.072f, hh=back?0.245f:0.208f;
        ms.multiply(new Quaternionf().rotateX(sw+sitF));
        b(ms,T,-hw,-hh,-hw, hw,0,hw, FO1,255);
        b(ms,T,-hw+0.007f,-hh+0.008f,-hw+0.005f, hw-0.007f,0,hw-0.005f, FO2,255);
        ms.translate(0,-hh,0);
        b(ms,T,-hw-0.010f,-0.022f,-hw-0.008f, hw+0.010f,0.010f,hw+0.008f, FK1,255); // колено
        ms.multiply(new Quaternionf().rotateX(-sw*0.55f-sitF*0.75f));
        float lw=hw-0.009f, lh=back?0.210f:0.190f;
        b(ms,T,-lw,-lh,-lw, lw,0,lw, FK1,255);
        b(ms,T,-lw+0.006f,-lh+0.007f,-lw+0.004f, lw-0.006f,0,lw-0.004f, FK2,255);
        ms.translate(0,-lh,0);
        // Лапа + пальцы
        b(ms,T,-0.092f,-0.052f,-0.115f, 0.092f,0.008f,0.076f, FK1,255);
        b(ms,T,-0.082f,-0.052f,-0.118f,-0.050f,-0.040f,-0.102f, FK2,255);
        b(ms,T,-0.022f,-0.052f,-0.118f, 0.022f,-0.040f,-0.102f, FK2,255);
        b(ms,T, 0.050f,-0.052f,-0.118f, 0.082f,-0.040f,-0.102f, FK2,255);
        ms.pop();
    }

    // ═══════════════════════════════════════════════════════════════════
    //  FAIRY  — детализированный гуманоид ~150 деталей
    // ═══════════════════════════════════════════════════════════════════
    private void fairy(MatrixStack ms) {
        Tessellator T = Tessellator.getInstance();
        float hue  = (animFrame * 0.062f) % 1f;
        int[] C1   = hsvToRgb(hue, 0.85f, 1.0f);
        int[] C2   = hsvToRgb((hue+0.33f)%1f, 0.85f, 1.0f);
        int[] C3   = hsvToRgb((hue+0.66f)%1f, 0.85f, 1.0f);
        int[] HAIR = hsvToRgb((hue+0.55f)%1f, 0.72f, 0.92f);
        int[] HA2  = hsvToRgb((hue+0.58f)%1f, 0.65f, 0.80f);
        boolean moving = moveSpeed > 0.002f;
        float wf   = (float) Math.sin(animFrame * 18f);
        float aSwing = (float) Math.sin(animFrame * 2.8f) * 0.09f;
        float lSwing = (float) Math.sin(animFrame * 2.8f) * 0.05f;
        Matrix4f m  = ms.peek().getPositionMatrix();

        // ══ КРЫЛЬЯ — аддитивное свечение ══════════════════════════════
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        float wa = wf * 0.88f;
        // Верхние (большие) — 3 секции каждое
        ms.push(); ms.translate(-0.075f, 0.305f, 0.018f);
        ms.multiply(new Quaternionf().rotateY(-wa));
        Matrix4f wm = ms.peek().getPositionMatrix();
        wing4(wm,T, 0,0.22f,0, -0.60f,0.42f,0, -0.65f,0.18f,0.04f, -0.05f,0.01f,0.02f, C1,120);
        wing4(wm,T, 0,0.22f,0, -0.65f,0.18f,0.04f, -0.58f,-0.05f,0.05f, -0.04f,0.01f,0.02f, C2,100);
        wing4(wm,T, 0,0.22f,0, -0.58f,-0.05f,0.05f, -0.38f,-0.18f,0.03f, -0.04f,0.01f,0.02f, C3, 80);
        ms.pop();
        ms.push(); ms.translate( 0.075f, 0.305f, 0.018f);
        ms.multiply(new Quaternionf().rotateY(wa));
        wm = ms.peek().getPositionMatrix();
        wing4(wm,T, 0,0.22f,0,  0.60f,0.42f,0,  0.65f,0.18f,0.04f,  0.05f,0.01f,0.02f, C1,120);
        wing4(wm,T, 0,0.22f,0,  0.65f,0.18f,0.04f,  0.58f,-0.05f,0.05f,  0.04f,0.01f,0.02f, C2,100);
        wing4(wm,T, 0,0.22f,0,  0.58f,-0.05f,0.05f,  0.38f,-0.18f,0.03f,  0.04f,0.01f,0.02f, C3, 80);
        ms.pop();
        // Нижние крылышки
        ms.push(); ms.translate(-0.062f, 0.172f, 0.018f);
        ms.multiply(new Quaternionf().rotateY(-wa*0.65f));
        wm = ms.peek().getPositionMatrix();
        wing4(wm,T, 0,0,0, -0.42f,0.05f,0, -0.38f,-0.22f,0.04f, 0,0,0, C2,98);
        ms.pop();
        ms.push(); ms.translate( 0.062f, 0.172f, 0.018f);
        ms.multiply(new Quaternionf().rotateY(wa*0.65f));
        wm = ms.peek().getPositionMatrix();
        wing4(wm,T, 0,0,0,  0.42f,0.05f,0,  0.38f,-0.22f,0.04f, 0,0,0, C2,98);
        ms.pop();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);

        // ══ ТЕЛО / ПЛАТЬЕ ═════════════════════════════════════════════
        // Корсет
        b(m,T,-0.095f,0.062f,-0.092f, 0.095f,0.368f,0.092f, C1, 255);
        b(m,T,-0.088f,0.072f,-0.085f, 0.088f,0.360f,0.085f, C2, 255);
        // Декор корсета
        b(m,T,-0.005f,0.078f,-0.094f, 0.005f,0.355f,-0.088f, C3, 255); // центральная полоска
        b(m,T,-0.088f,0.215f,-0.095f, 0.088f,0.228f,-0.089f, C3, 255); // горизонтальный пояс
        // Плечи
        b(m,T,-0.122f,0.315f,-0.080f,-0.090f,0.372f, 0.075f, C1,255);
        b(m,T, 0.090f,0.315f,-0.080f, 0.122f,0.372f, 0.075f, C1,255);
        // Юбка (расширяется ярусами)
        b(m,T,-0.122f,0.000f,-0.120f, 0.122f,0.068f, 0.120f, C2,255);
        b(m,T,-0.138f,-0.062f,-0.135f, 0.138f,0.005f, 0.135f, C3,255);
        b(m,T,-0.148f,-0.118f,-0.145f, 0.148f,-0.058f,0.145f, C2,245);
        b(m,T,-0.135f,-0.165f,-0.132f, 0.135f,-0.115f,0.132f, C1,230);
        // Оборки
        for (int i=0;i<4;i++) {
            float fy=-0.168f+i*0.052f;
            b(m,T,-0.150f+i*0.004f,fy,-0.148f+i*0.004f, 0.150f-i*0.004f,fy+0.018f,0.148f-i*0.004f, C3,200-i*20);
        }

        // ══ ГОЛОВА ════════════════════════════════════════════════════
        // Голова
        b(m,T,-0.108f,0.368f,-0.108f, 0.108f,0.598f, 0.108f, SK1,255);
        b(m,T,-0.100f,0.375f,-0.100f, 0.100f,0.592f, 0.100f, SK2,255);
        // Лоб чуть выпуклый
        b(m,T,-0.095f,0.532f,-0.112f, 0.095f,0.592f,-0.092f, SK1,255);
        // Подбородок
        b(m,T,-0.072f,0.368f,-0.085f, 0.072f,0.402f,-0.072f, SK2,255);
        // Щёки
        b(m,T,-0.112f,0.415f,-0.082f,-0.100f,0.528f,-0.022f, SK2,255);
        b(m,T, 0.100f,0.415f,-0.082f, 0.112f,0.528f,-0.022f, SK2,255);

        // Нос
        b(m,T,-0.020f,0.452f,-0.112f, 0.020f,0.468f,-0.108f, SK3,255);
        b(m,T,-0.015f,0.455f,-0.114f, 0.015f,0.465f,-0.112f, new int[]{165,108,95},255);

        // Рот
        b(m,T,-0.045f,0.412f,-0.111f, 0.045f,0.425f,-0.108f, LIP,255);
        b(m,T,-0.040f,0.414f,-0.112f, 0.040f,0.423f,-0.109f, new int[]{235,95,95},255);
        // Носогубная складка
        b(m,T,-0.025f,0.425f,-0.110f,-0.020f,0.452f,-0.107f, SK3,180);
        b(m,T, 0.020f,0.425f,-0.110f, 0.025f,0.452f,-0.107f, SK3,180);

        // Глаза — полная детализация
        // Орбита
        b(m,T,-0.092f,0.478f,-0.112f,-0.030f,0.528f,-0.110f, SK3,255);
        b(m,T, 0.030f,0.478f,-0.112f, 0.092f,0.528f,-0.110f, SK3,255);
        // Радужка (цвет меняется с hue)
        b(m,T,-0.088f,0.482f,-0.113f,-0.035f,0.524f,-0.111f, C1, 255);
        b(m,T, 0.035f,0.482f,-0.113f, 0.088f,0.524f,-0.111f, C1, 255);
        // Зрачок
        b(m,T,-0.080f,0.490f,-0.114f,-0.044f,0.516f,-0.112f, new int[]{6,4,4},255);
        b(m,T, 0.044f,0.490f,-0.114f, 0.080f,0.516f,-0.112f, new int[]{6,4,4},255);
        // Блик
        b(m,T,-0.074f,0.508f,-0.115f,-0.065f,0.516f,-0.113f, WHI,220);
        b(m,T, 0.065f,0.508f,-0.115f, 0.074f,0.516f,-0.113f, WHI,220);
        // Ресницы
        b(m,T,-0.094f,0.522f,-0.113f,-0.028f,0.532f,-0.110f, new int[]{18,10,10},255);
        b(m,T, 0.028f,0.522f,-0.113f, 0.094f,0.532f,-0.110f, new int[]{18,10,10},255);
        // Тени под глазами
        b(m,T,-0.088f,0.475f,-0.112f,-0.034f,0.484f,-0.110f, SK3,170);
        b(m,T, 0.034f,0.475f,-0.112f, 0.088f,0.484f,-0.110f, SK3,170);

        // Брови (яркие)
        b(m,T,-0.092f,0.532f,-0.112f,-0.032f,0.542f,-0.109f, HAIR,255);
        b(m,T, 0.032f,0.532f,-0.112f, 0.092f,0.542f,-0.109f, HAIR,255);

        // Уши эльфа
        b(m,T,-0.112f,0.455f,-0.070f,-0.102f,0.522f,-0.025f, SK1,255);
        b(m,T, 0.102f,0.455f,-0.070f, 0.112f,0.522f,-0.025f, SK1,255);
        b(m,T,-0.115f,0.510f,-0.055f,-0.104f,0.558f,-0.035f, SK2,255);
        b(m,T, 0.104f,0.510f,-0.055f, 0.115f,0.558f,-0.035f, SK2,255);
        b(m,T,-0.118f,0.548f,-0.042f,-0.105f,0.585f,-0.028f, SK1,255);
        b(m,T, 0.105f,0.548f,-0.042f, 0.118f,0.585f,-0.028f, SK1,255);

        // ══ ВОЛОСЫ — детальные ════════════════════════════════════════
        // Шапочка
        b(m,T,-0.120f,0.558f,-0.122f, 0.120f,0.648f, 0.122f, HAIR,255);
        b(m,T,-0.112f,0.565f,-0.114f, 0.112f,0.642f, 0.114f, HA2, 255);
        // Длинные пряди сзади (6 прядей)
        b(m,T,-0.108f,0.375f, 0.085f, 0.108f,0.560f, 0.148f, HAIR,255);
        b(m,T,-0.098f,0.295f, 0.078f, 0.098f,0.385f, 0.142f, HAIR,248);
        b(m,T,-0.085f,0.215f, 0.070f, 0.085f,0.302f, 0.135f, HAIR,235);
        b(m,T,-0.068f,0.138f, 0.062f, 0.068f,0.225f, 0.125f, HAIR,215);
        // Боковые пряди
        b(m,T,-0.122f,0.418f,-0.085f,-0.108f,0.558f, 0.108f, HAIR,255);
        b(m,T, 0.108f,0.418f,-0.085f, 0.122f,0.558f, 0.108f, HAIR,255);
        b(m,T,-0.125f,0.305f,-0.068f,-0.110f,0.425f, 0.095f, HAIR,240);
        b(m,T, 0.110f,0.305f,-0.068f, 0.125f,0.425f, 0.095f, HAIR,240);
        // Чёлка
        b(m,T,-0.108f,0.552f,-0.122f, 0.108f,0.570f,-0.082f, HAIR,255);
        b(m,T,-0.092f,0.540f,-0.116f,-0.020f,0.556f,-0.095f, HA2, 235);
        b(m,T, 0.020f,0.540f,-0.116f, 0.092f,0.556f,-0.095f, HA2, 235);

        // Корона
        b(m,T,-0.098f,0.644f,-0.098f, 0.098f,0.668f, 0.098f, C2, 255);
        b(m,T,-0.010f,0.664f,-0.010f, 0.010f,0.710f, 0.010f, C1, 255); // центральный зубец
        b(m,T,-0.068f,0.660f,-0.008f,-0.040f,0.694f, 0.008f, C3, 255);
        b(m,T, 0.040f,0.660f,-0.008f, 0.068f,0.694f, 0.008f, C3, 255);
        b(m,T,-0.095f,0.660f,-0.008f,-0.072f,0.682f, 0.008f, C2, 255);
        b(m,T, 0.072f,0.660f,-0.008f, 0.095f,0.682f, 0.008f, C2, 255);

        // ══ РУКИ ══════════════════════════════════════════════════════
        // Плечи
        b(m,T,-0.152f,0.322f+aSwing,-0.062f,-0.095f,0.368f,0.062f, SK1,255);
        b(m,T, 0.095f,0.322f-aSwing,-0.062f, 0.152f,0.368f,0.062f, SK1,255);
        // Предплечья
        b(m,T,-0.152f,0.205f+aSwing,-0.055f,-0.095f,0.325f,0.055f, SK2,255);
        b(m,T, 0.095f,0.205f-aSwing,-0.055f, 0.152f,0.325f,0.055f, SK2,255);
        // Перчатки
        b(m,T,-0.152f,0.148f+aSwing,-0.055f,-0.095f,0.210f,0.055f, C1, 255);
        b(m,T, 0.095f,0.148f-aSwing,-0.055f, 0.152f,0.210f,0.055f, C1, 255);
        // Кисти
        b(m,T,-0.148f,0.092f+aSwing,-0.050f,-0.098f,0.152f,0.050f, SK1,255);
        b(m,T, 0.098f,0.092f-aSwing,-0.050f, 0.148f,0.152f,0.050f, SK1,255);
        // Пальцы (5 пальцев на каждой руке — маленькие выступы)
        for (int i=0;i<5;i++) {
            float fx=-0.148f+i*0.012f, fw=0.009f;
            b(m,T, fx, 0.065f+aSwing,-0.048f, fx+fw, 0.092f+aSwing,0.048f, SK2,255);
            float fx2=0.148f-i*0.012f;
            b(m,T,fx2-fw, 0.065f-aSwing,-0.048f,fx2, 0.092f-aSwing,0.048f, SK2,255);
        }

        // ══ НОГИ ══════════════════════════════════════════════════════
        b(m,T,-0.068f,-0.145f+lSwing,-0.068f,-0.015f, 0.018f,0.068f, SK1,255);
        b(m,T, 0.015f,-0.145f-lSwing,-0.068f, 0.068f, 0.018f,0.068f, SK1,255);
        // Туфельки с каблуком
        b(m,T,-0.078f,-0.200f+lSwing,-0.092f,-0.010f,-0.142f,0.068f, C3, 255);
        b(m,T, 0.010f,-0.200f-lSwing,-0.092f, 0.078f,-0.142f,0.068f, C3, 255);
        // Каблук
        b(m,T,-0.072f,-0.208f+lSwing, 0.038f,-0.015f,-0.196f,0.068f, C2, 255);
        b(m,T, 0.015f,-0.208f-lSwing, 0.038f, 0.072f,-0.196f,0.068f, C2, 255);
        // Носок туфли
        b(m,T,-0.075f,-0.200f+lSwing,-0.105f,-0.012f,-0.188f,-0.088f, C1,255);
        b(m,T, 0.012f,-0.200f-lSwing,-0.105f, 0.075f,-0.188f,-0.088f, C1,255);

        // ══ СВЕЧЕНИЕ ══════════════════════════════════════════════════
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        for (int d=5; d>=1; d--) {
            float r=0.10f+d*0.072f;
            b(m,T,-r,-0.21f-r,-r, r,0.72f+r,r, C1, 10/d);
        }
        // 16 орбитальных частиц
        for (int i=0;i<16;i++) {
            float a  = animFrame*2.2f+i*0.393f;
            float rad= 0.42f+(float)Math.sin(animFrame*0.82f+i)*0.09f;
            float px = (float)Math.cos(a)*rad;
            float py = 0.28f+(float)Math.sin(a*1.6f)*0.28f;
            float pz = (float)Math.sin(a)*rad;
            int[] pc = hsvToRgb((hue+i/16f)%1f,0.9f,1f);
            b(m,T,px-0.025f,py-0.025f,pz-0.025f, px+0.025f,py+0.025f,pz+0.025f, pc,158);
        }
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
    }

    // ═══════════════════════════════════════════════════════════════════
    //  MINI WARDEN  — гипер-детализированный, 1:1 с реальным вардена
    // ═══════════════════════════════════════════════════════════════════
    private void warden(MatrixStack ms) {
        Tessellator T = Tessellator.getInstance();

        float pulse  = 0.5f + 0.5f * (float) Math.sin(animFrame * 2.9f);
        float pulse2 = 0.5f + 0.5f * (float) Math.sin(animFrame * 1.8f + 1.2f);
        int   sA     = (int)(128 + 127 * pulse);
        float run    = Math.min(1f, moveSpeed * 195f);
        float ph     = (float) Math.sin(animFrame * 2.4f);
        Matrix4f m   = ms.peek().getPositionMatrix();

        // ══ НОГИ — снизу вверх ══
        ms.push(); ms.translate(-0.28f, 0.02f, -0.08f);
        ms.multiply(new Quaternionf().rotateX(-ph * 0.16f * run));
        Matrix4f lLeg = ms.peek().getPositionMatrix();
        b(lLeg,T,-0.18f,-0.45f,-0.18f, 0.18f,0,-0.02f, MB1,255);
        b(lLeg,T,-0.16f,-0.44f,-0.16f, 0.16f,-0.01f,-0.04f, MB2,255);
        // нога-пластина
        b(lLeg,T,-0.19f,-0.06f,-0.19f, 0.19f,0.04f,-0.02f, MR1,255);
        ms.pop();
        ms.push(); ms.translate( 0.28f, 0.02f, -0.08f);
        ms.multiply(new Quaternionf().rotateX( ph * 0.16f * run));
        Matrix4f rLeg = ms.peek().getPositionMatrix();
        b(rLeg,T,-0.18f,-0.45f,-0.18f, 0.18f,0,-0.02f, MB1,255);
        b(rLeg,T,-0.16f,-0.44f,-0.16f, 0.16f,-0.01f,-0.04f, MB2,255);
        b(rLeg,T,-0.19f,-0.06f,-0.19f, 0.19f,0.04f,-0.02f, MR1,255);
        ms.pop();

        // ══ ОСНОВНОЕ ТЕЛО — характерный силуэт вардена ══
        // Нижняя часть туловища (уже)
        b(m,T,-0.38f,0.02f,-0.25f, 0.38f,0.45f,0.25f, MB1,255);
        b(m,T,-0.36f,0.04f,-0.23f, 0.36f,0.43f,0.23f, MB2,255);
        // Верхняя часть (шире — характерный вид вардена)
        b(m,T,-0.48f,0.42f,-0.27f, 0.48f,1.05f,0.27f, MB1,255);
        b(m,T,-0.46f,0.44f,-0.25f, 0.46f,1.03f,0.25f, MB2,255);
        b(m,T,-0.44f,0.46f,-0.23f, 0.44f,1.01f,0.23f, MB3,255);

        // Рёбра — горизонтальные пластины (6 пар, характерны для вардена)
        for (int i = 0; i < 6; i++) {
            float ry = 0.08f + i * 0.155f;
            float ww = 0.34f + i * 0.014f; // сужается книзу
            // Передние
            b(m,T,-ww, ry,        -0.272f, ww, ry + 0.068f, -0.260f, MR1, 255);
            // Задние
            b(m,T,-ww, ry,         0.260f, ww, ry + 0.068f,  0.272f, MR2, 255);
            // Боковые шипики
            b(m,T,-ww-0.028f,ry,-0.14f,-ww,ry+0.055f,0.14f, MR2,255);
            b(m,T, ww,ry,-0.14f, ww+0.028f,ry+0.055f,0.14f, MR2,255);
        }

        // Хребетные гребни (7 штук, характерные для спины вардена)
        for (int i = 0; i < 7; i++) {
            float ry  = 0.22f + i * 0.118f;
            float rh  = 0.058f + i * 0.007f;
            float osc = (i % 2 == 0) ? 0.018f : -0.018f;
            b(m,T, osc-0.030f, ry + 0.082f - rh, -0.278f,
                    osc+0.030f, ry + 0.082f,        -0.264f, MR1, 255);
        }

        // ══ МАССИВНЫЕ ПЛЕЧИ — ключевая черта вардена ══
        // Левое плечо
        b(m,T,-0.72f,0.62f,-0.33f,-0.44f,1.10f,-0.10f, MB1,255);
        b(m,T,-0.70f,0.64f,-0.31f,-0.45f,1.08f,-0.12f, MB2,255);
        b(m,T,-0.68f,0.66f,-0.29f,-0.46f,1.06f,-0.14f, MB3,255);
        // Плечевые шипы (2)
        b(m,T,-0.748f,0.980f,-0.230f,-0.608f,1.248f,-0.148f, MR1,255);
        b(m,T,-0.728f,0.862f,-0.350f,-0.628f,0.988f,-0.270f, MR1,255);
        b(m,T,-0.715f,0.900f,-0.355f,-0.635f,0.970f,-0.278f, MR2,255);

        // Правое плечо
        b(m,T, 0.44f,0.62f,-0.33f, 0.72f,1.10f,-0.10f, MB1,255);
        b(m,T, 0.45f,0.64f,-0.31f, 0.70f,1.08f,-0.12f, MB2,255);
        b(m,T, 0.46f,0.66f,-0.29f, 0.68f,1.06f,-0.14f, MB3,255);
        b(m,T, 0.608f,0.980f,-0.230f, 0.748f,1.248f,-0.148f, MR1,255);
        b(m,T, 0.628f,0.862f,-0.350f, 0.728f,0.988f,-0.270f, MR1,255);
        b(m,T, 0.635f,0.900f,-0.355f, 0.715f,0.970f,-0.278f, MR2,255);

        // ══ ГОЛОВА — широкая, приплюснутая ══
        b(m,T,-0.400f,1.055f,-0.400f, 0.400f,1.575f, 0.400f, MB1,255);
        b(m,T,-0.385f,1.062f,-0.385f, 0.385f,1.568f, 0.385f, MB2,255);
        b(m,T,-0.368f,1.070f,-0.368f, 0.368f,1.560f, 0.368f, MB3,255);

        // Гребни на голове (5 пар)
        b(m,T,-0.402f,1.472f,-0.210f, 0.402f,1.585f,-0.068f, MR1,255);
        b(m,T,-0.402f,1.472f, 0.068f, 0.402f,1.585f, 0.210f, MR1,255);
        b(m,T,-0.405f,1.415f,-0.265f, 0.405f,1.485f,-0.182f, MR2,255);
        b(m,T,-0.405f,1.415f, 0.182f, 0.405f,1.485f, 0.265f, MR2,255);
        // Боковые гребни
        b(m,T,-0.402f,1.358f,-0.090f,-0.386f,1.495f, 0.090f, MR1,255);
        b(m,T, 0.386f,1.358f,-0.090f, 0.402f,1.495f, 0.090f, MR1,255);

        // Антенна (3 сегмента с пульсацией)
        b(m,T,-0.070f,1.572f,-0.070f, 0.070f,1.755f, 0.070f, MG1,(int)(178+77*pulse));
        b(m,T,-0.056f,1.748f,-0.056f, 0.056f,1.812f, 0.056f, MG2,(int)(212+43*pulse));
        b(m,T,-0.040f,1.806f,-0.040f, 0.040f,1.848f, 0.040f, MG1,sA);
        // Кончик антенны — яркое свечение
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
        b(m,T,-0.032f,1.842f,-0.032f, 0.032f,1.872f, 0.032f, MG2,sA);
        for (int d=2;d>=1;d--) {
            float r2=0.018f+d*0.032f;
            b(m,T,-0.040f-r2,1.840f-r2,-0.040f-r2, 0.040f+r2,1.875f+r2,0.040f+r2, MG1,45/d);
        }
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);

        // Глаза (длинные, характерные для вардена — "трещины")
        int eA = (int)(185 + 70 * pulse);
        // Левый глаз
        b(m,T,-0.298f,1.245f,-0.405f,-0.105f,1.348f,-0.390f, MG1,eA);
        b(m,T,-0.290f,1.252f,-0.407f,-0.112f,1.342f,-0.393f, MG2,eA);
        // Правый глаз
        b(m,T, 0.105f,1.245f,-0.405f, 0.298f,1.348f,-0.390f, MG1,eA);
        b(m,T, 0.112f,1.252f,-0.407f, 0.290f,1.342f,-0.393f, MG2,eA);
        // Свечение глаз
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
        for (int d=3;d>=1;d--) {
            float r2=0.018f+d*0.042f;
            b(m,T,-0.298f-r2,1.245f-r2,-0.405f-r2,-0.105f+r2,1.348f+r2,-0.390f+r2, MG1,52/d);
            b(m,T, 0.105f-r2,1.245f-r2,-0.405f-r2, 0.298f+r2,1.348f+r2,-0.390f+r2, MG1,52/d);
        }
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);

        // "Рот" — три горизонтальные щели
        b(m,T,-0.212f,1.162f,-0.408f,-0.045f,1.178f,-0.393f, MG1,150);
        b(m,T, 0.045f,1.162f,-0.408f, 0.212f,1.178f,-0.393f, MG1,150);
        b(m,T,-0.105f,1.180f,-0.408f, 0.105f,1.195f,-0.393f, MG1,112);
        // Зубы — 5 штук
        for (int i=0; i<5; i++) {
            float tx = -0.195f + i * 0.086f;
            b(m,T, tx,1.145f,-0.410f, tx+0.038f,1.165f,-0.392f, MB3,255);
        }

        // ══ SOUL CORE — пульсирующий центр ══
        b(m,T,-0.148f,0.520f,-0.312f, 0.148f,0.978f,-0.292f, MS1,sA);
        b(m,T,-0.118f,0.548f,-0.314f, 0.118f,0.952f,-0.295f, MS2,(int)(sA*0.82f));
        b(m,T,-0.085f,0.582f,-0.316f, 0.085f,0.922f,-0.298f, MS3,(int)(sA*0.62f));
        // Внутренний блик
        b(m,T,-0.055f,0.618f,-0.317f, 0.055f,0.885f,-0.300f, new int[]{225,85,255},(int)(75*pulse2));

        // Свечение soul core
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
        for (int d=5;d>=1;d--) {
            float r2=0.018f+d*0.050f;
            b(m,T,-0.148f-r2,0.520f-r2,-0.312f-r2, 0.148f+r2,0.978f+r2,-0.292f+r2, MS1,28/d);
        }
        // 14 орбитальных частиц
        for (int i=0; i<14; i++) {
            float a2 = animFrame * 1.65f + i * 0.449f;
            float rad = 0.58f + (float)Math.sin(animFrame * 0.72f + i) * 0.12f;
            float px  = (float)Math.cos(a2) * rad;
            float py  = 0.70f + (float)Math.sin(a2 * 2.2f) * 0.33f;
            float pz  = (float)Math.sin(a2) * rad;
            // Чередуем цвет душ (пурпурный / голубой)
            int[] pc = i % 3 == 0 ? MG1 : MS1;
            b(m,T,px-0.036f,py-0.036f,pz-0.036f, px+0.036f,py+0.036f,pz+0.036f, pc,135);
        }
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);

        // ══ РУКИ — длинные, свисающие ══
        ms.push(); ms.translate(-0.685f, 0.925f, -0.215f);
        ms.multiply(new Quaternionf().rotateX( ph * 0.182f * run));
        Matrix4f lArm = ms.peek().getPositionMatrix();
        b(lArm,T,-0.135f,-0.555f,-0.135f, 0.135f, 0.000f, 0.005f, MB1,255);
        b(lArm,T,-0.122f,-0.542f,-0.122f, 0.122f,-0.012f,-0.008f, MB2,255);
        // Пластина на руке
        b(lArm,T,-0.138f,-0.168f,-0.140f, 0.138f,-0.098f,-0.128f, MR1,255);
        // Когти (4)
        for (int i=0;i<4;i++) {
            float cx2 = -0.118f + i * 0.082f;
            b(lArm,T,cx2,-0.582f,-0.148f,cx2+0.040f,-0.548f,-0.128f, MR1,255);
        }
        ms.pop();

        ms.push(); ms.translate( 0.685f, 0.925f, -0.215f);
        ms.multiply(new Quaternionf().rotateX(-ph * 0.182f * run));
        Matrix4f rArm = ms.peek().getPositionMatrix();
        b(rArm,T,-0.135f,-0.555f,-0.135f, 0.135f, 0.000f, 0.005f, MB1,255);
        b(rArm,T,-0.122f,-0.542f,-0.122f, 0.122f,-0.012f,-0.008f, MB2,255);
        b(rArm,T,-0.138f,-0.168f,-0.140f, 0.138f,-0.098f,-0.128f, MR1,255);
        for (int i=0;i<4;i++) {
            float cx2 = -0.118f + i * 0.082f;
            b(rArm,T,cx2,-0.582f,-0.148f,cx2+0.040f,-0.548f,-0.128f, MR1,255);
        }
        ms.pop();
    }
    // ═══════════════════════════════════════════════════════════════════
    //  HELPERS
    // ═══════════════════════════════════════════════════════════════════

    /** Удобный box с MatrixStack */
    private void b(MatrixStack ms,Tessellator T,
                   float x1,float y1,float z1,float x2,float y2,float z2,int[]c,int a){
        b(ms.peek().getPositionMatrix(),T,x1,y1,z1,x2,y2,z2,c,a);
    }

    /** Куб из 6 граней */
    private void b(Matrix4f m,Tessellator T,
                   float x1,float y1,float z1,float x2,float y2,float z2,int[]c,int a){
        if(a<=0)return;
        BufferBuilder buf=T.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
        q(buf,m,x1,y1,z1,x2,y1,z1,x2,y2,z1,x1,y2,z1,c,a);
        q(buf,m,x2,y1,z2,x1,y1,z2,x1,y2,z2,x2,y2,z2,c,a);
        q(buf,m,x1,y2,z1,x2,y2,z1,x2,y2,z2,x1,y2,z2,c,a);
        q(buf,m,x2,y1,z1,x1,y1,z1,x1,y1,z2,x2,y1,z2,c,a);
        q(buf,m,x2,y1,z1,x2,y1,z2,x2,y2,z2,x2,y2,z1,c,a);
        q(buf,m,x1,y1,z2,x1,y1,z1,x1,y2,z1,x1,y2,z2,c,a);
        try{BufferRenderer.drawWithGlobalProgram(buf.end());}catch(Exception ignored){}
    }

    private void q(BufferBuilder b,Matrix4f m,
                   float x1,float y1,float z1,float x2,float y2,float z2,
                   float x3,float y3,float z3,float x4,float y4,float z4,int[]c,int a){
        b.vertex(m,x1,y1,z1).color(c[0],c[1],c[2],a);
        b.vertex(m,x2,y2,z2).color(c[0],c[1],c[2],a);
        b.vertex(m,x3,y3,z3).color(c[0],c[1],c[2],a);
        b.vertex(m,x4,y4,z4).color(c[0],c[1],c[2],a);
    }

    /** 4-вершинное крыло (двустороннее) */
    private void wing4(Matrix4f m,Tessellator T,
                       float x0,float y0,float z0,float x1,float y1,float z1,
                       float x2,float y2,float z2,float x3,float y3,float z3,int[]c,int a){
        for(int s=0;s<2;s++){
            BufferBuilder b=T.begin(VertexFormat.DrawMode.QUADS,VertexFormats.POSITION_COLOR);
            if(s==0){
                b.vertex(m,x0,y0,z0).color(c[0],c[1],c[2],a);
                b.vertex(m,x1,y1,z1).color(c[0],c[1],c[2],a/2);
                b.vertex(m,x2,y2,z2).color(c[0],c[1],c[2],a/2);
                b.vertex(m,x3,y3,z3).color(c[0],c[1],c[2],a);
            }else{
                b.vertex(m,x3,y3,z3).color(c[0],c[1],c[2],a);
                b.vertex(m,x2,y2,z2).color(c[0],c[1],c[2],a/2);
                b.vertex(m,x1,y1,z1).color(c[0],c[1],c[2],a/2);
                b.vertex(m,x0,y0,z0).color(c[0],c[1],c[2],a);
            }
            try{BufferRenderer.drawWithGlobalProgram(b.end());}catch(Exception ignored){}
        }
    }

    private static double dist2D(double x1,double z1,double x2,double z2){
        double dx=x1-x2,dz=z1-z2; return Math.sqrt(dx*dx+dz*dz);
    }

    private static int[] hsvToRgb(float h,float s,float v){
        h=h%1f;if(h<0)h+=1f;
        int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);
        float r,g,bl;
        switch(i%6){
            case 0->{r=v;g=t;bl=p;} case 1->{r=q;g=v;bl=p;} case 2->{r=p;g=v;bl=t;}
            case 3->{r=p;g=q;bl=v;} case 4->{r=t;g=p;bl=v;} default->{r=v;g=p;bl=q;}
        }
        return new int[]{(int)(r*255),(int)(g*255),(int)(bl*255)};
    }
}