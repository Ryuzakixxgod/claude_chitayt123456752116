package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.BooleanSetting;

public class NoOverlayModule extends Module {
    // ИСПРАВЛЕНО: добавлено поле noSnow которое искал MixinInGameHud
    public final BooleanSetting noFire    = new BooleanSetting("No Fire",    true);
    public final BooleanSetting noTotem   = new BooleanSetting("No Totem",   true);
    public final BooleanSetting noPortal  = new BooleanSetting("No Portal",  false);
    public final BooleanSetting noPumpkin = new BooleanSetting("No Pumpkin", true);
    public final BooleanSetting noSnow    = new BooleanSetting("No Snow",    false);
    public final BooleanSetting noWater   = new BooleanSetting("No Water",   false);

    public NoOverlayModule() {
        super("NoOverlay", "Убирает нежелательные оверлеи", Category.MISC);
        addSettings(noFire, noTotem, noPortal, noPumpkin, noSnow, noWater);
    }

    public boolean skipCrystal() { return isEnabled(); }
}
