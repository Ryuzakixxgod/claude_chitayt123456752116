package ru.ryuzaki.module.modules.particles;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.RyuzakiRenderCache;

/**
 * AuraParticleModule — частицы по орбите вокруг игрока.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - new Quaternionf() × 2 на частицу в render.
 *    При 40 частицах × 240 FPS = 19 200 Quaternionf/сек → 2 за весь кадр.
 *    yaw/pitch квантернионы вычисляются ОДИН РАЗ для всех частиц,
 *    затем ms.push()/translate()/multiply(cached)/pop() — ноль новых объектов.
 *  - colorBuf[3] переиспользуется — ноль new int[] в getColor()
 */
public class AuraParticleModule extends Module {

    public final NumberSetting  density = new NumberSetting("Density",    40,  5, 120, 5);
    public final NumberSetting  speed   = new NumberSetting("Speed",       1.0, 0.1, 4.0, 0.1);
    public final NumberSetting  size    = new NumberSetting("Size",       0.05, 0.01, 0.2, 0.01);
    public final NumberSetting  radius  = new NumberSetting("Radius",     0.8, 0.2, 2.0, 0.1);
    public final BooleanSetting rainbow = new BooleanSetting("Rainbow",   true);
    public final BooleanSetting glow    = new BooleanSetting("Glow",      true);
    public final BooleanSetting rise    = new BooleanSetting("Rise",      false);

    private static final int MAX = 120;
    private final float[] pAngle    = new float[MAX];
    private final float[] pAngSpeed = new float[MAX];
    private final float[] pRadius   = new float[MAX];
    private final float[] pRiseY    = new float[MAX];
    private final float[] pPhase    = new float[MAX];
    private final float[] pHue      = new float[MAX];
    private int pCount = 0;

    private float globalHue = 0f;
    private boolean registered = false;

    // Кэш Quaternionf — переиспользуем, не создаём в render
    private final Quaternionf qYaw   = new Quaternionf();
    private final Quaternionf qPitch = new Quaternionf();

    // Переиспользуемый буфер цвета
    private final int[] colorBuf = new int[3];

    public AuraParticleModule() {
        super("AuraParticle", "Летающие частицы вокруг игрока", Category.PARTICLES);
        addSettings(density, speed, size, radius, rainbow, glow, rise);
    }

    @Override
    public void onEnable() {
        reinit();
        if (!registered) {
            WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
            registered = true;
        }
    }

    @Override public void onDisable() { pCount = 0; }

    private void reinit() {
        pCount = Math.min(density.getValue().intValue(), MAX);
        java.util.Random rng = new java.util.Random();
        float TAU = (float)(Math.PI * 2);
        for (int i = 0; i < pCount; i++) {
            pAngle[i]    = rng.nextFloat() * TAU;
            pAngSpeed[i] = (0.015f + rng.nextFloat() * 0.025f) * (rng.nextBoolean() ? 1 : -1);
            pRadius[i]   = radius.getValue().floatValue() * (0.7f + rng.nextFloat() * 0.6f);
            pRiseY[i]    = (float)(rng.nextDouble() * 2.0);
            pPhase[i]    = rng.nextFloat() * TAU;
            pHue[i]      = rng.nextFloat();
        }
    }

    @Override
    public void onUpdate() {
        if (!isEnabled()) return;
        int want = Math.min(density.getValue().intValue(), MAX);
        if (want != pCount) reinit();
        globalHue = (globalHue + 0.002f * speed.getValue().floatValue()) % 1f;
        float spd = speed.getValue().floatValue();
        for (int i = 0; i < pCount; i++) {
            pAngle[i] += pAngSpeed[i] * spd;
            if (rise.isEnabled()) {
                pRiseY[i] += 0.008f * spd;
                if (pRiseY[i] > 2.2f) pRiseY[i] = 0f;
            }
        }
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled() || pCount == 0) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        Vec3d cam = ctx.camera().getPos();
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        double px = mc.player.getX() - cam.x;
        double py = mc.player.getY() + mc.player.getHeight() * 0.5 - cam.y;
        double pz = mc.player.getZ() - cam.z;

        float yawRad   = (float)Math.toRadians(mc.gameRenderer.getCamera().getYaw());
        float pitchRad = (float)Math.toRadians(mc.gameRenderer.getCamera().getPitch());
        float sz       = size.getValue().floatValue();

        // Вычисляем квантернионы ОДИН РАЗ для всех частиц
        qYaw.identity().rotateY((float)(Math.PI + yawRad));
        qPitch.identity().rotateX(-pitchRad);

        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Tessellator tess = Tessellator.getInstance();

        // ── Glow pass ───────────────────────────────────────────────
        if (glow.isEnabled()) {
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
            BufferBuilder gb = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
            boolean any = false;
            for (int i = 0; i < pCount; i++) {
                float cx = (float)(px + Math.cos(pAngle[i]) * pRadius[i]);
                float cy = (float)(py + pRiseY[i]);
                float cz = (float)(pz + Math.sin(pAngle[i]) * pRadius[i]);
                getColor(i, colorBuf);
                float gs = sz * 4f;

                // ms.push/multiply/pop с кэшированными Quaternionf — ноль new Quaternionf()
                ms.push();
                ms.translate(cx, cy, cz);
                ms.multiply(qYaw);    // переиспользуем
                ms.multiply(qPitch);  // переиспользуем
                Matrix4f m = ms.peek().getPositionMatrix();
                gb.vertex(m, -gs, -gs, 0).color(colorBuf[0], colorBuf[1], colorBuf[2], 25);
                gb.vertex(m,  gs, -gs, 0).color(colorBuf[0], colorBuf[1], colorBuf[2], 25);
                gb.vertex(m,  gs,  gs, 0).color(colorBuf[0], colorBuf[1], colorBuf[2],  0);
                gb.vertex(m, -gs,  gs, 0).color(colorBuf[0], colorBuf[1], colorBuf[2],  0);
                ms.pop();
                any = true;
            }
            if (any) try { BufferRenderer.drawWithGlobalProgram(gb.end()); } catch (Exception e) {}
            else     try { gb.end(); } catch (Exception ignored) {}
        }

        // ── Core pass ───────────────────────────────────────────────
        RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA);
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        boolean any2 = false;
        for (int i = 0; i < pCount; i++) {
            float cx = (float)(px + Math.cos(pAngle[i]) * pRadius[i]);
            float cy = (float)(py + pRiseY[i]);
            float cz = (float)(pz + Math.sin(pAngle[i]) * pRadius[i]);
            float pulse = 0.85f + 0.15f * (float)Math.sin(RyuzakiRenderCache.now * 0.003f + pPhase[i]);
            float s2 = sz * pulse;
            getColor(i, colorBuf);

            ms.push();
            ms.translate(cx, cy, cz);
            ms.multiply(qYaw);
            ms.multiply(qPitch);
            Matrix4f m = ms.peek().getPositionMatrix();
            buf.vertex(m, -s2, -s2, 0).color(colorBuf[0], colorBuf[1], colorBuf[2], 190);
            buf.vertex(m,  s2, -s2, 0).color(colorBuf[0], colorBuf[1], colorBuf[2], 190);
            buf.vertex(m,  s2,  s2, 0).color(colorBuf[0], colorBuf[1], colorBuf[2], 190);
            buf.vertex(m, -s2,  s2, 0).color(colorBuf[0], colorBuf[1], colorBuf[2], 190);
            ms.pop();
            any2 = true;
        }
        if (any2) try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception e) {}
        else      try { buf.end(); } catch (Exception ignored) {}

        RenderSystem.enableCull();
        RenderSystem.disableBlend();
        RenderSystem.defaultBlendFunc();
    }

    /** Записывает цвет в out[3] — ноль аллокаций */
    private void getColor(int i, int[] out) {
        if (!rainbow.isEnabled()) {
            int[] r1 = RyuzakiRenderCache.rgb1;
            out[0] = r1[0]; out[1] = r1[1]; out[2] = r1[2];
        } else {
            RyuzakiRenderCache.hsvFill((globalHue + pHue[i] * 0.4f) % 1f, 0.85f, 1f, out);
        }
    }
}
