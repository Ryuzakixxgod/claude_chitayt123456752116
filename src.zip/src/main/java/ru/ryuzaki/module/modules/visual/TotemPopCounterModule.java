package ru.ryuzaki.module.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.render.DrawHelper;
import ru.ryuzaki.render.msdf.Fonts;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.awt.Color;
import java.util.*;

/**
 * TotemPopCounter 10/10 — animated pill HUD + chat notify.
 * Каждый поп = всплывающая карточка с анимацией появления/исчезновения.
 */
public class TotemPopCounterModule extends Module {
    public final BooleanSetting showSelf  = new BooleanSetting("Show Self",    true);
    public final BooleanSetting chat      = new BooleanSetting("Chat Notify",  true);
    public final BooleanSetting showHud   = new BooleanSetting("HUD Popup",    true);

    private static TotemPopCounterModule instance;

    private static class PopEvent {
        String name; int count; long time; float alpha=0f, scale=0f;
        float yOff=0f; // animation
        PopEvent(String n,int c){ name=n; count=c; time=System.currentTimeMillis(); }
    }

    private final Map<UUID,Integer>  popCounts  = new HashMap<>();
    private final Map<UUID,Long>     lastPop    = new HashMap<>();
    private final List<PopEvent>     popEvents  = new ArrayList<>();

    public TotemPopCounterModule(){
        super("TotemPops","Счётчик тотемов — красивый HUD",Category.VISUAL);
        addSettings(showSelf,chat,showHud);
        instance=this;
    }

    public static TotemPopCounterModule getInstance(){ return instance; }

    public void onTotemPop(PlayerEntity player){
        if(!isEnabled()) return;
        MinecraftClient mc=MinecraftClient.getInstance();
        if(player==mc.player&&!showSelf.isEnabled()) return;
        UUID id=player.getUuid();
        long now=System.currentTimeMillis();
        if(now-lastPop.getOrDefault(id,0L)<300) return;
        int count=popCounts.getOrDefault(id,0)+1;
        popCounts.put(id,count); lastPop.put(id,now);
        if(chat.isEnabled()&&mc.player!=null)
            mc.player.sendMessage(Text.literal("§c⚡ §f"+player.getName().getString()+" §cpop §7[§c"+count+"§7]"),false);
        if(showHud.isEnabled())
            synchronized(popEvents){ popEvents.add(new PopEvent(player.getName().getString(),count)); }
    }

    public void onTick(){
        if(!isEnabled()) return;
        long now=System.currentTimeMillis();
        popCounts.entrySet().removeIf(e->now-lastPop.getOrDefault(e.getKey(),0L)>300_000L);
    }

    public void renderHud(DrawContext ctx, int sw, int sh){
        if(!isEnabled()||!showHud.isEnabled()) return;
        synchronized(popEvents){
            long now=System.currentTimeMillis();
            Iterator<PopEvent> it=popEvents.iterator();
            float baseY=sh-60f;
            int idx=0;
            while(it.hasNext()){
                PopEvent p=it.next();
                float age=(now-p.time)/1000f;
                if(age>3.5f){it.remove();continue;}
                // Alpha animation
                float target = age<0.3f ? age/0.3f : age>3.0f ? 1f-(age-3.0f)/0.5f : 1f;
                p.alpha += (target-p.alpha)*0.18f;
                // Scale pop
                float scT = age<0.15f ? age/0.15f : 1f;
                p.scale += (scT-p.scale)*0.25f;
                // Y slide
                float yT = idx*36f;
                p.yOff += (yT-p.yOff)*0.18f;

                renderPopCard(ctx,p,sw,baseY-p.yOff);
                idx++;
            }
        }
    }

    private void renderPopCard(DrawContext ctx,PopEvent p,int sw,float y){
        MatrixStack ms=ctx.getMatrices();
        int[]c=RyuzakiRenderCache.rgb1;
        float W=180f,H=30f;
        float x=(sw-W)/2f;
        float cy=y+H/2f;
        int a=(int)(255*p.alpha);

        // Scale from center
        ms.push();
        ms.translate(x+W/2f,cy,0);
        ms.scale(p.scale,p.scale,1f);
        ms.translate(-x-W/2f,-cy,0);

        // Background
        DrawHelper.drawRect(ms,x,y,W,H,15f,new Color(8,6,18,(int)(220*p.alpha)));
        // Left accent
        DrawHelper.drawRect(ms,x,y+H*0.2f,2f,H*0.6f,1f,new Color(c[0],c[1],c[2],(int)(220*p.alpha)));
        // Border
        DrawHelper.drawOutline(ms,x,y,W,H,15f,new Color(c[0],c[1],c[2],(int)(60*p.alpha)),1f);

        // ⚡ icon
        drawT(ctx,ms,"⚡",x+10,cy-5,new Color(c[0],c[1],c[2],a),12f,false);
        // Name
        drawT(ctx,ms,p.name,x+28,cy-6,new Color(237,232,255,a),10.5f,true);
        // Count badge
        String cStr="×"+p.count;
        float cW=tw(cStr,9f)+10;
        float cX=x+W-cW-8;
        DrawHelper.drawRect(ms,cX,cy-9,cW,18f,9f,new Color(c[0],c[1],c[2],(int)(30*p.alpha)));
        drawT(ctx,ms,cStr,cX+5,cy-5,new Color(c[0],c[1],c[2],a),9f,true);
        // "popped totem" label
        drawT(ctx,ms,"popped totem",x+28,cy+2,new Color(150,140,180,(int)(160*p.alpha)),8f,false);

        ms.pop();
    }

    private void drawT(DrawContext ctx,MatrixStack ms,String t,float x,float y,Color col,float size,boolean bold){
        var f=bold?Fonts.BOLD:Fonts.MEDIUM;
        if(f!=null){try{DrawHelper.drawText(ms.peek().getPositionMatrix(),f.getFont(size),t,x,y,col);return;}catch(Exception ignored){}}
        int argb=(col.getAlpha()<<24)|(col.getRed()<<16)|(col.getGreen()<<8)|col.getBlue();
        ctx.drawText(MinecraftClient.getInstance().textRenderer,t,(int)x,(int)(y-7),argb,false);
    }
    private float tw(String s,float sz){
        if(Fonts.BOLD!=null)return Fonts.BOLD.getWidth(s,sz);
        return MinecraftClient.getInstance().textRenderer.getWidth(s);
    }
}
