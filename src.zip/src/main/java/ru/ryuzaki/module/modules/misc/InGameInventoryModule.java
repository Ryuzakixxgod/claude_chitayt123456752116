package ru.ryuzaki.module.modules.misc;
// src/main/java/ru/ryuzaki/module/modules/misc/InGameInventoryModule.java
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

public class InGameInventoryModule extends Module {
    public final BooleanSetting showHotbar = new BooleanSetting("Hotbar",   false);
    public final BooleanSetting showArmor  = new BooleanSetting("Armor",    true);
    public final BooleanSetting showMain   = new BooleanSetting("Main Inv", true);
    public final NumberSetting  scale      = new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.1);
    public final NumberSetting  posX       = new NumberSetting("X",     10.0, 0.0, 400.0, 1.0);
    public final NumberSetting  posY       = new NumberSetting("Y",     10.0, 0.0, 400.0, 1.0);

    public InGameInventoryModule() {
        super("InvHUD", "Инвентарь на экране", Category.MISC);
        addSettings(showHotbar, showArmor, showMain, scale, posX, posY);
    }

    public void renderHud(DrawContext ctx, int sw, int sh) {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null) return;

        int   x  = posX.getValue().intValue();
        int   y  = posY.getValue().intValue();
        float sc = scale.getValue().floatValue();

        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        ctx.getMatrices().scale(sc, sc, 1f);

        ctx.fill(0, 0, 166, 76, rgba(10, 8, 22, 200));
        ctx.fill(0, 0, 166, 1,  rgba(120, 60, 220, 180));
        ctx.fill(0, 75, 166, 76, rgba(120, 60, 220, 120));
        ctx.drawText(mc.textRenderer, Text.literal("§8Inventory"), 2, 2, 0xFF667788, false);

        if (showArmor.isEnabled()) {
            int ai = 0;
            for (ItemStack s : mc.player.getArmorItems()) {
                int ax = 2 + ai * 20, ay = 10;
                ctx.fill(ax, ay, ax+18, ay+18, rgba(15,12,30,200));
                ctx.fill(ax, ay, ax+18, ay+1,  rgba(80,40,160,150));
                if (!s.isEmpty()) {
                    ctx.drawItem(s, ax+1, ay+1);
                    drawCount(ctx, mc, s, ax+1, ay+1); // вместо drawItemInSlot
                }
                ai++;
            }
            ItemStack off = mc.player.getOffHandStack();
            ctx.fill(82, 10, 100, 28, rgba(15,12,30,200));
            if (!off.isEmpty()) {
                ctx.drawItem(off, 83, 11);
                drawCount(ctx, mc, off, 83, 11);
            }
        }

        if (showMain.isEnabled()) {
            var inv = mc.player.getInventory();
            for (int row = 0; row < 3; row++) {
                for (int col = 0; col < 9; col++) {
                    int sx = 2+col*18, sy = 32+row*18;
                    ItemStack s = inv.getStack(9 + row*9 + col);
                    ctx.fill(sx, sy, sx+18, sy+18, rgba(15,12,30,200));
                    ctx.fill(sx, sy, sx+18, sy+1,  rgba(40,20,80,120));
                    if (!s.isEmpty()) {
                        ctx.drawItem(s, sx+1, sy+1);
                        drawCount(ctx, mc, s, sx+1, sy+1);
                    }
                }
            }
        }

        if (showHotbar.isEnabled()) {
            var inv = mc.player.getInventory();
            for (int col = 0; col < 9; col++) {
                int sx = 2+col*18, sy = 68;
                ItemStack s = inv.getStack(col);
                boolean sel = inv.selectedSlot == col;
                ctx.fill(sx, sy, sx+18, sy+18, sel ? rgba(80,40,160,180) : rgba(15,12,30,200));
                if (!s.isEmpty()) {
                    ctx.drawItem(s, sx+1, sy+1);
                    drawCount(ctx, mc, s, sx+1, sy+1);
                }
            }
        }

        ctx.getMatrices().pop();
    }

    // Рисуем кол-во предмета вручную — заменяет drawItemInSlot
    private void drawCount(DrawContext ctx, MinecraftClient mc, ItemStack s, int x, int y) {
        if (s.getCount() > 1) {
            String cnt = String.valueOf(s.getCount());
            ctx.drawText(mc.textRenderer, cnt,
                    x + 17 - mc.textRenderer.getWidth(cnt),
                    y + 9, 0xFFFFFF, true);
        }
        // Полоска прочности
        if (s.isDamageable() && s.getDamage() > 0) {
            int barLen = Math.round(13f * (1f - (float)s.getDamage() / s.getMaxDamage()));
            ctx.fill(x+1, y+14, x+15, y+16, rgba(0,0,0,255));
            int g = (int)(255 * (1f - (float)s.getDamage() / s.getMaxDamage()));
            int r = 255 - g;
            ctx.fill(x+1, y+14, x+1+barLen, y+15, rgba(r, g, 0, 255));
        }
    }

    private static int rgba(int r,int g,int b,int a){
        return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }
}