package ru.ryuzaki.module.modules.particles;

import com.mojang.blaze3d.systems.RenderSystem;
import ru.ryuzaki.render.NativeGL;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.RyuzakiRenderCache;
import ru.ryuzaki.util.Vec3RingBuffer;

/**
 * TrailModule — след за игроком.
 *
 * ОПТИМИЗАЦИИ vs оригинал:
 *  - getColor() создавал new int[] на каждую точку каждый кадр.
 *    При длине 40 точек × 240 FPS = 9 600 new int[]/сек → 0.
 *    Теперь: один переиспользуемый int[3] colorBuf.
 *  - Void/Flame/Ice стили тоже больше не аллоцируют — пишем в colorBuf напрямую.
 */
public class TrailModule extends Module {

    public final ModeSetting    style     = new ModeSetting("Style","Cosmic","Cosmic","Rainbow","Void","Flame","Ice");
    public final NumberSetting  length    = new NumberSetting("Length",    40, 5, 120, 1);
    public final NumberSetting  thickness = new NumberSetting("Thickness", 2.0, 0.5, 5.0, 0.25);
    public final NumberSetting  opacity   = new NumberSetting("Opacity",   200, 50, 255, 5);
    public final BooleanSetting glow      = new BooleanSetting("Glow", true);

    private final Vec3RingBuffer trail = new Vec3RingBuffer(128);
    private float globalHue = 0f;
    private boolean registered = false;

    // Переиспользуемый буфер цвета — ноль new int[] в render
    private final int[] colorBuf = new int[3];

    public TrailModule() {
        super("Trail", "Эпический след за игроком", Category.PARTICLES);
        addSettings(style, length, thickness, opacity, glow);
    }

    @Override
    public void onEnable() {
        trail.clear();
        if (!registered) {
            WorldRenderEvents.AFTER_TRANSLUCENT.register(this::render);
            registered = true;
        }
    }

    @Override public void onDisable() { trail.clear(); }

    public void tick() {
        if (!isEnabled()) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        globalHue = (globalHue + 0.003f) % 1f;
        trail.push(mc.player.getX(), mc.player.getY() + mc.player.getHeight() * 0.1, mc.player.getZ());
    }

    private void render(WorldRenderContext ctx) {
        if (!isEnabled()) return;
        int total = Math.min(trail.size(), length.getValue().intValue());
        if (total < 2) return;

        Vec3d cam = ctx.camera().getPos();
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;

        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);
        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        Matrix4f mat   = ms.peek().getPositionMatrix();
        Tessellator tess = Tessellator.getInstance();
        float thick  = thickness.getValue().floatValue() * 0.018f;
        int   baseA  = opacity.getValue().intValue();

        if (glow.isEnabled()) {
            RenderSystem.blendFunc(org.lwjgl.opengl.GL11.GL_SRC_ALPHA, org.lwjgl.opengl.GL11.GL_ONE);
            drawRibbon(tess, mat, total, (int)(baseA * 0.08f), thick * 2.2f);
            RenderSystem.defaultBlendFunc();
        }
        drawRibbon(tess, mat, total, baseA, thick);

        ms.pop();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private void drawRibbon(Tessellator tess, Matrix4f mat, int total, int alpha, float thick) {
        BufferBuilder buf = tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        boolean any = false;

        for (int i = 0; i < total; i++) {
            float f = 1f - (float)i / (total - 1);
            int   a = (int)(alpha * f * f);
            if (a <= 0) continue;

            // getColor записывает в colorBuf — ноль аллокаций
            getColor(f, colorBuf);
            float x = trail.getX(i), y = trail.getY(i), z = trail.getZ(i);
            float h = thick * f / 2f;
            buf.vertex(mat, x - h, y - h, z).color(colorBuf[0], colorBuf[1], colorBuf[2], a);
            buf.vertex(mat, x + h, y + h, z).color(colorBuf[0], colorBuf[1], colorBuf[2], a);
            any = true;
        }
        if (any) try { BufferRenderer.drawWithGlobalProgram(buf.end()); } catch (Exception e) {}
        else     try { buf.end(); }                                       catch (Exception ignored) {}
    }

    /** Записывает цвет в out[3] — ноль аллокаций */
    private void getColor(float f, int[] out) {
        switch (style.getCurrent()) {
            case "Rainbow" -> RyuzakiRenderCache.hsvFill((globalHue + f * 0.3f) % 1f, 0.9f, 1f, out);
            case "Void"    -> { out[0] = (int)(40*f); out[1] = 0; out[2] = (int)(80*f); }
            case "Flame"   -> { out[0] = 255; out[1] = (int)(140*f); out[2] = 0; }
            case "Ice"     -> { out[0] = (int)(100+155*f); out[1] = (int)(180+75*f); out[2] = 255; }
            default -> {        // Cosmic
                int[] r1 = RyuzakiRenderCache.rgb1, r2 = RyuzakiRenderCache.rgb2;
                out[0] = (int)(r1[0] + (r2[0] - r1[0]) * f);
                out[1] = (int)(r1[1] + (r2[1] - r1[1]) * f);
                out[2] = (int)(r1[2] + (r2[2] - r1[2]) * f);
            }
        }
    }
}
