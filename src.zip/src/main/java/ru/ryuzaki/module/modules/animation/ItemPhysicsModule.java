package ru.ryuzaki.module.modules.animation;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

public class ItemPhysicsModule extends Module {
    public static ItemPhysicsModule INSTANCE;

    private final BooleanSetting rotation = new BooleanSetting("Rotation", true);
    private final BooleanSetting bounce = new BooleanSetting("Bounce", true);
    private final NumberSetting rotationSpeed = new NumberSetting("Rotation Speed", 1.0, 0.1, 3.0, 0.1);
    private final NumberSetting bounciness = new NumberSetting("Bounciness", 0.5, 0.0, 1.0, 0.05);

    public ItemPhysicsModule() {super("ItemPhysics", "Realistic item physics", Category.ANIMATION);
                INSTANCE = this;
addSettings(rotation, bounce, rotationSpeed, bounciness);
    }

    public boolean shouldRotate() {
        return isEnabled() && rotation.isEnabled();
    }

    public boolean shouldBounce() {
        return isEnabled() && bounce.isEnabled();
    }

    public float getRotationSpeed() {
        return rotationSpeed.getValue().floatValue();
    }

    public float getBounciness() {
        return bounciness.getValue().floatValue();
    }
}