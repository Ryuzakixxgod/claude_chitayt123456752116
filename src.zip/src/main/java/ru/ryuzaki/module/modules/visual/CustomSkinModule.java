package ru.ryuzaki.module.modules.visual;

import com.mojang.blaze3d.platform.TextureUtil;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

public class CustomSkinModule extends Module {
    public static CustomSkinModule INSTANCE;

    private final ModeSetting skin = new ModeSetting("Skin", "Ryuzaki",
            "Ryuzaki", "Demon_Red", "Demon_White", "Among_Us", "Sonic", "Crab", "Spongebob", "Pikachu"
    );

    private final NumberSetting scale = new NumberSetting("Scale", 1.0, 0.5, 2.0, 0.05);

    private Identifier currentSkinId;
    private String lastSkin = "";

    public static CustomSkinModule get() { return INSTANCE; }

    public CustomSkinModule() {
        super("CustomSkin", "Custom player skins", Category.VISUAL);
        INSTANCE = this;
        addSettings(skin, scale);
    }

    @Override
    public void onEnable() {
        applySkin();
    }

    @Override
    public void onDisable() {
        removeSkin();
    }

    @Override
    public void onUpdate() {
        if (!skin.getSelected().equals(lastSkin)) {
            applySkin();
        }
    }

    private void applySkin() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        removeSkin();

        String skinName = skin.getSelected();
        lastSkin = skinName;

        try {
            NativeImage image = generateSkin(skinName);
            if (image == null) return;

            currentSkinId = Identifier.of("ryuzaki", "customskin_" + skinName.toLowerCase());
            NativeImageBackedTexture texture = new NativeImageBackedTexture(image);

            mc.execute(() -> {
                mc.getTextureManager().registerTexture(currentSkinId, texture);
            });

        } catch (Exception e) {
            System.err.println("[CustomSkin] Error generating skin: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void removeSkin() {
        if (currentSkinId != null) {
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.execute(() -> {
                try {
                    mc.getTextureManager().destroyTexture(currentSkinId);
                } catch (Exception ignored) {}
            });
            currentSkinId = null;
        }
    }

    private NativeImage generateSkin(String type) {
        NativeImage img = new NativeImage(64, 64, true);

        // Заполняем прозрачностью
        for (int x = 0; x < 64; x++) {
            for (int y = 0; y < 64; y++) {
                img.setColorArgb(x, y, 0x00000000);
            }
        }

        switch (type) {
            case "Ryuzaki" -> generateRyuzaki(img);
            case "Demon_Red" -> generateDemon(img, true);
            case "Demon_White" -> generateDemon(img, false);
            case "Among_Us" -> generateAmongUs(img);
            case "Sonic" -> generateSonic(img);
            case "Crab" -> generateCrab(img);
            case "Spongebob" -> generateSpongebob(img);
            case "Pikachu" -> generatePikachu(img);
        }

        return img;
    }

    private void generateRyuzaki(NativeImage img) {
        int skin = rgba(245, 220, 200, 255); // Бледная кожа
        int hair = rgba(20, 20, 20, 255);    // Черные волосы
        int eyes = rgba(60, 60, 80, 255);    // Темные круги
        int shirt = rgba(240, 240, 240, 255); // Белая футболка
        int pants = rgba(100, 100, 120, 255); // Джинсы

        // Голова (8x8x8)
        fillBox(img, 8, 8, 8, 8, skin);   // Лицо
        fillBox(img, 0, 8, 8, 8, hair);   // Правая сторона
        fillBox(img, 16, 8, 8, 8, hair);  // Левая сторона
        fillBox(img, 8, 0, 8, 8, hair);   // Верх
        fillBox(img, 16, 0, 8, 8, hair);  // Низ
        fillBox(img, 24, 8, 8, 8, hair);  // Зад

        // Глаза
        img.setColorArgb(10, 10, rgba(80, 80, 100, 255));
        img.setColorArgb(13, 10, rgba(80, 80, 100, 255));

        // Темные круги под глазами
        img.setColorArgb(10, 11, eyes);
        img.setColorArgb(13, 11, eyes);

        // Торчащие волосы (второй слой)
        fillBox(img, 40, 8, 8, 8, hair);  // Overlay голова

        // Тело
        fillBox(img, 20, 20, 8, 12, shirt);
        fillBox(img, 28, 20, 4, 12, shirt);
        fillBox(img, 16, 20, 4, 12, shirt);

        // Руки
        fillBox(img, 44, 20, 4, 12, skin);  // Правая рука
        fillBox(img, 36, 52, 4, 12, skin);  // Левая рука

        // Ноги
        fillBox(img, 4, 20, 4, 12, pants);  // Правая нога
        fillBox(img, 20, 52, 4, 12, pants); // Левая нога
    }

    private void generateDemon(NativeImage img, boolean isRed) {
        int skin = isRed
                ? rgba(200, 50, 50, 255)    // Красная кожа
                : rgba(230, 230, 240, 255); // Белая кожа
        int horns = rgba(40, 40, 40, 255);
        int eyes = isRed
                ? rgba(255, 200, 0, 255)    // Желтые глаза
                : rgba(255, 100, 100, 255); // Красные глаза
        int clothes = rgba(20, 20, 20, 255);

        // Голова
        fillBox(img, 8, 8, 8, 8, skin);
        fillBox(img, 0, 8, 8, 8, skin);
        fillBox(img, 16, 8, 8, 8, skin);
        fillBox(img, 8, 0, 8, 8, skin);
        fillBox(img, 16, 0, 8, 8, skin);
        fillBox(img, 24, 8, 8, 8, skin);

        // Рога (второй слой)
        img.setColorArgb(40, 8, horns);  // Левый рог
        img.setColorArgb(41, 8, horns);
        img.setColorArgb(41, 7, horns);
        img.setColorArgb(46, 8, horns);  // Правый рог
        img.setColorArgb(47, 8, horns);
        img.setColorArgb(46, 7, horns);

        // Светящиеся глаза
        img.setColorArgb(10, 10, eyes);
        img.setColorArgb(13, 10, eyes);
        img.setColorArgb(10, 11, eyes);
        img.setColorArgb(13, 11, eyes);

        // Тело
        fillBox(img, 20, 20, 8, 12, clothes);
        fillBox(img, 28, 20, 4, 12, clothes);
        fillBox(img, 16, 20, 4, 12, clothes);

        // Руки
        fillBox(img, 44, 20, 4, 12, skin);
        fillBox(img, 36, 52, 4, 12, skin);

        // Ноги
        fillBox(img, 4, 20, 4, 12, clothes);
        fillBox(img, 20, 52, 4, 12, clothes);
    }

    private void generateAmongUs(NativeImage img) {
        int body = rgba(200, 20, 20, 255);  // Красное тело
        int visor = rgba(100, 180, 220, 255); // Голубой визор
        int backpack = rgba(180, 20, 20, 255);

        // Тело круглое (имитация)
        fillBox(img, 8, 8, 8, 8, body);
        fillBox(img, 0, 8, 8, 8, body);
        fillBox(img, 16, 8, 8, 8, body);
        fillBox(img, 24, 8, 8, 8, backpack);

        // Визор
        fillBox(img, 9, 10, 6, 3, visor);

        // Тело
        fillBox(img, 20, 20, 8, 12, body);
        fillBox(img, 28, 20, 4, 12, body);
        fillBox(img, 16, 20, 4, 12, body);

        // Короткие руки
        fillBox(img, 44, 20, 4, 8, body);
        fillBox(img, 36, 52, 4, 8, body);

        // Короткие ноги
        fillBox(img, 4, 20, 4, 8, body);
        fillBox(img, 20, 52, 4, 8, body);
    }

    private void generateSonic(NativeImage img) {
        int blue = rgba(20, 100, 200, 255);
        int skin = rgba(240, 180, 140, 255);
        int shoes = rgba(220, 20, 20, 255);
        int white = rgba(255, 255, 255, 255);

        // Голова синяя
        fillBox(img, 8, 8, 8, 8, blue);
        fillBox(img, 0, 8, 8, 8, blue);
        fillBox(img, 16, 8, 8, 8, blue);
        fillBox(img, 8, 0, 8, 8, blue);
        fillBox(img, 24, 8, 8, 8, blue);

        // Морда (бежевая)
        fillBox(img, 9, 11, 6, 4, skin);

        // Глаза
        img.setColorArgb(10, 10, rgba(0, 0, 0, 255));
        img.setColorArgb(13, 10, rgba(0, 0, 0, 255));

        // Иголки (второй слой)
        for (int i = 0; i < 8; i++) {
            img.setColorArgb(40 + i, 0, blue);
            img.setColorArgb(40 + i, 1, blue);
        }

        // Тело
        fillBox(img, 20, 20, 8, 12, blue);

        // Перчатки
        fillBox(img, 44, 20, 4, 12, white);
        fillBox(img, 36, 52, 4, 12, white);

        // Кроссовки
        fillBox(img, 4, 20, 4, 12, shoes);
        fillBox(img, 20, 52, 4, 12, shoes);

        // Белая полоска на кроссовках
        fillBox(img, 4, 22, 4, 2, white);
        fillBox(img, 20, 54, 4, 2, white);
    }

    private void generateCrab(NativeImage img) {
        int shell = rgba(200, 80, 40, 255);
        int claws = rgba(220, 100, 60, 255);
        int eyes = rgba(0, 0, 0, 255);

        // Панцирь (голова)
        fillBox(img, 8, 8, 8, 8, shell);
        fillBox(img, 0, 8, 8, 8, shell);
        fillBox(img, 16, 8, 8, 8, shell);
        fillBox(img, 8, 0, 8, 8, shell);
        fillBox(img, 24, 8, 8, 8, shell);

        // Глаза на стебельках (второй слой)
        img.setColorArgb(41, 6, shell);
        img.setColorArgb(41, 7, shell);
        img.setColorArgb(41, 8, eyes);

        img.setColorArgb(46, 6, shell);
        img.setColorArgb(46, 7, shell);
        img.setColorArgb(46, 8, eyes);

        // Тело
        fillBox(img, 20, 20, 8, 12, shell);

        // Клешни (руки)
        fillBox(img, 44, 20, 4, 12, claws);
        fillBox(img, 36, 52, 4, 12, claws);

        // Увеличенные клешни
        fillBox(img, 44, 28, 5, 4, claws);
        fillBox(img, 35, 60, 5, 4, claws);

        // Ноги
        fillBox(img, 4, 20, 4, 12, shell);
        fillBox(img, 20, 52, 4, 12, shell);
    }

    private void generateSpongebob(NativeImage img) {
        int yellow = rgba(255, 220, 50, 255);
        int holes = rgba(200, 180, 40, 255);
        int pants = rgba(100, 70, 40, 255);
        int shirt = rgba(255, 255, 255, 255);
        int tie = rgba(200, 20, 20, 255);
        int eyes = rgba(255, 255, 255, 255);
        int pupil = rgba(0, 120, 200, 255);

        // Желтое лицо
        fillBox(img, 8, 8, 8, 8, yellow);
        fillBox(img, 0, 8, 8, 8, yellow);
        fillBox(img, 16, 8, 8, 8, yellow);
        fillBox(img, 8, 0, 8, 8, yellow);
        fillBox(img, 24, 8, 8, 8, yellow);

        // Дырки в губке
        img.setColorArgb(9, 9, holes);
        img.setColorArgb(14, 10, holes);
        img.setColorArgb(11, 13, holes);

        // Большие глаза
        fillBox(img, 9, 9, 2, 3, eyes);
        fillBox(img, 13, 9, 2, 3, eyes);
        img.setColorArgb(9, 10, pupil);
        img.setColorArgb(13, 10, pupil);

        // Белая рубашка
        fillBox(img, 20, 20, 8, 8, shirt);

        // Красный галстук
        fillBox(img, 23, 22, 2, 4, tie);

        // Коричневые штаны
        fillBox(img, 20, 28, 8, 4, pants);

        // Руки желтые
        fillBox(img, 44, 20, 4, 12, yellow);
        fillBox(img, 36, 52, 4, 12, yellow);

        // Ноги желтые
        fillBox(img, 4, 20, 4, 12, yellow);
        fillBox(img, 20, 52, 4, 12, yellow);
    }

    private void generatePikachu(NativeImage img) {
        int yellow = rgba(255, 220, 0, 255);
        int cheeks = rgba(255, 80, 80, 255);
        int ears = rgba(40, 40, 40, 255);
        int tail = rgba(200, 150, 0, 255);

        // Желтая голова
        fillBox(img, 8, 8, 8, 8, yellow);
        fillBox(img, 0, 8, 8, 8, yellow);
        fillBox(img, 16, 8, 8, 8, yellow);
        fillBox(img, 8, 0, 8, 8, yellow);
        fillBox(img, 24, 8, 8, 8, yellow);

        // Уши (второй слой)
        fillBox(img, 40, 4, 2, 4, yellow);
        fillBox(img, 40, 4, 2, 2, ears); // Черные кончики
        fillBox(img, 46, 4, 2, 4, yellow);
        fillBox(img, 46, 4, 2, 2, ears);

        // Щеки
        fillBox(img, 8, 12, 2, 2, cheeks);
        fillBox(img, 14, 12, 2, 2, cheeks);

        // Глаза
        img.setColorArgb(10, 10, rgba(0, 0, 0, 255));
        img.setColorArgb(13, 10, rgba(0, 0, 0, 255));

        // Тело
        fillBox(img, 20, 20, 8, 12, yellow);

        // Руки
        fillBox(img, 44, 20, 4, 12, yellow);
        fillBox(img, 36, 52, 4, 12, yellow);

        // Ноги
        fillBox(img, 4, 20, 4, 12, yellow);
        fillBox(img, 20, 52, 4, 12, yellow);

        // Хвост (на спине)
        fillBox(img, 26, 21, 2, 6, tail);
    }

    private void fillBox(NativeImage img, int x, int y, int w, int h, int color) {
        for (int dx = 0; dx < w; dx++) {
            for (int dy = 0; dy < h; dy++) {
                int px = x + dx;
                int py = y + dy;
                if (px >= 0 && px < 64 && py >= 0 && py < 64) {
                    img.setColorArgb(px, py, color);
                }
            }
        }
    }

    private int rgba(int r, int g, int b, int a) {
        return (a << 24) | (b << 16) | (g << 8) | r;
    }

    /** Alias — getActiveTexture() вызывается из MixinPlayerEntityRenderer */
    public Identifier getActiveTexture() { return getSkinTexture(); }

    public String getSkinName() { return skin.getCurrent(); }

    public Identifier getSkinTexture() {
        return isEnabled() ? currentSkinId : null;
    }

    public float getScale() {
        return isEnabled() ? scale.getValue().floatValue() : 1f;
    }
}