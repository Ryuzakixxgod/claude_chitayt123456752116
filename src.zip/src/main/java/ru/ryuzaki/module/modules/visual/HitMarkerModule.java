package ru.ryuzaki.module.modules.visual;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.RyuzakiRenderCache;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * HitMarker 10/10 — шутерный хит-маркер с реальными дугами.
 * Circle = настоящая окружность через отдельные отрезки, не квадраты.
 */
public class HitMarkerModule extends Module {
    public static HitMarkerModule INSTANCE;
    public final ModeSetting   style    = new ModeSetting("Style","Cross","Cross","Dot","Circle","Star","X","Diamond");
    public final NumberSetting size     = new NumberSetting("Size",    8.0, 3.0, 20.0, 1.0);
    public final NumberSetting duration = new NumberSetting("Duration",8.0, 2.0, 25.0, 1.0);
    public final BooleanSetting kill    = new BooleanSetting("Kill Effect",  true);
    public final BooleanSetting rainbow = new BooleanSetting("Rainbow",      false);
    public final BooleanSetting theme   = new BooleanSetting("Theme Color",  true);

    private static class Mark {
        float life,maxLife; boolean isKill; int[]color;
        Mark(float l,boolean k,int[]c){life=maxLife=l;isKill=k;color=c;}
    }
    private final List<Mark> marks = new ArrayList<>();
    private float hue = 0f;

    public HitMarkerModule(){
        super("HitMarker","✖ хит-маркер как в шутере",Category.VISUAL);
        INSTANCE = this;
        addSettings(style,size,duration,kill,rainbow,theme);
    }

    public void onHit(boolean isKill){
        if(!isEnabled()) return;
        hue=(hue+0.1f)%1f;
        int[]c;
        if(rainbow.isEnabled()) c=hsv(hue,0.9f,1f);
        else if(theme.isEnabled()) c=RyuzakiRenderCache.rgb1;
        else c=isKill?new int[]{255,60,60}:new int[]{255,255,255};
        marks.add(new Mark(duration.getValue().floatValue(),isKill,c));
    }

    public void render(DrawContext ctx,int sw,int sh){
        if(!isEnabled()) return;
        MatrixStack ms=ctx.getMatrices();
        Iterator<Mark>it=marks.iterator();
        while(it.hasNext()){
            Mark m=it.next(); m.life-=1f;
            if(m.life<=0){it.remove();continue;}
            float pct=m.life/m.maxLife;
            float alpha=(float)Math.pow(pct,0.5f);
            float sizeMult=1f+0.35f*(float)Math.sin(pct*Math.PI);
            int sz=(int)(size.getValue()*sizeMult);
            int cx=sw/2,cy=sh/2;
            int a=(int)(225*alpha);
            int r=m.color[0],g=m.color[1],b=m.color[2];

            // Glow
            for(int gl=3;gl>=1;gl--) drawShape(ctx,ms,cx,cy,sz+gl*2,r,g,b,(int)(a*0.12f/gl));
            // Core
            drawShape(ctx,ms,cx,cy,sz,r,g,b,a);

            // Kill burst
            if(m.isKill&&kill.isEnabled()){
                for(int i=0;i<8;i++){
                    double ang=Math.PI*i/4;
                    float kR=sz*1.6f*(1f-pct*.3f);
                    int px=(int)(cx+kR*Math.cos(ang)), py=(int)(cy+kR*Math.sin(ang));
                    int kS=Math.max(1,(int)(2*(pct)));
                    ctx.fill(px-kS,py-kS,px+kS+1,py+kS+1,
                        (Math.max(0,(int)(a*pct))<<24)|(r<<16)|(g<<8)|b);
                }
            }
        }
    }

    private void drawShape(DrawContext ctx,MatrixStack ms,int cx,int cy,int sz,int r,int g,int b,int a){
        if(a<=0) return;
        int t=Math.max(1,(int)(sz*0.13f));
        int col=(Math.max(0,Math.min(255,a))<<24)|(r<<16)|(g<<8)|b;
        switch(style.getCurrent()){
            case "Cross" -> {
                ctx.fill(cx-sz,cy-t,cx-sz/4,cy+t+1,col);
                ctx.fill(cx+sz/4,cy-t,cx+sz+1,cy+t+1,col);
                ctx.fill(cx-t,cy-sz,cx+t+1,cy-sz/4,col);
                ctx.fill(cx-t,cy+sz/4,cx+t+1,cy+sz+1,col);
            }
            case "Dot" -> ctx.fill(cx-t-1,cy-t-1,cx+t+2,cy+t+2,col);
            case "Circle" -> {
                // Real circle via 24 arc segments
                int segs=24;
                for(int i=0;i<segs;i++){
                    double a1=2*Math.PI*i/segs, a2=2*Math.PI*(i+1)/segs;
                    int x1=(int)(cx+sz*Math.cos(a1)), y1=(int)(cy+sz*Math.sin(a1));
                    int x2=(int)(cx+sz*Math.cos(a2)), y2=(int)(cy+sz*Math.sin(a2));
                    drawLine2D(ctx,x1,y1,x2,y2,col,t);
                }
            }
            case "Star" -> {
                for(int i=0;i<6;i++){
                    double ang=Math.PI*i/3;
                    int ex=(int)(cx+sz*Math.cos(ang)), ey=(int)(cy+sz*Math.sin(ang));
                    drawLine2D(ctx,cx,cy,ex,ey,col,t);
                }
            }
            case "X" -> {
                int n=sz; float f=1f;
                for(int i=0;i<=n;i++,f-=1f/n){
                    int aa=(Math.max(0,(int)(a*f))<<24)|(r<<16)|(g<<8)|b;
                    ctx.fill(cx-n+i-t,cy-n+i-t,cx-n+i+t+1,cy-n+i+t+1,aa);
                    ctx.fill(cx+n-i-t,cy-n+i-t,cx+n-i+t+1,cy-n+i+t+1,aa);
                }
            }
            case "Diamond" -> {
                ctx.fill(cx-t,cy-sz,cx+t+1,cy,col);
                ctx.fill(cx-t,cy,cx+t+1,cy+sz+1,col);
                ctx.fill(cx-sz,cy-t,cx,cy+t+1,col);
                ctx.fill(cx,cy-t,cx+sz+1,cy+t+1,col);
            }
        }
    }

    private void drawLine2D(DrawContext ctx,int x1,int y1,int x2,int y2,int col,int t){
        int dx=Math.abs(x2-x1),dy=Math.abs(y2-y1);
        int steps=Math.max(1,Math.max(dx,dy));
        for(int i=0;i<=steps;i++){
            int px=x1+(x2-x1)*i/steps, py=y1+(y2-y1)*i/steps;
            ctx.fill(px-t,py-t,px+t+1,py+t+1,col);
        }
    }

    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
