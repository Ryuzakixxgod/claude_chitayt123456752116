package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/HitFlashModule.java
import net.minecraft.client.gui.DrawContext;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;
import ru.ryuzaki.util.color.ColorRGBA;

public class HitFlashModule extends Module {
    public static HitFlashModule INSTANCE;
    public final NumberSetting  duration  = new NumberSetting("Duration",  10.0, 3.0, 30.0, 1.0);
    public final NumberSetting  maxAlpha  = new NumberSetting("Alpha",     75.0, 10.0, 200.0, 5.0);
    public final ModeSetting    style     = new ModeSetting("Style","Radial","Radial","Full","Edges","Pulse");
    public final BooleanSetting rainbow   = new BooleanSetting("Rainbow",  false);
    public final ColorSetting   color     = new ColorSetting("Color", new ColorRGBA(255,50,50,180));

    private int   flashTicks=0;
    private float currentAlpha=0f;
    private float hue=0f;
    private float lastDmgDir=0f; // направление удара (для Radial)

    public HitFlashModule(){super("HitFlash","Кинематографическая вспышка при уроне",Category.VISUAL);
        INSTANCE = this;addSettings(duration,maxAlpha,style,rainbow,color);}

    public void onHit(float damageDir){
        if(!isEnabled()) return;
        flashTicks=(int)duration.getValue().intValue();
        currentAlpha=maxAlpha.getValue().floatValue();
        lastDmgDir=damageDir;
    }

    public void onTick(){
        if(!isEnabled()||flashTicks<=0){currentAlpha=0;return;}
        flashTicks--;
        // Easing: быстро нарастает, медленно гаснет
        float progress=(float)flashTicks/duration.getValue().floatValue();
        currentAlpha=maxAlpha.getValue().floatValue()*(float)Math.pow(progress,0.7f);
        if(rainbow.isEnabled()) hue=(hue+0.015f)%1f;
    }

    public void render(DrawContext ctx,int sw,int sh){
        if(!isEnabled()||currentAlpha<=1f) return;
        int r,g,b;
        if(rainbow.isEnabled()){int[]c=hsv(hue,0.85f,1f);r=c[0];g=c[1];b=c[2];}
        else{ColorRGBA c=color.getColor();if(c==null)return;r=c.getRed();g=c.getGreen();b=c.getBlue();}
        int a=(int)Math.min(255,currentAlpha);

        switch(style.getCurrent()){
            case"Full"  -> ctx.fill(0,0,sw,sh,rgba(r,g,b,a));
            case"Edges" -> {
                int edgeW=(int)(sw*0.12f);
                for(int i=edgeW;i>=1;i--){float f=(float)i/edgeW;int ea=(int)(a*(1-f*f));ctx.fill(0,0,i,sh,rgba(r,g,b,ea));ctx.fill(sw-i,0,sw,sh,rgba(r,g,b,ea));ctx.fill(i,0,sw-i,i,rgba(r,g,b,ea));ctx.fill(i,sh-i,sw-i,sh,rgba(r,g,b,ea));}
            }
            case"Pulse" -> {
                float pMult=0.5f+0.5f*(float)Math.sin(System.currentTimeMillis()*0.015f);
                ctx.fill(0,0,sw,sh,rgba(r,g,b,(int)(a*pMult)));
            }
            default -> { // Radial — свечение с одной стороны (откуда пришёл удар)
                int radW=(int)(sw*0.2f);
                // Левая сторона
                for(int i=radW;i>=1;i--){float f=(float)i/radW;int ea=(int)(a*(1-f*f)*0.8f);ctx.fill(0,0,i,sh,rgba(r,g,b,ea));}
                // Правая
                for(int i=radW;i>=1;i--){float f=(float)i/radW;int ea=(int)(a*(1-f*f)*0.6f);ctx.fill(sw-i,0,sw,sh,rgba(r,g,b,ea));}
                // Верх
                for(int i=radW/2;i>=1;i--){float f=(float)i/(radW/2);int ea=(int)(a*(1-f*f)*0.5f);ctx.fill(0,0,sw,i,rgba(r,g,b,ea));}
            }
        }
    }

    private static int rgba(int r,int g,int b,int a){a=Math.min(255,a);return((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}
