package ru.ryuzaki.module.modules.combat;

import it.unimi.dsi.fastutil.ints.Int2ObjectMaps;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;
import com.professor.cyberhacks.*;

public final class AutoTotemModule extends Module {

    // HP threshold setting - player chooses when to put totem
    public final NumberSetting минHP = new NumberSetting("Мин HP", 10.0, 1.0, 20.0, 1.0);
    // Delay to avoid anti-cheat detection when walking
    public final NumberSetting задержка = new NumberSetting("Задержка (тики)", 5.0, 0.0, 20.0, 1.0);
    // Only swap when actually taking damage (not just walking)
    public final BooleanSetting толькоПриУроне = new BooleanSetting("Только При Уроне", false);

    private int swapCooldown = 0;
    private boolean wasTakingDamage = false;

    public AutoTotemModule() {
        super("AutoTotem", "Автоматический тотем в офф-хенд", Category.COMBAT);
        addSettings(минHP, задержка, толькоПриУроне);
    }

    @Override
    public void onUpdate() {
        if (!isEnabled() || !MC.inGame()) return;

        var player = MC.player();
        if (player == null) return;

        // Decrease cooldown
        if (swapCooldown > 0) {
            swapCooldown--;
            return;
        }

        // Check if already has totem
        if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            wasTakingDamage = false;
            return;
        }

        // Check HP threshold
        float currentHP = player.getHealth();
        if (currentHP > минHP.getValue()) {
            wasTakingDamage = false;
            return;
        }

        // Anti-cheat bypass: only swap when actually taking damage
        if (толькоПриУроне.isEnabled()) {
            // Check if health is dropping (taking damage)
            // Track previous health
            float maxHP = player.getMaxHealth();
            // Simple check - only swap if HP is below threshold and not full
            if (player.getHealth() > минHP.getValue() + 2.0f) {
                wasTakingDamage = false;
                return;
            }
            // Only swap if we were recently below threshold
            if (!wasTakingDamage && player.getHealth() > минHP.getValue()) {
                wasTakingDamage = true;
                return;
            }
        } else {
            wasTakingDamage = false;
        }

        // Find totem in inventory
        for (int slot = 9; slot < 45; slot++) {
            if (player.getInventory().getStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
                // Send swap packet
                var packet = new ClickSlotC2SPacket(
                    player.currentScreenHandler.syncId,
                    player.currentScreenHandler.getRevision(),
                    slot,
                    40,
                    SlotActionType.SWAP,
                    player.getOffHandStack(),
                    Int2ObjectMaps.emptyMap()
                );

                MC.sendPacket(packet);
                swapCooldown = задержка.getValue().intValue();
                break;
            }
        }
    }

    @Override
    public void onDisable() {
        swapCooldown = 0;
        wasTakingDamage = false;
    }
}