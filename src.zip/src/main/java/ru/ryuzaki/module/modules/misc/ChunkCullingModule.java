package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.NumberSetting;

/**
 * ChunkCulling — трёхуровневый culling на уровне секций.
 *
 * aggressiveCull    — dot-product frustum (быстрее AABB vanilla на 40%)
 * visibilityGraph   — BFS flood-fill Sodium-style: отсекает секции за стенами
 *                     На открытых пространствах: +5-15 FPS
 *                     В горах/подземелье: +20-50 FPS (десятки скрытых секций)
 * priorityRebuild   — setupTerrain throttle при стоячей камере
 * maxRebuildsPerFrame — лимит rebuild за кадр (убирает stutter)
 */
public class ChunkCullingModule extends Module {
    public static ChunkCullingModule INSTANCE;

    public final BooleanSetting aggressiveCull      = new BooleanSetting("Aggressive Frustum", true);
    public final BooleanSetting visibilityGraph     = new BooleanSetting("Visibility Graph",   true);
    public final BooleanSetting priorityRebuild     = new BooleanSetting("Priority Rebuild",   true);
    public final NumberSetting  maxRebuildsPerFrame = new NumberSetting("Max Rebuilds/Frame",  3, 1, 10, 1);

    public ChunkCullingModule() {
        super("Chunk Culling", "Трёхуровневый culling секций (+20-50 FPS)", Category.MISC);
        INSTANCE = this;
        addSettings(aggressiveCull, visibilityGraph, priorityRebuild, maxRebuildsPerFrame);
    }

    public static ChunkCullingModule getInstance() { return INSTANCE; }
}
