package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/EnderBlackHoleModule.java
// Пункт 10: за эндер жемчугом летит чёрная дыра — МАКСИМАЛЬНО красиво

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;
import ru.ryuzaki.settings.ColorSetting;
import ru.ryuzaki.settings.NumberSetting;
import ru.ryuzaki.util.color.ColorRGBA;

import java.util.ArrayList;
import java.util.List;

public class EnderBlackHoleModule extends Module {
    public final NumberSetting  size      = new NumberSetting("Size",       1.0, 0.3, 3.0, 0.1);
    public final NumberSetting  trailLen  = new NumberSetting("Trail",      30.0, 5.0, 80.0, 5.0);
    public final BooleanSetting accretion = new BooleanSetting("Disk",      true);
    public final BooleanSetting jets      = new BooleanSetting("Jets",      true);
    public final BooleanSetting distort   = new BooleanSetting("Distortion",true);
    public final ColorSetting   diskColor = new ColorSetting("Disk Color",  new ColorRGBA(255,140,20,255));

    // Trail points per pearl
    private static class TrailPoint { double x,y,z; long t; TrailPoint(double x,double y,double z,long t){this.x=x;this.y=y;this.z=z;this.t=t;} }
    private final java.util.Map<Integer, List<TrailPoint>> trails = new java.util.HashMap<>();

    public EnderBlackHoleModule(){
        super("EnderBlackHole","Чёрная дыра за эндер жемчугом",Category.VISUAL);
        addSettings(size,trailLen,accretion,jets,distort,diskColor);
    }

    // Вызывается из RyuzakiClient tick
    public void onTick(){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(!isEnabled()||mc.world==null) return;
        long now=System.currentTimeMillis();
        long maxAge=(long)(trailLen.getValue()*50);
        for(Entity e:mc.world.getEntities()){
            if(!(e instanceof EnderPearlEntity)) continue;
            trails.computeIfAbsent(e.getId(),k->new ArrayList<>())
                    .add(new TrailPoint(e.getX(),e.getY(),e.getZ(),now));
        }
        // Удаляем старые точки и мёртвые трейлы
        var it=trails.entrySet().iterator();
        while(it.hasNext()){
            var entry=it.next();
            boolean pearlAlive=false;
            for(Entity check:mc.world.getEntities()){if(check.getId()==entry.getKey()&&check instanceof EnderPearlEntity){pearlAlive=true;break;}}
            entry.getValue().removeIf(p->now-p.t>maxAge);
            if(!pearlAlive&&entry.getValue().isEmpty()) it.remove();
        }
    }

    public void render3D(MatrixStack ms, float td){
        MinecraftClient mc=MinecraftClient.getInstance();
        if(!isEnabled()||mc.world==null||mc.gameRenderer==null) return;
        Vec3d cam=mc.gameRenderer.getCamera().getPos();
        long now=System.currentTimeMillis();
        float phase=(float)((now%3000)/3000.0*Math.PI*2.0);
        float sz=size.getValue().floatValue();
        long maxAge=(long)(trailLen.getValue()*50);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        Tessellator tess=Tessellator.getInstance();

        ms.push();
        ms.translate(-cam.x,-cam.y,-cam.z);
        Matrix4f mat=ms.peek().getPositionMatrix();

        for(Entity e:mc.world.getEntities()){
            if(!(e instanceof EnderPearlEntity pearl)) continue;
            double px=pearl.getX(),py=pearl.getY(),pz=pearl.getZ();
            List<TrailPoint> trail=trails.get(pearl.getId());

            // 1. ТРЕЙЛ — тёмно-фиолетовые кольца по траектории
            if(trail!=null&&trail.size()>1){
                for(int i=0;i<trail.size()-1;i++){
                    TrailPoint tp=trail.get(i);
                    float age=(float)(now-tp.t)/maxAge;
                    float trailA=1f-age;
                    if(trailA<=0) continue;
                    int[]hc=hsv(0.75f+age*0.1f,0.9f,0.8f+trailA*0.2f);
                    int ta=(int)(trailA*180);
                    float tr=sz*0.18f*(1f-age*0.7f);
                    // Кольцо на каждой точке трейла
                    int SEGS=16;
                    BufferBuilder bb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                    for(int s=0;s<=SEGS;s++){
                        double a=2.0*Math.PI*s/SEGS;
                        bb.vertex(mat,(float)(tp.x+tr*Math.cos(a)),(float)tp.y,(float)(tp.z+tr*Math.sin(a))).color(hc[0],hc[1],hc[2],ta);
                    }
                    db(tess,bb);
                    // Glow вокруг кольца
                    for(int gl=3;gl>=1;gl--){
                        float gtr=tr*(1f+gl*0.4f);
                        BufferBuilder gb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                        for(int s=0;s<=12;s++){
                            double a=2.0*Math.PI*s/12;
                            gb.vertex(mat,(float)(tp.x+gtr*Math.cos(a)),(float)tp.y,(float)(tp.z+gtr*Math.sin(a))).color(hc[0],hc[1],hc[2],(int)(ta*0.08f/gl));
                        }
                        db(tess,gb);
                    }
                }
            }

            // 2. ЧЁРНАЯ ДЫРА — заполненная сфера из колец (тёмная)
            // Внешний слой — тёмно-тёмно-фиолетовый полупрозрачный
            int BH_RINGS=20;
            for(int ring=BH_RINGS;ring>=1;ring--){
                double phi=Math.PI*(ring)/(BH_RINGS+1);
                float ry=(float)(py+sz*0.45f*Math.cos(phi));
                float rr=(float)(sz*0.45f*Math.sin(phi));
                float darkness=1f-(float)ring/BH_RINGS;
                int ba=(int)(darkness*darkness*220);
                int[]bc=hsv(0.78f,0.95f,darkness*0.4f);
                BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                for(int s=0;s<=32;s++){
                    double a=2.0*Math.PI*s/32;
                    rb.vertex(mat,(float)(px+rr*Math.cos(a)),ry,(float)(pz+rr*Math.sin(a))).color(bc[0],bc[1],bc[2],ba);
                }
                db(tess,rb);
            }
            // Центр — самый тёмный, почти чёрный с фиолетовым отливом
            for(int gl=8;gl>=1;gl--){
                float gr=sz*0.42f*(float)gl/8;
                float fa=(float)gl/8;
                int ba=(int)((1f-fa)*180);
                int[]bc=hsv(0.76f,0.98f,(1f-fa)*0.3f);
                BufferBuilder fb=tess.begin(VertexFormat.DrawMode.TRIANGLE_FAN,VertexFormats.POSITION_COLOR);
                fb.vertex(mat,(float)px,(float)py,(float)pz).color(0,0,0,200);
                for(int s=0;s<=32;s++){
                    double a=2.0*Math.PI*s/32;
                    fb.vertex(mat,(float)(px+gr*Math.cos(a)),(float)py,(float)(pz+gr*Math.sin(a))).color(bc[0],bc[1],bc[2],ba);
                }
                db(tess,fb);
            }

            // 3. АККРЕЦИОННЫЙ ДИСК — яркое кольцо вокруг экватора
            if(accretion.isEnabled()){
                ColorRGBA dc=diskColor.getColor();
                int dr=dc!=null?dc.getRed():255,dg=dc!=null?dc.getGreen():140,db2=dc!=null?dc.getBlue():20;
                float diskR=sz*0.82f;
                float diskTilt=0.3f; // наклон диска
                float diskPhase=phase*1.4f;
                // Диск — заполненное кольцо с градиентом
                for(int layer=6;layer>=1;layer--){
                    float inner=diskR*0.65f*layer/6f;
                    float outer=diskR*(1f+layer*0.12f);
                    float la=0.25f/layer;
                    BufferBuilder dbb=tess.begin(VertexFormat.DrawMode.TRIANGLE_STRIP,VertexFormats.POSITION_COLOR);
                    for(int s=0;s<=48;s++){
                        double a=diskPhase+2.0*Math.PI*s/48;
                        float bright=0.4f+0.6f*(float)Math.pow(Math.max(0,Math.cos(a-diskPhase*0.5f)),2.0);
                        dbb.vertex(mat,(float)(px+inner*Math.cos(a)),(float)(py+inner*Math.sin(a)*Math.sin(diskTilt)),(float)(pz+inner*Math.sin(a)*Math.cos(diskTilt))).color(dr,dg,db2,(int)(la*bright*255*2f));
                        dbb.vertex(mat,(float)(px+outer*Math.cos(a)),(float)(py+outer*Math.sin(a)*Math.sin(diskTilt)),(float)(pz+outer*Math.sin(a)*Math.cos(diskTilt))).color(dr,dg,db2,0);
                    }
                    db(tess,dbb);
                }
                // Яркий контур диска
                BufferBuilder dc2=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                for(int s=0;s<=64;s++){
                    double a=diskPhase+2.0*Math.PI*s/64;
                    float bright=0.5f+0.5f*(float)Math.sin(phase*4+s*0.3f);
                    dc2.vertex(mat,(float)(px+diskR*Math.cos(a)),(float)(py+diskR*Math.sin(a)*Math.sin(diskTilt)),(float)(pz+diskR*Math.sin(a)*Math.cos(diskTilt))).color(dr,dg,db2,(int)(bright*240));
                }
                db(tess,dc2);
            }

            // 4. ДЖЕТЫ — два луча из полюсов (как у настоящей ЧД)
            if(jets.isEnabled()){
                float jetLen=sz*2.8f;
                float jetPhase=phase*2f;
                for(int dir=-1;dir<=1;dir+=2){
                    // Основной луч
                    for(int gl=4;gl>=1;gl--){
                        float gr=sz*0.08f*gl;
                        BufferBuilder jb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                        float jitter=(float)(gl*0.02f*Math.sin(jetPhase+dir));
                        jb.vertex(mat,(float)px,(float)py,(float)pz).color(255,255,255,(int)(180.0f/gl));
                        jb.vertex(mat,(float)px+jitter,(float)(py+dir*jetLen*0.5f),(float)pz).color(140,100,255,(int)(120.0f/gl));
                        jb.vertex(mat,(float)px,(float)(py+dir*jetLen),(float)pz).color(80,40,180,0);
                        db(tess,jb);
                    }
                    // Пульсирующие кольца вдоль джета
                    for(int ring=1;ring<=6;ring++){
                        float rp=(float)ring/6;
                        float rphase=(jetPhase-rp*3f)%((float)Math.PI*2);
                        float rr2=sz*0.2f*(1f-rp)*Math.abs((float)Math.sin(rphase));
                        if(rr2<0.01f) continue;
                        float ry2=(float)(py+dir*jetLen*rp);
                        int ra=(int)((1f-rp)*160*(0.5f+0.5f*Math.abs((float)Math.sin(rphase))));
                        BufferBuilder rb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                        for(int s=0;s<=20;s++){
                            double a=2.0*Math.PI*s/20;
                            rb.vertex(mat,(float)(px+rr2*Math.cos(a)),ry2,(float)(pz+rr2*Math.sin(a))).color(160,100,255,ra);
                        }
                        db(tess,rb);
                    }
                }
            }

            // 5. ГРАВИТАЦИОННОЕ ИСКАЖЕНИЕ — кольца расширяющихся волн
            if(distort.isEnabled()){
                for(int wave=3;wave>=1;wave--){
                    float wPhase=((phase*0.8f)+(wave*2.1f))%(float)(Math.PI*2);
                    float wR=sz*(0.6f+wave*0.35f+0.25f*(float)Math.sin(wPhase));
                    float wA=0.08f/wave;
                    BufferBuilder wb=tess.begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP,VertexFormats.POSITION_COLOR);
                    for(int s=0;s<=40;s++){
                        double a=2.0*Math.PI*s/40;
                        float jitter2=0.015f*(float)Math.sin(phase*5+s*0.8f);
                        wb.vertex(mat,(float)(px+(wR+jitter2)*Math.cos(a)),(float)py,(float)(pz+(wR+jitter2)*Math.sin(a))).color(120,60,220,(int)(wA*255));
                    }
                    db(tess,wb);
                }
            }
        }

        ms.pop();
        RenderSystem.enableDepthTest();
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static void db(Tessellator t,BufferBuilder b){try{BufferRenderer.drawWithGlobalProgram(b.end());}catch(Exception ignored){}}
    private static int[]hsv(float h,float s,float v){h=h%1f;if(h<0)h+=1f;int i=(int)(h*6);float f=h*6-i,p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);float r,g,b;switch(i%6){case 0->{r=v;g=t;b=p;}case 1->{r=q;g=v;b=p;}case 2->{r=p;g=v;b=t;}case 3->{r=p;g=q;b=v;}case 4->{r=t;g=p;b=v;}default->{r=v;g=p;b=q;}}return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};}
}