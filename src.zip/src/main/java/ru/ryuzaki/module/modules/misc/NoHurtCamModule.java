package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.BooleanSetting;

/**
 * 🚀 No Hurt Cam
 *
 * При каждом получении урона Minecraft крутит камеру (tilt).
 * Это пересчёт матриц + плохо видно в PvP.
 *
 * Подключается через MixinCamera — перехватывает addRoll/tilt.
 *
 * Бонус FPS: небольшой, но стабильный (~0.5-1ms убирает)
 * Бонус геймплей: ОГРОМНЫЙ — видишь противника даже под ударами.
 */
public class NoHurtCamModule extends Module {
    public static NoHurtCamModule INSTANCE;

    public final BooleanSetting noDamageRoll  = new BooleanSetting("No Damage Tilt",   true);
    public final BooleanSetting noPortalSpin  = new BooleanSetting("No Portal Spin",   true);
    public final BooleanSetting noNauseaSpin  = new BooleanSetting("No Nausea Spin",   true);

    public NoHurtCamModule() {
        super("No Hurt Cam", "Remove camera shake on damage (+clarity)", Category.MISC);
        INSTANCE = this;
        addSettings(noDamageRoll, noPortalSpin, noNauseaSpin);
    }

    public static NoHurtCamModule getInstance() { return INSTANCE; }

    // Геттеры используются в MixinCamera
    public static boolean skipDamageRoll()  { return INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.noDamageRoll.isEnabled(); }
    public static boolean skipPortalSpin()  { return INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.noPortalSpin.isEnabled(); }
    public static boolean skipNauseaSpin()  { return INSTANCE != null && INSTANCE.isEnabled() && INSTANCE.noNauseaSpin.isEnabled(); }
}
