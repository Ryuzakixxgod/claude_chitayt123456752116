package ru.ryuzaki.module.modules.misc;

import ru.ryuzaki.gui.style.ThemeManager;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.hud.elements.WatermarkHud;

import java.awt.Color;

public class ThemeModule extends Module {

    private static final String[] THEME_NAMES = {
        "Sakura","Liquid","Emerald","Amethyst","Ruby","Sunset",
        "Ocean","Gold","Midnight","Monochrome","Aurora","Lavender",
        "Coral","Mint","Peach","Galaxy"
    };
    public final ModeSetting theme = new ModeSetting("Theme", "Sunset", THEME_NAMES);

    public ThemeModule() {
        super("Theme", "Цвет акцента клиента", Category.MISC);
        addSettings(theme);
        setEnabled(true);
    }

    @Override
    public void onUpdate() {
        String currentTheme = theme.getCurrent();
        ThemeManager.get().setTheme(currentTheme);

        // Обновляем accent в ThemeManager
        Color accent = ThemeManager.get().getAccent();
        int r = accent.getRed(), g = accent.getGreen(), b = accent.getBlue();

        // Обновляем watermark
        WatermarkHud.setAccentColor(r, g, b);
    }
}
