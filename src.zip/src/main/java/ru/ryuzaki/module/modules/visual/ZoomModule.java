package ru.ryuzaki.module.modules.visual;
// src/main/java/ru/ryuzaki/module/modules/visual/ZoomModule.java
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.*;

public class ZoomModule extends Module {
    public static ZoomModule INSTANCE;
    public final NumberSetting  fovMult    = new NumberSetting("FOV Mult",   0.25, 0.05, 0.90, 0.05);
    public final NumberSetting  smoothIn   = new NumberSetting("Smooth In",  0.08, 0.01, 0.5, 0.01);
    public final NumberSetting  smoothOut  = new NumberSetting("Smooth Out", 0.15, 0.01, 0.5, 0.01);
    public final BooleanSetting cinematic  = new BooleanSetting("Cinematic Mouse",true);
    public final BooleanSetting scrollZoom = new BooleanSetting("Scroll Zoom",    true);

    private boolean zooming  = false;
    private float   currentFov = 1f;
    private float   scrollMult = 1f; // дополнительный множитель от скролла

    public ZoomModule(){
        super("Zoom","Плавное приближение — держи C",Category.VISUAL);
        INSTANCE = this;
        addSettings(fovMult,smoothIn,smoothOut,cinematic,scrollZoom);
    }

    public void onTick(){
        if(!isEnabled()){zooming=false;currentFov=1f;scrollMult=1f;return;}
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.currentScreen!=null){zooming=false;return;}
        zooming=GLFW.glfwGetKey(mc.getWindow().getHandle(),GLFW.GLFW_KEY_C)==GLFW.GLFW_PRESS;
        if(!zooming) scrollMult=lerp(scrollMult,1f,0.1f); // плавно сбрасываем скролл
    }

    // Вызывается из MixinMouse при скролле когда zooming=true
    public void onScroll(double delta){
        if(!isEnabled()||!zooming||!scrollZoom.isEnabled()) return;
        scrollMult=Math.max(0.1f,Math.min(3f,(float)(scrollMult-(delta*0.1))));
    }

    public boolean isZooming(){return zooming;}

    public float getFov(float orig){
        if(!isEnabled()) return orig;
        float target = zooming
            ? orig*fovMult.getValue().floatValue()*scrollMult
            : orig;
        float speed  = zooming
            ? smoothIn.getValue().floatValue()
            : smoothOut.getValue().floatValue();
        currentFov = lerp(currentFov, target, speed);
        return currentFov;
    }

    // Замедление мыши при зуме (cinematic feel)
    public double modifyMouseDelta(double delta){
        if(!isEnabled()||!zooming||!cinematic.isEnabled()) return delta;
        float zoomFactor=currentFov/getFovBase();
        return delta*Math.max(0.1,zoomFactor);
    }

    private float getFovBase(){
        MinecraftClient mc=MinecraftClient.getInstance();
        return mc.options.getFov().getValue().floatValue();
    }
    private static float lerp(float a,float b,float t){return a+(b-a)*t;}
}
