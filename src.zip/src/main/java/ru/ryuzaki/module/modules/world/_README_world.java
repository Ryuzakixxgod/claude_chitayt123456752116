// ════════════════════════════════════════════════════════════════════
//  WORLD MODULES — CustomSky, FogControl, TimeChanger, NoWeather
//  MixinBackgroundRenderer, MixinClientWorld, MixinWeather
// ════════════════════════════════════════════════════════════════════

// ── CustomSkyModule.java ─────────────────────────────────────────────
package ru.ryuzaki.module.modules.world;
// Отдельный файл, но для компактности показываем рядом

/*
CustomSky работает через:
  MixinBackgroundRenderer -> onRenderSkyColor()
  MixinWorldRenderer -> onRenderSky()

Добавь в ryuzaki.mixins.json:
  "MixinBackgroundRenderer",
  "MixinWorldRenderer",
  "MixinClientWorld"
*/
