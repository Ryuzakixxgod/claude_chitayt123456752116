package ru.ryuzaki.module.modules.animation;

import ru.ryuzaki.module.Category;
import ru.ryuzaki.module.Module;
import ru.ryuzaki.settings.ModeSetting;
import ru.ryuzaki.settings.NumberSetting;

public class CapePhysicsModule extends Module {
    public static CapePhysicsModule INSTANCE;

    private final ModeSetting mode = new ModeSetting("Mode", "Smooth", "Smooth", "Realistic", "Wavy");
    private final NumberSetting intensity = new NumberSetting("Intensity", 1.0, 0.1, 2.0, 0.1);

    public CapePhysicsModule() {super("CapePhysics", "Realistic cape movement", Category.ANIMATION);
                INSTANCE = this;
addSettings(mode, intensity);
    }

    public String getMode() {
        return mode.getSelected();
    }

    public float getIntensity() {
        return intensity.getValue().floatValue();
    }
}