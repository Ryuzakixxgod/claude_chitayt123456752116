package ru.ryuzaki.module;

import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;
import ru.ryuzaki.settings.BindSetting;

import java.util.ArrayList;
import java.util.List;

/**
 * BindManager — глобальный обработчик биндов
 *
 * Поддерживает:
 *  • Клавиши клавиатуры (GLFW key codes)
 *  • Кнопки мыши (LMB/RMB/MMB/MB4/MB5)
 *  • Колёсико мыши вверх/вниз ← НОВОЕ
 *
 * Вызывается из миксинов:
 *  • onKeyPress(int glfwKey)
 *  • onMouseButton(int button)
 *  • onMouseScroll(double verticalDelta)  ← НОВОЕ
 */
public class BindManager {

    private static BindSetting listeningBind = null;
    private static final List<Runnable> onBindSet = new ArrayList<>();

    // =======================================================================
    //  LISTEN MODE — GUI нажал "ждём бинд"
    // =======================================================================
    public static void startListening(BindSetting setting) {
        // Сбросить предыдущий
        if (listeningBind != null) listeningBind.stopListening();
        listeningBind = setting;
        setting.startListening();
    }

    public static void stopListening() {
        if (listeningBind != null) {
            listeningBind.stopListening();
            listeningBind = null;
        }
    }

    public static boolean isListening() {
        return listeningBind != null;
    }

    public static BindSetting getListening() {
        return listeningBind;
    }

    // =======================================================================
    //  KEYBOARD — вызвать из MixinClientPlayerInput или EventBus
    // =======================================================================
    public static boolean onKeyPress(int glfwKey, int action) {
        if (action != GLFW.GLFW_PRESS) return false;

        // ESC — отмена прослушивания
        if (isListening() && glfwKey == GLFW.GLFW_KEY_ESCAPE) {
            listeningBind.clearBind();
            notifyBindSet();
            stopListening();
            return true;
        }

        // Запись бинда
        if (isListening()) {
            listeningBind.setKey(glfwKey);
            notifyBindSet();
            stopListening();
            return true;
        }

        // Выполнение биндов
        if (MinecraftClient.getInstance().currentScreen != null) return false;
        for (Module m : ModuleManager.modules) {
            if (m.getBind() != null && m.getBind().getKey() == glfwKey) {
                m.toggle();
            }
        }
        return false;
    }

    // =======================================================================
    //  MOUSE BUTTON — вызвать из MixinMouse
    // =======================================================================
    public static boolean onMouseButton(int button, int action) {
        if (action != GLFW.GLFW_PRESS) return false;

        // Конвертация: button 0 → -1, button 1 → -2, ...
        int bindCode = -(button + 1);

        if (isListening()) {
            listeningBind.setKey(bindCode);
            notifyBindSet();
            stopListening();
            return true;
        }

        if (MinecraftClient.getInstance().currentScreen != null) return false;
        for (Module m : ModuleManager.modules) {
            if (m.getBind() != null && m.getBind().getKey() == bindCode) {
                m.toggle();
            }
        }
        return false;
    }

    // =======================================================================
    //  MOUSE SCROLL — вызвать из MixinMouse.mouseScrolled
    //  verticalDelta > 0 = вверх, < 0 = вниз
    // =======================================================================
    public static boolean onMouseScroll(double verticalDelta) {
        int bindCode = verticalDelta > 0
                ? BindSetting.BIND_MOUSE_WHEEL_UP
                : BindSetting.BIND_MOUSE_WHEEL_DOWN;

        if (isListening()) {
            listeningBind.setKey(bindCode);
            notifyBindSet();
            stopListening();
            return true;
        }

        if (MinecraftClient.getInstance().currentScreen != null) return false;
        for (Module m : ModuleManager.modules) {
            if (m.getBind() != null && m.getBind().getKey() == bindCode) {
                m.toggle();
            }
        }
        return false;
    }

    // =======================================================================
    //  CALLBACK — GUI получает уведомление когда бинд установлен
    // =======================================================================
    public static void addOnBindSet(Runnable r) { onBindSet.add(r); }
    public static void removeOnBindSet(Runnable r) { onBindSet.remove(r); }
    private static void notifyBindSet() { onBindSet.forEach(Runnable::run); }

    // Очистка коллбэков при дисконнекте
    public static void clearCallbacks() { onBindSet.clear(); }
}
