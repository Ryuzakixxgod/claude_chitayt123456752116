package ru.ryuzaki.module;

import ru.ryuzaki.module.modules.combat.AimAssistModule;
import ru.ryuzaki.module.modules.combat.AutoTotemModule;
import ru.ryuzaki.module.modules.combat.KillAuraModule;
import ru.ryuzaki.module.modules.combat.TriggerBotModule;
import ru.ryuzaki.module.modules.combat.VelocityModule;
import ru.ryuzaki.module.modules.combat.AutoClickerModule;
import ru.ryuzaki.module.modules.combat.ReachModule;
import ru.ryuzaki.module.modules.animation.*;
import ru.ryuzaki.module.modules.misc.*;
import ru.ryuzaki.module.modules.particles.*;
import ru.ryuzaki.module.modules.player.FullbrightModule;
import ru.ryuzaki.module.modules.player.SprintModule;
import ru.ryuzaki.module.modules.player.AntiAFKModule;
import ru.ryuzaki.module.modules.player.AutoRespawnModule;
import ru.ryuzaki.module.modules.player.NoFallModule;
import ru.ryuzaki.module.modules.visual.*;
import ru.ryuzaki.module.modules.misc.ThemeModule;
import ru.ryuzaki.module.modules.world.*;
import ru.ryuzaki.module.modules.movement.FlightModule;
import ru.ryuzaki.module.modules.movement.SpeedModule;
import ru.ryuzaki.module.modules.movement.NoSlowModule;
import java.util.*;

public class ModuleManager {
    public static final List<Module> modules = new ArrayList<>();
    private static final Map<Class<? extends Module>, Module> moduleMap = new HashMap<>();

    public static void init() {
        // ── VISUAL ──────────────────────────────────────────────────
        add(new MotionBlurModule());
        add(new BlockOutlineModule());
        add(new TargetESP());
        add(new TrajectoryModule());
        // BloomModule   — УДАЛЁН (#6)
        add(new HitboxModule());
        add(new AspectRatioModule());
        add(new ZoomModule());
        // HitFlashModule   — УДАЛЁН (#6)
        add(new CompassHudModule());
        add(new SpeedLinesModule());
        // PlayerOutlineModule — УДАЛЁН (#6)
        // GlowESPModule       — УДАЛЁН (#6)
        add(new HologramPlayerModule());
        // KillLightningModule — УДАЛЁН (#6)
        add(new CrosshairFXModule());
        add(new GlitchEffectModule());
        add(new ShockwaveModule());
        add(new ScreenEdgeGlowModule());
        add(new SpeedStreaksModule());
        add(new EnderBlackHoleModule());
        add(new CustomSkinModule());
        add(new HatModule());
        add(new CapeModule());
        add(new PetModule());

        // ── ANIMATION ───────────────────────────────────────────────
        add(new SwingModule());
        add(new ItemPhysicsModule());
        add(new CapePhysicsModule());
        add(new SmoothCameraModule());

        // ── PARTICLES ───────────────────────────────────────────────
        add(new TrailModule());
        add(new AuraParticleModule());
        add(new WorldParticleModule());
        add(new JumpParticleModule());
        // KillEffectModule — УДАЛЁН (#14)
        add(new CosmicCritModule());
        add(new AmbientParticleModule());

        // ── WORLD ───────────────────────────────────────────────────
        add(new CustomSkyModule());
        add(new FogControlModule());
        add(new DynamicLightsModule());
        add(new BetterWaterModule());
        add(new NoWeatherModule());
        add(new TimeChangerModule());
        add(new EnviroFXModule());

        // ── MISC ────────────────────────────────────────────────────
        add(new HitSoundModule());
        add(new ChatHighlightModule());
        add(new ArmorAlertModule());
        add(new SmartFPSLimiter());
        add(new NoHurtCamModule());
        add(new StaticFogModule());
        add(new NoBeaconBeamModule());
        add(new TextureLODModule());
        add(new RainbowChatModule());
        add(new NoOverlayModule());
        add(new EntityCullerModule());
        add(new ChunkOptimizerModule());
        add(new SmartLODModule());
        add(new FastMathModule());
        add(new NetworkOptimizerModule());
        add(new SmartCullModule());
        add(new AntiLagModule());
        add(new FPSBoostModule());
        add(new RyuzakiFpsOptimizer());
        add(new MusicPlayerModule());
        add(new CoordSaverModule());
        add(new BlockEntityCullerModule());
        add(new ParticleCullerModule());
        add(new ChunkThreadsModule());
        add(new ChunkCullingModule());
        add(new RenderTweaksModule());
        add(new DrawCallBatcherModule());
        add(new InGameInventoryModule());
        add(new ShaderCompatModule());
        add(new FriendsModule());
        add(new ThemeModule());

        // ── COMBAT ────────────────────────────────────────────────────
        add(new KillAuraModule());
        add(new TriggerBotModule());
        add(new AimAssistModule());
        add(new AutoTotemModule());
        add(new VelocityModule());
        add(new AutoClickerModule());
        add(new ReachModule());

        // ── MOVEMENT ───────────────────────────────────────────────────
        add(new FlightModule());
        add(new SpeedModule());
        add(new NoSlowModule());

        // ── PLAYER ─────────────────────────────────────────────────────
        add(new FullbrightModule());
        add(new SprintModule());
        add(new AntiAFKModule());
        add(new AutoRespawnModule());
        add(new NoFallModule());

        // ── VISUAL доп ──────────────────────────────────────────────
        add(new HitMarkerModule());
        add(new DamageNumbersModule());
        add(new TotemPopCounterModule());
        add(new VisualRangeModule());
        add(new BreadcrumbsModule());

        // Waypoints — всегда включён, не отображается в GUI
        WaypointsModule wp = new WaypointsModule();
        wp.setEnabled(true);
        add(wp);
    }

    private static void add(Module m) {
        modules.add(m);
        moduleMap.put(m.getClass(), m);
    }

    public static List<Module> getModulesByCategory(Category cat) {
        return modules.stream()
                .filter(m -> m.category == cat)
                .filter(m -> !(m instanceof WaypointsModule))
                .toList();
    }

    @SuppressWarnings("unchecked")
    public static <T extends Module> T getModule(Class<T> clazz) {
        return (T) moduleMap.get(clazz);
    }
}
