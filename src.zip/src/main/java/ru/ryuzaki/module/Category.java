package ru.ryuzaki.module;

public enum Category {
    HUD("HUD"),
    VISUAL("Визуал"),
    ANIMATION("Анимация"),
    PARTICLES("Частицы"),
    WORLD("Мир"),
    COMBAT("Бой"),
    PLAYER("Игрок"),
    MOVEMENT("Движение"),
    MISC("Прочее");

    public final String displayName;
    Category(String name) { this.displayName = name; }
}