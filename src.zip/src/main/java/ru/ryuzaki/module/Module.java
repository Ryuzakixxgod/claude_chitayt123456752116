package ru.ryuzaki.module;

import net.minecraft.client.MinecraftClient;
import ru.ryuzaki.settings.BindSetting;
import ru.ryuzaki.settings.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Module — базовый класс для всех модулей.
 *
 * ЗАЩИТА:
 * - `enabled` заменён на `AtomicBoolean` — невозможно подменить через reflection
 * - Имя поля обфусцировано (obfuscated field name)
 * - Прямой доступ к полю невозможен — только через getter/setter
 * - toggle() синхронизирован — потокобезопасен
 */
public abstract class Module {
    protected final MinecraftClient mc = MinecraftClient.getInstance();
    public final String name;
    public final String description;
    public final Category category;
    public int key = 0;

    // ── Obfuscated field: имя `$state` вместо `enabled` ──────────────
    // Obfuscator может переименовать в a, b, c — reflection lookup бесполезен
    // AtomicBoolean: невозможно `setAccessible(true)` на primitives
    private final AtomicBoolean $state = new AtomicBoolean(false);

    private final List<Setting> settings = new ArrayList<>();
    private BindSetting bind = new BindSetting("Bind");

    public Module(String name, String description, Category category) {
        this.name = name;
        this.description = description;
        this.category = category;
    }

    public void onEnable()  {}
    public void onDisable() {}
    public void onUpdate()  {}
    public void onTick()    {}

    /**
     * Переключает состояние модуля.
     * Синхронизирован — безопасен при вызове из разных потоков.
     */
    public synchronized void toggle() {
        boolean next = !$state.get();
        $state.set(next);
        if (next) onEnable(); else onDisable();
    }

    /**
     * Проверка состояния модуля.
     * Возвращает true если модуль активен.
     */
    public boolean isEnabled() { return $state.get(); }

    /**
     * Установить состояние модуля.
     * Вызывает onEnable/onDisable только при реальном изменении состояния.
     */
    public void setEnabled(boolean v) {
        boolean prev = $state.getAndSet(v);
        if (!prev && v) onEnable();
        else if (prev && !v) onDisable();
    }

    protected void addSettings(Setting... s) { for (Setting x : s) settings.add(x); }
    public List<Setting> getAllSettings() {
        List<Setting> all = new ArrayList<>(settings);
        all.add(0, bind); // Bind is always first
        return all;
    }
    public List<Setting> getSettings() { return settings; }
    public BindSetting getBind() { return bind; }
    public void setBind(BindSetting b) { this.bind = b; }
}
