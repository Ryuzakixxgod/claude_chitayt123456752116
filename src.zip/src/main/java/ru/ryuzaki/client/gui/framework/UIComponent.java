package ru.ryuzaki.client.gui.framework;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec4f;

import java.util.ArrayList;
import java.util.List;

/** Base class for all custom UI components. */
public abstract class UIComponent {
    protected float x, y, width, height;
    protected UIComponent parent;
    protected final List<UIComponent> children = new ArrayList<>();
    protected boolean hovered = false;
    protected boolean focused = false;

    public UIComponent(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public void setParent(UIComponent parent) {
        this.parent = parent;
    }

    public void addChild(UIComponent child) {
        child.setParent(this);
        this.children.add(child);
    }

    public List<UIComponent> getChildren() {
        return children;
    }

    public boolean contains(double mx, double my) {
        return mx >= x && my >= y && mx < x + width && my < y + height;
    }

    public void mouseMove(double mx, double my) {
        boolean now = contains(mx, my);
        if (now != hovered) {
            hovered = now;
            onHoverChanged(now);
        }
        for (UIComponent child : children) {
            child.mouseMove(mx - x, my - y);
        }
    }

    public void mouseClick(double mx, double my, int button) {
        if (contains(mx, my)) {
            onClick(mx - x, my - y, button);
            for (UIComponent child : children) {
                child.mouseClick(mx - x, my - y, button);
            }
        }
    }

    public void keyPress(int keyCode, int scanCode, int modifiers) {
        // propagate to focused child if needed
        for (UIComponent child : children) {
            child.keyPress(keyCode, scanCode, modifiers);
        }
    }

    public void render(DrawContext ctx, float delta) {
        ctx.getMatrices().push();
        ctx.getMatrices().translate(x, y, 0);
        renderSelf(ctx, delta);
        for (UIComponent child : children) {
            child.render(ctx, delta);
        }
        ctx.getMatrices().pop();
    }

    protected abstract void renderSelf(DrawContext ctx, float delta);

    protected void onHoverChanged(boolean hovered) {}
    protected void onClick(double mx, double my, int button) {}
}
