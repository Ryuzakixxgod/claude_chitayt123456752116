package ru.ryuzaki.client.gui.framework;

import net.minecraft.client.gui.DrawContext;
import java.util.ArrayList;
import java.util.List;

/** Simple linear layout for demo purposes. */
public class UILayout extends UIComponent {
    public enum Orientation { HORIZONTAL, VERTICAL }
    private final Orientation orientation;
    private final float padding;

    public UILayout(float x, float y, float width, float height, Orientation orientation, float padding) {
        super(x, y, width, height);
        this.orientation = orientation;
        this.padding = padding;
    }

    @Override
    protected void renderSelf(DrawContext ctx, float delta) {
        // No background for layout itself
    }

    @Override
    public void addChild(UIComponent child) {
        super.addChild(child);
        layoutChildren();
    }

    private void layoutChildren() {
        float offset = padding;
        for (UIComponent child : children) {
            if (orientation == Orientation.HORIZONTAL) {
                child.x = offset;
                child.y = padding;
                offset += child.width + padding;
            } else {
                child.x = padding;
                child.y = offset;
                offset += child.height + padding;
            }
        }
    }
}
