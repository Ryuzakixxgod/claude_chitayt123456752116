package ru.ryuzaki.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import ru.ryuzaki.gui.MusicPlayerScreen;
import ru.ryuzaki.module.ModuleManager;
import ru.ryuzaki.module.modules.misc.MusicPlayerModule;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public final class ClientStats {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");
    private static Method fpsMethod;
    private static boolean fpsMethodChecked;

    private ClientStats() {
    }

    public static String username(MinecraftClient client) {
        if (client == null || client.getSession() == null) {
            return "Player";
        }
        String name = client.getSession().getUsername();
        return name == null || name.isBlank() ? "Player" : name;
    }

    public static int fps(MinecraftClient client) {
        try {
            if (!fpsMethodChecked) {
                fpsMethodChecked = true;
                fpsMethod = MinecraftClient.class.getDeclaredMethod("getCurrentFps");
                fpsMethod.setAccessible(true);
            }
            if (fpsMethod != null) {
                Object value = Modifier.isStatic(fpsMethod.getModifiers()) ? fpsMethod.invoke(null) : fpsMethod.invoke(client);
                if (value instanceof Number number) {
                    return Math.max(0, number.intValue());
                }
            }
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            fpsMethod = null;
        }
        return 0;
    }

    public static int ping(MinecraftClient client) {
        if (client == null || client.player == null || client.getNetworkHandler() == null) {
            return 0;
        }
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        return entry == null ? 0 : Math.max(0, entry.getLatency());
    }

    public static String time() {
        return LocalTime.now().format(TIME);
    }

    public static MusicInfo music() {
        MusicPlayerModule module = ModuleManager.getModule(MusicPlayerModule.class);
        if (module != null && module.isEnabled() && module.hasMedia()) {
            String title = clean(module.getTrackTitle(), "System media");
            String subtitle = clean(module.getArtistName(), module.isPlayingTrack() ? "Playing" : "Paused");
            String source = clean(module.getSourceName(), "");
            if (!source.isBlank()) {
                subtitle = subtitle.isBlank() ? source : subtitle + " / " + source;
            }
            return new MusicInfo(title, subtitle, module.isPlayingTrack() ? 0.65F : 0.0F, module.isPlayingTrack());
        }

        if (MusicPlayerScreen.hasActiveTrack()) {
            return new MusicInfo(
                clean(MusicPlayerScreen.currentTrackName(), "Music Player"),
                clean(MusicPlayerScreen.currentTrackStatus(), "Idle"),
                MusicPlayerScreen.currentProgress(),
                MusicPlayerScreen.isAudioPlaying()
            );
        }

        return new MusicInfo("No media playing", "Idle", 0.0F, false);
    }

    private static String clean(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.strip();
    }

    public record MusicInfo(String title, String subtitle, float progress, boolean playing) {
    }
}
