package ru.ryuzaki.client;

import net.minecraft.util.Identifier;

public final class RelicClient {
    public static final String MOD_ID = "ryuzaki";
    public static final Identifier RELIC_FONT = Identifier.of(MOD_ID, "relic");

    private RelicClient() {}
}
