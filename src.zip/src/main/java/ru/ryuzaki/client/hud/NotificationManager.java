package ru.ryuzaki.client.hud;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class NotificationManager {
    private static final List<Notification> NOTIFICATIONS = new ArrayList<>();

    private NotificationManager() {
    }

    public static void push(String text, int ticks) {
        NOTIFICATIONS.add(new Notification(text, Math.max(20, ticks)));
    }

    public static void tick() {
        Iterator<Notification> iterator = NOTIFICATIONS.iterator();
        while (iterator.hasNext()) {
            Notification notification = iterator.next();
            notification.ticksLeft--;
            if (notification.ticksLeft <= 0) {
                iterator.remove();
            }
        }
    }

    public static List<Notification> active() {
        return List.copyOf(NOTIFICATIONS);
    }

    public static final class Notification {
        private final String text;
        private int ticksLeft;

        private Notification(String text, int ticksLeft) {
            this.text = text;
            this.ticksLeft = ticksLeft;
        }

        public String text() {
            return text;
        }

        public int ticksLeft() {
            return ticksLeft;
        }
    }
}
