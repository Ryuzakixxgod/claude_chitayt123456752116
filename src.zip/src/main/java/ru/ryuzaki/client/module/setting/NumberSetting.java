package ru.ryuzaki.client.module.setting;

import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;

public final class NumberSetting extends Setting {
    private final double min;
    private final double max;
    private final double step;
    private final DoubleSupplier getter;
    private final DoubleConsumer setter;
    private double value;

    public NumberSetting(String name, double value, double min, double max, double step) {
        this(name, value, min, max, step, null, null);
    }

    public NumberSetting(String name, double value, double min, double max, double step,
                         DoubleSupplier getter, DoubleConsumer setter) {
        super(name);
        this.min = min;
        this.max = max;
        this.step = step;
        this.getter = getter;
        this.setter = setter;
        setValue(value);
    }

    public double min() {
        return min;
    }

    public double max() {
        return max;
    }

    public double value() {
        return getter != null ? getter.getAsDouble() : value;
    }

    public void setValue(double value) {
        double clamped = Math.max(min, Math.min(max, value));
        if (step > 0.0D) {
            clamped = Math.round(clamped / step) * step;
        }
        this.value = Math.max(min, Math.min(max, clamped));
        if (setter != null) {
            setter.accept(this.value);
        }
    }

    public String display() {
        double shown = value();
        if (Math.abs(shown - Math.round(shown)) < 0.0001D) {
            return String.valueOf((int) Math.round(shown));
        }
        return String.format(java.util.Locale.ROOT, "%.2f", shown).replace('.', ',');
    }
}
