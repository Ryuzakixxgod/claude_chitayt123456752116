package ru.ryuzaki.client.module;

public enum ModuleCategory {
    HUD("HUD", "H"),
    RENDER("Render", "R"),
    PLAYER("Player", "P"),
    THEMES("Themes", "T"),
    CONFIGS("Configs", "C"),
    WAYPOINTS("Waypoints", "W");

    private final String title;
    private final String icon;

    ModuleCategory(String title, String icon) {
        this.title = title;
        this.icon = icon;
    }

    public String title() {
        return title;
    }

    public String icon() {
        return icon;
    }
}
