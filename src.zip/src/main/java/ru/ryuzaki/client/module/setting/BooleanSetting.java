package ru.ryuzaki.client.module.setting;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public final class BooleanSetting extends Setting {
    private final BooleanSupplier getter;
    private final Consumer<Boolean> setter;
    private boolean enabled;

    public BooleanSetting(String name, boolean enabled) {
        this(name, enabled, null, null);
    }

    public BooleanSetting(String name, boolean enabled, BooleanSupplier getter, Consumer<Boolean> setter) {
        super(name);
        this.enabled = enabled;
        this.getter = getter;
        this.setter = setter;
    }

    public boolean enabled() {
        return getter != null ? getter.getAsBoolean() : enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
        if (setter != null) {
            setter.accept(enabled);
        }
    }

    public void toggle() {
        setEnabled(!enabled());
    }
}
