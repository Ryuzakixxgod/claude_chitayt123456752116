package ru.ryuzaki.client.module.setting;

import java.util.Arrays;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

public final class ModeSetting extends Setting {
    private final List<String> modes;
    private final Supplier<String> getter;
    private final Consumer<String> setter;
    private String value;

    public ModeSetting(String name, String value, String... modes) {
        this(name, value, null, null, modes);
    }

    public ModeSetting(String name, String value, Supplier<String> getter, Consumer<String> setter, String... modes) {
        super(name);
        this.modes = Arrays.asList(modes);
        this.getter = getter;
        this.setter = setter;
        this.value = this.modes.contains(value) ? value : this.modes.getFirst();
    }

    public List<String> modes() {
        return modes;
    }

    public String value() {
        if (getter == null) return value;
        String current = getter.get();
        return modes.contains(current) ? current : value;
    }

    public void setValue(String value) {
        if (modes.contains(value)) {
            this.value = value;
            if (setter != null) {
                setter.accept(value);
            }
        }
    }
}
