package ru.ryuzaki.client.module;

import ru.ryuzaki.client.module.setting.BooleanSetting;
import ru.ryuzaki.client.module.setting.ModeSetting;
import ru.ryuzaki.client.module.setting.NumberSetting;
import ru.ryuzaki.module.ModuleManager;

import java.util.ArrayList;
import java.util.List;

public final class ModuleRegistry {
    private ModuleRegistry() {
    }

    public static List<Module> createDefaults() {
        List<Module> modules = new ArrayList<>();

        ru.ryuzaki.module.modules.visual.TrajectoryModule trajectory = trajectory();
        Module projectile = bound(
                "ProjectilePrediction",
                "Shows the trajectory of the projectiles",
                ModuleCategory.RENDER,
                trajectory
        );
        if (trajectory != null) {
            projectile.setting(mode("Style", trajectory.style))
                .setting(bool("Glow", trajectory.showGlow))
                .setting(bool("Landing", trajectory.showLand))
                .setting(bool("Dot Trail", trajectory.showDot))
                .setting(number("Width", trajectory.lineWidth));
        }
        modules.add(projectile);

        ru.ryuzaki.module.modules.misc.NoOverlayModule noOverlay = noOverlay();
        Module noRender = bound(
                "NoRender",
                "Hides the elements you don't need.",
                ModuleCategory.RENDER,
                noOverlay
        );
        if (noOverlay != null) {
            noRender.setting(bool("Fire", noOverlay.noFire))
                .setting(bool("Totem", noOverlay.noTotem))
                .setting(bool("Portal", noOverlay.noPortal))
                .setting(bool("Pumpkin", noOverlay.noPumpkin))
                .setting(bool("Snow", noOverlay.noSnow))
                .setting(bool("Water", noOverlay.noWater));
        }
        modules.add(noRender);

        ru.ryuzaki.module.modules.visual.HatModule hat = hat();
        Module chinaHat = bound(
                "ChinaHat",
                "A Chinese hat over your head",
                ModuleCategory.RENDER,
                hat
        );
        if (hat != null) {
            chinaHat.setting(mode("Style", hat.style));
        }
        modules.add(chinaHat);

        ru.ryuzaki.module.modules.visual.HitboxModule hitboxes = hitboxes();
        Module customBoxes = bound(
                "CustomBoxes",
                "Displays players' hitboxes with shading",
                ModuleCategory.RENDER,
                hitboxes
        );
        if (hitboxes != null) {
            customBoxes.setting(mode("Target", hitboxes.target))
                .setting(mode("Style", hitboxes.style))
                .setting(bool("Filled", hitboxes.filled))
                .setting(bool("Head Box", hitboxes.headBox))
                .setting(bool("Eye Ray", hitboxes.eyeLine))
                .setting(number("Alpha", hitboxes.alpha));
        }
        modules.add(customBoxes);

        ru.ryuzaki.module.modules.world.TimeChangerModule timeChanger = timeChanger();
        Module worldTime = bound(
                "WorldTime",
                "Changes the time of day visually",
                ModuleCategory.RENDER,
                timeChanger
        );
        if (timeChanger != null) {
            worldTime.setting(timeMode())
                .setting(bool("Freeze Time", timeChanger.freeze));
        }
        modules.add(worldTime);

        modules.add(bound(
                "BetterThemes",
                "Animated pulsing gradients for themes",
                ModuleCategory.RENDER,
                ModuleManager.getModule(ru.ryuzaki.module.modules.misc.ThemeModule.class)
        ));

        ru.ryuzaki.module.modules.particles.JumpParticleModule jumpParticle = jumpParticle();
        Module jumpCircle = bound(
                "JumpCircle",
                "Custom circles when jumping",
                ModuleCategory.RENDER,
                jumpParticle
        );
        if (jumpParticle != null) {
            jumpCircle.setting(mode("Style", jumpParticle.style))
                .setting(bool("Rainbow", jumpParticle.rainbow))
                .setting(bool("Text", jumpParticle.showText))
                .setting(bool("Sparks", jumpParticle.sparks))
                .setting(bool("Multi Ring", jumpParticle.multiRing))
                .setting(number("Max Size", jumpParticle.maxSize))
                .setting(number("Lifetime", jumpParticle.lifetime));
        }
        modules.add(jumpCircle);

        return modules;
    }

    private static Module bound(String name, String description, ModuleCategory category,
                                ru.ryuzaki.module.Module real) {
        if (real == null) {
            return new Module(name, description, category, false, () -> false, ignored -> {});
        }
        return new Module(name, description, category, real.isEnabled(), real::isEnabled, real::setEnabled);
    }

    private static BooleanSetting bool(String name, ru.ryuzaki.settings.BooleanSetting real) {
        return new BooleanSetting(name, real.isEnabled(), real::isEnabled, real::setValue);
    }

    private static NumberSetting number(String name, ru.ryuzaki.settings.NumberSetting real) {
        return new NumberSetting(name, real.getValue(), real.getMin(), real.getMax(), real.getStep(),
            () -> real.getValue(), real::setValue);
    }

    private static ModeSetting mode(String name, ru.ryuzaki.settings.ModeSetting real) {
        return new ModeSetting(name, real.getCurrent(), real::getCurrent, real::setCurrent, real.getModes());
    }

    private static ModeSetting timeMode() {
        ru.ryuzaki.module.modules.world.TimeChangerModule mod = timeChanger();
        return new ModeSetting("Time", timeName(mod.time.getValue()), () -> timeName(mod.time.getValue()), value -> {
            double time = switch (value) {
                case "Day" -> 1000.0;
                case "Noon" -> 6000.0;
                case "Evening" -> 12000.0;
                case "Night" -> 18000.0;
                default -> mod.time.getValue();
            };
            mod.time.setValue(time);
        }, "Day", "Noon", "Evening", "Night");
    }

    private static String timeName(double time) {
        if (time < 3500.0) return "Day";
        if (time < 9000.0) return "Noon";
        if (time < 15000.0) return "Evening";
        return "Night";
    }

    private static ru.ryuzaki.module.modules.visual.TrajectoryModule trajectory() {
        return ModuleManager.getModule(ru.ryuzaki.module.modules.visual.TrajectoryModule.class);
    }

    private static ru.ryuzaki.module.modules.misc.NoOverlayModule noOverlay() {
        return ModuleManager.getModule(ru.ryuzaki.module.modules.misc.NoOverlayModule.class);
    }

    private static ru.ryuzaki.module.modules.visual.HatModule hat() {
        return ModuleManager.getModule(ru.ryuzaki.module.modules.visual.HatModule.class);
    }

    private static ru.ryuzaki.module.modules.visual.HitboxModule hitboxes() {
        return ModuleManager.getModule(ru.ryuzaki.module.modules.visual.HitboxModule.class);
    }

    private static ru.ryuzaki.module.modules.world.TimeChangerModule timeChanger() {
        return ModuleManager.getModule(ru.ryuzaki.module.modules.world.TimeChangerModule.class);
    }

    private static ru.ryuzaki.module.modules.particles.JumpParticleModule jumpParticle() {
        return ModuleManager.getModule(ru.ryuzaki.module.modules.particles.JumpParticleModule.class);
    }
}
