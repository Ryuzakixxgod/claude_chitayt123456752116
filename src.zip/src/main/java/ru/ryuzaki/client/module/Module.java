package ru.ryuzaki.client.module;

import ru.ryuzaki.client.hud.NotificationManager;
import ru.ryuzaki.client.module.setting.Setting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public final class Module {
    private final String name;
    private final String description;
    private final ModuleCategory category;
    private final List<Setting> settings = new ArrayList<>();
    private final BooleanSupplier enabledGetter;
    private final Consumer<Boolean> enabledSetter;
    private boolean enabled;

    public Module(String name, String description, ModuleCategory category, boolean enabled) {
        this(name, description, category, enabled, null, null);
    }

    public Module(String name, String description, ModuleCategory category, boolean enabled,
                  BooleanSupplier enabledGetter, Consumer<Boolean> enabledSetter) {
        this.name = name;
        this.description = description;
        this.category = category;
        this.enabled = enabled;
        this.enabledGetter = enabledGetter;
        this.enabledSetter = enabledSetter;
    }

    public Module setting(Setting setting) {
        settings.add(setting);
        return this;
    }

    public String name() {
        return name;
    }

    public String description() {
        return description;
    }

    public ModuleCategory category() {
        return category;
    }

    public List<Setting> settings() {
        return settings;
    }

    public boolean enabled() {
        return enabledGetter != null ? enabledGetter.getAsBoolean() : enabled;
    }

    public void setEnabled(boolean enabled) {
        boolean previous = enabled();
        this.enabled = enabled;
        if (enabledSetter != null) {
            enabledSetter.accept(enabled);
        }
        boolean current = enabled();
        if (previous != current) {
            NotificationManager.push(name + (current ? " enabled" : " disabled"), 100);
        }
    }

    public void toggle() {
        setEnabled(!enabled());
    }
}
