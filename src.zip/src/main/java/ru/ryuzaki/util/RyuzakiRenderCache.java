package ru.ryuzaki.util;

import net.minecraft.client.MinecraftClient;

/**
 * RyuzakiRenderCache — глобальный кэш, обновляется ОДИН раз в начале кадра.
 * Все модули и миксины читают отсюда — ноль повторных вычислений.
 */
public final class RyuzakiRenderCache {
    private RyuzakiRenderCache() {}

    // ── Время ─────────────────────────────────────────────────────────
    public static long    now        = System.currentTimeMillis();
    public static float   hue        = 0f;
    public static float   hue2       = 0f;
    public static float   sinPhase   = 0f;
    public static float   pulseA     = 1f;
    public static float   deltaTime  = 0.016f;

    // ── Цвета темы ────────────────────────────────────────────────────
    public static int[]   rgb1       = {140, 60, 255};
    public static int[]   rgb2       = {60, 200, 255};
    public static int     colorTheme  = 0xFFAA55FF;
    public static int     colorTheme2 = 0xFF55AAFF;
    public static int     colorBg     = 0xD7050310;
    public static int     colorBgLight= 0x80050310;
    public static int     colorLine   = 0x3CFFFFFF;
    public static int     colorText   = 0xFFEEEEFF;
    public static int     colorSubtext= 0xFF667788;

    // ── Экран ─────────────────────────────────────────────────────────
    public static int     screenW    = 1920;
    public static int     screenH    = 1080;
    public static float   guiScale   = 2f;
    public static boolean isInGame   = false;

    // ── Кэш камеры ────────────────────────────────────────────────────
    public static double  camLookX   = 0.0;
    public static double  camLookY   = 0.0;
    public static double  camLookZ   = 1.0;
    public static double  camPosX    = 0.0;
    public static double  camPosY    = 0.0;
    public static double  camPosZ    = 0.0;
    public static double  cosFovHalf = 0.0;
    public static float   camYaw     = 0f;
    public static float   camPitch   = 0f;

    // ── FOV кэш — используется в SmartCull и любом модуле ────────────
    // Обновляется один раз за кадр, а не пересчитывается в каждом вызове
    public static double  fovDeg           = 90.0;
    public static double  fovRad           = Math.PI / 2.0;
    public static double  screenWOverFovRad = 1920.0 / (Math.PI / 2.0); // sw / fovRad

    // ── Внутреннее ────────────────────────────────────────────────────
    private static long lastNow    = -1;
    private static int  frameCount = 0;

    public static boolean has3DVisuals() { return true; }

    public static void update() {
        // Не обновляем если мир уже уничтожен (дисконнект)
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null || mc.world == null) return;

        long newNow = System.currentTimeMillis();
        if (lastNow > 0) deltaTime = Math.min((newNow - lastNow) / 1000f, 0.1f);
        lastNow = newNow;
        now     = newNow;
        frameCount++;

        ru.ryuzaki.render.GlStateCache.resetFrame();

        sinPhase = (float) Math.sin(now * 0.003);
        pulseA   = 0.75f + 0.25f * Math.abs(sinPhase);

        // Цвет темы — раз в 6 кадров
        if (frameCount % 6 == 0) {
            java.awt.Color accent = ru.ryuzaki.gui.style.ThemeManager.get().getAccent();
            rgb1[0] = accent.getRed(); rgb1[1] = accent.getGreen(); rgb1[2] = accent.getBlue();
            hue  = java.awt.Color.RGBtoHSB(accent.getRed(), accent.getGreen(), accent.getBlue(), null)[0];
            hue2 = (hue + 0.12f) % 1f;
            int[] tmp = hsv(hue2, 0.70f, 1f);
            rgb2[0] = tmp[0]; rgb2[1] = tmp[1]; rgb2[2] = tmp[2];
            colorTheme  = rgba(rgb1[0], rgb1[1], rgb1[2], 255);
            colorTheme2 = rgba(rgb2[0], rgb2[1], rgb2[2], 255);
        }

        if (mc.getWindow() != null) {
            screenW  = mc.getWindow().getScaledWidth();
            screenH  = mc.getWindow().getScaledHeight();
            guiScale = (float) mc.getWindow().getScaleFactor();
        }
        isInGame = mc.world != null && mc.player != null;

        if (mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
            var cam = mc.gameRenderer.getCamera();
            camYaw   = cam.getYaw();
            camPitch = cam.getPitch();

            float yawRad   = (float) Math.toRadians(camYaw);
            float pitchRad = (float) Math.toRadians(camPitch);
            float cosPitch = (float) Math.cos(pitchRad);

            camLookX = -Math.sin(yawRad) * cosPitch;
            camLookY = -Math.sin(pitchRad);
            camLookZ =  Math.cos(yawRad) * cosPitch;

            var camPos = cam.getPos();
            camPosX = camPos.x;
            camPosY = camPos.y;
            camPosZ = camPos.z;

            // FOV кэш — один Math.toRadians за кадр вместо одного на каждую сущность
            fovDeg = mc.options != null ? mc.options.getFov().getValue() : 90.0;
            fovRad = Math.toRadians(fovDeg);
            cosFovHalf = Math.cos(Math.toRadians(fovDeg / 2.0 + 15.0));
            screenWOverFovRad = screenW / fovRad; // кэшируем деление
        }
    }

    // ── Утилиты ───────────────────────────────────────────────────────

    public static int rgba(int r, int g, int b, int a) {
        return ((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF);
    }

    public static void hsvFill(float h, float s, float v, int[] out) {
        h = h % 1f; if (h < 0) h += 1f;
        int i = (int)(h * 6);
        float f = h*6-i, p = v*(1-s), q = v*(1-f*s), t = v*(1-(1-f)*s);
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r=v; g=t; b=p; } case 1 -> { r=q; g=v; b=p; }
            case 2 -> { r=p; g=v; b=t; } case 3 -> { r=p; g=q; b=v; }
            case 4 -> { r=t; g=p; b=v; } default -> { r=v; g=p; b=q; }
        }
        out[0]=(int)(r*255); out[1]=(int)(g*255); out[2]=(int)(b*255);
    }

    public static int[] hsv(float h, float s, float v) {
        h = h % 1f; if (h < 0) h += 1f;
        int i = (int)(h * 6);
        float f = h*6-i, p = v*(1-s), q = v*(1-f*s), t = v*(1-(1-f)*s);
        float r, g, b;
        switch (i % 6) {
            case 0 -> { r=v; g=t; b=p; } case 1 -> { r=q; g=v; b=p; }
            case 2 -> { r=p; g=v; b=t; } case 3 -> { r=p; g=q; b=v; }
            case 4 -> { r=t; g=p; b=v; } default -> { r=v; g=p; b=q; }
        }
        return new int[]{(int)(r*255),(int)(g*255),(int)(b*255)};
    }

    public static int rainbowAt(float position, int alpha) {
        int[] c = hsv((hue + position * 0.2f) % 1f, 0.75f, 1f);
        return rgba(c[0], c[1], c[2], alpha);
    }

    public static float lerp(float current, float target, float speed) {
        return current + (target - current) * Math.min(1f, speed * deltaTime * 60f);
    }

    public static boolean isInFrustum(double wx, double wy, double wz) {
        double dx = wx - camPosX, dy = wy - camPosY, dz = wz - camPosZ;
        double distSq = dx*dx + dy*dy + dz*dz;
        if (distSq < 64.0) return true;
        double dist = Math.sqrt(distSq);
        double dot  = (dx * camLookX + dy * camLookY + dz * camLookZ) / dist;
        return dot >= cosFovHalf;
    }

    public static double camDistSq(double wx, double wy, double wz) {
        double dx=wx-camPosX, dy=wy-camPosY, dz=wz-camPosZ;
        return dx*dx + dy*dy + dz*dz;
    }

    public static int getFrameCount() { return frameCount; }
}
