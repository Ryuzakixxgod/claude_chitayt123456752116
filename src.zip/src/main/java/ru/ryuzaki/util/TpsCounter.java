package ru.ryuzaki.util;

/**
 * TpsCounter — реальный расчёт TPS сервера через WorldTimeUpdateS2CPacket.
 * Вызывается из MixinClientPlayNetworkHandler при получении пакета времени.
 * Логика аналогична TPSCalc из Minced/Plintus.
 */
public final class TpsCounter {
    private TpsCounter() {}

    private static float  tps       = 20f;
    private static long   lastNano  = -1;
    private static float  smoothed  = 20f;

    /** Вызвать при каждом WorldTimeUpdateS2CPacket */
    public static void onWorldTimePacket() {
        long now = System.nanoTime();
        if (lastNano > 0) {
            long delay = now - lastNano;
            float raw = 20f * (1_000_000_000f / delay);
            tps = Math.max(0f, Math.min(20f, raw));
            // Экспоненциальное сглаживание
            smoothed = smoothed * 0.85f + tps * 0.15f;
        }
        lastNano = now;
    }

    /** Возвращает сглаженное TPS (0.0 – 20.0) */
    public static float getTps() {
        return Math.round(smoothed * 10f) / 10f;
    }

    public static void reset() { lastNano = -1; smoothed = 20f; tps = 20f; }
}
