package ru.ryuzaki.util.animation;

public class Animation {
    private final long duration;
    private float value;
    private Easing easing;
    private long startTime;
    private boolean running;
    private float target;

    public Animation(long duration, float startValue, Easing easing) {
        this.duration = duration; this.value = startValue;
        this.easing = easing; this.target = startValue;
    }

    public void update(boolean run) {
        if (run && !running) { startTime = System.currentTimeMillis(); running = true; target = 1f; }
        else if (!run && running) { startTime = System.currentTimeMillis(); running = false; target = 0f; }

        if (value != target) {
            float progress = Math.min(1f, (float)(System.currentTimeMillis()-startTime)/duration);
            float eased = easing.apply(progress);
            value = run ? eased : 1f - eased;
            if (progress >= 1f) value = target;
        }
    }

    // Для прямого обновления (moving, markerRotation)
    public void update(float newValue) { this.value = newValue; }

    public float getValue() { return value; }
    public void setEasing(Easing e) { this.easing = e; }
}
