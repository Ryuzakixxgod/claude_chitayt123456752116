package ru.ryuzaki.util.animation;

public enum Easing {
    LINEAR {
        public float apply(float t) { return t; }
    },
    BOTH_CUBIC {
        public float apply(float t) {
            return t < 0.5f ? 4*t*t*t : 1 - (float)Math.pow(-2*t+2, 3)/2;
        }
    },
    FIGMA_EASE_IN_OUT {
        public float apply(float t) {
            return t < 0.5f ? 2*t*t : 1 - (float)Math.pow(-2*t+2, 2)/2;
        }
    },
    EASE_IN {
        public float apply(float t) { return t * t * t; }
    },
    EASE_OUT {
        public float apply(float t) { return 1 - (float)Math.pow(1 - t, 3); }
    };

    public abstract float apply(float t);
}