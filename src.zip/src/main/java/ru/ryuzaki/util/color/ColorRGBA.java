package ru.ryuzaki.util.color;

import java.awt.Color;

public class ColorRGBA {
    private final int r, g, b, a;

    public ColorRGBA(int r, int g, int b, int a) {
        this.r = clamp(r); this.g = clamp(g); this.b = clamp(b); this.a = clamp(a);
    }
    public ColorRGBA(int r, int g, int b) { this(r, g, b, 255); }
    public ColorRGBA(Color c) { this(c.getRed(), c.getGreen(), c.getBlue(), c.getAlpha()); }

    public int getRed()   { return r; }
    public int getGreen() { return g; }
    public int getBlue()  { return b; }
    public int getAlpha() { return a; }

    // ARGB int для vertex.color(int)
    public int getRGB() { return ((a&0xFF)<<24)|((r&0xFF)<<16)|((g&0xFF)<<8)|(b&0xFF); }

    // withAlpha(int) — абсолютное значение 0..255
    public ColorRGBA withAlpha(int newAlpha) { return new ColorRGBA(r, g, b, clamp(newAlpha)); }

    // withAlpha(float) — если > 1.0 то абсолютное (0..255), иначе множитель (0..1)
    public ColorRGBA withAlpha(float v) {
        return v > 1.0f ? new ColorRGBA(r, g, b, clamp((int)v)) : new ColorRGBA(r, g, b, clamp((int)(v*255)));
    }

    public ColorRGBA mix(ColorRGBA o, float t) {
        t = Math.max(0,Math.min(1,t));
        return new ColorRGBA((int)(r+(o.r-r)*t),(int)(g+(o.g-g)*t),(int)(b+(o.b-b)*t),(int)(a+(o.a-a)*t));
    }

    public Color toAWT() { return new Color(r, g, b, a); }
    private static int clamp(int v) { return Math.max(0, Math.min(255, v)); }
}
