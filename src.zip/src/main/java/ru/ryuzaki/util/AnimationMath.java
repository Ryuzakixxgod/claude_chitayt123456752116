package ru.ryuzaki.util;
import java.awt.Color;
public class AnimationMath {
    public static float fast(float current, float target, float speed) {
        float d = target - current;
        return Math.abs(d) < 0.01f ? target : current + d * speed * 0.1f;
    }
    public static float lerp(float a, float b, float t) { return a + (b - a) * t; }
}