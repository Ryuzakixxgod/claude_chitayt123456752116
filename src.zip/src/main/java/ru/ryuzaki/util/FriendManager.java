package ru.ryuzaki.util;
// src/main/java/ru/ryuzaki/util/FriendManager.java
import java.util.*;

public class FriendManager {
    private static final Set<String> friends = new HashSet<>();
    public static void add(String nick)    { friends.add(nick.toLowerCase()); }
    public static void remove(String nick) { friends.remove(nick.toLowerCase()); }
    public static boolean isFriend(String nick) { return friends.contains(nick.toLowerCase()); }
    public static Set<String> getFriends() { return Collections.unmodifiableSet(friends); }
}