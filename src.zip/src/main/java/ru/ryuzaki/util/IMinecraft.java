package ru.ryuzaki.util;

import net.minecraft.client.MinecraftClient;

public interface IMinecraft {
    MinecraftClient mc = MinecraftClient.getInstance();

    static boolean nullCheck() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return mc == null || mc.player == null || mc.world == null;
    }
}
