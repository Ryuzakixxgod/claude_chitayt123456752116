package ru.ryuzaki.util;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;

import java.awt.Color;

/**
 * RenderUtils — shared 2D/3D rendering helpers.
 *
 * Previously drawRoundedRect was named "rounded" but just called ctx.fill().
 * Now properly rounds corners using the circle approximation algorithm.
 */
public final class RenderUtils {

    private RenderUtils() {}

    // ════════════════════════════════════════════════════════════════
    //  2D — DrawContext-based helpers
    // ════════════════════════════════════════════════════════════════

    /**
     * Filled rectangle — plain, no rounding.
     * x,y = top-left; w,h = size.
     */
    public static void drawRect(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x, y, x + w, y + h, color);
    }

    /**
     * Filled rectangle with properly rounded corners.
     * Uses circle-segment approximation — same as ModernClickGuiV3.fillRound.
     * Previously this method existed but just called ctx.fill() — that was a bug.
     *
     * @param ctx   DrawContext
     * @param x,y   top-left position
     * @param w,h   dimensions
     * @param color ARGB
     * @param r     corner radius in pixels
     */
    /**
     * Float-coordinate overload used by GUI components that store float positions.
     * Arg order: ctx, x, y, w, h, r, color  (r before color — matches component call sites)
     */
    public static void drawRoundedRect(DrawContext ctx, float x, float y, float w, float h, int r, int color) {
        drawRoundedRect(ctx, (int)x, (int)y, (int)w, (int)h, color, r);
    }

    /** Canonical int version. Arg order: ctx, x, y, w, h, color, r */
    public static void drawRoundedRect(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        int x2 = x + w, y2 = y + h;
        r = Math.min(r, Math.min(w / 2, h / 2));
        if (r <= 0) { ctx.fill(x, y, x2, y2, color); return; }

        // Centre column
        ctx.fill(x + r, y,     x2 - r, y2,     color);
        // Left column
        ctx.fill(x,     y + r, x + r,  y2 - r, color);
        // Right column
        ctx.fill(x2 - r,y + r, x2,     y2 - r, color);

        // Rounded corners
        for (int i = 0; i < r; i++) {
            int w2 = r - (int)Math.round(Math.sqrt(Math.max(0.0, (double)r*r - (double)(r-1-i)*(r-1-i))));
            ctx.fill(x  + w2,  y  + i,     x  + r,  y  + i + 1, color); // TL
            ctx.fill(x2 - r,   y  + i,     x2 - w2, y  + i + 1, color); // TR
            ctx.fill(x  + w2,  y2 - i - 1, x  + r,  y2 - i,     color); // BL
            ctx.fill(x2 - r,   y2 - i - 1, x2 - w2, y2 - i,     color); // BR
        }
    }

    /**
     * 1-pixel border of a rounded rectangle.
     */
    public static void drawRoundedBorder(DrawContext ctx, int x, int y, int w, int h, int color, int r) {
        int x2 = x + w, y2 = y + h;
        r = Math.min(r, Math.min(w / 2, h / 2));

        ctx.fill(x + r,  y,      x2 - r, y + 1,  color); // top
        ctx.fill(x + r,  y2 - 1, x2 - r, y2,     color); // bottom
        ctx.fill(x,      y + r,  x + 1,  y2 - r, color); // left
        ctx.fill(x2 - 1, y + r,  x2,     y2 - r, color); // right

        for (int i = 0; i < r; i++) {
            int w2 = r - (int)Math.round(Math.sqrt(Math.max(0.0, (double)r*r - (double)(r-1-i)*(r-1-i))));
            ctx.fill(x  + w2,     y  + i,     x  + w2 + 1, y  + i + 1, color);
            ctx.fill(x2 - w2 - 1, y  + i,     x2 - w2,     y  + i + 1, color);
            ctx.fill(x  + w2,     y2 - i - 1, x  + w2 + 1, y2 - i,     color);
            ctx.fill(x2 - w2 - 1, y2 - i - 1, x2 - w2,     y2 - i,     color);
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  2D — MatrixStack-based (for use outside DrawContext)
    // ════════════════════════════════════════════════════════════════

    /**
     * Filled rectangle via direct GL — works outside a DrawContext render phase.
     */
    public static void fillRect(MatrixStack ms, float x1, float y1, float x2, float y2, int color) {
        Matrix4f m = ms.peek().getPositionMatrix();
        float a = ((color >> 24) & 0xFF) / 255f;
        float r = ((color >> 16) & 0xFF) / 255f;
        float g = ((color >>  8) & 0xFF) / 255f;
        float b =  (color        & 0xFF) / 255f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder buf = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buf.vertex(m, x1, y2, 0).color(r, g, b, a);
        buf.vertex(m, x2, y2, 0).color(r, g, b, a);
        buf.vertex(m, x2, y1, 0).color(r, g, b, a);
        buf.vertex(m, x1, y1, 0).color(r, g, b, a);
        BufferRenderer.drawWithGlobalProgram(buf.end());
        RenderSystem.disableBlend();
    }

    // ════════════════════════════════════════════════════════════════
    //  COLOUR UTILITIES
    // ════════════════════════════════════════════════════════════════

    /** Pack RGBA components into an ARGB int. */
    public static int rgba(int r, int g, int b, int a) {
        return ((a & 0xFF) << 24) | ((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF);
    }

    /**
     * Animated rainbow colour.
     * @param offset per-element phase offset to stagger colours
     */
    public static int rainbow(float offset) {
        return Color.HSBtoRGB((System.currentTimeMillis() % 10000L) / 10000f + offset, 0.8f, 1f);
    }
}
