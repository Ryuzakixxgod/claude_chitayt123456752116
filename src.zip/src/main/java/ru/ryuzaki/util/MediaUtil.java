package ru.ryuzaki.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.List;
import java.util.concurrent.*;

/**
 * MediaUtil — читает системный медиаплеер.
 * Использует рефлексию для mediatransport4j (compile-time зависимость не нужна).
 * Fallback на PowerShell SMTC если нативная библиотека недоступна.
 */
public final class MediaUtil {

    public static class TrackInfo {
        public final String title;
        public final String artist;

        public TrackInfo(String t, String a) {
            this.title  = clean(t);
            this.artist = clean(a);
        }

        private static String clean(String s) {
            if (s == null) return "";
            // Фильтр COM-мусора от .NET
            if (s.contains("ComObject") || s.contains("__Com")
                || s.contains("GetAwaiter") || s.contains("GetResult")) return "";
            return s.trim();
        }

        public boolean isEmpty() { return title.isEmpty() && artist.isEmpty(); }

        public String display() {
            if (artist.isEmpty()) return title;
            if (title.isEmpty())  return artist;
            return title + " - " + artist;
        }
    }

    private static volatile TrackInfo  current = null;
    private static volatile Identifier artId   = null;
    private static volatile boolean    playing = false;
    private static volatile boolean    inited  = false;
    private static String lastHash = "";

    // Кэшируем reflection методы
    private static Method  mGetSessions = null;
    private static Method  mGetTitle    = null;
    private static Method  mGetArtist   = null;
    private static Method  mHasThumb    = null;
    private static Method  mGetThumb    = null;
    private static boolean reflReady    = false;
    private static boolean reflFailed   = false;

    private static final ScheduledExecutorService exec =
        Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "RyuzakiMedia");
            t.setDaemon(true);
            return t;
        });

    public static void init() {
        if (inited) return;
        inited = true;
        exec.scheduleAtFixedRate(MediaUtil::poll, 0, 500, TimeUnit.MILLISECONDS);
    }

    private static void initReflection() {
        if (reflReady || reflFailed) return;
        try {
            Class<?> transport = Class.forName("by.bonenaut7.mediatransport4j.api.MediaTransport");
            Class<?> session   = Class.forName("by.bonenaut7.mediatransport4j.api.MediaSession");
            // MediaTransport.init() — нужно вызвать один раз
            try { transport.getMethod("init").invoke(null); } catch (Exception ignored) {}
            mGetSessions = transport.getMethod("getMediaSessions");
            mGetTitle    = session.getMethod("getTitle");
            mGetArtist   = session.getMethod("getArtist");
            mHasThumb    = session.getMethod("hasThumbnail");
            mGetThumb    = session.getMethod("getThumbnail");
            reflReady = true;
        } catch (Throwable e) {
            reflFailed = true;
        }
    }

    private static void poll() {
        initReflection();
        if (reflReady) {
            pollNative();
        } else {
            pollPS();
        }
    }

    @SuppressWarnings("unchecked")
    private static void pollNative() {
        try {
            List<?> sessions = (List<?>) mGetSessions.invoke(null);
            if (sessions == null || sessions.isEmpty()) {
                current = null; playing = false; return;
            }
            Object s = sessions.get(0);
            String title  = str(mGetTitle.invoke(s));
            String artist = str(mGetArtist.invoke(s));
            TrackInfo info = new TrackInfo(title, artist);
            current = info.isEmpty() ? null : info;
            playing = current != null;

            boolean hasThumb = (boolean) mHasThumb.invoke(s);
            if (hasThumb) {
                ByteBuffer buf = (ByteBuffer) mGetThumb.invoke(s);
                if (buf != null) {
                    String h = hash(buf);
                    if (!h.isEmpty() && !h.equals(lastHash)) {
                        lastHash = h;
                        loadArt(buf, h);
                    }
                }
            }
        } catch (Exception e) {
            current = null; playing = false;
        }
    }

    private static String str(Object o) {
        if (o == null) return "";
        String s = o.toString();
        if (s.contains("Com") || s.contains("__") || s.contains("Await")) return "";
        return s;
    }

    private static void pollPS() {
        try {
            Process proc = new ProcessBuilder("powershell.exe", "-NonInteractive", "-NoProfile", "-Command",
                "$s=[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager," +
                "Windows.Media.Control,ContentType=WindowsRuntime]::RequestAsync()" +
                ".GetAwaiter().GetResult().GetCurrentSession();" +
                "if($s){$p=$s.TryGetMediaPropertiesAsync().GetAwaiter().GetResult();" +
                "Write-Output ($p.Title+'|'+$p.Artist)}else{Write-Output 'NONE'}")
                .redirectErrorStream(true).start();
            String out;
            try (BufferedReader br = new BufferedReader(new InputStreamReader(proc.getInputStream()))) {
                out = br.readLine();
            }
            proc.waitFor(2, TimeUnit.SECONDS);
            proc.destroyForcibly();
            if (out == null || out.equals("NONE") || out.isBlank()) {
                current = null; playing = false; return;
            }
            String[] p = out.split("\\|", -1);
            TrackInfo info = new TrackInfo(p.length > 0 ? p[0] : "", p.length > 1 ? p[1] : "");
            current = info.isEmpty() ? null : info;
            playing = current != null;
        } catch (Exception e) {
            current = null; playing = false;
        }
    }

    private static void loadArt(ByteBuffer buf, String hash) {
        try {
            byte[] bytes = new byte[buf.remaining()];
            buf.get(bytes); buf.rewind();
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
            if (img == null) return;
            MinecraftClient.getInstance().execute(() -> {
                try {
                    // Удаляем старую текстуру перед регистрацией новой
                    if (artId != null) {
                        MinecraftClient.getInstance().getTextureManager().destroyTexture(artId);
                    }
                    NativeImage ni = new NativeImage(NativeImage.Format.RGBA, img.getWidth(), img.getHeight(), false);
                    try {
                        for (int y = 0; y < img.getHeight(); y++)
                            for (int x = 0; x < img.getWidth(); x++) {
                                int argb = img.getRGB(x, y);
                                int a=(argb>>24)&0xFF,r=(argb>>16)&0xFF,g=(argb>>8)&0xFF,b=argb&0xFF;
                                ni.setColorArgb(x, y, (a<<24)|(b<<16)|(g<<8)|r);
                            }
                        Identifier id = Identifier.of("ryuzaki", "art_" + hash.substring(0, 8));
                        MinecraftClient.getInstance().getTextureManager()
                            .registerTexture(id, new NativeImageBackedTexture(ni));
                        artId = id;
                    } finally {
                        ni.close();
                    }
                } catch (Exception e) {
                    System.err.println("[Ryuzaki] Art load error: " + e.getMessage());
                }
            });
        } catch (Exception e) {
            System.err.println("[Ryuzaki] Art decode error: " + e.getMessage());
        }
    }

    private static String hash(ByteBuffer buf) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] b = new byte[Math.min(buf.remaining(), 512)];
            buf.get(b); buf.rewind();
            md.update(b);
            return HexFormat.of().formatHex(md.digest());
        } catch (Exception e) { return ""; }
    }

    public static TrackInfo  getCurrent() { return current; }
    public static boolean    isPlaying()  { return playing && current != null; }
    public static Identifier getArtId()   { return artId; }
    public static void       shutdown()   { exec.shutdownNow(); }
}
