package ru.ryuzaki.util;
// src/main/java/ru/ryuzaki/util/BezierAnimation.java
// AnimationCore — движок анимаций на кривых Безье

public class BezierAnimation {

    // ── Предустановленные кривые Безье ────────────────────────────────
    // Кубическая кривая через 4 контрольные точки P0=(0,0), P1, P2, P3=(1,1)

    /** Ease In Out — плавный разгон и торможение */
    public static float easeInOut(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return bezierCubic(t, 0.42f, 0f, 0.58f, 1f);
    }

    /** Ease Out — быстрый старт, плавное торможение */
    public static float easeOut(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return bezierCubic(t, 0f, 0f, 0.58f, 1f);
    }

    /** Ease In — плавный старт, быстрое окончание */
    public static float easeIn(float t) {
        t = Math.max(0f, Math.min(1f, t));
        return bezierCubic(t, 0.42f, 0f, 1f, 1f);
    }

    /** Spring — упругий отскок */
    public static float spring(float t) {
        t = Math.max(0f, Math.min(1f, t));
        float f = t * t * t - t * (float)Math.sin(t * Math.PI);
        return Math.max(0f, Math.min(1f, f * 1.2f + t * 0.3f));
    }

    /** Кубическая кривая Безье — численный метод */
    private static float bezierCubic(float t, float x1, float y1, float x2, float y2) {
        // Находим параметр через итерации Ньютона
        float u = t;
        for (int i = 0; i < 8; i++) {
            float x = cubicBezier(u, 0, x1, x2, 1) - t;
            float dx = cubicBezierDeriv(u, 0, x1, x2, 1);
            if (Math.abs(dx) < 1e-6f) break;
            u -= x / dx;
            u = Math.max(0f, Math.min(1f, u));
        }
        return cubicBezier(u, 0, y1, y2, 1);
    }

    private static float cubicBezier(float t, float p0, float p1, float p2, float p3) {
        float it = 1 - t;
        return it*it*it*p0 + 3*it*it*t*p1 + 3*it*t*t*p2 + t*t*t*p3;
    }

    private static float cubicBezierDeriv(float t, float p0, float p1, float p2, float p3) {
        float it = 1 - t;
        return 3*it*it*(p1-p0) + 6*it*t*(p2-p1) + 3*t*t*(p3-p2);
    }

    // ── Анимированное значение ─────────────────────────────────────────
    public static class AnimatedFloat {
        private float current;
        private float target;
        private float duration; // секунды
        private long  startMs;
        private float startVal;
        private int   type; // 0=easeInOut, 1=easeOut, 2=easeIn, 3=spring

        public AnimatedFloat(float initial) {
            this.current = initial;
            this.target  = initial;
            this.startVal = initial;
            this.duration = 0.25f;
        }

        public AnimatedFloat(float initial, float durationSec) {
            this(initial);
            this.duration = durationSec;
        }

        public void setTarget(float t) {
            if (Math.abs(t - target) < 0.001f) return;
            startVal = current;
            startMs  = System.currentTimeMillis();
            target   = t;
        }

        public float get() {
            if (Math.abs(current - target) < 0.001f) { current = target; return current; }
            float elapsed = (System.currentTimeMillis() - startMs) / 1000f;
            float progress = Math.min(1f, elapsed / Math.max(0.001f, duration));
            float eased = switch (type) {
                case 1  -> easeOut(progress);
                case 2  -> easeIn(progress);
                case 3  -> spring(progress);
                default -> easeInOut(progress);
            };
            current = startVal + (target - startVal) * eased;
            return current;
        }

        public boolean isDone() { return Math.abs(current - target) < 0.001f; }
        public void setType(int t) { this.type = t; }
        public void snap(float v) { current = target = v; }
    }
}
