package ru.ryuzaki.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

public class IntroSoundHelper {
    private static boolean played = false;

    public static void tryPlay(MinecraftClient mc) {
        if (played || mc.player == null) return;
        played = true;
        try {
            Identifier id = Identifier.of("ryuzaki", "intro");
            SoundEvent event = net.minecraft.registry.Registries.SOUND_EVENT.get(id);
            if (event == null) {
                System.err.println("[Ryuzaki] Sound 'ryuzaki:intro' not found in registry.");
                return;
            }
            mc.getSoundManager().play(PositionedSoundInstance.master(event, 1.0f, 1.0f));
        } catch (Exception e) {
            System.err.println("[Ryuzaki] Intro sound error: " + e.getMessage());
        }
    }

    public static void reset() { played = false; }
}