package ru.ryuzaki.util;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
public class TargetManager {
    private static TargetManager instance;
    private LivingEntity target;
    private TargetManager() {}
    public static TargetManager getInstance() { if(instance==null) instance=new TargetManager(); return instance; }
    public Entity getCurrentTarget() { return target; }
    public LivingEntity getTarget() { return target; }
    public void setTarget(LivingEntity t) { this.target=t; }
    public void updateTarget() {
        MinecraftClient mc=MinecraftClient.getInstance();
        if(mc.player==null||mc.world==null){target=null;return;}
        LivingEntity closest=null; double dist=Double.MAX_VALUE;
        for(Entity e:mc.world.getEntities()) {
            if(!(e instanceof LivingEntity l)||e==mc.player||!l.isAlive()) continue;
            double d=mc.player.distanceTo(e);
            if(d<6.0&&d<dist){closest=l;dist=d;}
        }
        target=closest;
    }
}