package ru.ryuzaki.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;

public final class Render2D {

    private static DrawContext cachedContext;
    private static boolean overlayActive = false;

    public static void beginOverlay(DrawContext context) {
        cachedContext = context;
        overlayActive = true;
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
    }

    public static void endOverlay() {
        overlayActive = false;
    }

    public static void rect(float x, float y, float w, float h, int color, float radius) {
        if (!overlayActive) return;
        // Use DrawContext fill for simple rectangles
        cachedContext.fill(RenderLayer.getGuiOverlay(), (int)x, (int)y, (int)(x + w), (int)(y + h), color);
    }

    public static void gradientRect(float x, float y, float w, float h, int[] colors, float radius) {
        if (!overlayActive || colors.length < 4) return;
        // For gradient, draw two overlapping rects
        int topColor = colors[0];
        int bottomColor = colors[2];
        cachedContext.fill(RenderLayer.getGuiOverlay(), (int)x, (int)y, (int)(x + w), (int)(y + h / 2), topColor);
        cachedContext.fill(RenderLayer.getGuiOverlay(), (int)x, (int)(y + h / 2), (int)(x + w), (int)(y + h), bottomColor);
    }
}
