package ru.ryuzaki.util;

/**
 * Vec3RingBuffer — circular buffer из xyz float без GC.
 * Вместо List<Vec3d> с add/remove(0) = O(n) + allocation каждый тик.
 * Здесь: push = O(1), zero allocation, cache-friendly layout.
 */
public final class Vec3RingBuffer {
    private final float[] data; // [x,y,z] × capacity
    private final int capacity;
    private int head = 0; // индекс следующей записи
    private int size = 0;

    public Vec3RingBuffer(int capacity) {
        this.capacity = capacity;
        this.data = new float[capacity * 3];
    }

    /** Добавить точку (O1, ноль allocation) */
    public void push(double x, double y, double z) {
        int i = head * 3;
        data[i]   = (float)x;
        data[i+1] = (float)y;
        data[i+2] = (float)z;
        head = (head + 1) % capacity;
        if (size < capacity) size++;
    }

    /** Получить точку от головы (0=последняя добавленная) */
    public float getX(int idx) { return data[ri(idx) * 3]; }
    public float getY(int idx) { return data[ri(idx) * 3 + 1]; }
    public float getZ(int idx) { return data[ri(idx) * 3 + 2]; }

    private int ri(int idx) { return (head - 1 - idx + capacity * 2) % capacity; }

    public int size()  { return size; }
    public void clear(){ head=0; size=0; }
    public boolean isEmpty() { return size == 0; }
}
